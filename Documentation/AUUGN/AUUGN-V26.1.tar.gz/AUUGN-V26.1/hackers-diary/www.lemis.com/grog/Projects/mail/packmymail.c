/*
 * Save a mail file
 *
 * $Id: packmymail.c,v 1.1 2005/01/24 22:56:03 grog Exp $
 */
#ifdef __linux__
#define _GNU_SOURCE					    /* for O_DIRECT */
#endif

#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <unistd.h>
#define XFER 131072
char fudge [27];					    /* to stuff up alignment */
char buf [XFER + 1024];
int main (int argc, char *argv [])
{
  char command [256];
  
  char *me = getlogin ();
  int now = time (NULL);

  sprintf (command, "mv /var/mail/%s /var/mail/%s.%d\n",
	   me,
	   me,
	   now );
  if (system (command))					    /* can't execute? */
    {
    fprintf  (stderr,
	      "Couldn't rename  /var/mail/%s /var/mail/%s.%d, probably permission error\n",
	      me,
	      me,
	      now );
    printf ("none");
    return 1;
    }

  sprintf (command, "gzip /var/mail/%s.%d\n",
	   me,
	   now );
  if (system (command))					    /* can't execute? */
    {
    perror ("Couldn't rename file");
    printf ("none");
    return 1;
    }

  printf ("/var/mail/%s.%d.gz", me, now);
  return 0;
  }
