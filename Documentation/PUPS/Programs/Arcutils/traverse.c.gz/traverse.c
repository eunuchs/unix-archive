#include <stdio.h>

#define BLKSIZ	512

/*
 * Definition of the unix super block.
 * The root super block is allocated and
 * read in iinit/alloc.c. Subsequently
 * a super block is allocated and read
 * with each mount (smount/sys3.c) and
 * released with unmount (sumount/sys3.c).
 * A disk block is ripped off for storage.
 * See alloc.c for general alloc/free
 * routines for free list and I list.
 */

struct	filsys {
	short	s_isize;	/* size in blocks of I list */
	short	s_fsize;	/* size in blocks of entire volume */
	short	s_nfree;	/* number of in core free blocks */
	short	s_free[100];	/* in core free blocks */
	short	s_ninode;	/* number of in core I nodes */
	short	s_inode[100];	/* in core free I nodes */
	char	s_flock;	/* lock during free list manipulation */
	char	s_ilock;	/* lock during I list manipulation */
	char	s_fmod;		/* super block modified flag */
	char	s_ronly;	/* mounted read-only flag */
	short	s_time[2];	/* current date of last update */
	short	pad[48];
};

/*
 * Inode structure as it appears on
 * the disk. Not used by the system,
 * but by things like check, df, dump.
 */
struct	inode {
	unsigned short	i_mode;
	char	i_nlink;
	char	i_uid;
	char	i_gid;
	char	i_size0;
	unsigned short i_size1;
	short	i_addr[8];
	short	i_atime[2];
	short	i_mtime[2];
};

/* modes */
#define		IALLOC	0100000
#define		IFMT	 060000
#define		IFDIR	 040000
#define		IFCHR	 020000
#define		IFREG	 000000
#define		IFBLK	 060000
#define		ILARG	 010000
#define		ISUID	  04000
#define		ISGID	  02000
#define		ISVTX	  01000
#define		IREAD	   0400
#define		IWRITE	   0200
#define		IEXEC	   0100

#define	INOPB	16

#ifndef	DIRSIZ
#define	DIRSIZ	14
#endif

struct	direct {		/* structure of directory entry */
	short	d_ino;		/* inode number */
	char	d_name[DIRSIZ];	/* file name */
};

int bnum ;
FILE * fd ;
struct filsys super ;
struct inode * ilist ;

char dirparts[8][16] ;

int tflag = 0 ;
int xflag = 0 ;
int vflag = 0 ;

struct ptabstr
{
	int	p_uid ;
	char *	p_name ;
	int	p_map ;
} ;

struct gtabstr
{
	int	g_gid ;
	char *	g_name ;
	int	g_map ;
} ;

struct ptabstr ptab[] =
{
	0,	"root",		0,
	1,	"daemon",	1,
	3,	"bin",		3,
	6,	"ken",		0,
	-1,	0,		0
} ;

struct gtabstr gtab[] =
{
	0,	"super",	0,
	1,	"other",	1,
	3,	"bin",		0,
	-1,	0,		0
} ;

main (argc,argv)
  int argc ;
  char ** argv ;
{
	register int n, m ;
	unsigned long int when ;
	extern char * malloc () ;
	extern char * ctime () ;

	(void) umask (0) ;

	if ( argc != 4 )
		Usage (argv[0]) ;

	for ( n = 0 ; argv[1][n] != '\0' ; n++ )
	{
		switch (argv[1][n])
		{
		  case 't':
			tflag = 1 ;
			break ;
		  case 'x':
			xflag = 1 ;
			break ;
		  case 'v':
			vflag = 1 ;
			break ;
		  default:
			Usage (argv[0]) ;
			break ;
		}
	}

	if ( (tflag+xflag) != 1 )
	{
		fprintf (stderr,"%s: one of {tx} must be given.\n",argv[0]) ;
		Usage (argv[0]) ;
	}

	if ( ( bnum = atoi (argv[2]) ) < 0 )
		Usage (argv[0]) ;

	if ( ( fd = fopen (argv[3],"r") ) == NULL )
	{
		perror (argv[3]) ;
		Usage (argv[0]) ;
	}

	(void) fseek (fd,(long)((bnum+0)*BLKSIZ),0) ;

	if ( fread (&(super),sizeof(super),1,fd) != 1 )
	{
		perror ("fread -- super block") ;
		exit (1) ;
	}

	when = ( ( (unsigned) super.s_time[0] ) << 16 ) |
	         ( (unsigned) super.s_time[1] ) ;

	if ( vflag )
		printf ("Super block last update time is %s",ctime(&(when))) ;

	ilist = (struct inode *) malloc (super.s_isize*BLKSIZ) ;

	(void) fseek (fd,(long)((bnum+1)*BLKSIZ),0) ;

	if ( fread (ilist,(super.s_isize*BLKSIZ),1,fd) != 1 )
	{
		perror ("fread -- I-list") ;
		exit (1) ;
	}

	Traverse (0,&(ilist[0])) ;

	(void) fclose (fd) ;

	exit (0) ;
}

int Usage (progname)
  char * progname ;
{
	fprintf (stderr,"Usage: %s {tvx} <blknum> file\n",progname) ;
	exit (1) ;
}

int Traverse (indent,ino)
  int indent ;
  struct inode * ino ;
{
	register int n, m ;
	struct direct dir[BLKSIZ/sizeof(struct direct)] ;

	for ( n = 0 ; n < 8 ; n++ )
	{
		if ( ino->i_addr[n] == 0 )
			break ;

		m = BLKSIZ * ( 0 + ino->i_addr[n] ) ;

		(void) fseek (fd,(long)(m),0) ;

		if ( fread (&(dir[0]),BLKSIZ,1,fd) != 1 )
		{
			perror ("fread -- dir block") ;
			exit (1) ;
		}

		for ( m = 0 ; m < BLKSIZ/sizeof(struct direct) ; m++ )
		{
			if ( dir[m].d_ino == 0 )
				continue ;

			ShowInode (indent,dir[m].d_name,dir[m].d_ino) ;
		}
	}
	return ;
}

#define PRINT	if (tflag||vflag) printf

int ShowInode (indent,name,inum)
  char * name ;
  int indent, inum ;
{
	register int n, m ;
	struct inode inode ;
	int gid, uid ;
	long int size ;
	long int atime, mtime ;
	long int timep[2] ;
	char buf[1024] ;
	extern char * ctime() ;

	if ( name[0] == '.' && name[1] == '\0' )
		return ;

	if ( name[0] == '.' && name[1] == '.' && name[2] == '\0' )
		return ;

	inode = ilist[inum-1] ;

	size = ((int)(inode.i_size0)<<16)|(inode.i_size1) ;

	atime = ( ( (unsigned) inode.i_atime[0] ) << 16 ) |
	          ( (unsigned) inode.i_atime[1] ) ;

	mtime = ( ( (unsigned) inode.i_mtime[0] ) << 16 ) |
	          ( (unsigned) inode.i_mtime[1] ) ;

	timep[0] = atime ; timep[1] = mtime ;

	for ( n = 0 ; n < indent ; n++ )
		PRINT ("  ") ;

	switch (inode.i_mode&IFMT)
	{
	  case IFDIR:
		PRINT ("d") ;
		break ;
	  case IFCHR:
		PRINT ("c") ;
		break ;
	  case IFBLK:
		PRINT ("b") ;
		break ;
	  case IFREG:
	  default:
		PRINT ("-") ;
		break ;
	}

	for ( n = 2 ; n >= 0 ; n-- )
	{
		m = ( inode.i_mode >> (3*n) ) & 07 ;

		if ( m & 04 )
			{PRINT ("r") ;}
		else
			{PRINT ("-") ;}

		if ( m & 02 )
			{PRINT ("w") ;}
		else
			{PRINT ("-") ;}

		switch (n)
		{
		  case 2:
			if ( m & 01 )
			{
				if ( inode.i_mode & ISUID )
					{PRINT ("s") ;}
				else
					{PRINT ("x") ;}
			}
			else
				PRINT ("-") ;
			break ;
		  case 1:
			if ( m & 01 )
			{
				if ( inode.i_mode & ISGID )
					{PRINT ("s") ;}
				else
					{PRINT ("x") ;}
			}
			else
				PRINT ("-") ;
			break ;
		  case 0:
			if ( m & 01 )
			{
				if ( inode.i_mode & ISVTX )
					{PRINT ("s") ;}
				else
					{PRINT ("x") ;}
			}
			else
				PRINT ("-") ;
			break ;
		}
	}

	PRINT (" %2d ",inode.i_nlink) ;

	for ( n = 0 ; ptab[n].p_uid != -1 ; n++ )
		if ( ptab[n].p_uid == inode.i_uid )
			break ;

	uid = ptab[n].p_map ;

	if ( ptab[n].p_uid != -1 )
		{PRINT ("%s",ptab[n].p_name) ;}
	else
		{PRINT ("%d",inode.i_uid) ;}

	for ( n = 0 ; gtab[n].g_gid != -1 ; n++ )
		if ( gtab[n].g_gid == inode.i_gid )
			break ;

	gid = gtab[n].g_map ;

	if ( gtab[n].g_gid != -1 )
		{PRINT ("/%s",gtab[n].g_name) ;}
	else
		{PRINT ("/%d",inode.i_gid) ;}

	PRINT (" %8d",size) ;

	strncpy (buf,ctime(&(mtime)),sizeof(buf)) ;

	buf[24] = 0 ;

	PRINT (" %s",buf) ;

	PRINT ("  %.14s\n",name) ;

	switch (inode.i_mode&IFMT)
	{
	  case IFDIR:
		strcpy (dirparts[indent],name) ;
		sprintf (buf,".") ;
		for ( n = 0 ; n <= indent ; n++ )
		{
			strcat (buf,"/") ;
			strcat (buf,dirparts[n]) ;
		}
		if ( xflag )
		{
			if ( mkdir (buf,inode.i_mode&0777) == -1 )
			{
				perror (buf) ;
				exit (1) ;
			}
			(void) utime (buf,timep) ;
			(void) chown (buf,uid,gid) ;
			(void) chmod (buf,inode.i_mode&0777) ;
		}
		Traverse (indent+1,&(inode)) ;
		break ;
	  case IFREG:
		strcpy (dirparts[indent],name) ;
		sprintf (buf,".") ;
		for ( n = 0 ; n <= indent ; n++ )
		{
			strcat (buf,"/") ;
			strcat (buf,dirparts[n]) ;
		}
		CreateFile (buf,&(inode),timep,uid,gid) ;
		break ;
	}
	return ;
}

int CreateFile (path,ino,timep,uid,gid)
  char * path ;
  struct inode * ino ;
  long int timep[2] ;
  int uid, gid ;
{
	register int n, m, p ;
	long int size ;
	char buf[BLKSIZ] ;
	short int ibuf[BLKSIZ/2] ;
	FILE * nfd ;

	if ( !xflag )
		return ;

	if ( ( nfd = fopen (path,"w") ) == NULL )
	{
		perror (path) ;
		exit (1) ;
	}

	size = ((int)(ino->i_size0)<<16)|(ino->i_size1) ;

	for ( n = 0 ; n < 8 ; n++ )
	{
		if ( ino->i_addr[n] == 0 )
			break ;

		m = BLKSIZ * ( 0 + ino->i_addr[n] ) ;

		(void) fseek (fd,(long)(m),0) ;

		if ( ino->i_mode & ILARG )
		{
			if ( fread (&(ibuf[0]),BLKSIZ,1,fd) != 1 )
			{
				perror ("fread -- indirect block") ;
				exit (1) ;
			}

			for ( p = 0 ; p < BLKSIZ/2 ; p++ )
			{
				if ( ibuf[p] == 0 )
					break ;

				m = BLKSIZ * ( 0 + ibuf[p] ) ;

				(void) fseek (fd,(long)(m),0) ;

				if ( fread (&(buf[0]),BLKSIZ,1,fd) != 1 )
				{
					perror ("fread -- file block") ;
					exit (1) ;
				}

				m = ( size < BLKSIZ ) ? size : BLKSIZ ;

				if ( fwrite (buf,m,1,nfd) != 1 )
				{
					perror ("fwrite -- file block") ;
					exit (1) ;
				}

				size -= m ;
			}
		}
		else
		{
			if ( fread (&(buf[0]),BLKSIZ,1,fd) != 1 )
			{
				perror ("fread -- file block") ;
				exit (1) ;
			}

			m = ( size < BLKSIZ ) ? size : BLKSIZ ;

			if ( fwrite (buf,m,1,nfd) != 1 )
			{
				perror ("fwrite -- file block") ;
				exit (1) ;
			}

			size -= m ;
		}
	}

	(void) fclose (nfd) ;

	(void) utime (path,timep) ;

	(void) chown (path,uid,gid) ;

	(void) chmod (path,ino->i_mode&07777) ;

	return ;
}
