#include <stdio.h>
main()
{
	int bc;
	int c;

	while ((bc = getint()) != 0) {
		while (bc--)
			putc(getc(stdin), stdout);
		getint();
	}
}

int
getint()
{
	int c1, c2, c3, c4;
	c1 = getc(stdin);
	c2 = getc(stdin);
	c3 = getc(stdin);
	c4 = getc(stdin);
	return c1 + c2 * 256 + c3*256*256 + c4*256*256*256;
}
