#ifdef PROTO
# define	P(s) s
#else
# define P(s) ()
#endif


/* as11.c */
void main P((int ac , char **av ));
void asm_trace P((int sno , char *sname ));
void begin_symbol P((void ));
void symbol_char P((int c ));
void finish_symbol P((void ));
int in_false_if P((void ));
int valid_opcode P((void ));
int instr_ops P((INSTR_OPS fmt ));
void first_operand P((void ));
void set_float_size P((int isdbl ));
int init_number P((int n ));
void store_float_point P((void ));
int float_noexp_ok P((void ));
void set_float_exp_sign P((int sgn ));
void set_float_exp P((int e ));
int have_a_digit P((void ));
int prefixed_ok P((void ));
void set_number_unsigned P((void ));
int store_number_digit P((int c ));
int finish_number P((void ));
void dyad_op P((int c ));
void dyad_op_str P((char *s ));
int monad_op P((int c ));
void monad_op_str P((char *s ));
void combine_op P((void ));
void set_ascii_term P((int c ));
int psop_ascii_term P((int c ));
void psop_ascii_char P((int c ));
void psop_ascii_expr P((void ));
void psop_ascii_null P((void ));
void psop_db P((void ));
void psop_dw P((void ));
void psop_dl P((void ));
void psop_dq P((void ));
void psop_df P((void ));
void psop_dd P((void ));
void psop_even P((void ));
void psop_odd P((void ));
void psop_space P((int factor ));
void psop_end P((int needpop ));
void psop_if_eq P((void ));
void psop_if_ne P((void ));
void psop_if_gt P((void ));
void psop_if_ge P((void ));
void psop_if_le P((void ));
void psop_if_lt P((void ));
void psop_if_df P((void ));
void psop_if_ndf P((void ));
void psop_doif P((void ));
void psop_iff P((void ));
void psop_ift P((void ));
void psop_iftf P((void ));
void psop_endc P((void ));
void psop_list_on P((void ));
void psop_list_off P((void ));
void psop_list_push P((void ));
void psop_list_pop P((void ));
void psop_include_begin P((int c ));
int psop_include_end P((int c ));
void psop_include_unterm P((void ));
void psop_include_char P((int c ));
void psop_align P((void ));
void pop_value P((void ));
void pop_op P((void ));
void get_spaces P((void ));
void skip_spaces P((void ));
void do_assignment P((int defn ));
void set_assign_sym P((void ));
void set_lc_start P((void ));
void do_lc P((void ));
void define_label P((void ));
void op_mode P((int m ));
void pc_mode P((int m ));
void symbol_value P((void ));
void warn_untermstring P((void ));
void warn_ignored P((void ));
int set_regno P((void ));
int set_fregno P((void ));
void begin_blocked_bytes P((void ));
void end_blocked_bytes P((void ));
void last_operand P((void ));

/* asm-parse.c */
int asm_parse P((char *s ));
FSMarg *asm_parsegetarg P((void ));
char *asm_parserest P((void ));

/* htable.c */
char *new_htable ();
char *find_hentry P((char *Tbl , char *entry ));
void add_new_hentry P((char *Tbl , char *entry ));
void map_htable ();
int string_hfxn P((char *str , int siz ));
int string_cmpfxn P((char *s1 , char *s2 ));

/* copyof.c */
char *copyofstr P((char *str ));

#undef P
