#ifdef PROTO
# define	P(s) s
#else
# define P(s) ()
#endif


/* pdp11.c */
void bugchk P((int va_alist ));
void busreset P((void ));
void checkpsw P((void ));
int idcmp P((char *idcp1 , char *idcp2 ));
void initinstrs P((void ));
void loadcore P((char *fn ));
void unimpl P((void ));
int get_deftbl P((word inst ));
void trapto P((int trapv ));
void interrupt P((DRIVER *d , int vec , int pri ));
void main P((int ac , char **av ));
int adjust_adjacent P((int dtx , INSTR_OPS opfwant ));
int disas P((word addr ));
int disas_r P((int rno ));
int disas_fr P((int rno ));
int disas_g P((int op , word *pcp ));
int disas_f P((int op , word *pcp ));


/* instrs.c */
void I_adc P((word inst ));
void I_add P((word inst ));
void I_ash P((word inst ));
void I_ashc P((word inst ));
void I_asl P((word inst ));
void I_asr P((word inst ));
void I_bic P((word inst ));
void I_bis P((word inst ));
void I_bit P((word inst ));
void I_bpt P((word inst ));
void I_cbranch P((word inst ));
void I_cfcc P((word inst ));
void I_clr P((word inst ));
void I_cmp P((word inst ));
void I_com P((word inst ));
void I_condcode P((word inst ));
void I_csm P((word inst ));
void I_dec P((word inst ));
void I_div P((word inst ));
void I_div P((word inst ));
void I_emhalt P((int inst ));
void I_emt P((word inst ));
void I_fadd P((void ));
void I_fdiv P((void ));
void I_fmul P((void ));
void I_fsub P((void ));
void I_halt P((word inst ));
void I_inc P((word inst ));
void I_iot P((word inst ));
void I_jmp P((word inst ));
void I_jsr P((word inst ));
void I_ldfps P((word inst ));
void I_mark P((word inst ));
void I_mfpd P((word inst ));
void I_mfpi P((word inst ));
void I_mfps P((word inst ));
void I_mfpt P((word inst ));
void I_mov P((word inst ));
void I_mtpd P((word inst ));
void I_mtpi P((word inst ));
void I_mtps P((word inst ));
void I_mul P((word inst ));
void I_neg P((word inst ));
void I_nop P((word inst ));
void I_reset P((word inst ));
void I_rol P((word inst ));
void I_ror P((word inst ));
void I_rti P((word inst ));
void I_rts P((word inst ));
void I_rtt P((word inst ));
void I_sbc P((word inst ));
void I_setd P((word inst ));
void I_setf P((word inst ));
void I_seti P((word inst ));
void I_setl P((word inst ));
void I_sob P((word inst ));
void I_spl P((word inst ));
void I_stfps P((word inst ));
void I_stst P((word inst ));
void I_sub P((word inst ));
void I_swab P((word inst ));
void I_sxt P((word inst ));
void I_trap P((word inst ));
void I_tst P((word inst ));
void I_tstset P((word inst ));
void I_wait P((word inst ));
void I_wrtlck P((word inst ));
void I_xor P((word inst ));

/* finstrs.c */
void I_absf P((word inst ));
void I_addf P((word inst ));
void I_clrf P((word inst ));
void I_cmpf P((word inst ));
void I_divf P((word inst ));
void I_ldcdf P((word inst ));
void I_ldcif P((word inst ));
void I_ldexp P((word inst ));
void I_ldf P((word inst ));
void I_modf P((word inst ));
void I_mulf P((word inst ));
void I_negf P((word inst ));
void I_stcfd P((word inst ));
void I_stcfi P((word inst ));
void I_stexp P((word inst ));
void I_stf P((word inst ));
void I_subf P((word inst ));
void I_tstf P((word inst ));

/* instr-aux.c */
int sxb P((byte b ));
int sxw P((word w ));
void clearpac P((void ));
void clear1pac P((ASPACE as , int inx ));
word fetchphys P((unsigned long int pa ));
void storephys P((unsigned long int pa , word w ));
word fetchword P((word va , ASPACE as ));
void storeword P((word va , ASPACE as , word w ));
int reg_access P((int loc , word *rp , int op , word fixedbits , word data ));
word sp_pop P((void ));
void sp_push P((word w ));
word get_operand_a P((int op ));
word get_operand_w P((int op ));
byte get_operand_b P((int op ));
void set_operand_w P((int op , word value ));
void set_operand_b P((int op , byte value ));
void rmw_operand_w ();
void rmw_operand_b ();

/* drivers.c */

/* clk.c */

/* rk11.c */

/* reg.c */

/* cons.c */
void cons__reset P((void ));
void cons__flush P((void ));

/* ltc.c */

#undef P
