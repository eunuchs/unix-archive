/* Copyright (c)1994-2000 Begemot Computer Associates. All rights reserved.
 * See the file COPYRIGHT for details of redistribution and use. */
/* $Id: regi.h,v 1.4 2000/03/04 08:03:31 hbb Exp $ */

# if defined(USE_REGISTERS)
#  if defined(i386)
register unsigned short src 	asm("si");
register unsigned short dst	asm("bx");
#  elif defined(sparc)
register unsigned short src	asm("g5");
register unsigned short dst	asm("g6");
#  else
unsigned short src;
unsigned short dst;
#  endif
# else
unsigned short src;
unsigned short dst;
# endif
