/* Copyright (c)1994-2000 Begemot Computer Associates. All rights reserved.
 * See the file COPYRIGHT for details of redistribution and use. */
/* $Id: cdefs.h,v 1.4 2000/03/04 08:03:27 hbb Exp $ */

# if __GNUC__ >= 2 && __GNUC_MINOR__ >= 5
#  define DEAD_FUNC	__attribute__((__volatile))
# else
#  define DEAD_FUNC
# endif

# if __GNUC__ >= 2
#  define UNUSED __attribute__((__unused__))
# else
#  define UNUSED
# endif

# define RCSID(ID) static char rcsid [] UNUSED = ID;
