/* Copyright (c)1994-2000 Begemot Computer Associates. All rights reserved.
 * See the file COPYRIGHT for details of redistribution and use. */
/* $Id: util.h,v 1.6 2000/03/04 08:04:07 hbb Exp $ */

# ifndef util_h_
# define util_h_

# include <sys/types.h>
# define ArraySize(A)	(sizeof(A)/sizeof(A[0]))
# define BAD_SWITCH(S)	panic("bad switch in '%s', %d: %ld\n", __FILE__, __LINE__, (long)(S));

void	set_argv0(char *);
void	catch_signal(int, void (*)());

caddr_t mmap_shared_parent(size_t, int *);
caddr_t mmap_shared_child(size_t, int);

# endif
