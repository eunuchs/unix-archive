# Copyright (c)1994-2000 Begemot Computer Associates. All rights reserved.
# See the file COPYRIGHT for details of redistribution and use.
#
# $Id: Makefile.c,v 1.5 2000/03/04 08:04:02 hbb Exp $

.c.o:
	@test -d .deps || mkdir .deps >/dev/null 2>&1
	$(CC) $(CFLAGS) -c -Wp,-MD,.deps/$*.d $< -o $@

.c.s:
	@test -d .deps || mkdir .deps >/dev/null 2>&1
	$(CC) $(CFLAGS) -S -Wp,-MD,.deps/$*.d $< -o $@

.c.p:
	@test -d .deps || mkdir .deps >/dev/null 2>&1
	$(CC) $(CFLAGS) -E -Wp,-MD,.deps/$*.d $< >$@

ifndef DEPS
DEPS = $(SRC:%.c=.deps/%.d)
endif


LIBTOOL_DEPS = @LIBTOOL_DEPS@
libtool: $(LIBTOOL_DEPS)
	$(SHELL) ./config.status --recheck


-include $(DEPS)
