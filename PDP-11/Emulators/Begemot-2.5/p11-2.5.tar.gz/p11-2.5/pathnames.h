/* Copyright (c)1994-2000 Begemot Computer Associates. All rights reserved.
 * See the file COPYRIGHT for details of redistribution and use. */
/* $Id: pathnames.h,v 1.7 2000/03/04 08:03:31 hbb Exp $ */

# ifdef HAVE_PATHS_H
#  include <paths.h>
# endif

# ifndef _PATH_BSHELL
#  define _PATH_BSHELL		"/bin/sh"
# endif

# ifndef _PATH_XTERM
#  define _PATH_XTERM		"/usr/X11/bin/xterm"
# endif

# ifndef _PATH_MON_HELP
#  define _PATH_MON_HELP	"mon.help"
# endif

# ifndef _PATH_COPYING
#  define _PATH_COPYING		"COPYRIGHT"
# endif
