/* Copyright (c)1994-2000 Begemot Computer Associates. All rights reserved.
 * See the file COPYRIGHT for details of redistribution and use. */

# include <stdio.h>
# include <stdlib.h>
# include <sys/types.h>
# include <sys/stat.h>
# include <errno.h>
# include <fcntl.h>
# include <unistd.h>
# include <string.h>

# include "cdefs.h"
# include "tty.h"

RCSID("$Id: tty_fifo.c,v 1.6 2000/03/04 08:04:04 hbb Exp $")


int		cs7;
char		*fname;



volatile void
Exit(int ex)
{
	unlink(fname);
	exit(ex);
}

/*
 * fd 0 is socket to parent
 */
int
main(int argc, char *argv[])
{
	int	opt;
	int	fd;

	while((opt = getopt(argc, argv, "7")) != EOF)
		switch(opt) {

		case '7':
			cs7 = 1;
			break;
		}
	argc -= optind;
	argv += optind;

	tty_init();

	if(mkfifo(fname = argv[0], 0666))
		return 80;
	if((fd = open(fname, 2)) < 0)
		return 100+errno;
	if(setsid() < 0)
		return 82;

	tty_loop(fd);

	Exit(0);
}

void
process_output()
{
	if(cs7)
		makecs7();
}

void
process_input()
{
}
