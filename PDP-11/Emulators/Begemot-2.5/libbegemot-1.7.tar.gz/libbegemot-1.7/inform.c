/* Copyright (c)1997 Begemot Computer Associates. All rights reserved.
 * See the file COPYRIGHT for details of redistribution and use. */
/*
 * $Id: inform.c,v 1.6 1998/03/17 15:33:05 hbb Exp $
 */
# include <stdio.h>
# include <stdlib.h>
# include "begemot.h"
# include "private.h"

/*
 * Display a info message.
 */
void
inform(const char *fmt, ...)
{
	va_list ap;

	va_start(ap, fmt);
	begemot_common_err("info", "\n", fmt, ap);
	va_end(ap);
}
void
vinform(const char *fmt, va_list ap)
{
	begemot_common_err("info", "\n", fmt, ap);
}
