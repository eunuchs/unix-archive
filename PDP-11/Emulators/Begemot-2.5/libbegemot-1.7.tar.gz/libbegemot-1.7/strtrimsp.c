/* Copyright (c)1997 Begemot Computer Associates. All rights reserved.
 * See the file COPYRIGHT for details of redistribution and use. */
/*
 * $Id: strtrimsp.c,v 1.3 1998/03/12 15:43:42 harti Exp $
 */
# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <ctype.h>
# include "begemot.h"

void
strtrimsp(char **sp, int which)
{
	char *p;

	if(which != 1) {
		p = *sp;
		while(*p != '\0' && isascii((u_int)*p) && isspace((u_int)*p))
			p++;
		*sp = p;
	}
	if(which != 0) {
		p = *sp + strlen(*sp);
		while(p > *sp && isascii((u_int)*p) && isspace((u_int)p[-1]))
			p--;
		p[0] = '\0';
	}
}
