/* Copyright (c)1997 Begemot Computer Associates. All rights reserved.
 * See the file COPYRIGHT for details of redistribution and use. */
/*
 * $Id: bug.c,v 1.6 1998/03/17 15:33:04 hbb Exp $
 */
# include <stdio.h>
# include <stdlib.h>
# include "begemot.h"
# include "private.h"

/*
 * Simple fatal exit for internal errors.
 */
void
bug(const char *fmt, ...)
{
	va_list ap;

	va_start(ap, fmt);
	begemot_common_err("internal error", "\n", fmt, ap);
	va_end(ap);

	abort();
}
void
vbug(const char *fmt, va_list ap)
{
	begemot_common_err("internal error", "\n", fmt, ap);

	abort();
}
