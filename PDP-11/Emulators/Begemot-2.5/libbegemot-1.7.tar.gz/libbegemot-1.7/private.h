/* Copyright (c)1997 Begemot Computer Associates. All rights reserved.
 * See the file COPYRIGHT for details of redistribution and use. */
/*
 * $Id: private.h,v 1.3 1998/03/17 15:33:06 hbb Exp $
 */

# ifndef private_h
# define private_h

# include <stdarg.h>
# include <sys/types.h>

# ifdef __cplusplus
extern "C" {
# endif

void begemot_common_err(const char *, const char *, const char *, va_list);

# ifdef __cplusplus
}
# endif
# endif
