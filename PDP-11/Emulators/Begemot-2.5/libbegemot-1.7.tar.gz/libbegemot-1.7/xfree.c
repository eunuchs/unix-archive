/* Copyright (c)1997 Begemot Computer Associates. All rights reserved.
 * See the file COPYRIGHT for details of redistribution and use. */
/*
 * $Id: xfree.c,v 1.1 1998/07/17 20:34:17 hbb Exp $
 */
# include <stdio.h>
# include <stdlib.h>
# include "begemot.h"

/*
 * Yes, there are free()s, that handle NULL pointers ...
 */
void
xfree(void *p)
{
	if(p)
		free(p);
}
