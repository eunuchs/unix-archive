/* Copyright (c)1997 Begemot Computer Associates. All rights reserved.
 * See the file COPYRIGHT for details of redistribution and use. */
/* 
 * $Id: strnchr.c,v 1.1 1999/04/15 10:07:07 hbb Exp $
 */
# include <string.h>
# include "begemot.h"

char *
strnchr(const char *s, int c, size_t n)
{
	while(n-- && *s) {
		if(*s == c)
			return (char *)s;
		s++;
	}
	return NULL;
}
