/* Copyright (c)1997 Begemot Computer Associates. All rights reserved.
 * See the file COPYRIGHT for details of redistribution and use. */
/*
 * $Id: xstrsave.c,v 1.2 1997/12/01 10:04:40 hbb Exp $
 */
# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include "begemot.h"

char *
xstrsave(const char *s)
{
	return strcpy(xalloc(strlen(s) + 1), s);
}
