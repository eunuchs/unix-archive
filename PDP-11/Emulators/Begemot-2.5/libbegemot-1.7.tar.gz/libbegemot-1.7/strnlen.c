/* Copyright (c)1997 Begemot Computer Associates. All rights reserved.
 * See the file COPYRIGHT for details of redistribution and use. */
/* 
 * $Id: strnlen.c,v 1.2 1997/12/01 10:04:40 hbb Exp $
 */
# include <string.h>
# include "begemot.h"

size_t
strnlen(const char *s, size_t n)
{
	const char *p = s;

	while(*p && n--)
		p++;
	return p - s;
}
