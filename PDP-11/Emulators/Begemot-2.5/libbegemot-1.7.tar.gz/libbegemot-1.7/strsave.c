/* Copyright (c)1997 Begemot Computer Associates. All rights reserved.
 * See the file COPYRIGHT for details of redistribution and use. */
/*
 * $Id: strsave.c,v 1.2 1997/12/01 10:04:40 hbb Exp $
 */
# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include "begemot.h"

char *
strsave(const char *s)
{
	char *p;

	if((p = malloc(strlen(s) + 1)) != NULL)
		(void)strcpy(p, s);
	return p;
}
