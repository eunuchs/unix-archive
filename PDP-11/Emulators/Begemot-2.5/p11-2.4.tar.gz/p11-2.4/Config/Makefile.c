# Copyright (c)1994-1999 Begemot Computer Associates. All rights reserved.
# See the file COPYRIGHT for details of redistribution and use.

.c.o:
	@test -d .deps || mkdir .deps >/dev/null 2>&1
	$(CC) $(CFLAGS) -c -Wp,-MD,.deps/$*.d $< -o $@

.c.s:
	@test -d .deps || mkdir .deps >/dev/null 2>&1
	$(CC) $(CFLAGS) -S -Wp,-MD,.deps/$*.d $< -o $@

.c.p:
	@test -d .deps || mkdir .deps >/dev/null 2>&1
	$(CC) $(CFLAGS) -E -Wp,-MD,.deps/$*.d $< >$@

ifndef DEPS
DEPS = $(SRC:%.c=.deps/%.d)
endif


LIBTOOL_DEPS = @LIBTOOL_DEPS@
libtool: $(LIBTOOL_DEPS)
	$(SHELL) ./config.status --recheck


-include $(DEPS)
