/* Copyright (c)1994-1999 Begemot Computer Associates. All rights reserved.
 * See the file COPYRIGHT for details of redistribution and use. */

# ifndef HAS_UCHAR
typedef unsigned char uchar;
# endif

extern uchar	buf[];
extern int	got;
extern uint	ticks;

void	nvt2bin(void);
void	bin2nvt(void);
void	deliacs(void);
void	insiacs(void);
void	makecs7(void);

void	tty_init(void);
void	tty_loop(int);

void	process_input(void);
void	process_output(void);

volatile void	Exit(int) DEAD_FUNC;
void	onsig();
void	xpanic(int, char *, ...) DEAD_FUNC;

# ifndef TCSASOFT
#  define TCSASOFT 0
# endif
