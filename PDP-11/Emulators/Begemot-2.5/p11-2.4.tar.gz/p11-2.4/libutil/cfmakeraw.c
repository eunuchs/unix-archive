/* Copyright (c)1994-1999 Begemot Computer Associates. All rights reserved.
 * See the file COPYRIGHT for details of redistribution and use. */
# ifndef HAS_CFMAKERAW

# include <termios.h>

/*
 * make tty raw
 */
void
cfmakeraw(struct termios *t)
{
        t->c_iflag &= ~(IGNBRK | BRKINT | PARMRK | INPCK | ISTRIP | INLCR | IGNCR | ICRNL | IXON | IXOFF | IXANY);
	t->c_iflag |= IGNPAR;
        t->c_oflag &= ~OPOST;
        t->c_cflag &= ~(CSIZE | PARENB);
        t->c_cflag |= CS8;
        t->c_lflag &= ~(ECHO | ECHONL | ICANON | ISIG | IEXTEN);
	t->c_cc[VMIN] = 1;
	t->c_cc[VTIME] = 0;
}
# endif
