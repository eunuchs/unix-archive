/* Copyright (c)1994-1999 Begemot Computer Associates. All rights reserved.
 * See the file COPYRIGHT for details of redistribution and use. */

# if __GNUC__ >= 2 && __GNUC_MINOR__ >= 5
#  define DEAD_FUNC	__attribute__((__volatile))
# else
#  define DEAD_FUNC
# endif

# if __GNUC__ >= 2
#  define UNUSED __attribute__((__unused__))
# else
#  define UNUSED
# endif
