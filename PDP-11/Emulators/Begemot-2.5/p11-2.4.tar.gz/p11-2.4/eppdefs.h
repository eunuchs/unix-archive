/* Copyright (c)1994-1999 Begemot Computer Associates. All rights reserved.
 * See the file COPYRIGHT for details of redistribution and use. */

typedef struct Comm 	Comm;
typedef struct Epp	Epp;

# define ETHMTU		1532
# define ETHMIN		60	/* 2.11BSD chokes with 54 */

enum {
	EPP_INIT	= 0x0001,
	EPP_RECEIVE	= 0x0002,	/* receive frame */
	EPP_TRANSMIT	= 0x0003,	/* transmit frame */
	EPP_ILOOP	= 0x0004,
	EPP_ELOOP	= 0x0005,
	EPP_EILOOP	= 0x0006,
	EPP_SETUP	= 0x0007,
	EPP_RSTATUS	= 0x0008,	/* receive status */
	EPP_XSTATUS	= 0x000A,	/* transmit status */
};

struct Epp {
	u_int	reset_count;
	u_short	type;
	u_short	len;
};

struct Comm {
	u_int	reset_count;
	u_int	rcv_enable;
};
