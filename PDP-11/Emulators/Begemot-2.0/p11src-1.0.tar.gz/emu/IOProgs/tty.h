/* p11 - pdp11 emulator; Copyright (C) 1994 Hartmut Brandt, Joerg Micheel 
 * see the file LICENSE for further information */

# ifndef HAS_UCHAR
typedef unsigned char uchar;
# endif

extern uchar	buf[];
extern int	got;
extern int	ticks;

void	nvt2bin(void);
void	bin2nvt(void);
void	deliacs(void);
void	insiacs(void);
void	makecs7(void);

void	tty_init(void);
void	tty_loop(int);

void	process_input(void);
void	process_output(void);

volatile void	Exit(int) DEAD_FUNC;
void	onsig();
