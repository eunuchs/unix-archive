/* p11 - pdp11 emulator; Copyright (C) 1994 Hartmut Brandt, Joerg Micheel 
 * see the file LICENSE for further information */

# ifdef USE_PATHH
#  include <paths.h>
# endif

# ifndef _PATH_BSHELL
#  define _PATH_BSHELL		"/bin/sh"
# endif

# ifndef _PATH_P11INCL
#  define _PATH_P11INCL		"/usr/harti/11/emu"
# endif

# ifndef _PATH_XTERM
#  define _PATH_XTERM		"/usr/X11/bin/xterm"
# endif

# ifndef _PATH_CPP
#  define _PATH_CPP		"cpp"
# endif
