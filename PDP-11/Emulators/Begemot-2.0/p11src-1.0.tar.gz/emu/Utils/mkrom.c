/* p11 - pdp11 emulator; Copyright (C) 1994 Hartmut Brandt, Joerg Micheel 
 * see the file LICENSE for further information */

/*
 * make a 'prom' from an as-assemebled file
 * handles currently proms up to 512 byte :-/
 */

# include <stdio.h>
# include <unistd.h>

char	rom[512];

main()
{
	long	a, l;
	int b;

	while(scanf("%lx %lx", &a, &l) == 2) {
		a -= 0173000;
		while(l--) {
			if(&rom[a] >= rom + sizeof(rom)) {
				fprintf(stderr, "address to big %lo\n", a);
				return 1;
			}
			if(scanf("%x", &b) != 1) {
				fprintf(stderr, "format error\n");
				return 1;
			}
			rom[a++] = b;
		}
	}
	write(1, rom, sizeof(rom));
	return 0;
}
