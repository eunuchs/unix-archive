/* p11 - pdp11 emulator; Copyright (C) 1994 Hartmut Brandt, Joerg Micheel 
 * see the file LICENSE for further information */

register unsigned short src asm("g5");
register unsigned short dst asm("g6");
