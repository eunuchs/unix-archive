/* p11 - pdp11 emulator; Copyright (C) 1994 Hartmut Brandt, Joerg Micheel 
 * see the file LICENSE for further information */

# if 1
register unsigned short src 	asm("si");
register unsigned short dst	asm("bx");
# else
unsigned short src;
unsigned short dst;
# endif
