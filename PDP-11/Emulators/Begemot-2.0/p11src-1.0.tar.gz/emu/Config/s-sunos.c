/* p11 - pdp11 emulator; Copyright (C) 1994 Hartmut Brandt, Joerg Micheel 
 * see the file LICENSE for further information */

/*
 * extra routines missed in moon-os
 */
#include	<stdio.h>
#include	<errno.h>
#include	<sys/types.h>
#include	<sys/termios.h>

extern int sys_nerr;
extern char *sys_errlist[];

char *
strerror(error)
int	error;
{
	static char	buf[81];

	if( error < sys_nerr )
		return sys_errlist[error];
	sprintf(buf, "unknown error %d", error);
	return buf;
}
