/* p11 - pdp11 emulator; Copyright (C) 1994 Hartmut Brandt, Joerg Micheel 
 * see the file LICENSE for further information */

/*
 * fast block move, addresses are aligned on 16bit boundaries
 */
# define CopyW(T,F,C)	bcopy((F), (T), (C) << 1)

/************************************************************
 *
 * processor emulation
 */

/*
 * Test word/byte and set N and Z
 */
# define TestW(V)
# define TestB(V)

/*
 * compare words/bytes and set NZCV
 */
# define CmpW(D,S)
# define CmpB(D,S)

/*
 * sub/add words/bytes and set NZCV
 */
# define SubWC(D,S)
# define AddWC(D,S)
# define SubBC(D,S)
# define AddBC(D,S)

/*
 * sub/add words/bytes and set NZV
 */
# define SubW(D,S)
# define AddW(D,S)
# define SubB(D,S)
# define AddB(D,S)
# define SwabB(D)

# define SCHAR(S)	((sshort)(schar)(S))


# define Div(v1,v2,v,d)
