/* p11 - pdp11 emulator; Copyright (C) 1994 Hartmut Brandt, Joerg Micheel 
 * see the file LICENSE for further information */

# include <stdlib.h>
# include <termios.h>
# include <sys/time.h>
# include <sys/resource.h>

int
getdtablesize()
{
	struct rlimit r;

	getrlimit(RLIMIT_NOFILE, &r);

	return r.rlim_cur;
}
