/* p11 - pdp11 emulator; Copyright (C) 1994 Hartmut Brandt, Joerg Micheel 
 * see the file LICENSE for further information */

# ifdef USE_VARARGS
#  define VA_START(A,B)	va_start((A))
# else
#  define VA_START(A,B) va_start((A), (B))
# endif

# if __GNUC__ >= 2 && __GNUC_MINOR__ >= 5
#  define DEAD_FUNC	__attribute__((__volatile))
# else
#  define DEAD_FUNC
# endif

# ifndef HAS_S5_SIGNALS
#  define SIGNAL(A,V) 	signal((A), (V))
# endif
