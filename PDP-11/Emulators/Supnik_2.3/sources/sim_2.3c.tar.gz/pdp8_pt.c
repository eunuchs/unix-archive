/* pdp8_pt.c: PDP-8 paper tape reader/punch simulator

   Copyright (c) 1993-1998,
   Robert M Supnik, Digital Equipment Corporation
   Commercial use prohibited

   30-Mar-98	RMS	Added RIM loader as PTR bootstrap.

   ptr		paper tape reader
   ptp		paper tape punch
*/

#include "pdp8_defs.h"

extern int32 int_req, dev_done, dev_enable, stop_inst;
extern unsigned int16 M[];
int32 ptr_stopioe = 0, ptp_stopioe = 0;			/* stop on error */
t_stat ptr_svc (UNIT *uptr);
t_stat ptp_svc (UNIT *uptr);
t_stat ptr_reset (DEVICE *dptr);
t_stat ptp_reset (DEVICE *dptr);
t_stat ptr_boot (int32 unitno);
extern t_stat sim_activate (UNIT *uptr, int32 delay);
extern t_stat sim_cancel (UNIT *uptr);

/* PTR data structures

   ptr_dev	PTR device descriptor
   ptr_unit	PTR unit descriptor
   ptr_reg	PTR register list
*/

UNIT ptr_unit = {
	UDATA (&ptr_svc, UNIT_SEQ+UNIT_ATTABLE, 0), SERIAL_IN_WAIT };

REG ptr_reg[] = {
	{ ORDATA (BUF, ptr_unit.buf, 8) },
	{ FLDATA (DONE, dev_done, INT_V_PTR) },
	{ FLDATA (ENABLE, dev_enable, INT_V_PTR) },
	{ FLDATA (INT, int_req, INT_V_PTR) },
	{ DRDATA (POS, ptr_unit.pos, 31), PV_LEFT },
	{ DRDATA (TIME, ptr_unit.wait, 24), PV_LEFT },
	{ FLDATA (STOP_IOE, ptr_stopioe, 0) },
	{ NULL }  };

DEVICE ptr_dev = {
	"PTR", &ptr_unit, ptr_reg, NULL,
	1, 10, 31, 1, 8, 8,
	NULL, NULL, &ptr_reset,
	&ptr_boot, NULL, NULL };

/* PTP data structures

   ptp_dev	PTP device descriptor
   ptp_unit	PTP unit descriptor
   ptp_reg	PTP register list
*/

UNIT ptp_unit = {
	UDATA (&ptp_svc, UNIT_SEQ+UNIT_ATTABLE, 0), SERIAL_OUT_WAIT };

REG ptp_reg[] = {
	{ ORDATA (BUF, ptp_unit.buf, 8) },
	{ FLDATA (DONE, dev_done, INT_V_PTP) },
	{ FLDATA (ENABLE, dev_enable, INT_V_PTP) },
	{ FLDATA (INT, int_req, INT_V_PTP) },
	{ DRDATA (POS, ptp_unit.pos, 31), PV_LEFT },
	{ DRDATA (TIME, ptp_unit.wait, 24), PV_LEFT },
	{ FLDATA (STOP_IOE, ptp_stopioe, 0) },
	{ NULL }  };

DEVICE ptp_dev = {
	"PTP", &ptp_unit, ptp_reg, NULL,
	1, 10, 31, 1, 8, 8,
	NULL, NULL, &ptp_reset,
	NULL, NULL, NULL };

/* Paper tape reader: IOT routine */

int32 ptr (int32 pulse, int32 AC)
{
switch (pulse) {					/* decode IR<9:11> */
case 0: 						/* RPE */
	dev_enable = dev_enable | (INT_PTR+INT_PTP);	/* set enable */
	int_req = INT_UPDATE;				/* update interrupts */
	return AC;
case 1:							/* RSF */
	return (dev_done & INT_PTR)? IOT_SKP + AC: AC;	
case 6:							/* RFC!RRB */
	sim_activate (&ptr_unit, ptr_unit.wait);
case 2:							/* RRB */
	dev_done = dev_done & ~INT_PTR;			/* clear flag */
	int_req = int_req & ~INT_PTR;			/* clear int req */
	return (AC | ptr_unit.buf);			/* or data to AC */
case 4:							/* RFC */
	sim_activate (&ptr_unit, ptr_unit.wait);
	dev_done = dev_done & ~INT_PTR;			/* clear flag */
	int_req = int_req & ~INT_PTR;			/* clear int req */
	return AC;
default:
	return (stop_inst << IOT_V_REASON) + AC;  }	/* end switch */
}

/* Unit service */

t_stat ptr_svc (UNIT *uptr)
{
int32 temp;

if ((ptr_unit.flags & UNIT_ATT) == 0)			/* attached? */
	return IORETURN (ptr_stopioe, SCPE_UNATT);
if ((temp = getc (ptr_unit.fileref)) == EOF) {
	if (feof (ptr_unit.fileref)) {
		if (ptr_stopioe) printf ("PTR end of file\n");
		else return SCPE_OK;  }
	else perror ("PTR I/O error");
	clearerr (ptr_unit.fileref);
	return SCPE_IOERR;  }
dev_done = dev_done | INT_PTR;				/* set done */
int_req = INT_UPDATE;					/* update interrupts */
ptr_unit.buf = temp & 0377;
ptr_unit.pos = ptr_unit.pos + 1;
return SCPE_OK;
}

/* Reset routine */

t_stat ptr_reset (DEVICE *dptr)
{
ptr_unit.buf = 0;
dev_done = dev_done & ~INT_PTR;				/* clear done, int */
int_req = int_req & ~INT_PTR;
dev_enable = dev_enable | INT_PTR;			/* set enable */
sim_cancel (&ptr_unit);					/* deactivate unit */
return SCPE_OK;
}

/* Paper tape punch: IOT routine */

int32 ptp (int32 pulse, int32 AC)
{
switch (pulse) {					/* decode IR<9:11> */
case 0: 						/* PCE */
	dev_enable = dev_enable & ~(INT_PTR+INT_PTP);	/* clear enables */
	int_req = INT_UPDATE;				/* update interrupts */
	return AC;
case 1:							/* PSF */
	return (dev_done & INT_PTP)? IOT_SKP + AC: AC;
case 2:							/* PCF */
	dev_done = dev_done & ~INT_PTP;			/* clear flag */
	int_req = int_req & ~INT_PTP;			/* clear int req */
	return AC;
case 6:							/* PLS */
	dev_done = dev_done & ~INT_PTP;			/* clear flag */
	int_req = int_req & ~INT_PTP;			/* clear int req */
case 4:							/* PPC */
	ptp_unit.buf = AC & 0377;			/* load punch buf */
	sim_activate (&ptp_unit, ptp_unit.wait);	/* activate unit */
	return AC;
default:
	return (stop_inst << IOT_V_REASON) + AC;  }	/* end switch */
}

/* Unit service */

t_stat ptp_svc (UNIT *uptr)
{
dev_done = dev_done | INT_PTP;				/* set done */
int_req = INT_UPDATE;					/* update interrupts */
if ((ptp_unit.flags & UNIT_ATT) == 0)			/* attached? */
	return IORETURN (ptp_stopioe, SCPE_UNATT);
if (putc (ptp_unit.buf, ptp_unit.fileref) == EOF) {
	perror ("PTP I/O error");
	clearerr (ptp_unit.fileref);
	return SCPE_IOERR;  }
ptp_unit.pos = ptp_unit.pos + 1;
return SCPE_OK;
}

/* Reset routine */

t_stat ptp_reset (DEVICE *dptr)
{
ptp_unit.buf = 0;
dev_done = dev_done & ~INT_PTP;				/* clear done, int */
int_req = int_req & ~INT_PTP;
dev_enable = dev_enable | INT_PTP;			/* set enable */
sim_cancel (&ptp_unit);					/* deactivate unit */
return SCPE_OK;
}

/* Bootstrap routine */

#define BOOT_START 07756
#define BOOT_LEN (sizeof (boot_rom) / sizeof (int))

static const int32 boot_rom[] = {
	06014,				/* 7756, RFC */
	06011,				/* 7757, LOOP, RSF */
	05357,				/* JMP .-1 */
	06016,				/* RFC RRB */
	07106,				/* CLL RTL*/
	07006,				/* RTL */
	07510,				/* SPA*/
	05374,				/* JMP 7774 */
	07006,				/* RTL */
	06011,				/* RSF */
	05367,				/* JMP .-1 */
	06016,				/* RFC RRB */
	07420,				/* SNL */
	03776,				/* DCA I 7776 */
	03376,				/* 7774, DCA 7776 */
	05357,				/* JMP 7757 */
	00000,				/* 7776, 0 */
	05301					/* 7777, JMP 7701 */
};

t_stat ptr_boot (int32 unitno)
{
int32 i;
extern int32 saved_PC;

for (i = 0; i < BOOT_LEN; i++) M[BOOT_START + i] = boot_rom[i];
saved_PC = BOOT_START;
return SCPE_OK;
}
