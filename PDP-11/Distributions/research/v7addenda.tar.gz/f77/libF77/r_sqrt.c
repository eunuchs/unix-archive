double r_sqrt(x)
float *x;
{
double sqrt();
return( sqrt(*x) );
}
