double r_cos(x)
float *x;
{
double cos();
return( cos(*x) );
}
