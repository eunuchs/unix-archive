double r_tanh(x)
float *x;
{
double tanh();
return( tanh(*x) );
}
