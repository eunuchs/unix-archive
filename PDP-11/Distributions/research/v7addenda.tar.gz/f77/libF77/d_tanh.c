double d_tanh(x)
double *x;
{
double tanh();
return( tanh(*x) );
}
