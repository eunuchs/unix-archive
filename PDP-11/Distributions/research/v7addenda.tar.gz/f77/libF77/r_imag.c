#include "complex"

double r_imag(z)
complex *z;
{
return(z->imag);
}
