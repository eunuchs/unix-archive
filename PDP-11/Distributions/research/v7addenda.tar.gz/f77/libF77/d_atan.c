double d_atan(x)
double *x;
{
double atan();
return( atan(*x) );
}
