double r_sinh(x)
float *x;
{
double sinh();
return( sinh(*x) );
}
