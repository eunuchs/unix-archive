double derfc_(x)
double *x;
{
double erfc();

return( erfc(*x) );
}
