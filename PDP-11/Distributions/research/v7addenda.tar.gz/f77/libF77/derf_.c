double derf_(x)
double *x;
{
double erf();

return( erf(*x) );
}
