double r_atan(x)
float *x;
{
double atan();
return( atan(*x) );
}
