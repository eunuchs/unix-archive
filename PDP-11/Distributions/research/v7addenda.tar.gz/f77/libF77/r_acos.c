double r_acos(x)
float *x;
{
double acos();
return( acos(*x) );
}
