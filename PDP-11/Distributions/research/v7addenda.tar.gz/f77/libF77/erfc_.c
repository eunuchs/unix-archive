float erfc_(x)
float *x;
{
double erfc();

return( erfc(*x) );
}
