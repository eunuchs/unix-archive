double d_sqrt(x)
double *x;
{
double sqrt();
return( sqrt(*x) );
}
