double d_asin(x)
double *x;
{
double asin();
return( asin(*x) );
}
