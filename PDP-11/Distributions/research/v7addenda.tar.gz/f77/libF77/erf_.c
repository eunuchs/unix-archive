float erf_(x)
float *x;
{
double erf();

return( erf(*x) );
}
