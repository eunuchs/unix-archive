double d_prod(x,y)
float *x, *y;
{
return( (*x) * (*y) );
}
