double d_atn2(x,y)
double *x, *y;
{
double atan2();
return( atan2(*x,*y) );
}
