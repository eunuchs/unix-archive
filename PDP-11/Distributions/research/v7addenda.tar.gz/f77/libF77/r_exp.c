double r_exp(x)
float *x;
{
double exp();
return( exp(*x) );
}
