long int i_mod(a,b)
long int *a, *b;
{
return( *a % *b);
}
