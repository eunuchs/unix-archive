double d_acos(x)
double *x;
{
double acos();
return( acos(*x) );
}
