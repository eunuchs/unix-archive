double d_cos(x)
double *x;
{
double cos();
return( cos(*x) );
}
