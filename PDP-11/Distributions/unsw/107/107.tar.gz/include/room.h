/*
 *
 *	Associate room name with tgroup bits for TERMBOOK
 */

struct	wlist

#define	NROOM		10

	roomlist[NROOM]
	{
	"11/40"		,	VROOM << 010 | 005	/* f */		,
	"314"		,	VROOM << 010 | 007	/* h */		,
	"318a"		,	VROOM << 010 | 000	/* a */		,
	"318c"		,	VROOM << 010 | 001	/* b */		,
	"343b"		,	VROOM << 010 | 003	/* d */		,
	"343c"		,	VROOM << 010 | 002	/* c */		,
	"343d"		,	VROOM << 010 | 004	/* e */		,
	"agsm"		,	VROOM << 010 | 006	/* g */		,
	"gt40"		,	VROOM << 010 | 010	/* i */		,
	"qume"		,	VROOM << 010 | 011	/* j */
	};

#define	SVIDEO		"Svt"
#define	STELE		"d"
#define	TGRPNULL	'\020'
