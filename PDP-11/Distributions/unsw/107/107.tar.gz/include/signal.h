#define NSIG 20

#define SIGHUP 1
#define SIGINT 2
#define SIGQIT 3
#define SIGQUIT 3
#define SIGINS 4
#define SIGILL 4
#define SIGTRC 5
#define SIGTRAP 5
#define SIGIOT 6
#define SIGEMT 7
#define SIGFPT 8
#define SIGFPE 8
#define SIGKIL 9
#define SIGBUS 10
#define SIGSEG 11
#define SIGSEGV 11
#define SIGSYS 12
#define SIGPIPE 13
#define SIGTERMINATE 14
#define SIGTIMEOUT 15
#define SIGCPUTL 16
#define SIGMEMPAR 17

#define	SIG_DFL	0
#define SIG_IGN	1
