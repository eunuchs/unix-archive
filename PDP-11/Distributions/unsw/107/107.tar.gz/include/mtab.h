/*
 *	Structure to describe contents of mount table.
 *	Note the size is 48 bytes which makes it convenient
 *	when using od and db on mtab.
 */

struct mtab
{
	char	m_spec[15];
	char	m_prot;
	char	m_file[32];
};

char	mtabf[]	"/etc/mtab";
