struct	iobuf
{
	int	fildes,
		nleft;
	char	*next,
		buff[512];
};
