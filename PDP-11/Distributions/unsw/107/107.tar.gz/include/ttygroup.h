/*
 *	terminal group definitions
 */

struct
{
	char	  tchar;	/* this char identifies this terminal group */
	unsigned  tmask;	/* 16 bit mask for this group */
}
tty_groups[]
{
	'a', 0000001,	/* Spare */
	'b', 0000002,	/* Rm 318C */
	'c', 0000004,	/* Rm 343C */
	'd', 0000010,	/* Rm 343B console & vt05 */
	'e', 0000020,	/* 662-1733 dial in line */
	'f', 0000040,	/* Log line from 11/40 */
	'g', 0000100,	/* Log line from AGSM */
	'h', 0000200,	/* Log line from VAX */
	'i', 0000400,	/* Log line from the CSU */
	'j', 0001000,	/* Tektronics gear, Rm 343C */
	'k', 0002000,	/* Qume */
	'l', 0004000,	/* Pete, Kev, Choc */
	'm', 0010000,	/* Spare */
	'n', 0020000,	/* Spare */
	'o', 0040000,	/* EE general office */
	'p', 0100000,	/* Spare */
	'x', 0177777,	/* The lot - any user can use it */
};

#define	NTTYGRPS	(sizeof tty_groups/sizeof tty_groups[0])
