#
/*
 *	The necessary declarations
 */

#include <local-system>
#include	<passwd.h>

char	*etcpasswd	ETCPASSWD;

