extern struct {int op,dnl,dimac,ditrap,ditf,alss,blss,nls,mkline,
		maxl,hnl,curd;} d[NDI];
extern struct {int pn,nl,yr,hp,ct,dn,mo,dy,dw,ln,dl,st,sb,cd;
	int vxx[NN-NNAMES];} v ;
/*static char Sccsid[] "@(#)t.h	1.3 of 4/26/77";*/
