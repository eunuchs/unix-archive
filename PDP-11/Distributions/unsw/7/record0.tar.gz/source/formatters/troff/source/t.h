extern struct {int op,dnl,dimac,ditrap,ditf,alss,blss,nls,mkline,
		maxl,hnl,curd;} d[NDI];
extern struct {int pn,nl,yr,hp,ct,dn,mo,dy,dw,ln,dl,st,sb;
	int vxx[NN-13];} v ;
