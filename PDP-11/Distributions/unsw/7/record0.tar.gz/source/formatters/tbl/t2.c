# include "t..c"
tableput()
{
savefill();
ifdivert();
getcomm();
getspec();
gettbl();
getstop();
checkuse();
choochar();
maktab();
runout();
release();
rstofill();
endoff();
}
