#include	"link.h"

pass2()
{
	register int t;
	register int **pp;
	register char *rr1;
	int mag[8];
	extern	ofd;

	/* if no object desired, skip this phase */
	if(flags&NO)
		return;

	/* initialize input and output */

	if(objyes == NIL)
		objyes = ext(firstfile,".out");
	close(creat(objyes, 0755));
	ofd = open(objyes, 2);
	if(ofd == -1)
		ferror("Cannot create out file.");
	init_in();

	objwrite(-1);

	/* library pointers */

	act_sec = NIL;
	libpnt = libuse;
	whmod = modhead;

	/* main loop on record type */

	while(t=getrec())
	switch(t) {

	case LMOD:
		textdump();
		if(*libpnt++ == 0) {
			slewto(EMOD);
			break;
		}
		slewto(GSD);

	case GSD:
		textdump();
		while((t=getgsd())>=0)
			if(t == MDN) {
				pp = pcorres;
				for(rr1 = whmod->mpsl; rr1 != NIL; rr1 = rr1->pll) {
					*pp++ = rr1;
					if((flags&NS)==0)
						for(t=rr1->plg; t!= NIL; t = t->gglp)
							symout(t->glp->gname,t->glp->gvalue);
				}
			}
		break;

	case TXT:
		textdump();
		movbyte(&load_addr,2);
		text_act = 1;
		rldcount = bcount;
		if(rldcount)
			movbyte(rldbuf,rldcount);
		break;

	case SDR:
		textdump();
		if(flags & (NS|GO))
			break;
		while(getgsd()>=0) {
			if(gsdent.fbyte & 1)
				continue;	/* ignore register declaractions */
			t = gsdent.val;
			if(gsdent.fbyte & REL)
				t =+ pcorres[gsdent.gtype]->llimlow;
			symout(gsdent.nm,t);
		}
		break;

	case RLD:
		rldproc();
		break;

	case PSD:
		textdump();
		psdproc();
		break;

	case EMOD:
		whmod = whmod->mpnt;
	default:
		textdump();
		
	}

	/* now,  seek to start of file and write out magic header */


	mag[0] = flags & P1 ? 0407:
		 flags & ID ? 0411:
			txtsize == 0 ? 0407 : 0410;
	mag[1] = txtsize;
	mag[2] = datsize;
	mag[3] = bsssize;
	mag[4] = symcount * 12;
	mag[5] = mag[6] = 0;
	mag[7] = 1;

	objwrite(3, 0, mag, 16);
	return;

}

textdump()
{
	register struct psectl *p1;
	register struct psect  *p2;
	register int t;
	int stype;

	if(text_act == 0)
		return;

	text_act = 0;
	p1 = act_sec;
	p2 = p1->plp;

	if(p2->pflags & BSS)
		return;
	stype = 0;
	t = p1->llimlow + load_addr;
	if((p2->pflags&SHR)==0) {
		t =- datstart;
		stype++;
	}
	objwrite(stype,t,rldbuf,rldcount);
}

struct	{
	char	sn[8];
	int	fl;
	int	nvl;
} sbb;

symout(np,vl)
int *np;
int vl;
{

	register char *r1,*r2;
	register int t;

	radcon(np, sbb.sn);
	for(r1 = &sbb.sn[6]; r1 > sbb.sn;) {
		if(*--r1 == ' ') *r1 = 0;
		if(*r1 == '$') *r1 = '_';
	}
	sbb.fl = 01;
	sbb.nvl = vl;
	if (symcount > 5400) {
		if (symovr == 0) {
			symovr++;
			printf("symbol table overflow -- ");
			printf("last symbol output was %.6s\n",
				sbb.sn);
		}
	return;
	}
	objwrite(2,12*symcount,&sbb,12);
	symcount++;
}
rldproc()
{
	char	rldtype;
	int	disp;
	int	addrp2;
	register int *q; register char *r;

	while(movbyte(&rldtype,1)) {
		bytflg = 0;
		movbyte(&disp,1);
		disp =& 0377;
		r = rldbuf - 4 + disp;
		addrp2 = disp - 2 + load_addr + act_sec->llimlow;

		if (rldtype & 0200) {
			bytflg = 1;
			rldtype =& 0177;
		}
		switch(rldtype) {
		
		case 1:		setup(r,getcon() + act_sec->llimlow);
				break;
		case 2:		q = ggsearch(getnam());
				setup(r, q->gvalue); break;
		case 3:		setup(r,getcon()-addrp2); break;
		case 4:		q = ggsearch(getnam());
				setup(r,q->gvalue-addrp2); break;
		case 5:		q = ggsearch(getnam());
				setup(r,getcon()+q->gvalue); break;
		case 6:		q = ggsearch(getnam());
				setup(r, getcon()+q->gvalue-addrp2);
				break;
		case 7:		textdump();
				act_sec = getsec(getnam());
		case 8:		textdump();
				getcon(); break;
		case 9:		setup(r,0); setup(r+2,bssstart+bsssize);
				break;
		case 10:	q = getsec(getnam());
				setup(r,q->llimlow); break;
		case 12:	q = getsec(getnam());
				setup(r,q->llimlow-addrp2); break;
		case 13:	q = getsec(getnam());
				setup(r, q->llimlow+getcon()); break;
		case 14:	q = getsec(getnam());
				setup(r,q->llimlow+getcon()-addrp2);
				break;

		}

	}
}



struct global *ggsearch(s)
int *s;
{
	register struct global *q;
	q = gsearch(s);
	if((q->gflags&DEF)==0) {
		printf("Reference of <");
		radout(q->gname);
		printf("> in <");
		radout(whmod->mname);
		printf(">\n");
	}
	return(q);
}

psdproc()
{
	char	keybyte,valmod;
	int	valwd;
	register int *ip,*vp;
	register char *q;

	vp = &clcsym.symval;
	while(movbyte(&keybyte,1)) {
		*vp = 0;
		clcsym.raw[0] = control.cnm[0];
		clcsym.raw[1] = control.cnm[1];
		if(keybyte&CCNAM) {
			movbyte(clcsym.raw,4);
			if(keybyte&CCSEC) {
				*vp = getsec(clcsym.raw)->llimlow;
			} else {
				if(clcsym.raw[0]) {
					q = ggsearch(clcsym.raw);
					*vp = q->gvalue;
				} else
					*vp = oprbuf[clcsym.raw[1] - 1];
			}
		} else
			if(keybyte&CCSEC)
				*vp = control.consec->llimlow;

		if(keybyte&CCVAL) {
			valwd = 0;
			if(keybyte&RBYTE)
				movbyte(&valwd,1);
			else
				movbyte(&valwd,2);
			*vp =+ valwd;
		}

		if(keybyte&CCDSP)
			*vp =- control.conloc + 2;

		if((keybyte&CCOPR)==0) {
			valmod = control.consec->plp->pflags;
			valmod = valmod&BSS ? 2 : valmod&SHR ? 0 : 1;
			valwd = keybyte&RBYTE ? 1: 2;
			if(valmod != 2)
				objwrite(valmod,control.conloc-(valmod==1 ? datstart : 0),vp,valwd);
			control.conloc =+ valwd;
			continue;
		}

		movbyte(&keybyte,1);
		if(keybyte&RBYTE)
			keybyte =& ~RBYTE;
		else {
			if(keybyte) {
				switch(keybyte) {
			
				case 1:	*vp = 0; break;
				case 2:	*vp = bssstart + bsssize; break;
				case 3: movbyte(clcsym.raw,4);
					q = getsec(clcsym.raw);  *vp = q->plp->plimlow; break;
				case 4: movbyte(clcsym.raw,4);
					q = getsec(clcsym.raw);  *vp = q->plp->plimhigh; break;
				case 5:	*vp = ~ *vp; break;
				case 6:	*vp = - *vp; break;

				}
				keybyte = 0;
			} else {
				control.consec = getsec(clcsym.raw);
				control.conloc = *vp;
				control.cnm[0] = clcsym.raw[0];
				control.cnm[1] = clcsym.raw[1];
				continue;
			}
		}

		movbyte(&valmod,1);
		ip = &oprbuf[valmod - 1];

		switch(keybyte) {

		case 0:	*ip = *vp; break;
		case 1:	*ip =+ *vp; break;
		case 2:	*ip =- *vp; break;
		case 3:	*ip =* *vp; break;
		case 4:	*ip =/ *vp; break;
		case 5:	*ip =& *vp; break;
		case 6:	*ip =| *vp; break;

		}
	}
}

