/* New librarian for fortran linker
 * J. N. Rottman
 */

#define	GOBBLE	512
#define	BUFSIZ	512
#define	BINSIZ	132
#define	NIL	0

#define	ACT_INF	1
#define	ACT_CLS	2
#define	ACT_DEL	3
#define	ACT_PAS	4

#define	COMMAND	0
#define	ARGUMENT 1


#define	SHR	01
#define	INS	02
#define	BSS	04
#define	DEF	010
#define	REL	020
#define	OVR	040
#define	GBL	0100
#define	EXC	0200

#define	GSD	01
#define	ESD	02
#define	TXT	03
#define	RLD	04
#define	ISD	05
#define	EMOD	06
#define	LMOD	07
#define	PSD	017
#define	SDR	022
#define	EDR	021


#define	MDN	0
#define	CSN	1
#define	ISN	2
#define	TRA	3
#define	GSN	4
#define	PSN	5
#define	PVI	6

struct	buf	{
	int	fildes;
	int	nonused;
	char	*nxtfree;
	char	buff[BUFSIZ];
	struct	buf	*nxtbuf;
} inbuf;

struct	gsd	{
	int	gsdnm[2];
	char	fb;
	char	ft;
	int	gv;
} gsd;

int	bcount;
char	*bpoint;
char	binbuf[BINSIZ];

struct	und	{
	int	*undg;
	struct	und	*undund;
};

struct	imp	{
	int	*impmod;
	struct	imp	*impimp;
};


struct	glist	{
	int	gn[2];
	struct	glist	*gb;
	struct	glist	*gf;
};

struct	file	{
	struct	buf	*fbb;
	char	fn[66];
};

struct	mod	{
	int	mn[2];
	int	mv[2];
	int	ma;
	struct	file	*mff;
	struct	glist	*mg;
	struct	mod	*mb;
	struct	mod	*mf;
	struct	glist	*mr;
};

#define	S_MOD	20
#define	S_GLIST	8
#define	S_FILE	68

struct	mod	*command;
struct	file	*libfile;

int	index;
int	iargc;
char	**iargv;

int	creff;
char	*memlow;
char	*memhigh;

#define	GLOBAL	1
#define	DELETE	2
#define	INSERT	3
#define	REPLACE	4
#define	APPEND	5
#define	LIST	6
#define	CREF	7

struct	mod *makelist();
char	*rawitem();
char	*getcore();
