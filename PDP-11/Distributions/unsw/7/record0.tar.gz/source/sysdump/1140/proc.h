/*
 * One structure allocated per active
 * process. It contains all data needed
 * about the process while the
 * process may be swapped out.
 * Other per process data (user.h)
 * is swapped with the process.
 */
struct	proc
{
	char	p_stat;
	char	p_flag;
	char	p_pri;		/* priority, negative is high */
	char	p_sig;		/* signal number sent to this process */
	char	p_uid;		/* user id, used to direct tty signals */
	char	p_time;		/* resident time for scheduling */
	char	p_cpu;		/* cpu usage for scheduling */
	char	p_nice;		/* nice for scheduling */
	int	p_ttyp;		/* controlling tty */
	int	p_pid;		/* unique process id */
	int	p_ppid;		/* process id of parent */
	int	p_addr;		/* address of swappable image */
	int	p_size;		/* size of swappable image (*64 bytes) */
	int	p_wchan;	/* event process is awaiting */
	int	*p_textp;	/* pointer to text structure */
#ifdef	NEW_SLEEP
	unsigned p_stl;		/* count of secs left of sleep time */
#endif
#ifdef	TIME_LIMITS
	unsigned p_rtl;		/* count of secs left of real time limit */
#endif
} proc[NPROC];

/* stat codes */
#define	SSLEEP	1		/* sleeping on high priority */
#define	SWAIT	2		/* sleeping on low priority */
#define	SRUN	3		/* running */
#define	SIDL	4		/* intermediate state in process creation */
#define	SZOMB	5		/* intermediate state in process termination */
#define	SSTOP	6		/* process being traced */

/* flag codes */
#define	SLOAD	01		/* in core */
#define	SSYS	02		/* scheduling process */
#define	SLOCK	04		/* process cannot be swapped */
#define	SSWAP	010		/* process is being swapped out */
#define	STRC	020		/* process is being traced */
#define	SWTED	040		/* another tracing flag */


#ifdef	ZOMBIE
struct	pzomb
{
	char	pz_stat;
	char	pz_flag;
	char	pz_pri;		/* priority, negative is high */
	char	pz_sig;		/* signal number sent to this process */
	int	pz_ur0;		/* returned status */
	char	pz_cpu;		/* cpu usage for scheduling */
	char	pz_nice;		/* nice for scheduling */
	int	pz_ttyp;		/* controlling tty */
	int	pz_pid;		/* unique process id */
	int	pz_ppid;		/* process id of parent */
	long	pz_utime;					   /* fix000 */
	long	pz_stime;	/* times returned from process */  /* fix000 */
};
#endif
