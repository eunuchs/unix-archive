main()
{
extern fout;

	register line;
	register char c;

	fout = dup(1);

	line = 1;
	printf("%6d\t",line);
	while ( c = getchar() )
		{
		putchar(c);
		if (c != '\n') continue;
		line++;
		printf("%6d\t",line);
		}
	flush();
}
