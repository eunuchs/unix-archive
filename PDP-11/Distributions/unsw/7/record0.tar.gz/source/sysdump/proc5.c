/* other routines */

#include "proc.h"

getuser(uid)
int	uid;
{
	register char *p;

	if (getpw(uid, wkbuf) != 0)
		return("unknown");
	for (p = wkbuf; *p != ':'; p++);
	*p = '\0';
	return(wkbuf);
}

bomb()
{
	/* signal handler
	 *
	 * at present just flush with message
	 *
	 */
	crash("unexpected termination. output flushed");
}

ttydecode(ttyp)
int	*ttyp;
{
	printf("ttydecode was passed %o\n", ttyp);
	printf("this routine is not yet implemented\n\n");
}

idecode(adr)
char	*adr;
{
	printf("idecode passd %o\n", adr);
	printf("this routine not yet implemented\n");
}

filedecode(adr)
char	*adr;
{
	printf("filedecode passed %o\n", adr);
	printf("this routine not yet implemented\n");
}

textdecode(ptr)
int	*ptr;
{
	printf("textdecode passed %o\nnot yet implemented\n\n", ptr);
}

treedecode(ptr)
int	ptr;
{
	printf("treedecode passed %o\nnot yet implemented\n\n", ptr);
}
