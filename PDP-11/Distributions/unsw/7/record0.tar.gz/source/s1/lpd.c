#
/*

	l p d  in a key of c

*/

#define	lpddir	"/tmp/lpd"

 
 
 
 
	int	desp;		/* file desc. of lp */
	int	elp	0;	/* cancel print flag */
	int	repf	0;	/* print repeated */
	int	batch;		/* batch printout */
	char	lock[]	"lock";
	struct	dirbuf {
			int d_ino;
			char d_name[14];
		} dbuf[2];

	char	m1[]	"\n\n\n *** print restarted by operator ***\n";
	char	m2[]	"\n\n\n *** print cancelled by operator ***\n";
#define NEJECT 4

int comdir;

eflag()
{
	signal(5,eflag);
	elp=1;
}
restart()
{
	signal(6, restart);
	elp = 2;
}
repeat()
{
	signal(7, repeat);
	repf++;
}
comp(s1,s2)
char *s1,*s2;
{
	register char *c1,*c2;

	c1 = s1; c2 = s2;
	while( (*c1 == *c2) && *c1) c2++,c1++;
	return(*c1 - *c2);
}

next()
{
	register struct dirbuf *d1,*d2;
	register i;

	seek(comdir, 32, 0);	/* skip . .. */
	d1 = &dbuf[0];
	d2 = &dbuf[1];
	d1->d_ino = 0;
	while( read(comdir,d1,16))
		if(d1->d_ino) break;
	if(!d1->d_ino) return(0);
	while( read(comdir,d2,16))
	{
		if(!d2->d_ino) continue;
		if(comp( &(d1->d_name[2]), &(d2->d_name[2])) > 0)

		{
			d2->d_ino = d1;
			d1 = d2;
			d2 = d1->d_ino;
		}
	}
	d1->d_ino = 'x/';
	return( d1);
}

main()
{
	register z,df;
	register char *buf;
	char	*dn;
	int desr,push,ncopies,ncsave,isban;
	char lastban[20];
	char buff[512];


	elp = 0; buf = buff;
	signal(1,1); signal(2,1); signal(3,1);
	signal(5,eflag);
	signal(6,restart);
	signal(7,repeat);

	z = 16;
	do close( --z); while(z);
	if( (chdir(lpddir) < 0) || (!stat(lock,buf)) ||
		((z = creat(lock,0)) < 0))
		exit();
	if(((comdir = open("x",0)) < 0) || !(dn = next()))
	{
		unlink(lock);
		exit();
	}
	if(desp = fork())
	{
		write(z,&desp,2);
		exit();
	}
	close(z);	/* daemon now ready to print */
	while((desp = open("/dev/lp",1)) < 0) sleep(10);
begin:
	do
	{
		push = isban = batch = repf = 0;
		ncopies = ncsave = 1;
		df = open(dn, 0);
		while(read(df,buf,40) == 40 )
		{
			buf[40] = 0;
			ncopies = ncsave;
			switch( (z = buf[0] | 040))
			{
		    case 'f':
				if((desr = open( &buf[1], 0)) < 0)
					break;
				do
				{
					write(desp,"\014",1);
					seek(desr,0,0);
					while((z = read(desr,buf,512)) && !elp)
						write(desp,buf,z);
					if( repf)
					{
						ncopies++;
						ncsave++;
						repf--;
					}
					if(elp == 2)
					{
						elp = repf = 0;
						seek(df, 0, 0);
						write(desp, m1, sizeof m1);
						ncopies = ncsave;
						if( isban) banner(lastban);
					}
				}
				while( --ncopies && !elp);
				close(desr);
				break;
		    case 'b':	batch++;
		    case 'l':	banner(&buf[1]);
				isban++;
				z = 0;
				while( (z<20) && (lastban[z++] = buf[z]));
				lastban[z] = 0;
				break;
		    case 'u':	unlink(&buf[1]);
				break;
		    case 'n':	ncopies = atoi(&buf[1]);
				if(ncopies <= 0) ncopies = 1;
				ncsave = ncopies;
				break;
		    case 'p':	push++;
				break;
		    case 'm':	{
					static char ttyname[] "/dev/tty?";
					ttyname[8] = buf[1];
					z = open(ttyname,1);
					write(z,"\007\n",2);
					prints(z,&buf[2]);
					prints(z,": lpd finished\n");
					close(z);
					break;
				}
			}
			if(elp)
			{
				write(desp, m2, sizeof m2);
				elp = 0;
			/*	break;	*/
			}
		}
		close(df);
		unlink(dn);
	} while( dn = next());
	sleep(10);
	if(dn = next()) goto begin;
	if( push)
		write(desp,"\001\014\001\014\001\014\001\014\001\014\001\014",2*NEJECT);
	unlink(lock);
}






	char m3[]
"\013\376\210\r\376\210\r\014\n\n\n\n\n\377\020unix edition-6 local print\n\n\377\060";
	char m4[]
"\377\000*****                     \n\n" ;
	char header[]
"\n\n\t\t\t\tUnix Note\n\n\n";

banner(s)
char *s;
{
	register char *i,*j;
	write(desp,m3,sizeof m3);
	write(desp,ijtime(),24);
	write(desp,header,2);
	i = &m4[8];
	for(j = s; *j && i < &m4[28] ; ) *i++ = *j++;
	*i++ = '\n'; *i++ = '\n';
	for(m4[1] = 40; m4[1] < 52; m4[1]++)
		write(desp,m4,i-m4);
	note(batch ? "batchnote" : "unixnote");
	write(desp,m3,8);
}



note(s)
char *s;
{
	int notebuf[256];
	register ndes,nbuf;

	nbuf = notebuf;
	if((ndes = open(s,0)) < 0) return;
	write(desp,header,sizeof header);
	while( write(desp,nbuf,read(ndes,nbuf,512)) == 512 );
	close(ndes);
}
