	char buf[1024];
main(){
	register fd,n;
	if( (fd=open("/etc/help.info",0))<0 ) exit();
	while( (n=read(fd,buf,sizeof buf))>0 ) write(1,buf,n);
}
