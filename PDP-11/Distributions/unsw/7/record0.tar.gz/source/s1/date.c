#ifndef unsw_orig
long	time();
long	timbuf;
#endif
#ifdef unsw_orig
int	timbuf[2];
#endif
char	*cbp;

#ifdef unsw_orig
char *tzname[2];
#endif
int	dmsize[];
char	cbuf[];
char	*cbp;

struct {
#ifndef unsw_orig
	char	w_code;
	char	w_uid;
	int	w_pgrp;
	long	w_ortime;
	long	w_nrtime;
	long	w_trash;
} wtmp;
#endif
#ifdef unsw_orig
	char	name[8];
	char	tty;
	char	fill1;
	int	wtime[2];
	int	fill2;
} wtmp[2];
#endif

main(argc, argv)
int argc, **argv;
{
	register char *tzn;
#ifndef unsw_orig
	extern int *localtime();
#endif
#ifdef unsw_orig
	extern int timezone, *localtime();
#endif
	int wf;

	if(argc > 1) {
		cbp = argv[1];
		if(gtime()) {
			write(1, "bad conversion\n", 15);
#ifndef unsw_orig
			exit(1);
#endif
#ifdef unsw_orig
			exit();
#endif
		}
#ifndef unsw_orig
		wtmp.w_ortime = time();
		wtmp.w_code = 4;
#endif
#ifdef unsw_orig
		if (*cbp != 's') {
	/* convert to Greenwich time, on assumption of Standard time. */
			dpadd(timbuf, timezone);
	/* Now fix up to local daylight time. */
			if (localtime(timbuf)[8])
				dpadd(timbuf, -1*60*60);
		}
		time(wtmp[0].wtime);
		wtmp[0].tty =  '|';
#endif
		if(stime(timbuf) < 0) {
			write(1, "no permission\n", 14);
		} else if ((wf = open("/usr/adm/wtmp", 1)) >= 0) {
#ifndef unsw_orig
			wtmp.w_nrtime = time();
#endif
#ifdef unsw_orig
			time(wtmp[1].wtime);
			wtmp[1].tty = '}';
#endif
			seek(wf, 0, 2);
#ifndef unsw_orig
			write(wf, &wtmp, sizeof wtmp);
#endif
#ifdef unsw_orig
			write(wf, wtmp, 32);
#endif
		}
	}
#ifndef unsw_orig
	timbuf = time();
#endif
#ifdef unsw_orig
	time(timbuf);
#endif
	cbp = cbuf;
	ctime(timbuf);
	write(1, cbuf, 20);
#ifndef unsw_orig
	write(1, "Sydney Time", 11);
#endif
#ifdef unsw_orig
	tzn = tzname[localtime(timbuf)[8]];
	if (tzn)
		write(1, tzn, 3);
#endif
	write(1, cbuf+19, 6);
}

gtime()
{
	register int i;
	register int y, t;
	int d, h, m;
	extern int *localtime();
#ifdef unsw_orig
	int nt[2];
#endif

	t = gpair();
	if(t<1 || t>12)
		goto bad;
	d = gpair();
	if(d<1 || d>31)
		goto bad;
	h = gpair();
	if(h == 24) {
		h = 0;
		d++;
	}
	m = gpair();
	if(m<0 || m>59)
		goto bad;
	y = gpair();
#ifndef unsw_orig
	if(y<0)
		y = localtime(time())[5];
#endif
#ifdef unsw_orig
	if (y<0) {
		time(nt);
		y = localtime(nt)[5];
	}
#endif
	if (*cbp == 'p')
		h =+ 12;
	if (h<0 || h>23)
		goto bad;
#ifndef unsw_orig
	timbuf = 0;
#endif
#ifdef unsw_orig
	timbuf[0] = 0;
	timbuf[1] = 0;
#endif
	y =+ 1900;
	for(i=1970; i<y; i++)
#ifndef unsw_orig
		timbuf =+ dysize(i);
#endif
#ifdef unsw_orig
		gdadd(dysize(i));
#endif
	/* Leap year */
	if (dysize(y)==366 && t >= 3)
#ifndef unsw_orig
		timbuf++;
#endif
#ifdef unsw_orig
		gdadd(1);
#endif
	while(--t)
#ifndef unsw_orig
		timbuf =+ dmsize[t-1];
	timbuf =+ d-1;
	timbuf = timbuf*24 + h;
	timbuf = timbuf*60 + m;
	timbuf =* 60;
#endif
#ifdef unsw_orig
		gdadd(dmsize[t-1]);
	gdadd(d-1);
	gmdadd(24, h);
	gmdadd(60, m);
	gmdadd(60, 0);
#endif
	return(0);

bad:
	return(1);
}

#ifndef unsw_orig
gpair()
#endif
#ifdef unsw_orig
gdadd(n)
#endif
{
#ifndef unsw_orig
	register int c, d;
	register char *cp;
#endif
#ifdef unsw_orig
	register char *t;
#endif

#ifdef unsw_orig
	t = timbuf[1]+n;
	if(t < timbuf[1])
		timbuf[0]++;
	timbuf[1] = t;
}

gmdadd(m, n)
{
	register int t1;

	timbuf[0] =* m;
	t1 = timbuf[1];
	while(--m)
		gdadd(t1);
	gdadd(n);
}

gpair()
{
	register int c, d;
	register char *cp;

#endif
	cp = cbp;
	if(*cp == 0)
		return(-1);
	c = (*cp++ - '0') * 10;
	if (c<0 || c>100)
		return(-1);
	if(*cp == 0)
		return(-1);
	if ((d = *cp++ - '0') < 0 || d > 9)
		return(-1);
	cbp = cp;
	return (c+d);
}
