error(s)
char *s;
{
	printf("ERROR:	%s\n",s);
	exit(-1);
}
main(argc,argv)
char **argv;
{
	register i,k; int r;
	if( argc!=2 ) error("one argument needed - to specify line number");
	if( argv[1][0] == '1' ) k=0175610;
	else if( argv[1][0] == '2' ) k=0175620;
	     else error("invalid line number, only 1 or 2 allowed");
	if( (i=open("/dev/kmem",2))<0 ) error("unable to open /dev/kmem");;
	seek(i,k,0); read(i,&r,2);
	if( argv[0][0] == 'c' ){
		if( r&02 ) error("modem already connected");
		r =| 02;
	} else {
		if( !(r&02) ) error("modem not connected");
		r =& 0177775;
	}
	seek(i,k,0); write(i,&r,2);
}
