/*
 *	create - create specified files
 */
main( argc, argv ) char **argv;
{
	register i;

	if( argc<2 ){
		prints(2, "Usage: create file ...\n");
		exit(1);
	}

	for( i=1; i<argc; i++ )
		if( creat(argv[i], 0606)<0 ){
			prints(2, argv[i]);
			prints(2, ": Can't create\n");
		}
}
