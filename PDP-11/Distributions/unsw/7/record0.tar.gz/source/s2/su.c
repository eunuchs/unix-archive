/* su -- become super-user */

#ifndef unsw_orig
char	password[65];
#endif
#ifdef unsw_orig
char	password[100];
#endif
char	pwbuf[100];
int	ttybuf[3];
main()
{
	register char *p, *q;
	extern fin;

	if(getpw(0, pwbuf))
		goto badpw;
	(&fin)[1] = 0;
	p = pwbuf;
	while(*p != ':')
		if(*p++ == '\0')
			goto badpw;
	if(*++p == ':')
		goto ok;
	gtty(0, ttybuf);
	ttybuf[2] =& ~010;
	stty(0, ttybuf);
	printf("password: ");
	q = password;
	while((*q = getchar()) != '\n')
#ifndef unsw_orig
		if((*q++ == '\0')||(q>&password[64]))
#endif
#ifdef unsw_orig
		if(*q++ == '\0')
#endif
			return;
	*q = '\0';
	ttybuf[2] =| 010;
	stty(0, ttybuf);
	printf("\n");
	q = crypt(password);
	while(*q++ == *p++);
	if(*--q == '\0' && *--p == ':')
		goto ok;
	goto error;

badpw:
	printf("bad password file\n");
#ifndef unsw_orig
	goto error;	/* ian j july 1976 */
			/* no super user default */
#endif
ok:
	setuid(0);
	execl("/bin/sh", "-", 0);
	printf("cannot execute shell\n");
error:
	printf("sorry\n");
}
