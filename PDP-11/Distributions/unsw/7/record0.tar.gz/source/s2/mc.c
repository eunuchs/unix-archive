/*
 * C [-line width] [+blank count] [filename]
 *
 *	temp file creation made unique
 *	prior scheme did not work
 *				ian j
 */

/*
 * Much of the complications in this program
 * comes from trying to optimize the I/O.
 */

char proto[] { "/tmp/mcaXXXXX" };

char iobuf[512];

main( argc,argv )
	char *argv[];
	{
	extern interrupt();
	register char *bp, *be;
	register lw;
	int line_width, blank_count, biggest, n_a_line;
	int input, output, cp, lc, buffer_size;
	char *arg, *blank;

	line_width = 80;
	blank_count = 2;
	while( argc-- > 1 ){
		arg = argv[argc];
		switch( *arg ){
		case '-':
			line_width = number( &arg[1] );
			continue;
		case '+':
			blank_count = number( &arg[1] );
			continue;
			}

		close( 0 );
		if( open(arg,0) < 0 )
			error("Can't open '%s'\n",arg);
		}

	if( (output=creat(mktemp(proto),0444)) < 0 )
		error("Can't get temp file\n");
	signal(2,&interrupt);
	lw = biggest = 0;

	while( buffer_size = read(0,iobuf,512) ){
		be = &iobuf[buffer_size];
		bp = &iobuf[0];
		while( bp<be )
			if( *bp++ == '\n' ){
				biggest = max(biggest,lw);
				lw = 0;
				}
			else
				lw++;
		write(output,iobuf,buffer_size);
		}

	n_a_line = ( line_width-1 ) / ( biggest=+blank_count );
	blank = sbrk(biggest);
	be = &blank[biggest];
	bp = &blank[0];
	while( bp<be ) *bp++ = ' ';
	close( 0 );
	close( output );
	input = open(proto,0);
	lw = cp = 0;

	while( buffer_size = read(input,iobuf,512) ){
		be = &iobuf[buffer_size];
		bp = lc = &iobuf[0];
		while( bp<be ){
			if( *bp=='\n' ){
				write(1,lc,bp-lc);
				if( ++cp >= n_a_line ){
					putchar('\n');
					cp = 0;
					}
				else 
					write(1,blank,biggest-(bp-lc+lw));
				lw = 0;
				lc = bp+1;
				}
			bp++;
			}
		if( be-lc ){
			write(1,lc,be-lc);
			lw =+ be-lc;
			}
		}
	if( cp ) putchar('\n');
	unlink(proto);
	}

max( a,b )
	{
	if( b<a ) return( a );
	return( b );
	}

copy( in,out )
	char *in, *out;
	{
	register char *i, *o;
	i = in;
	o = out;
	while( *o++ = *i++ );
	return( out );
	}

interrupt(){
	unlink(proto);
	exit();
	}

number( s )
	char *s;
	{
	register c;
	register char *sp;
	c = 0;
	sp = s;
	while( *sp>='0' && *sp<='9' ) c = c*10 + *sp++ - '0';
	if( *sp!='\0' )
		error("%s: illegal numeric\n",s);
	return( c );
	}

error( format,a1,a2,a3 ){
	extern fout;
	fout = 2;
	printf( format,a1,a2,a3 );
	exit();
	}
