	/*
	 *	this creation just reads raw tape file specified as
	 *	1st argument.  it then reports on record size etc.  on
	 *	double tapemark it stops.
	 */

char buf[25000];
int flag 0;

catch()
{
flag = 1;
}

main(argc,argv)
int argc;char **argv;
{
	char register *iold,*i,*nrec;	int infd;
	signal(1,catch);
	signal(2,catch);
	signal(3,catch);
	if(argc!=2) { printf("arg count !!\n"); exit(); }
	if( (infd=open(argv[1],0))<0 ) {
		printf("CAN'T open %s\n",argv[1]);
		exit(-1);
	}
	nrec=0;
	iold=read(infd,buf,sizeof buf);
	for(;;){
		nrec++;
		i=read(infd,buf,sizeof buf);
		if(i==iold && i==0) goto fini;
		if(i==iold) continue;
		if(iold) {
			if(iold!=0177777) printf("%6.6l. * %6.6o(%6.6l.)\n",
							nrec,iold,iold);
			else {
				printf("%6.6l. *  ERR  \n",nrec);
				if(nrec>1) exit();
			}
		} else {
			printf("\tTM\n");
			if(nrec>1) exit();
		}
		nrec=0; iold=i;
	}
 fini: 	printf("\tEOT\n");
}
