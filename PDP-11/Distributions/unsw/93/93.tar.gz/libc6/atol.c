/*
 *	pdp11 version of atol
 */

long atol(s)
register char *s;
{
	register long result;
	register sign;

	sign = 0;
	while((*s == ' ') || (*s == '\t')) s++;
	if(*s == '-')
	{
		sign++;
		s++;
	}
	result = 0;
	while ((*s >= '0') && (*s <= '9'))
		result = result * 10 + *s++ - '0';

	if (sign)
		return(-result);
	else
		return(result);
}
