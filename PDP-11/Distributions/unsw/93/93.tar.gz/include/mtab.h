/*
 *	Structure to describe contents of mount table.
 *	Note the size is 48 bytes which makes it convenient
 *	when using od and adb on mtab.
 */

struct mtab
{
	char	m_spec[15];	/* b-special, less the /dev/ */
	char	m_prot;
	char	m_file[32];	/* what it is mounted on */
};

#define	MTABF	"/etc/mtab"
