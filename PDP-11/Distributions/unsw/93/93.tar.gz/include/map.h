/*
 * Structure of the coremap and swapmap
 */
struct map
{
	short	m_size;
	unsigned short m_addr;
};
