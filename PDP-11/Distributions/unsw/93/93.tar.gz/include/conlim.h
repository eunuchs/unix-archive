/*
**	mapping of classes to connect time limits
*/

time_t	conlims[] =
{
	 3*60*60	/* cs1 */
	,4*60*60	/* cs2 */
	,6*60*60	/* cs3 */
	,0		/* hons */
	,6*60*60	/* dip */
	,0		/* pgrad */
	,3*60*60	/* cm */
	,0		/* eng */
};

#define	NCONLIMS	((sizeof conlims)/(sizeof conlims[0]))

#define	CONINHR		8			/* start for connect control */
#define	CONINWDAY	1		/*   "    "     "       "    */
#define	CONOUTHR	16		/* end for connect control */
#define	CONOUTWDAY	6		/*  "   "     "       "    */
