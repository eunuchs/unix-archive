/*	terminal group definitions	*/

struct tergrp
{
	char		tg_char;	/* this char identifies this terminal group */
	tmask_t		tg_mask;	/* 16 bit mask for this group */
}
	tty_groups[] =
{
	'a', 0000001,	/* spare */
	'b', 0000002,	/* 318c */
	'c', 0000004,	/* 343d (staff) */
	'd', 0000010,	/* console + vt05 */
	'e', 0000020,	/* dial-in */
	'f', 0000040,	/* 11/40 log line */
	'g', 0000100,	/* spare */
	'h', 0000200,	/* VAX log line */
	'i', 0000400,	/* CSU log line */
	'j', 0001000,	/* tektronics stuff */
	'k', 0002000,	/* qume */
	'l', 0004000,	/* 343e */
	'm', 0010000,	/* DSL log line */
	'n', 0020000,	/* comms room 423 */
	'o', 0040000,	/* school office */
	'p', 0100000,	/* spare */
	'x', 0177777,	/* The lot - any user can use it */
};

#define	NTTYGROUPS	(sizeof tty_groups/sizeof tty_groups[0])
