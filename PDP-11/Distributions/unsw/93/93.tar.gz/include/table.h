/*
 * getaddr system call interface
 */
#define	G_PROC	0
#define	G_TEXT	1
#define	G_INODE	2
#define	G_FILE	3
#define	G_MOUNT	4
#define	G_SWPLO	5
#define	G_SWPDV	6

struct table
{
	char	*tb_addr;	/* core-address of the table */
	unsigned tb_size;	/* size of each element */
	unsigned tb_num;	/* number of elements */
};
