main()
{
	char *p;
	int decpt, sign;

	p = ecvt(1.0, 16, &decpt, &sign);
	printf("p=%o decpt=%d sign=%d str=%s\n", p, decpt, sign, p);
}
