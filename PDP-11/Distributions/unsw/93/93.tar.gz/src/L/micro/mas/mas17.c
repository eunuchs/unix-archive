#include	"mas0.h"

#include	"table1"			/* mod023 */

struct aform abuf[128];

struct iform ibuf[128];


int hashtab[128];		/* hash table for initial addresses of local labels */

struct symbol symtab[NSYMBOL];		/* mod008 */
struct fb fbtable[NFB];			/* mod008 */
int curfb[20];

char symbuf[18];
char tsymbuf[32];
