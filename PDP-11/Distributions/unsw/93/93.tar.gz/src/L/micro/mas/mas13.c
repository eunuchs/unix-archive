#

#include	"mas0.h"

FILE	*input;
char	*fins;			/* mod011 */
int	errc, lc;		/* mod011 */
extern FILE * tsav;
extern char * tsavfn;
extern short tsavlc;
extern	struct aform aout;

extern	char symbuf[], tsymbuf[32];		/* mod011 */
extern	struct segment segopt;
extern	char getnonbl();
extern	char getch();
extern	ppc, pc_def;
extern	struct evalx r;
extern	lab;
extern	char tch;
extern jmp_buf env;



pseudop(opc)
{
	register n;
	register char c;
	register int *tp;
	int *ip;
	char *tcp;

	switch (opc)
	{
    case o_SEG:	if (segopt.segcount == 0) segerr();
		segopt.segcount++;
		return;

    case o_EQU:	if (! lab) syntax();
		getexpr();
		evalexpr();
		if (r.r_type != ABS)	/* und, exp or est */
			outaform(a_EQU+lab);
		equsym(lab);
		return;

    case o_ORG:	if (lab) syntax();
		getexpr();
		evalexpr();
		if (r.r_type == UND) relerr("rel 3");		/* mod018 */
		pass1a();
		newif(i_REL);
		evalexpr();
		if (r.r_type != ABS) syserr(1);			/* mod018 */
		ppc = r.r_val;
		pc_def = ABS;
		return;

    case o_FCB:	ppc =+ getlis();
		return;

    case o_FDB:	ppc =+ getlis() << 1;
		return;

    case o_FCC:	if ((c = getnonbl()) != SLASH) syntax();
		while ((c = getc(input)) != SLASH)		/* mod010 */
		{
			if (c == SLOSH && nonspec(getc(input))) ppc++;	/* mod010 */
			if (c == NL) syntax();
			if (c == EOF) eoferr();
			ppc++;
		}
		return;

    case o_RMB:
    case o_ZMB:	getexpr();
		evalexpr();
		if ((n = r.r_type) == UND) relerr("rel 1");	/* mod018 */
		if (n != ABS)
		{
			pass1a();
			evalexpr();
		}
		if (r.r_type != ABS) syserr(2);			/* mod018 */
		if ((n = r.r_val) < 0) relerr("rel 2");		/* mod018 */
		ppc =+ n;
		return;

    case o_TXT:	if (tsav != NULL) txterr();		/* mod011 */
		c = getnonbl();
		tcp = tsymbuf;
		while (c != SP && c != TAB && c != NL)
		{
			*tcp++ = c;
			if (tcp >= &tsymbuf[sizeof tsymbuf]) txterr();
			c = getc(input);
		}
		*tcp = '\0';
		tch = c; getcomm();
		tsavlc = lc;
		tsavfn = fins;
		tsav = input;
		if ((input = fopen(fins = tsymbuf, "r")) == NULL) txterr();
		lc = errc = 0;
		longjmp(env);
	}
}



nonspec(c)
register char c;
{
	if    (c == SLASH ||
		c == SLOSH ||
		c == 'n' ||
		c == 't' ||
		c == 's' ||
		c == '0' ||
		c == 'r' ||		/* mod004 */
		c == 'b')		/* mod004 */
			return(0);
	return(1);
}
