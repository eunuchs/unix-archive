#

#include	"mas.h"


extern struct mnems mnem[];
extern  type, opct;
extern struct symbol symtab[];
extern hashtab[];
extern struct segment segopt;
extern int numsym;
extern char symbuf[];




mnemlook()
{
register struct mnems *m;
	m = mnem;
	while(m->mtyp)
		if((m->mn[0] == symbuf[0]) && (m->mn[1] == symbuf[1]) &&
			(m->mn[2] == symbuf[2]) &&
			(((symbuf[3] == '\0') && (m->mn[3] == '\0')) ||
		   ((m->mn[3] == symbuf[3]) && (symbuf[4] == '\0'))))
		   {type = m->mtyp; opct = m->mopc; return(m->mtyp);}
		else
		   m++;
	type = o_BAD; return(0);
}



lookup()
{
register j;
register struct symbol *sym  ;
register char *s;
char loc;

	loc = 0;
	s = symbuf;
	if ( (j = segopt.segtype) == 1 ) {
		if ( *s == segopt.segchar ) {
			loc = segopt.segcount;
			s++;
		}
	}
	else
	if ( j == 2 ) {
		if ( *s == segopt.segchar )
			s++;
		else
			loc = segopt.segcount;
	}

	j = hashtab[ hash(s) ];
	do {
		sym = &symtab[j];
		if ( (sym->s_seg == loc) && compar(&sym->s_name[0],s) )
			return(j);
	}	while ( (j = sym->s_chain) != 0 );
	write(2, "lookup\n", 7);
	syserr();
}
 
 
 
hash(a)
char *a;
{
register char *s;
register char c;
register h;
	h = 0;
	s = a;
	while ( (c = *s++) != '\0' )
		h += (c - 61) * 29;
	if (h < 0)
		h = -h;
	return( h % 127 );
}
 
 
 
compar(a1, a2)
char *a1, *a2;
{
register char *s1, *s2;
register char c;
int	i;
	s1 = a1;
	s2 = a2;
	i = 0;

	while ( (c = *s1++) == *s2++ )
		if(( ++i == 8) || ( c == '\0' ))
			return(1);
	return(0);
}
