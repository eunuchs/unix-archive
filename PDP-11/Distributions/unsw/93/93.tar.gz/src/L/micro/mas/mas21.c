#


#include	"mas0.h"


char	*symtmp, *fbtmp, *itmp, *ltmp;
int	sfile, fbfile, ifile;

struct	iform *iptr;
int	icount;
extern	struct iform ibuf[];

FILE * list;
char	line[], *linep;

int	obfile;

FILE *input;
FILE *tsav;
char *tsavfn;
int   tsavlc;
extern	struct symbol symtab[];
extern	char maddr[];
extern	int mcode[];
extern	hashtab[];
extern	struct fb fbtable[];
extern	curfb[];
extern	char symbuf[];
extern	bytec;		/* mod001 */

int	gargc;
char	**gargv;


int	numsym;
int	lab, undef;

struct	segment segopt;

int	nextfb;

char	*fins;
int	qcompar();


int	peekc;
int	npc, spc, ppc;
int	lc, errc;
int	operand;




mexit()				/* mod002 */
{
	signal(2,1);
	signal(3,1);
	unlink(ltmp);
	unlink(symtmp);
	unlink(fbtmp);
	unlink(itmp);
	exit();
}


main(argc, argv)
char **argv;
{
	register char *s, c;
	register n;

	signal(2, mexit);
	signal(3, mexit);	/* mod002 */

	ltmp = "/tmp/motmx.5";
	c = ltmp[9] = argv[0][0];	/* temp file char */
	gargc = argc -1;		/* mod016 */
	gargv = &argv[1];		/* mod016 */

	symtmp = "/tmp/motmx.0"; symtmp[9] = c;
	fbtmp = "/tmp/motmx.1";  fbtmp[9] = c;
	itmp = "/tmp/motmx.2";   itmp[9] = c;

	if ((sfile = open(symtmp,0)) == -1 ||
	     (fbfile = open(fbtmp,0)) == -1 ||
	     (ifile = open(itmp, 0)) == -1)  help();
	read(sfile, hashtab, 256);

	s = symtab;
	do
	{
		n = read(sfile, s, 512);
		s =+ n; numsym =+ n;
	} while (n == 512);
	numsym =/ sizeof symtab[0];		/* mod006 */

	s = fbtable;
	do
	{
		n = read(fbfile, s, 512);
		s =+ 512;
	} while (n == 512);

	close(sfile); unlink(symtmp);
	close(fbfile); unlink(fbtmp);

	icount = read(ifile, ibuf, 512);
	iptr = ibuf;
	icount =>> 2;

	argproc();

	nextfb = 20;
	for (n = 0; n < 20; n++) curfb[n] = n;

	write(obfile, "L\n", 2);
	newrec();

	input = NULL;
	if (newfile() == 0) help();

	linep = line;
	lcopy();						/* mod021 */

	if ((c = getch()) == '#')
	{
		lc++;
		getsym(getnonbl());
/*		linep = &line[l_OPR];			mod021 */
		if ((c = getnonbl()) == MINUS)
		{
/*			*linep++ = c;			mod021 */
			c = getch();
			segopt.segtype = 2;
		}
		else segopt.segtype = 1;
		segopt.segchar = c;			/* mod021 */
		segopt.segcount++;
/*		tch = getch();					mod022 */
/*		lcomma();					mod022 */
		lcoml();
	}
	else peekc = c;					/* mod021 */

	for (;;)		/* main loop */
	{
		spc = ppc = npc;
		undef = lab = 0;
		lc++;
		/* linep now reset in `lcopy'			mod021 */
		if ((c = getch()) == EOF)			/* mod022 */
		{
			if (newfile()) continue;
			break;
		}

		switch (c)
		{
	    case NL:	peekc = c;				/* mod022 */
			lcoml();
			continue;

	    case SP:
	    case TAB:	break;					/* mod022 */

	    case STAR:	lcoml();
			continue;

	    default:	peekc = c;				/* label */
			getsym();				/* mod022 */
			if (DIGIT(c)) deffb(c-'0');
			else lab = lookup();
		}

		if ((peekc = getnonbl()) == ':') peekc = 0;	/* optional colon */
		if ((peekc = getnonbl()) == NL)			/* mod022 */
		{
			lcomm();
			continue;
		}
		if ((n = getmnem()) == 0)	/* get op code */
			continue;		/* zero means done */
		lcode1(n);
		outbyte(n);
		if ((n = (ppc-spc)) == 2)
		{
			lcode2(operand, 1);	/* mod014 */
			outbyte(operand);
			if (operand >= 256 || operand <= -256) toobig();	/* mod023 */
		}
		else if (n == 3)
		{
			lcode3(operand);
			outword(operand);
		}
		lcomm();
	}

	if (iins(i_REL) == 0) syserr(1);
	if (bytec > 3) outrec();		/* mod001 */
	close(obfile);				/* mod000 */
	if (n = segopt.segcount) llocals(n);
	lglobals();
	if (list != NULL)
	{
		close(list);
	}
	mexit();
}





deffb(ind)
{
	register i;

	i = ind;
	curfb[i] = curfb[i+10];
	curfb[i+10] = nextfb++;
}


argproc()	/* mod003 */
{
	register char *of,*lf;
	register char **i;

	of = "m.out"; lf = 0;
	i = gargv;
	while (*i != 0)
	{
		if (i[0][0] == '-')
		{
			if (i[0][1] == 'l') if (i[0][2]) lf = i[0]+2; else lf = "m.lst";
			if(i[0][1] == 'o') if( i[0][2]) of = i[0]+2; else of = "/dev/null";
		}
		i++;
	}
	if ((obfile = creat(of,0600)) == -1) help();
	if (lf && (list = fopen(lf, "w")) == NULL) help();
}



newfile()
{
register *ip, *tp;

	if(input != NULL)
		fclose(input);				/* mod005, mod011 */
	if (tsav != NULL)
	{
		lc = tsavlc;
		fins = tsavfn;
		input = tsav;
		tsav = NULL;
		errc = 0;
		return (1);
	}
	while (gargc--)
	{
		fins = *gargv++;
		if (*fins == '-') continue;		/* mod016 */
		if ((input = fopen(fins, "r")) == NULL) continue;	/* mod005,016 */
		lc = 0;
		errc = 0;
		return (1);
	}
	return (0);
}



getmnem()
{
	register char acc;
	register opc, n;
	int adrm;

	if (getsym() == 4) acc = symbuf[3] | 040;		/* mod022 */
	else acc = 0;					/* mod016, 022 */
	symbuf[3] = 0;
	n = mnemlook();
	adrm = maddr[n] & 0x7f;
	opc = mcode[n];

	switch (adrm)
	{
	case o_INH:	ppc++; break;

	case o_DUAL:
	case o_ADDD:	if (!acc) acc = getacc();
			if (acc <= B)
			{
				if (acc == B) opc =+ 0100;
				opc =+ getimm(2);
			}
			else
			{
				if (symbuf[0] == 'a') opc =+ 0x35;	/* subd & addd */
				opc =+ 3 + getimm(3);
			}
			break;

	case o_STA:	if (!acc) acc = getacc();
			if (acc == B) opc =+ 0100;
			opc =+ getdirec();
			break;

	case o_AEI:
	case o_LSLD:	if (acc)
			{
				ppc++;
				if (acc == B) opc =+ 020;
				if (acc == D)
				{
					opc = 4;
					if (symbuf[2] == 'l') opc++;
				}
			}
			else
			{
				if ((n = getind()) == 4)	/* "xxl d", "xxr d" */
				{
					opc = n;
					if (symbuf[2] == 'l') opc++;
				}
				else opc =+ n;
			}
			break;

	case o_PUSH:	if (!acc) acc = getacc();
			if (acc == B) opc++; 
			else if (acc == X) opc =+ 6;
			ppc++;
			break;

	case o_IDEI:	opc =+ getimm(3); break;

	case o_DEI:	opc =+ getdirec(); break;

	case o_JMPS:	opc =+ getind(); break;

	case o_BNCH:	operand = n = getexpr();
			ppc =+ 2;
			if (undef) break;
			n =- ppc;
			if (n < -128 || n > 127) { brerr(); n = 0; }
			operand = n & 0377;
			break;

	case o_JBRS:	operand = getexpr();
			if (iins(i_LONG))
			{
				opc = mcode[n+1];
				ppc =+ 3;
				break;
			}
			ppc =+ 2;
			n = operand - ppc;
			if (n < -128 || n > 127) syserr(2);
			operand = n & 0377;
			break;

	case o_JEQS:	if (iins(i_LONG))
			{
				n = getexpr();
				operand = 03;		/* inverse jump 2 bytes */
				outbyte(opc);
				outbyte(operand);
				lcode1(opc);
				lcode2(operand, 1);		/* mod014 */
				lcomm();
				spc =+ 2;
				outbyte(0176);		/* jmp in extended mode */
				outword(n);
				lcode1(0176);
				lcode3(n);
/*				tch = NL;			mod022 */
/*				linep = &line[l_C2+4];		mod022 */
				peekc = NL;			/* mod022 */
				*linep++ = peekc;		/* mod022 */
				lcoml();			/* mod022 */
				return (0);		/* already listed */
			}
			symbuf[0] = 'b';
			opc = mcode[mnemlook()];
			n = getexpr();				/* mod022 */
			ppc =+ 2;
			n =- ppc;
			if ((n < -128) || (n > 127)) syserr(3);
			operand = n & 0377;
			break;

	default:	pseudop(adrm);
			return (0);
	}

	return (opc);
}



help()
{
	printf("help - temp files lost\n"); mexit();		/* mod002 */
}




iins(i)
char i;
{
	if (iptr->i_def == i && spc == iptr->i_pc)
	{
		if (--icount) { iptr++; return (1); }
		icount = read(ifile, ibuf, 512);
		icount =>> 2;
		iptr = ibuf;
		return (1);
	}
	return (0);
}



syserr(n)
{
	if (errc++ == 0) printf("%s:\n", fins);
	printf("%5d\tassembler error %d\n", lc, n);
}


error(s)
char *s;
{
	if (errc++ == 0) printf("%s:\n", fins);
	printf("%5d\t%s\n", lc, s);
}


brerr()
{
	error("branch error");
/*	line[l_UND] = 'B';				mod021 */
}


fbund()
{
	if (errc++ == 0) printf("%s:\n", fins);
	printf("%5d\tundefined fwd/back label %s\n", lc, symbuf);
}


underr()
{
	if (errc++ == 0) printf("%s:\n", fins);
	printf("%5d\tundefined label %s\n", lc, symbuf);
}


toobig()					/* mod023 */
{
	error("WARNING: operand exceeds 8 bits");
}
