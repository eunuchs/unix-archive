typedef unsigned int ino_t;
typedef long time_t;
typedef int dev_t;
typedef long off_t;
