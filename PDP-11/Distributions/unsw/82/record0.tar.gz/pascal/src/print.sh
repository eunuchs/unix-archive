# print
# (c) 1979 Regents of the University of California
pr $* | lpr
