#include "whoami"
/* Copyright (c) 1979 Regents of the University of California */
char	version[] "May 7, 1979";
