/* include the next define if you have separate I and D */
#define	SEPARATE_ID	1

/* include the next define if you have hardware floating point */
#define	HARDWARE_FP	1

/* include the next define if you want interpreted programs only */
/* #define	INT_ONLY	1 */

/* path names */
#define	INFO_PATH	"/user2/pas/pc.info"
#define	ERR_PATH	"/user2/pas/pc.errors"
#define	AS_PATH		"/user2/pas/as"
#define	MV_PATH		"/bin/mv"
#define	LD_PATH		"/bin/ld"
#define	PC_PATH		"/bin/pc"
#define	EM1_PATH	"/bin/em1"
#define	PROF_PATH	"/bin/eprof"
#define	COUNT_PATH	"/bin/ecount"
#define	FLOW_PATH	"/bin/eflow"
#define	PEM_PATH	"/user2/pas/pc:pem"
#define	PEMI_PATH	"/user2/pas/pc:pem.out"
#define	OPT_PATH	"/user2/pas/pc:opt"
#define	PDP_PATH	"/user2/pas/pc:pdp"
#define	ENC_PATH	"/user2/pas/pc:encode"
#define	ENCI_PATH	"/user2/pas/pc:encode.out"
#define	DEC_PATH	"/user2/pas/pc:decode"
#define	DECI_PATH	"/user2/pas/pc:decode.out"
#define	LIB_PATH	"/user2/pas/pc:makelib"
#define	ASS_PATH	"/user2/pas/pc:ass"
#define	RT0_PATH	"/user2/pas/pc:rt0.o"
#define	FRT0_PATH	"/user2/pas/pc:frt0.o"
#define	BSS_PATH	"/user2/pas/pc:bss.o"
#define	LIBEM_PATH	"/user2/pas/pc:emlib.a"
#define	LIBPR_PATH	"/user2/pas/pc:prlib.a"
#define	LIBP_PATH	"/user2/pas/libP.a"
#define	LIB2_PATH	"/user2/pas/lib2.a"
#define	EM1PR_PATH	"/user2/pas/em1:pr.a"
#define	EM1P_PATH	"/user2/pas/em1:P.a"
#define	EM12_PATH	"/user2/pas/em1:2.a"
#define	TABLES_PATH	"/user2/pas/em1:tables"
#define	INT_DIR		"/user2/pas/em1:int"
#define	TMP_DIR		"/tmp"
