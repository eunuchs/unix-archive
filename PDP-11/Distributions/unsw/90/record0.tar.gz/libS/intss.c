intss()
{
	return(ttyn(0) != 'x');
}
