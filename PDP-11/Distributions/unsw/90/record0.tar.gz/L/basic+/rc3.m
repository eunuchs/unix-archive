; The use and distribution of the information
; contained herein may be restricted.
;
	add	spda,r2		;bias it
	asr	r2		;set carry if increment is one
	bcc	fxfor1		;branch if not one
	asl	r2		;limit addr into r2
fxfor3:	if	(r0),gt,(r2),fxfor2 ;branch if variable gt limit
fxfor4:	com	(r1)		;truth value to true
fxfor2:	rts	pc

fxfor1:	asl	r2		;restore increment addr
	ifsign	(r2)+,pl,fxfor3	;branch on positive increment
	if	(r0),ge,(r2),fxfor4 ;branch if variable ge limit
	rts	pc
;floating for pushpops

forf:	mov	#pifj,-(sp)	;set up return thru intern. false jump
	br	flfor

forfx:	mov	#pifjxn,-(sp)	;set up external "for" false jump
flfor:	jsr	pc,pushf	;push variable
	gwtxt	r0		;2nd arg into carry
	add	spda,r0		;bias addr of 2nd arg
	asr	r0		;set carry if increment is one
	bcc	flfor1		;branch if not one
	asl	r0		;limit addr into r0
flfor2:	jsr	pc,pushf2	;push limit
	jmp	.le.f		;exit with le test

flfor1:	asl	r0		;variable addr into r0
	add	#fltle2,r0	;limit addr into r0
	ifsign	mfltl2(r0),pl,flfor2;br if increment +
	jsr	pc,pushf2	;push limit
	jmp	.ge.f		;exit with ge test
;these routines do the pushpops for "while" or "until"
;controlled modifiers

repti:
reptf:	mov	#ifj2,-(r1)	;save end offset for endrpt
	br	rept2
reptix:
reptfx:	mov	#ifjxn2,-(r1)	;save end offset for endrpt
rept2:	add	#4,r5		;ipc to third arg
pushc:	movb	(r5)+,-(r1)	;save tentative jump addr
	movb	(r5)+,-(r1)
	rts	pc		;do the conditional

;at the end of the conditional, we'll come here

endrpt:	jsr	pc,setdro	;set the drop thru flag for subseq. "next"
	mov	(r1)+,(r2)	;truth value to rpterm
	mov	(r1)+,r0	;tentative jump addr to r0
	tst	(r2)
	jmp	@(r1)+		;exit thru approp. cond. jump

setdro:	mov	spda,r2		;r2 _ base
	add	#nexdro,r2	;abs addr nexdro flag into r2
	mov	#-1,(r2)+	;set nexdro & inc r2 to addr of rpterm
	rts	pc
; special string function
; 	arg decodes as follows:
;	bit 0 => trim parity
;	bit 1 => discard all spaces and tabs
;	bit 2 => discard terminators and junk bytes
;	bit 3 => discard leading spaces and tabs
;	bit 4 => reduce spaces and tabs to one space
;	bit 5 => convert lower case to upper case
;	bit 6 => convert [ to ( and ] to )
;	bit 7 => discard trailing spaces and tabs

cvss:	jsr	r5,intfun	;straighten out arguments
	args	fas,fai		;one string then one integer
	mov	(r1)+,r4	;get arg bit pattern to here
	bic	#-377-1,r4	;clear unwanted bits
	mov	length(r1),r3	;final str <= length of original string
	jsr	pc,builds	;build us a new string please
	mov	r1,r2		;copy the r1 stack top
	tst	(r1)+		;skip link word on original string
	add	(r1)+,r2	;r2 is abs ptr to original string
	mov	r3,-(sp)	;save start of new string
10$:	dec	(r1)		;more to go in original string ?
	bmi	90$		;nope, so finish up
	movb	(r2)+,r5	;yep so fetch a byte
	bpl	20$		;no parity bit so no trim needed
	bit	r4,#1		;trim parity (bit 0) ?
	beq	20$		;no, forget it
	bic	#-177-1,r5	;else trim parity and its extension
20$:	bit	r4,#2		;discard all spaces and tabs (bit 1) ?
	beq	30$		;no, keep them for now
	jsr	pc,120$		;space or tab ?
	beq	10$		;discard if found
30$:	bit	r4,#4		;ignore terminators and junk (bit 2) ?
	beq	40$		;nope, keep 'em
	mov	#110$,r0	;get terminator list
32$:	cmpb	r5,(r0)		;terminator or junk ?
	beq	10$		;yes so discard
	tstb	(r0)+		;more in list ?
	bne	32$		;keep checking if more
40$:	tst	r4		;leading part of string ?
	bmi	50$		;nope
	bit	r4,#10		;discard leading spaces and tabs ?
	beq	48$		;no,so set flag for not leading
	jsr	pc,120$		;space or tab ?
	beq	10$		;yes so discard
48$:	bis	#100000,r4	;no longer leading part of string
50$:	bit	r4,#20		;reduce spaces and tabs to one space ?
	beq	60$		;not this time
	jsr	pc,120$		;space or tab ?
	bne	60$		;nope
	cmp	r3,(sp)		;target string now null ?
	beq	58$		;yes, so send a space
	cmpb	-1(r3),#040	;previous space in target string ?
	beq	10$		;yes, so discard this space or tab
58$:	mov	#040,r5		;send one space to target string
	br	80$		;without further diddling
60$:	bit	r4,#40		;convert lc to uc ?
	beq	70$		;nope
	cmp	r5,#'a+40	;in range ?
	blt	70$		;nope, so not lower case
	cmp	r5,#'z+40	;really in range ?
	bgt	70$		;definitely not lower case
	bic	#40,r5		;convert to upper case
	br	80$		;plunk it into new string
70$:	bit	r4,#100		;convert [ to ( and ] to ) ???
	beq	80$		;nope
	mov	#"[],r0		;get brackets for comparison
	cmpb	r5,r0		;is it a left bracket ?
	beq	75$		;tis
	swab	r0		;switch to right bracket
	cmpb	r5,r0		;one of those ?
	bne	80$		;no
	dec	r5		;] = 135 - 64 = ) = 51
75$:	sub	#63,r5		;[ = 133 - 63 = ( = 50
80$:	movb	r5,(r3)+	;store in new string
	br	10$		;and continue .....

90$:	bit	r4,#200		;trim tailing spaces and tabs ?
	beq	100$		;nope, leave em
92$:	cmp	r3,(sp)		;is target string null ?
	beq	100$		;yes, so no trimming possible
	cmpb	-(r3),#40	;trailing space ?
	beq	92$		;yes so discard
	cmpb	(r3),#011	;trailing tab ?
	beq	92$		;yes, so discard
	inc	r3		;else keep that last character
100$:	tst	(sp)+		;dump the saved new string start
	mov	spda,r0		;get spda to r0
	br	mid9		;and finish up

110$:	.byte	012,014,015,033,177,000	; terminator list

120$:	cmpb	r5,#040		;space ?
	beq	124$		;yes
	cmpb	r5,#011		;tab ?
124$:	rts	pc		;return condition codes
;checks the string at the top of the stack for inclusion
;in the next string on the stack as a substring
;at or beyond the position specified by the number which
;follows on the stack - if included, returns the
;character position at which first occurrence starts -
;if not, returns 0 - the null string is a substring
;of every string immediately

instr:	jsr	r5,intfun	;get the args straightened out
	args	fai,fas,fas	;interger-string-string args
	mov	r5,-(sp)	;save ipc
	mov	spda,r2		;r2 is the base register
	mov	r1,r5		;r5 _ old r1 stack ptr
	jsr	pc,pstjs	;throw out top string
	mov	r1,r0		;r0 _ new r1 stack ptr
	mov	-(r0),r4	;r4 _ length of supposed substring
	add	-(r0),r5	;r5 _ its addr
	mov	r1,r2		;r2 _ old r1 stack ptr
	jsr	pc,pstjs	;throw out top string
	mov	r1,r0		;r0 _ new r1 stack ptr
	mov	-(r0),r3	;r3 _ length of supposed outer string
	add	-(r0),r2	;r2 _ its beg addr
	dec	(r1)		;dec char position to start at
	bpl	instr0		;branch on positive char position
	clr	(r1)		;early start correction
instr0:	add	(r1),r2		;start at indicated char
	sub	(r1),r3		;with appropriate length
instr1:	if  r4,gt,r3,instr2	;branch if no room for inclusion
	inc	(r1)		;othws, advance position indicatio
	clr	r0		;clr char match counter
instr4:	if  r0,eq,r4,mid8	;branch if substring found
	inc	r0		;othws, inc match counter
	if  (r2)+,eq,(r5)+,instr4,b  ;loop back on char match
	sub	r0,r5		;restore beg of supposed substring
	inc	r2		;try one char further down
	sub	r0,r2		;of supposed outer string
	dec	r3		;dec its length
	br	instr1		;around outer loop again

instr2:	clr	(r1)		;send back a 0 to indicate failure
	br	mid8		;restore ipc and exit

;concatenate routine
concat:	mov	length(r1),r3	;r3 _ length of 2nd string
	add	strlen+length(r1),r3;plus length of 1st string
	jsr	pc,builds	;start to build the string
	mov	#matblk,r4	;r4_addr temp storage blok
	add	r0,r4		;bias block addr
	clr	(r4)+		;put a 0 block length into block as flag
	mov	r1,r5
	tst	(r1)+		;skip over link
	add	(r1)+,r5	;abs addr 2nd string into r5
	mov	(r1)+,(r4)+	;its length into block
	mov	r1,r2
	tst	(r1)+		;skip link of 1st string
	add	(r1)+,r2	;unbiased addr of 1st string in r2
	mov	(r1)+,(r4)	;length of 1st string into block
	add	#strlen,(r0)	;throw out first string header
conca1:	dec	(r4)		;dec length of one of strings
	bmi	conca2		;done with this string if neg
	movb	(r2)+,(r3)+	;othws, transfer a char
	br	conca1		;around again

conca2:	mov	r5,r2		;r2 _ addr of 1st string
	ifzero	ne,-(r4),conca1	;go around again if nonzero length
	br	mid6		;exit
;pushpop for mid

subst1:	jsr	r5,intfun	;straighten out args
	args	fas,fai,fai	;string-integer-integer args
	mov	(r1)+,r3	;r3_substring length
mid1:	mov	(r1)+,r4	;r4_char position
	dec	r4		;a little smoother decremented
	bpl	mid2		;branch on positive char position
mid5:	clr	r4		;pretend it was 1
mid2:	mov	r4,r2		;r2 _ adjusted char position
	neg	r2		;negated
	add	length(r1),r2	;r2 _ length of remainder of string
	bpl	1$		;going to return null if negative
	clr	r2		;yep it was neg
1$:	tst	r3		;also yield null
	bpl	2$		;if length of result
	clr	r3		;look negative here
2$:	if  r3,ge,r2,3$	;br if putative length gr than rest of string
	mov	r3,r2		;anyway, r2 _ lesser length
3$:	mov	r2,r3		;and so does r3
	jsr	pc,builds	;build substring on r1 stack
	add	r1,r4		;prepare to derelativize
	tst	(r1)+		;point at string ptr
	add	(r1)+,r4	;r4_abs. addr 1st substring char
4$:	dec	r2		;decrement length
	bmi	mid9		;branch if done
	movb	(r4)+,(r3)+	;transfer a char
	br	4$

mid9:	tst	(r1)+		;adjust r1 to point just above header
mid6:	jsr	pc,@(sp)+	;finish up in builds
mid8:	mov	(sp)+,r5	;restore ipc
	rts	pc

;pushpop for right

substr:	jsr	r5,intfun	;straighten out args
	args	fas,fai		;string-integer args
	mov	#77777,r3	;far far right indeed
	br	mid1		;process as variant of mid

left:	jsr	r5,intfun	;straighten out args
	args	fas,fai		;string-integer args
	mov	(r1)+,r3	;r3_substring length
	br	mid5
chr$:	jsr	r5,intfun	;fix arg if necessary
	args	fai
	mov	(r1)+,r2	;r2_ascii value char
	clr	r3		;approx length of string
	jsr	pc,builds	;build the string etc
	movb	r2,(r3)+	;move the character in
	br	cvs3		;put new header on list & exit

posf:	tst	(r1)		;see if any argument
	beq	1$		;branch if zero assumed
	jsr	r5,intfun	;call the common function interpreter
	args	fai		;one integer
1$:	mov	(r1)+,r3	;get the wanted channel #
	bic	#-17-1,r3	;make sure it is valid
	ash	#4,r3		;times 16.
pos04:	add	#base+iolen,r3	;go to buffer header relative
pos02:	add	spda,r3		;make address absolute
	mov	positn(r3),-(r1)
	mov	#72.,r0		;we stock only one line-length
2$:	rts	pc		;and out
;	do the tab function
tabf:	jsr	r5,intfun	;adjust arg types
	args	fai		;one integer
	jsr	pc,pos000	;find position
	sub	(r1)+,(r1)	;find amount needed to go
	br	spac01		;and do it

pos000:	mov	spda,r3		;get spda base bias
	mov	currio(r3),r3	;now get current io address
	bne	pos02		;we are doing io
	br	pos04		;else use console

spaces:	jsr	r5,intfun	;fix arg if necessary
	args	fai		;want an integer argument
spac01:	mov	#40,r2		;byte to use is <space>
spac02:	mov	(r1)+,r3	;r3 _ number of spaces in string
	mov	r3,r4		;also r4
	bpl	1$		;branch if positive length
	clr	r3		;else make  no string
1$:	jsr	pc,builds	;begin to build the string
2$:	dec	r4		;decrement string length
	bmi	cvs3		;exit when length count goes negative
	movb	r2,(r3)+	;othws, add a byte to the string
	br	2$		;and go round again

string:	jsr	r5,intfun	;get 2 'fai' args
	args	fai,fai
	mov	(r1)+,r2	;second arg is byte value for string
	br	spac02
;convert vector to string

cvs:	clr	-(r1)		;initialize to zeroth entry
	jsr	pc,cvspus	;push first entry
	mov	(r1)+,r4	;r4_string length
	mov	r4,r3		;so does r3
	jsr	pc,builds	;build the string
cvs1:	dec	r4		;dec length
	bmi	cvs2		;almost done if negative
	sub	r0,r3		;guard against disaster
	mov	2(sp),r5	;r5 _ relative ipc saved by builds
	add	spta,r5		;now ipc absolute
	cmpb	-(r5),-(r5)	;but we have to point at array address
	jsr	pc,cvspus	;push entry
	add	r0,r3		;unguard
	mov	(r1)+,r2	;r2_matrix entry
	movb	r2,(r3)+	;put l.s. byte into string
	br	cvs1		;and around again
cvs2:	tst	(r1)+		;get rid of running array index
cvs3:	jsr	pc,@(sp)+	;return to builds to finish up
	mov	(r2),(r1)	;link _ relative ptr to 1st string header
	jsr	pc,pushs2	;put header on header list
	br	mid8

;turns a string into an array

csv:	clr	-(sp)		;initialize to zeroth entry
	mov	length(r1),-(r1);string length to top of stack
	jsr	pc,csvpop	;salt it away in array
	mov	r1,r4		;r4 _ r1 stack pointer
	jsr	pc,pstjs	;pop string to j space
	mov	-(r1),r3	;r3 _ string length
	add	-(r1),r4	;r4 _ abs string pointer
	cmp	(r1)+,(r1)+	;clean up r1 stack
csv1:	dec	r3		;decrement length
	bmi	csv2		;done if negative
	clr	-(r1)		;othws,set up another pop
	movb	(r4)+,(r1)	;with byte from the string
	sub	r0,r4		;guarding against disaster
	cmpb	-(r5),-(r5)	;adjust ipc for next pop
	jsr	pc,csvpop	;pop r1 stack to matrix
	add	r0,r4		;danger behind us
	br	csv1		;around again

csv2:	tst	(sp)+		;rid of running array index
	rts	pc
;special push for cvs routine - fixes the pushed item
;if it was a floater-saves r3 & r4
;exit with r0 = spda - jsr pc

cvspus:	mov	r3,-(sp)	;save r3 & r4
	mov	r4,-(sp)
	mov	(r1),-(r1)	;array index _ running index
	inc	2(r1)		;increment running index
	jsr	pc,indo1	;push array entry
	jmask0	ne,(r0),fixary,cvspu1,b	;br on fixed num
	jsr	pc,fix		;othws, fix it
cvspu1:	mov	(sp)+,r4	;restore r4 & r3
	mov	(sp)+,r3
	mov	spda,	r0	;but set r0 to spda
	rts	pc

;special pop for csv routine - pops the top integer
;(floated, if need be) into array - saves r3 & r4 -
;exit with r0 = spda - jsr pc

csvpop:	mov	r3,-(sp)	;save r3 & r4
	mov	r4,-(sp)
	mov	6(sp),-(r1)	;array index _ running index
	inc	6(sp)		;increment running index
	clr	-(r1)		;dummy in 2nd index of zero
	jsr	pc,indx90	;call array preface
	clr	dim2-aryflg(r0)	;make it a vector!
	jmask0	ne,(r0),fixary,csvpo,b  ;br if integer array
	jsr	r5,edsave	;save r0,2,3,4,5
	jsr	pc,flt		;float the number
	jsr	r5,edrest	;and restore them
csvpo:	jsr	pc,indr3	;pop to array
	br	cvspu1		;reset r3 & r4 and set r0 to spda
date$:	jsr	r5,intfun	;see what we've got
	args	fai		;we'd like an integer
date07:	mov	(r1)+,r4	;get the argument
	bne	1$		;branch if supplied
	.date			;get info
	mov	xrb+xrlen,r4	;else use today for fun
1$:	mov	#10.,r3		;we need 9 bytes(10 for safe side)
	jsr	pc,builds	;go set up for string build
	jsr	r5,savreg	;save all registers
	mov	r4,r5		;put date in an odd register
	bmi	90$		;branch if screwy type date
	clr	r4		;clear high order of date
	div	#1000.,r4	;and divide for year-1970
	mov	r4,r1		;save answer here temporarily
	mov	r5,r4		;so we can put the remainder here
	bne	2$		;no remainder is an error
90$:	clr	r4		;if error, set day to 0
	clr	r5		;set year to 0
	mov	#dattbe+1,r2	;and month to xxx
	br	20$		;now do the date date

2$:	mov	r1,r5		;(year-1970) back to here
	add	#70.,r5		;and correct for the -1970 hack
	dec	r4		;decrement for linear 0-n range
	mov	#dattbl-3,r2	;get month table pointer (less 3)
10$:	add	#3,r2		;go to next month in the table
	movb	(r2)+,r1	;and get # days in that month
	beq	90$		;none is end of table and an error
	bpl	11$		;>0 is normal type month
	neg	r1		;<0 is february
	bit	r5,#3		;was it a leap year?
	bne	11$		;nope, so no correction needed
	inc	r1		;yes, feb. gets one more day
11$:	sub	r1,r4		;was this the month we wanted?
	bge	10$		;nope, more days to go yet
	add	r1,r4		;yes, correct day in month value
	inc	r4		;and make 1-n
20$:	jsr	pc,date25	;put out the date as "dd"
	movb	#'-,(r3)+	; then a dash
	movb	(r2)+,(r3)+	;  and now the month
	movb	(r2)+,(r3)+	;   one letter at a
	movb	(r2)+,(r3)+	;    time...
	movb	#'-,(r3)+	;and another dash
	jsr	pc,date25	;finally put out the year
date90:	mov	r3,3*2(sp)	;update r3 in saved registers
	jsr	r5,resreg	;and restore registers
	jmp	cvs3		;and out to common cleanup
date25:	mov	r5,-(sp)	;save r5
	mov	r4,r5		;then put this in low order spot
	clr	r4		;and clear high order
	div	#10.,r4		;divide by 10.
	add	#'0,r4		;this is the ascii answer
	movb	r4,(r3)+	;output it
	add	#'0,r5		;this is the ascii remainder
	movb	r5,(r3)+	;output it
	mov	(sp)+,r4	;move old r5 to r4 for helping hand
	rts	pc		;and out

time$:	jsr	r5,intfun	;clean up the args if needed
	args	fai		;we need one integer
time07:	mov	(r1)+,r4	;get the number
	bne	1$		;branch if he supplied it
	.date			;get info
	mov	xrb+xrbc,r4	;else use the time right now
1$:	mov	#8.,r3		;we'll need 8 characters
	jsr	pc,builds	;go set up a string
	jsr	r5,savreg	;save all the registers
	mov	#1440.,r5	;this many minutes in any given day
	sub	r4,r5		;and now we have the time of day
	clr	r4		;clear the high order
	div	#60.,r4		;and divide for hours
	mov	time.b,-(sp)	;guess at "  " or "pm" wanted
	sub	time.c,r4	;sub +0. or +12. from hours
	bge	9$		;"pm" was right
	mov	time.a,(sp)	;replace "pm" with "  " or "am"
	add	time.c,r4	;and restore hour value to original
9$:	bne	10$		;all now o.k.
	add	time.c,r4	;correct hours for 12:00 to 12:59
10$:	jsr	pc,date25	;output hours
	movb	#':,(r3)+	; then a colon ":"
	jsr	pc,date25	;  and then the minutes
	movb	#40,(r3)+	;then a space
	mov	(sp)+,(r3)+	; and, finally, the junk
	br	date90		;now cleanup
	tmporg	ti

time.a:	.word	"am		;or "  " for 24-hour time
time.b:	.word	"pm		;or "  " for 24-hour time
time.c:	.word	+12.		;or +0. for 24-hour time

	unorg

dattbl:	.byte	31.,'j,'a+40,'n+40
	.byte	-28.,'f,'e+40,'b+40
	.byte	31.,'m,'a+40,'r+40
	.byte	30.,'a,'p+40,'r+40
	.byte	31.,'m,'a+40,'y+40
	.byte	30.,'j,'u+40,'n+40
	.byte	31.,'j,'u+40,'l+40
	.byte	31.,'a,'u+40,'g+40
	.byte	30.,'s,'e+40,'p+40
	.byte	31.,'o,'c+40,'t+40
	.byte	30.,'n,'o+40,'v+40
	.byte	31.,'d,'e+40,'c+40
dattbe:	.byte	00.,'x,'x,'x
;puts a string on the r1 stack - calling sequence:
;		r3 _	tight upper bound on string length
;		jsr	pc,builds	(no abs pointers & no string data pointers)
;		initialize
;	loop:	go ret if condition for string end met
;		get ready to ship char (keeping r0 _ spda
;					and r3 properly absolute)
;		(r3)+ _	char
;		br	loop
;	ret:	jsr	pc,@(sp)+
;		mov	(r2),(r1)	(to put new header on list)
;		jsr	pc,pushs2
;		   or	nothing		(if previous item 
;					on r1 stack was a string
;					header still on header list
;					whose link is undestroyed by
;					r1 stack diddling in the
;					char transmission portion of
;					coroutine)
;		mov	(sp)+	r5	(to restore ipc if r5 orig ipc)
;		   or	tst (sp)+ (if r5 not ipc at entry)
;		exit	code
;at first exit to coroutine, r3 is absolute addr of
;first string byte to be stored into - at all
;exits, r0 is spda, and must be so maintained -
;at last exit r2 is also spda - warning:  the value
;of spda & spta may change between the initial entry to builds
;and the first exit to coroutine - if r5 contains
;ipc, an appropiately updated version is on the sp stack at
;exit - othws, junk word on stack at exit
;does not use r2, r4, or r5 except for the return of spda in r2 at last exit
builds:	mov	sp,r0		;keep back up of stack pointer
	mov	(sp),-(sp)	;make a slot for ipc
	mov	r5,(r0)		;slot _ ipc
	sub	spta,(r0)	;relativize w.r.t. spta
	mov	spda,r0		;r0 is the base register
	bic	#1,r3		;make string length even
	add	#2,r3		;little slack
	bpl	blds0		;br if string length nonnegative
	xcdcor	!fatal		;too big!
blds0:	mov	r3,strnom(r0)	;tell garbage collector how much
	add	nexstr(r0),r3	;r3 _ approx. end of string to be built
	if r3,lo,strlim(r0),blds1  ;branch if room for string
	jsr	r5,econom	;user-core manager
	+	strnom		;give us string space please
blds1:	mov	nexstr(r0),r3	;r3 _ next available byte in string space
	add	r0,r3		;bias r3
	jsr	pc,@(sp)+	;go build the string, etc
	sub	r0,r3		;unbias r3
	mov	r3,-(r1)	;length _ rel loc of next free string byte
	mov	r3,-(r1)	;string link does too
	add	r0,(r1)+	;string link _ abs addr
	sub	nexstr(r0),(r1)	;length _ length of string built
	bgt	blds2		;branch if positive length
	clr	(r1)		;else make zero length
blds2:	sub	(r1),-(r1)	;string link _ abs addr of string built
	tst	-(r1)		;point at link
	sub	r1,2(r1)	;relativize ptr
	inc	r3		;make r3 even (round up)
	bic	#1,r3
	mov	r3,nexstr(r0)	;update next avail string byte addr
	add	spta,2(sp)	;make possible ipc absolute
	mov	r0,r2		;public service - r2 _ set to bias
	rts	pc
pwri:	mov	(r1)+,-(sp)	;save the power
	blt	pwri00		;if negitive give zero result
	mov	(r1)+,-(sp)	;save the number
	mov	#1,-(r1)	;start the product at 1
pwri10:	dec	2(sp)		;decrement the count
	blt	pwri20		;exit if done
	mov	(sp),-(r1)	;move the base number
	jsr	pc,muli		;and multiply
	br	pwri10		;and loop for more if needed

pwri20:	tst	(sp)+		;pop the number
pwri25:	tst	(sp)+		;pop the exponent
	rts	pc		;and return

pwri00:	clr	(r1)		;make result 0
	br	pwri25		;and exit nicely

pushi1:	mov	#1,-(r1)	;push integer 1
	rts	pc
	.title	basic
	.end
