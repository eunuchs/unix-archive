; The use and distribution of the information
; contained herein may be restricted.
;
title	mx,<mx - mat statements>,24,08-jul-74,tph/jdm

	.ifdf	hello
	org	xt,tkmat-dotabv
	.word	domat	;mat(rix)
	.endc

	org	pt,0
	..	ppmrd,matrd	;matrix push-pops
	..	ppmprn,matprn
	..	ppmprt,matprt
	..	ppminp,matinp
	..	ppmzr,matzro
	..	ppmc1,matc1
	..	ppmid,matid
	..	ppmtrn,mattrn
	..	ppminv,matinv
	..	ppsmpf,matsmf
	..	ppsmpi,matsmi
	..	ppmcpy,matcpy
	..	ppmmul,matmul
	..	ppmadd,matadd
	..	ppmsub,matsub
	..	ppmprc,matprc
	..	ppmpus,matpus
	..	ppmpop,matpop
	..	ppzsma,zsmadd
	..	ppmpr,matpr
	..	ppmain,matin
	..	ppmrd0,matrd0
	..	pprdim,rowdim
	..	ppcdim,coldim
	..	ppcmpi,cmpipp
	..	ppfflt,ffltpp
	..	ppcals,callpp
	..	ppcali,calipp
	..	ppcoru,corupp
	..	pprts,rtspp
	..	ppreor,reorpp
	..	ppbegn,beginp
	..	ppffuf,ffuf
	..	pptst,tstfl
	..	ppemc,emcode
	.csect	mx

	.ifdf	hello
	.globl	saint					;(tr)
	.endc
	.globl	flt,fix,addf				;(ma)
	.globl	sinf1
	.globl	prints,printf,crlf,nxtzon		;(pn)
	.globl	indo3,indr3,pushi1,indegh,reads		;(rc)
	.globl	readf,inputs,inputf
	.globl	expdif,fltlen,fltle2,fltle4
	.ifdf	hello
;the matrix operations in the table below
;all have similar push pop operator formats
;the first dimension is pushed on the r1
;stack, then the second (zero is pushed
;whenever a given dimension is not specified), and
;the pushpop operator is followed by a
;two byte matrix header address
;matrix operation		rts push-pop op
;mat read			ppmrd
;mat print with tabs		ppmprt
;mat print no tabs		ppmprn
;mat input			ppmip
;mat c=zer			ppmzr
;mat c=con			ppmc1
;mat c=idn			ppmid
domadm:	rntj	lpar,domra1	;if no dimensions specified
	rci			;first dimension
	ntj	comma,domra2	;must be vector
	rci			;2nd dimension
	b	domra3
domra2:	cb	ppfix0		;use zero for unspecified dim
domra3:	t	rpar		;must be ")"
	r
	quits
domra1:	cb	ppfix0		;dummy in 1st dim
	cb	ppfix0		;leave
	cb	ppnot		;-1 around as no index flag
	quits

selec3:	rntj	pound,domse1	;read and get pound
	rci			;if pound then get integer
	t	comma		;forca a comma
	sarf			;??
	r			;read next token
	quits
domse1:	cb	ppfix0
	quits			;exit subroutine
;routine to handle one member of possible list of arrays
;for mat read,input,& print
domray:	x			;x for matrix;must be indexed variable
	pt			;save it
	calls	domadm
	sarf			;for la
	c2of1			;compile the saved op code
	cw			;compile the array header in-line
	quits

;mat verb-messiest of all
	.even
domat:	jsr	r5,saint	;use the syntax analyzer interpreter
	rntj	tread,domat3
	pbs	ppmrd		;matrix read op
	b	domat2
domat3:	ntj	input,domat1
	calls	selec3
	cb	ppendi		;empty buffer
	cb	ppssi
	pbs	ppminp		;matrix input op
	b	dom99
domat2:	r
dom99:	calls	domray		;compile one member of list
	tj	comma,domat2
	tj	semico,domat2
doma52:	tst1ai
	quit
domad1:	b	domadm
domat1:	ntj	print,domat5
;mat print routine--------------------------------------------------
;compile ppmprn pop if no tabs between elements,
;and ppmprt if tabs are desired
	calls	selec3
	cb	ppsso
	x			;get array header
	pt			;save it
	calls	domadm		;compile dimensions
	ej	domb03		;needs a crlf (use ppmprt)
	tj	comma,domb05	;tabs, no crlf if end
	t	semico		;only other legal token
	cb	ppmprn		;no tabs,no crlf if end
	b	domb04
domb05:	cb	ppmprt		;put out tabs type pop
domb04:	re			;must see end of statement
	b	domb06
domb03:	cb	ppmprc		;column vector
domb06:	cw			;header
	cb	ppcrlf
	quit
domat5:	xij	doma51		;must be a mat. variable
	xf
doma51:	ptype
	pt			;saveit
	rt	equals		;demand "="
	rntj	zer,domat6
	pbs	ppmzr		;zero matrix
doma10:	calls	domad1		;compile dimensions
	cbs			;compile up byte from stack
doma53:	cw			;compile array name from stack
	b	doma52
domat6:	ntj	con,domat9
	pbs	ppmc1		;set matrix to all 1's
	b	doma10
domat9:	ntj	idn,doma11
	pbs	ppmid		;set matrix to identity
	b	doma10
doma11:	ntj	trnlp,doma14
	cb	ppmtrn		;matrix transpose
doma16:	rx			;read operand
	matcht			;must be same type as first mat
	ct			;compile it
	rt	rpar
	b	doma24
doma14:	ntj	invlp,doma15
	cb	ppminv		;matrix inverse
	b	doma16
doma15:	ntj	lpar,doma17	;scalar multiply case
	r			;next token
	cn			;compile either type of number
	copr	domopt		;and appropriate pop depend on float or integer
	t	rpar
	sarf			;for la
	rt	star
	rx			;read last operand
	matcht			;must be same type as first mat
	ct			;compile last opero
doma24:	r
	b	doma53
domopt:	.byte	ppsmpf,ppsmpi	;scalar multiply push/pops
doma17:	x			;mat a=b case
	matcht			;must be same type as first mat
	pt			;push the first operand
	rnej	doma19		;copu case
	cb	ppmcpy		;matrix copy
	cw			;ppmcpy[a][c]
	b	doma53
doma19:	ntj	star,doma20
	cb	ppmmul		;matrix multiply
doma22:	rx
	ct			;first operand
	cw
	matcht			;must be same type as first mat
	b	doma24		;ppmmul[a][b][c]
doma20:	ntj	plus,doma21
	cb	ppmadd
	b	doma22
doma21:	t	bmins
	cb	ppmsub
	b	doma22
	.even
	.endc
;stores the top word of the r1 stack less expdif on the sp stack
;used to set a minimum  exponent for zsmadd, etc.  jsr pc

difexp:	mov	(r1),r2		;save exponent in r2
	rol	r2		;dump sign
	mov	r2,r0		;into r0 with it
	sub	#expdif,r0	;get min allowable nonzero exponent
	if	r0,los,r2,difex1  ;br if result smaller
	clr	r0		;othws, make it zero
difex1:	jsr	r0,@(sp)+	;save r0 on stack

;an add pushpop which returns zero if the result is very small.

zsmadd:	jsr	pc,difexp	;save min allowable exponent on sp stack
	jsr	pc,addf		;add two top floaters together
zsmad0:	mov	(r1),r0		;get m.s. word of result
	rol	r0		;dump its sign
	if	(sp)+,los,r0,bginp1  ;exit if result big enough
	jmp	sinf1		;substitute a floating 0
;for a pushpop byte argument indirectly pointing to an
;array header, gets the absolute address of 
;the array header into r2.

comdim:	mov	spda,r2		;get the bias
	movb	(r5)+,r0	;relative indirect address
	add	r2,r0		;absolute 
	add	(r0),r2		;absolute header address
	rts	pc

;gets the row dimension of matrix indirectly
;referenced through byte argument

rowdim:	jsr	pc,comdim	;do the above
	mov	dim1(r2),-(r1)	;othws push dim1
	rts	pc

;gets the column dimension of matrix
;indirectly referenced through byte arg

coldim:	jsr	pc,comdim	;r2<--header address
	mov	dim2(r2),-(r1)	;push dim2
bginp1:	rts	pc

;substitutes and integer one for the top
;r1 stack integer unless that integer is a zero

beginp:	ifzero	eq,(r1)+,bginp3	;exit if top of stack 0
	jmp	pushi1		;otherwise, substitute 1

bginp3:	clr	-(r1)		;leave 0 at top of r1 stack
	rts	pc
;pushes a matrix entry onto the r1 stack (floated).
;1st byte arg indirectly points to matrix header, 2nd
;and 3rd bytes point directly at indices.

matpus:	jsr	pc,comatp	;setup via indx90
	jmask0	eq,(r0),fixary,matp1,b  ;br if floating
	mov	#flt,-(sp)	;exit through flt
matp1:	jmp	indo3		;push matrix item

;pops a matrix entry from the r1 stack (fixed,
;if necessary).  args as for matpus.

matpop:	jsr	pc,comatp	;setup via indx90
	jmask0	eq,(r0),fixary,matpp1,b; br if floating
	mov	r3,-(sp)	;othws, save r3 for indr3
	jsr	pc,fix		;fix item
	mov	(sp)+,r3	;restore r3 for indr3
matpp1:	jmp	indr3		;pop off

;entered with r5 pointing to the first of 3
;byte addresses - 1st indirect to a
;matrix header, the other 2 direct to indices.
;sets up a call into indx90. interchanges
;r5 with 4(sp) before and afeer the indx90
;call. this enables main line bookkeeping on
;the ipc in case of core allocation.

comatp:	mov	spda,r2		;bias
	movb	(r5)+,r0	;relative indirect header addrs
	add	r2,r0		;absolute
	mov	(r0),r0		;relative direct header adress
	movb	(r5)+,r3	;relative index address
	add	r2,r3		;absolute
	mov	(r3),-(r1)	;push index
	movb	(r5)+,r3	;and again
	add	r2,r3
	mov	(r3),-(r1)
	mov	(sp)+,r3	;save top of stack
	jsr	pc,swpipc	;interchange ipc's
	mov	r3,-(sp)	;restore top of stack
	jsr	pc,indegh	;into indx90
	jsr	pc,@(sp)+	;return to calling routine for awhile
	br	matrd2		;re-interchange ipc's and exit

swpipc:	mov	r5,-(sp)	;interchange ipc's
	mov	3*2(sp),r5
	mov	(sp)+,2*2(sp)
	rts	pc
;pushpop subroutine & coroutine routines
;subroutine call.  r1ext _r5_ address
callpp:	movb	(r5)+,-(r1)	;subroutine jump address
	movb	(r5)+,-(r1)	;onto r1 stack
	add	r5,(r1)		;derelativize subroutine address
call0:	mov	spda,r2		;get the bias
	mov	r5,r1ext(r2)	;save return address
	mov	(r1)+,r5	;set subroutine address
	rts	pc

;coroutine call.  also subroutine exit.  r1ext <=> r5
corupp:	mov	spda,r2		;get the bias
	mov	r1ext(r2),-(r1) ;save destination address
	br	call0

;subroutine call theough r1.  r1ext_r5_(r1)
calipp:	mov	(r1),-(r1)	;save destination address
	br	call0

;honest subroutine exit.  r5_r1ext_(r1)+
rtspp:	mov	spda,r2		;get bias
	mov	r1ext(r2),r5	;return address into r5
	mov	(r1)+,r1ext(r2) ;pop to dummy top
	rts	pc

;a pushpop which "ors" the top two r1 words together
;but does not remove them.

reorpp:	tst	(r1)		;look at pseudo-index
	bpl	bginp3		;br if honest index
	mov	(r1)+,(r1)	;move dishonest index down for popping it
reori:	rts	pc

;a pushpop which tests the top two r1 stack
;items and compliants if they are not equal.
;throw top items away.

cmpipp:	if	(r1)+,eq,(r1),reori	;exit if top elements equal
	dimerr	!fatal		;dimension error otherwise
;fetches the floater under the top integer to
;the top of the stack

ffltpp:	mov	#fltle2+2,r2	;point to floater below integer
ffufs0:	add	r1,r2		;by adding in r1 pointer
	mov	#fltlen,r0	;get word counter
ffufs1:	mov	-(r2),-(r1)	;and move a floater
	sob	r0,ffufs1	;loop
	rts	pc
;ppushpop causes exit from internal pushpop to machine code
;following at next even location

emcode:	mov	r5,r4		;save current internal pp pointer
	inc	r4		;even up
	bic	#1,r4
	mov	2(sp),r5	;restore external pp pointer
	mov	(sp)+,(sp)	;obliterate external pointer temp
	mov	r4,pc		;exit to machine code

;code for pushpop ppffuf (copy 2'nd from top float # at head of stack)
ffuf:	mov	#fltle4,r2	;prepare to point to 2nd floater
	br	ffufs0		;now go move it

;code for pushpop pptst (branches to byte address following
;if nv3<>0,otherwise drops through)
tstfl:	movb	(r5)+,r2		;move 1-byte addr. to r2
	mov	spda,r3			;move c(spda) to r3
	ifz	nv3(r3),tstf1		;test c(nv3), br if =0
	add	r2,r5			;nv3 flag <>0, so add r2 to int. pc
tstf1:	rts	pc			;and exit
;set z flop if matrix pointed at by matric
;is a string array. also interchanges ipc's.
tstrng:	mov	spda,r2		;get bias
	add	matric(r2),r2	;absolute address array header
	mov	(sp)+,r3	;save top of stack
	jsr	pc,swpipc	;swap ipc's
	mov	r3,-(sp)	;restore top of stack
	bitb	#strary,aryflg(r2)	;test string array flag
tstrn1:	rts	pc		;and out
;print pushpop for individual matrix entries
matpr:	jsr	pc,tstrng	;test string flag
	beq	matpr1		;br if not string
	jsr	pc,prints	;print string
	br	matpr2
matpr1:	jsr	pc,printf	;print floater
matpr2:	mov	spda,r2
	mov	nvtm(r2),r4	;get tab & crlf flags
	bmi	matpr5		;if crlf flag set, output crlf
	mov	cb2(r2),r3	;r3_inner repeat loop limit
	if  nv2(r2),ne,r3,matpr4  ;exit if ne control variable
	dec	r3		;make small num nonpositive
	ble	matpr4		;exit on such numbers
	jsr	pc,crlf		;output two crlf's
matpr5:	jsr	pc,crlf		;output crlf
	br	matrd2

matpr4:	tstb	r4		;check tab flag
	bpl	matrd2		;exit if not set
	jsr	pc,nxtzon	;othws, send out the tab
	br	matrd2

;read pushpop for individual matrix entries
matrd0:	jsr	pc,tstrng	;test string flag
	beq	matrd1		;br if not a string matrix
	jsr	pc,reads	;read string
	br	matrd2

matrd1:	jsr	pc,readf	;read a floater
matrd2:	jsr	pc,swpipc	;swap ipc's
	rts	pc

;input pushpop for individual matrix entries

matin:	jsr	pc,tstrng	;test string flag
	beq	matin1		;br if not a string matrix
	jsr	pc,inputs	;input a string
	br	matrd2

matin1:	jsr	pc,inputf	;input a floater
	br	matrd2
;routines to set matria, matrib, & matric to
;pointers to the array headers whose addresses
;follow matrix pushpops.  mat3st sets matrib to the
;address of the second arg of a matrix operation
;and does nat2st.  mat2st sets matria to the
;address of the first arg and does mat1st.  mat1st
;sets matric to the address of the destination matrix.

mat3st:	mov	#6,r0
matnst:	mov	#matric,r2
	add	spda,r2
	add	r0,r2
matlst:	movb	(r5)+,-(r2)
	dec	r0
	bne	matlst
	rts	pc

mat2st:	mov	#4,r0
	br	matnst

mat1st:	mov	#2,r0
	br	matnst
;a frequently used pushpop double-indexed repeat
;coroutine for matrix stuff

mat2lp:	.byte	pprdim,matria	;push source row dim
	.byte	ppcdim,matria	;push source column dim
matlp0:	.byte	ppemc		;exit to machine code
	.even
	mov	spda,r0		;set base register
	add	matric(r0),r0	;get absolute address of destination header
	mov	(r1),dim2(r0)	;get the column dim
	mov	2(r1),dim1(r0)	;get the row dim
	jsr	r5,@(sp)+	;back to internal pushpop
matl00:	.ppm	pprepi,cb2	;set immer rpt lim
	.byte	ppbegn		;get inner rpt start
	.ppm	ppopi,nvt	;save in a temp
	.ppm	pprepi,cb1	;set outer rpt lim
	.byte	ppbegn		;get outer rpt start
	.ppm	ppopi,nv1	;pop to control variable
	.ppm	ppushi,r1ext	;position subroutine address
mt2lp1:	.ppm	ppfri,nv1,cb1+1,mt2lp4-me.	;begin outer repeat
	.ppm	ppushi,nvt	;fetch inner repeat start
	.ppm	ppopi,nv2	;pop to control variable
mt2lp2:	.ppm	ppfri,nv2,cb2+1,mt2lp3-me.	;begin inner repeat
	.byte	ppcali		;call subroutine
mt2lp3:	.ppm	ppnxi,nv2,cb2+1,mt2lp2-me.	;end of inner repear
mt2lp4:	.ppm	ppnxi,nv1,cb1+1,mt2lp1-me.	;end of outer repeat
	.byte	pprts		;honest sub exit

;a frequently used pushpop double-indexed repeat
;coroutine for matrix stuff - with indices on r1 stack.

mat2in:	.byte	ppreor		;set up test on indices
	.ppm	ppifj,matlp0-me.  ;br if user-supplied indices
mat2i1:	.byte	pprdim,matric	;othws, use the
	.byte	ppcdim,matric	;destination matrix dims
	.ppm	ppuj,matlp0-me.	;rejoin nonzero case
;a variant of mat2in
mat2i2:	.byte	ppreor		;set up test on indices
	.ppm	ppifj,matl00-me.	;br if user supplied indices
	.ppm	ppuj,mat2i1-me.	;just like mat2in
	.even
;the matrix copy pushpop
matcpy:	jsr	pc,mat2st	;set source & destination address
	jsr	r5,@(sp)+	;into interpretive mode
	.ppm	ppcals,mat2lp-me.	;set up double loop
;this code gets executed repeatedly
	.byte	ppmpus,matria,nv1,nv2	;push source entry
matcp1:	.byte	ppmpop,matric,nv1,nv2	;pop to destination
matcp2:	.byte	ppcoru		;back to repeat loop
	.byte	ppexit		;home james
	.even
;matrix scalar multiplies
matsmi:	jsr	pc,flt		;fit integer & drop thru
matsmf:	jsr	pc,mat2st	;set source & destination address
	jsr	r5,@(sp)+	;into interpretive mode
	.ppm	ppcals,mat2lp-me.	;set up double loop
;this code gets executed repeatedly
	.byte	ppfflt		;fetch multiplier
	.byte	ppmpus,matria,nv1,nv2	;push source entry
	.byte	ppmulf		;multiply
	.byte	ppmpop,matric,nv1,nv2  ;pop to destination
	.byte	ppcoru		;back to double loop
	.byte	ppkif		;get rid of scalar multiplier
	.byte	ppexit		;out
	.even
;routine useful to matrix add & substract

matad0:	.byte	pprdim,matria	;push a row dim
	.byte	pprdim,matrib	;push b row dim
	.byte	ppcmpi		;error if not equl
	.byte	ppcdim,matria	;push a col dim
	.byte	ppcdim,matrib	;push b col dim
	.byte	ppcmpi		;error if not equal
	.byte	ppcoru		;back
	.even

;matrix add

matadd:jsr	pc,mat3st	;set source & destination addresses
	jsr	r5,@(sp)+	;enter interpreter
	.ppm	ppcals,matad0-me.	;test dimensions
	.ppm	ppcals,matlp0-me.	;enter interpreter
;this code gets executed over & over
	.byte	ppmpus,matria,nv1,nv2	;push a entry
	.byte	ppmpus,matrib,nv1,nv2	;push b entry
	.byte	ppaddf		;add
	.ppm	ppuj,matcp1-me.	;exit vai matcp1
	.even

;matrix sub

matsub:	jsr	pc,mat3st	;set source & destination addresses
	jsr	r5,@(sp)+	;enter interpreter
	.ppm	ppcals,matad0-me.	;test dimensions
	.ppm	ppcals,matlp0-me.	;set up double loop
;over & over
	.byte	ppmpus,matria,nv1,nv2	;push a entry
	.byte	ppmpus,matrib,nv1,nv2	;push b entry
	.byte	ppsubf		;subtract
	.ppm	ppuj,matcp1-me.	;exit via matcp1
	.even
;matrix multiply

matmul:	jsr	pc,mat3st	;set source & destination addresses
	jsr	r5,@(sp)+	;enter interpreter
	.byte	ppcdim,matria	;matrix a's column dimension
	.byte	pprdim,matrib	;matrix b's row dimension
	.byte	ppcmpi		;error if indices not equal
	.ppm	pprepi,cb3	;set dot product loop limit
	.byte	ppbegn		;get its start
	.ppm	ppopi,nvtm	;save in temp
	.byte	pprdim,matria	;matrix a's row dim
	.byte	ppcdim,matrib	;matrix b's column dim
	.ppm	ppcals,matlp0-me.	;set up double outer loop
;this is the inner loop
	.byte	ppufl0		;push floating 0
	.ppm	ppushi,nvtm	;get dot loop start
	.ppm	ppopi,nv3	;pop to control var
mamul1:	.ppm	ppfri,nv3,cb3+1,mamul2-me.	;begin dot loop
	.byte	ppmpus,matria,nv1,nv3	;push a term
	.byte	ppmpus,matrib,nv3,nv2	;push b term
	.byte	ppmulf		;multiply
	.byte	ppaddf		;add to running total
mamul2:	.ppm	ppnxi,nv3,cb3+1,mamul1-me.	;end of dot loop
	.ppm	ppuj,matcp1-me.	;exit via matcp1
	.even
;matrix transpose

mattrn:	jsr	pc,mat2st	;set source & destination addresses
	jsr	r5,@(sp)+	;no into interpretive mode
	.byte	ppcdim,matria	;push source column dim
	.byte	pprdim,matria	;push row dim
	.ppm	ppcals,matlp0-me.	;set up double loop
;this code gets executed over & over
	.byte	ppmpus,matria,nv2,nv1	;push source entry
	.ppm	ppuj,matcp1-me.	;exit via matcp1
;the matrix zero pushpop

matzro:	jsr	pc,mat1st	;get destination address
	jsr	r5,@(sp)+	;into interpretive mode
	.ppm	ppcals,mat2in-me.	;initialize double loop
;inside code
mzro:	.byte	ppufl0		;push floating zero
	.ppm	ppuj,matcp1-me.	;go to matcp1
	.even

;the matrix one pushpop

matc1:	jsr	pc,mat1st	;get destination address
	jsr	r5,@(sp)+	;into interpretive mode
	.ppm	ppcals,mat2in-me.	;init double loop
;inside code
mc1:	.byte	ppufl1		;push floating one
	.ppm	ppuj,matcp1-me.	;go to matcp1
	.even

;the matrix identity pushpop

matid:	jsr	pc,mat1st	;get destination address
	jsr	r5,@(sp)+	;into interpretive mode
	.ppm	ppcals,mat2in-me.	;initialize double loop
;inside code
	.ppm	ppushi,nv1
	.ppm	ppushi,nv2
	.byte	ppeqi
	.ppm	ppitj,mc1-me.	;on diagonal, push 1
	.ppm	ppuj,mzro-me.	;off diagonal, push 0
	.even
;matrix print pushpop

matprc:	mov	#100000,-(r1)	;signal crlf
	br	matpn1

matprt:	mov	#200,-(r1)	;signal tab
	br	matpn1

matprn:	clr	-(r1)		;signal no tabs or crlf's
matpn1:	jsr	pc,mat1st	;get source address
	jsr	r5,@(sp)+	;start interpreting
	.ppm	ppopi,nvtm	;save tab-crlf flag
	.ppm	ppcals,mat2i2-me.	;set up double loop
;this code is executed repeatedly
	.byte	ppmpus,matric,nv1,nv2	;push item for printing
	.byte	ppmpr		;print it
	.byte	ppcoru		;back to repeat loop
	.byte	ppexit
	.even

;matrix read routine

matrd:	jsr	pc,mat1st	;set destination
	jsr	r5,@(sp)+	;interpretive mode
	.ppm	ppcals,mat2in-me.	;set up double loop
;repeated code
	.byte	ppmrd0		;read an entry
	.ppm	ppuj,matcp1-me.	;exit via matcp1
	.even


;matrix input routine

matinp:	jsr	pc,mat1st	;set destination
	jsr	r5,@(sp)+	;interpretive mode
	.ppm	ppcals,mat2in-me.	;set up double loop
;repeated code
	.byte	ppmain		;input an entry
	.byte	ppmpop,matric,nv1,nv2  ;pop to destination matrix
	.ppm	ppushi,nvtm	;push done flag
	.ppm	ppifj,matcp2-me.  ;go to matcp2 if not done
	.byte	ppijs		;if done early, dump coroutine addrs
	.byte	ppexit
	.even
;the matrix inversion pushpop
matinv:	jsr	pc,mat2st	;set source and destin. addresses
	jsr	r5,@(sp)+	;enter interpretive mode
	.byte	pprdim,matria		;push arg row dim
	.byte	ppcdim,matria		;push arg column dim
	.byte	ppcmpi		;check for equality
	.byte	ppemc		;exit to machine code
	.even
	ifzero	ne,(r1)+,milcm4  ;br if dims nonzero
	dimerr	!fatal		;othws, send back dimension error
milcm4:	jsr	r5,@(sp)+	;back to pushpop
	;copy arg into destination
	.ppm	ppcals,mat2lp-me.	;set up double loop
	.byte	ppmpus,matria,nv1,nv2  ;push arg entry
	.byte	ppmpop,matric,nv1,nv2  ;pop to destination
	.byte	ppcoru		;back to double loop
	;end of copy operation
	.byte	ppufl1		;push a floating one
	.ppm	ppopf,det	;store it in det
	.byte	ppfix1		;push an integer one
	.ppm	ppopi,nv1	;init. loop var. to 1
milb1:	.ppm	ppfri,nv1,cb1+1,mile1-me.	;begin loop to init.
						;0'th col. of a to 0
	.byte	ppufl0			;push a floating zero
	.byte	ppmpop,matric,nv1,z00000	;set a(i,0)=0
mile1:	.ppm	ppnxi,nv1,cb1+1,milb1-me.	;end of loop
	.byte	ppfix1		;push integer 1
	.ppm	ppopi,nv2	;init. i to 1
milb2:	.ppm	ppfri,nv2,cb1+1,mile2-me.	;set up i loop
	.byte	ppufl0		;push floating 0 as init. val. of p
	.byte	ppfix1		;push integer 1
	.ppm	ppopi,nv1	;init. j to 1
milb3:	.ppm	ppfri,nv1,cb1+1,mile3-me.	;set up j loop
	.byte	ppmpus,matric,nv1,z00000	;push a(j,0)
	.byte	ppufl0		;push floating 0
	.byte	ppnef		;test for <>
	.ppm	ppitj,mile3-me.	;branch if a(j,0)<>0
	.byte	ppmpus,matric,nv1,nv2	;push a(j,i)
	.byte	ppffuf		;copy p at head of stack
	.byte	ppabxf		;calc. its absolute val.
	.byte	ppffuf		;copy a(j,i)
	.byte	ppabxf		;calc. its abs. val.
	.byte	ppgef		;test for >=
	.ppm	ppifj,mill1-me.	;branch if abs(a(j,i))>abs(p)
	.byte	ppkif		;kill a(j,i),leaving old p value
	.ppm	ppuj,mile3-me.	;and branch back
mill1:	.ppm	ppopf,temf	;store a(j,i) in temf
	.byte	ppkif		;kill the old value of p
	.ppm	ppushf,temf	;bring back c(temf) as the new p val.
	.ppm	ppushi,nv1	;push the value of j
	.ppm	ppopi,nvtm	;store it as the value of l
mile3:	.ppm	ppnxi,nv1,cb1+1,milb3-me.	;end of j loop
	.ppm	pprepf,temf	;save the final p value in temf
	.ppm	ppushf,det	;push the curr. det. value
	.byte	ppmulf		;calc. p*c(det)
	.ppm	pprepf,det	;and store back in det
	.byte	ppufl0		;push a floating 0
	.byte	ppnef		;test for det<>0
	.ppm	ppitj,mill3-me.	;branch if <>0
	.byte	ppemc		;exit to machine code
	.even
	minver			;determinant=0, can't invert
	rts	pc		;keep going after error
mill3:	.byte	ppufl1		;push floating 1
	.byte	ppnegf		;negate,get floating -1 on stack
	.byte	ppmpop,matric,nvtm,nv2	;a(l,i)=-1
	.ppm	ppushi,nv2		;push i
	.byte	ppflt		;float i
	.byte	ppmpop,matric,nvtm,z00000	;a(l,0)=i
	.ppm	ppushi,nvtm		;push l
	.byte	ppflt		;float l
	.byte	ppmpop,matric,z00000,nv2	;a(0,i)=l
	.byte	ppfix1		;push an integer 1
	.ppm	ppopi,nv1		;init. j value to 1
milb4:	.ppm	ppfri,nv1,cb1+1,mile4-me.	;set up j loop
	.byte	ppmpus,matric,nvtm,nv1	;push a(l,j)
	.byte	ppnegf		;negate,get -a(l,j) on stack
	.ppm	ppushf,temf	;push p
	.byte	ppdivf		;calc. -a(l,j)/p
	.byte	ppmpop,matric,nvtm,nv1		;a(l,j)=-a(l,j)/p
mile4:	.ppm	ppnxi,nv1,cb1+1,milb4-me.	;end of j loop
	.byte	ppfix1		;push an integer 1
	.ppm	ppopi,nv1		;init. j to 1
milb5:	.ppm	ppfri,nv1,cb1+1,mile5-me.	;set up j loop
	.ppm	ppushi,nv1	;get j
	.ppm	ppushi,nvtm	;get l
	.byte	ppeqi		;test if j=l
	.ppm	ppitj,mile5-me.	;branch if =
	.byte	ppmpus,matric,nv1,nv2	;get a(j,i), i.e. s
	.byte	ppmpus,matric,nv1,nv2	;get it again
	.ppm	ppushf,temf		;push p
	.byte	ppdivf		;divide by p
	.byte	ppmpop,matric,nv1,nv2	;a(j,i)=a(j,i)/p
	.byte	ppfix1		;push an integer 1
	.ppm	ppopi,nv3		;init. k to 1
milb6:	.ppm	ppfri,nv3,cb1+1,mile6-me.	;set up k loop
	.ppm	ppushi,nv3		;push k
	.ppm	ppushi,nv2		;push i
	.byte	ppeqi		;test if k=i
	.ppm	ppitj,mile6-me.	;branch if =
	.byte	ppmpus,matric,nv1,nv3	;push a(j,k)
	.byte	ppffuf		;copy s at top of stack
	.byte	ppmpus,matric,nvtm,nv3	;push a(l,k)
	.byte	ppmulf		;calc. s*a(l,k)
	.byte	ppzsma		;calc. a(j,k)+s*a(l,k),testing for underflow
	.byte	ppmpop,matric,nv1,nv3	;store in a(j,k)
mile6:	.ppm	ppnxi,nv3,cb1+1,milb6-me.	;end of k loop
	.byte	ppkif		;kill top float on stack,i.e. s
mile5:	.ppm	ppnxi,nv1,cb1+1,milb5-me.	;end of j loop
mile2:	.ppm	ppnxi,nv2,cb1+1,milb2-me.	;end of i loop
	;unscrambling of rows and columns begins here
	.byte	ppfix0		;push an integer 0
	.ppm	ppopi,nv3	;set pptst flag=0
	.ppm	ppushi,cb1	;push n
	.byte	ppfix1		;push an integer 1
	.byte	ppsubi		;calc. n-1
	.ppm	ppopi,cb2		;and store it in cb2
mill4:	.byte	ppfix1		;push an integer 1
	.ppm	ppopi,nv1		;init. i to 1
milb7:	.ppm	ppfri,nv1,cb2+1,mile7-me.	;set up i loop
	.byte	pptst,mill5-.-1	;branch if col. pass
mill14:	.byte	ppmpus,matric,nv1,z00000	;push a(i,0),call it l
	.ppm	ppuj,mill6-me.	;branch to mill6
mill5:	.byte	ppmpus,matric,z00000,nv1	;push a(0,i),call it l
mill6:	.byte	ppfix		;fix l
	.ppm	pprepi,nvtm	;and store in nvtm
	.ppm	ppushi,nv1	;push i
	.byte	ppeqi		;test if i=l
	.ppm	ppitj,mile7-me.	;if so, branch
	.byte	pptst,mill7-.-1	;branch if col. pass
	.ppm	ppushf,det	;push c(det)
	.byte	ppnegf		;negate,leaves -c(det) on stack
	.ppm	ppopf,det	;and store back in det
mill7:	.byte	ppfix0		;push an integer 0
	.ppm	ppopi,nv2	;init. j to 0
milb8:	.ppm	ppfri,nv2,cb1+1,mile8-me.	;set up j loop
	.byte	pptst,mill8-.-1		;branch if col. pass
	.byte	ppmpus,matric,nv1,nv2	;push a(i,j) as p
	.ppm	ppuj,mill9-me.	;branch to mill9
mill8:	.byte	ppmpus,matric,nv2,nv1	;push a(j,i) as p
mill9:	.byte	pptst,mill10-.-1	;branch if col. pass
	.byte	ppmpus,matric,nvtm,nv2	;push a(l,j)
	.byte	ppmpop,matric,nv1,nv2	;and store it in a(i,j)
	.ppm	ppuj,mill11-me.	;branch to mill11
mill10:	.byte	ppmpus,matric,nv2,nvtm	;push a(j,l)
	.byte	ppmpop,matric,nv2,nv1	;and store it in a(j,i)
mill11:	.byte	pptst,mill12-.-1	;branch if col. pass
	.byte	ppmpop,matric,nvtm,nv2	;store p in a(l,j)
	.ppm	ppuj,mile8-me.		;branch to mile8
mill12:	.byte	ppmpop,matric,nv2,nvtm	;store p in a(j,l)
mile8:	.ppm	ppnxi,nv2,cb1+1,milb8-me.	;end of j loop
	.byte	pptst,mill5-.-1	;branch if col. pass
	.ppm	ppuj,mill14-me.	;branch to mill14
mile7:	.ppm	ppnxi,nv1,cb2+1,milb7-me.	;end of i loop
	.byte	pptst,mill15-.-1	;branch if col. pass completed
	.byte	ppfix1		;push an integer 1
	.ppm	pprepi,nv3		;set pptst flag <>0
	.ppm	ppuj,mill4-me.+1	;branch to mill4+1; go around again for cols.
mill15:	.byte	ppexit		;done,exit
	.even
	.end
