ma.m:scafix:	modd	#1.0,f0		;get integer part
xcma4.m:	modd	#1.0,f0		;get integer part
xfma2.m:	divf	#2.0,f0		;e'=(x/e+e)/2
xfma2.m:	ldd	#1.0,f0		;f0=1.0
xfma2.m:	mulf	#2.0,f2
xfma2.m:	modd	#0.25,f0	;f0=fract(x/2pi)
xfma2.m:	modf	#4.0,f0		;f0=fract(4*fract(x/2pi))
xfma2.m:	addf	#1.0,f0		;y=1.0-x
xfma2.m:plusqz:	ldf	#1.0,f1		;1.0
xfma2.m:	subf	#1.0,f0		;x*root3-1.0
xfma4.m:	divd	#2.0,f0		;e'=(x/e+e)/2e
xfma4.m:	cmpd	#1.0,f2		;is this log(1.000000000)?
xfma4.m:	addd	#1.0,f2		;make f2 positive
xfma4.m:m16:	modd	#16.0,f2	;f2=fract(16*(x*log2(e)-float(z)))
xfma4.m:	divd	#16.0,f2	;e=f2/16
xfma4.m:	modd	#1.0,f0		;f0= fract(x/2pi)
xfma4.m:	modd	#4.0,f0		;f0= fract(4*fract(x/2pi))
xfma4.m:	addd	#1.0,f0		;y=1.0-x
xfma4.m:plusqz:	ldd	#1.0,f1		;1.0
xfma4.m:	subd	#1.0,f0		;x*root3-1.0
