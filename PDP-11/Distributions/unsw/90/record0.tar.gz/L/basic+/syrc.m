; The use and distribution of the information
; contained herein may be restricted.
;
.iif	ndf	$list$	.nlist
title	syrc,<basic+ system definitions>,24,19-jul-74,tph/mhb/jdm
;
; macro definitions

; get a word out of the data area at run time - gwtxt

.macro	gwtxt	reg
	  movb	(r5)+,-(r1)
	  movb	(r5)+,-(r1)
	  mov	(r1)+,reg
.endm

; transcendentals

.macro	topr1	op,addr
	  mov	#addr,r0
	  jsr	pc,@#pushf2
	  jsr	pc,@#op
.endm

.macro	movflt	adr1,adr2
.rept	fltlen
	  mov	adr1,adr2
.endr
.endm

.macro	fltpp	arg
.rept	fltlen/2
	  cmp	arg,arg
.endr
.endm

.macro	fltclr	arg
.rept	fltlen-2
	  clr	arg
.endr
.endm
; equates to la's tables

plus	=	 0	;+
star	=	 1	;*
;	=	 2	;/
bmins	=	 3	;binary -
;	=	 4	;unary -
;	=	 5	;^ or **
;	=	 6	;.and.
;	=	 7	;.or.
;	=	10	;.xor.
;	=	11	;.not.
;	=	12	;.imp.
;	=	13	;.eqv.
equals	=	14	;=
;	=	15	;<>
;	=	16	;>
;	=	17	;>=
;	=	20	;<
;	=	21	;<=
;	=	22	;==
push	=	23	;
lpar	=	24	;(
rpar	=	25	;)
comma	=	26	;,
endol	=	27	;end of line
semico	=	30	;;

colon	=	43	;:
pound	=	44	;#
then	=	300	;then
else	=	301	;else
step	=	302	;step
asfile	=	303	;as file
;	=	304	;
unless	=	305	;unless
using	=	306	;using
zer	=	307	;zer(
idn	=	310	;idn(
con	=	311	;con(
trnlp	=	312	;trn(
invlp	=	313	;inv(
to	=	314	;to
finasf	=	315	;for input as file
fouasf	=	316	;for output as file
as	=	317	;as
rcorsz	=	320	;record size
mode	=	321	;mode
;clussz	=	322	;cluster size
record	=	323	;record
count	=	324	;count
;filesz	=	325	;file size
tkcont	=	 46	;cont(inue)
;	=	 50	;list
;	=	 52	;list nh
;	=	 54	;delete
;	=	 56	;length
;	=	 60	;new
;	=	 62	;old
;	=	 64	;rename
;	=	 66	;replace
;	=	 70	;run
;	=	 72	;run nh
;	=	 74	;assign
;	=	 76	;save
;	=	100	;deassign
;	=	102	;unsave
;	=	104	;catalog
;	=	106	;compile
hello	=	110	;hello
;	=	112	;bye
;	=	114	;tape
;	=	116	;key
tkapnd	=	120	;append
tkmore	=	122	;more to come...

tkrand	=	124	;randomize
tkmat	=	126	;mat(rix)
tkchng	=	130	;change
input	=	132	;input
tkprin	=	134	;print
;	=	136	;dim(ension)
;	=	140	;def(ine)
goto	=	142	;goto
;	=	144	;if
;	=	146	;for
;	=	150	;on
;	=	152	;return
;	=	154	;let
;	=	156	;data
;	=	160	;restore
;	=	162	;resume
;	=	164	;stop
;	=	166	;end
;	=	170	;on error goto
;	=	172	;open
;	=	174	;close
;	=	176	;chain
remrk	=	200	;rem(ark)
;	=	202	;next
;	=	204	;name
tread	=	206	;read
tgosub	=	210	;gosub
;	=	212	;fnend
;	=	214	;input line
;	=	216	;while
;	=	220	;until
;	=	222	;kill
tkget	=	224	;get
;	=	226	;put
;	=	230	;field
;	=	232	;lset
;	=	234	;rset
tkuloc	=	236	;unlock
tkslep	=	240	;sleep
tkwait	=	242	;wait
tkshel	=	244	;shell
print	=	tkprin

; xt (translator table) definitions

dotabv	=	tkcont		;lowest index into table

tldipt	=	0		;start of table indicies

tldipb	=	tkrand-tkcont+tldipt	;start of program table indicies

tldipl	=	tkshel		;highest 'good' index
; argument macros

.macro	args	a1,a2,a3
.if	ne	a3+0
	.word	a1*4+a2*4+a3
.mexit
.endc
.if	ne	a2+0
	.word	a1*4+a2
.mexit
.endc
	.word	a1
.endm

; push-pop macro

.macro	.ppm	pshpop,ad1,ad2,ad3
	.byte	pshpop
.narg	tmptag
.if	ge	tmptag-2
me.	=	.+2
	.byte	ad1&177400/400,ad1&377
.endc
.if	ge	tmptag-3
me.	=	.+2
	.byte	ad2&177400/400,ad2&377
.endc
.if	ge	tmptag-4
me.	=	.+2
	.byte	ad3&177400/400,ad3&377
.endc
.endm

; loop macros

.macro	.bloop	name,count
name'1:	dec	count		;beg loop name
	bmi	name'2+2	;if count exausted, exit
.endm

.macro	.eloop	name
name'2:	br	name'1		;end of loop name
.endm
; testing macros

.macro	if	a1,rel,a2,addr,by
	 cmp'by	a1,a2		;branch if a1 rel a2
	 b'rel	addr
.endm

.macro	ifzero	rel,a1,addr,by
	 tst'by	a1		;branch if a1 rel 0
	 b'rel	addr
.endm

.macro	ifsign	a1,sgn,addr,by
	 tst'by	a1
	 b'sgn	addr		;branch if a1 sgn'us
.endm

.macro	jmask0	rel,a1,mask,addr,by
	 bit'by	#'mask,a1	;if 0 rel a1 & mask
	 b'rel	addr		;then go to addr
.endm

.macro	ifz	a1,addr,by
	 tst'by	a1
	 beq	addr		;if a1 = 0 then addr
.endm

.macro	ifnz	a1,addr,by
	 tst'by	a1
	 bne	addr		;if a1 <> 0 then addr
.endm

.macro	iftoka	rel,arg,addr
	 jsr	r5,@#tatest
	 .word	arg
	 b'rel	addr
.endm

.macro	tbitt	a1,addr
	 bitb	#'a1,toke(r0)
	 beq	addr
.endm
; job flag bits:

$.equ.	jfstop	,100000		;stop this user after current pop
$.equ.	jfonce	,040000		;just run him once
$.equ.	jfcc	,   200+jfstop	;a ^c has been typed
$.equ.	jfccc	,   100		;enable ^c error catcher
;$.equ.		,    10		;unused
$.equ.	jfrts	,     6		;numerical errors posted here
;$.equ.		,     1		;unused
; error modifiers

post	=	emt		;post an error

pstflt	=	2+jfstop	;floating error
pstfix	=	4+jfstop	;fix error
pstdv0	=	6+jfstop	;division by 0 error

ioterr	=	emt+1		;get the fip error

; user area definitions

r1smin	=	60		;r1 stack minimum
caiblk	=	2		;initial #k in user job

; relative to spda (all <0)

onecon	=		-10	;constant of 1. (4 word)
z00000	=	onecon	+2	;location of an integer 0
picon	=	onecon	-10	;pi constant (4 word)
det	=	picon	-10	;det for mat inv (4 word)
errval	=	det	-2	;err value
cb1	=	errval	-2	;outer loop limit
nv1	=	cb1	-2	;outer loop control var
cb2	=	nv1	-2	;inner loop limit
nv2	=	cb2	-2	;inner loop control var
nv3	=	nv2	-2	;dot loop control var in mat mul
nvt	=	nv3	-2	;reserved double loop temp
nvtm	=	nvt	-2	;free temp word
cb3	=	nvtm	-2	;dot loop limit in mat mul
temf	=	cb3	-10+2	;temp over matrib & cb3 (4 word)
matrib	=	temf		;2nd matrix operand address
matria	=	matrib	-2	;1st matrix operand address
matric	=	matria	-2	;??
recoun	=	matric	-2	;count value for get
r1ext	=	recoun	-2	;r1 stack ??
curlin	=	r1ext	-2	;current line number when ^c
valerr	=	curlin	-2	;error line number
status	=	valerr	-2	;status of last 'open'
lstpda	=	status	;!!!!!!!!last minus spda address

basven	=	1.		;basic-plus compatibility level

fas	=	3		;string type
fai	=	2		;integer type
faf	=	1		;floating type
; tokens consist of a byte of flags and an
; address word - flag bits as below

tokf	=	200		;token flag - sign bit
basf	=	100		;basic verb, fncn, oropr
dataf	=	 40		;data - num or string
funcf	=	 20		;function flag - must be 020
indexf	=	 10		;indexed flag - must be 010
strinf	=	  4		;string flag - must be 004
floatf	=	  2		;floating flag - must be 002
intgf	=	  1		;integer flag - must be 001

linum	=	tokf			;token for line numbers
dstr	=	tokf+strinf+dataf 	;token for data strings
dflt	=	tokf+floatf+dataf 	;token for floating data
dint	=	tokf+intgf+dataf  	;token for integer data
fltint	=	256.*dflt+dint
bastok	=	tokf+basf		;basic token usually returned from fixed table
bfi	=	bastok+funcf+intgf	;token for integer funct
bff	=	bastok+funcf+floatf	;token for floating funct
bfs	=	bastok+funcf+strinf	;token for string funct

varfif	=	basf+dataf+funcf+indexf+strinf ;value for testing number variables
; stat is a flag word for the lexical analyzer
; flag bits are those described below : the first 8 bits
; are often set and unset in parallel, the others one
; at a time

; parallel bits

blinef	=	     1		;beg of logical line
bstatf	=	     2		;beg of statement
ctunf	=	     4		;change - to unary
quot1f	=	    10		;turned off by cr
linumf	=	    20		;next item a possible line number
arf	=	    40		;matrix command array flag
harf	=	   100		;treat nonstring variables as array variables
comf	=	   200		;comment flag - must be the sign bit

; single bits

tablef	=	  1000		;variable name not in symbol table
immedf	=	  2000		;immediate logical line
numbf	=	  4000		;set when nmscan sees a number
outexf	=	 10000		;set when outside arith expr (tlcomf)
convff	=	 20000		;set when intg to fltg conv required
fileff	=	 40000		;getting a file name
quotf	=	100000		;complemented by quote or apostrophe - must be sign
; constants

space	=	40		;ascii space
cr	=	15		;ascii carriage return
asclf	=	12		;ascii line feed
tab	=	11		;ascii tab
alt	=	33		;ascii altmode
ctrz	=	32		;ascii control/z
bmin	=	37		;dummy for binary minus
bumchr	=	36		;dummy for line feeds
endchr	=	35		;end of line symbol in lex buffer
com	=	'!		;comment delimiter
quote	=	'"		;quote
apos	=	''		;apostrophe
slop	=	arylen+12	;# free bytes needed in variable table for new
blins	=	bstatf+blinef+linumf+convff ;flags set at beg line
blinc	=	harf+arf+comf+quotf+ctunf+immedf ;flags cleared at beg line
bstas	=	outexf		;flags set at beg of statement
bstac	=	blinc+blinef+bstatf ;flags cleared at beg of statement
;vars	=	0		;flags set after variable
varc	=	linumf+ctunf+quot1f ;flags cleared after variable
;lins	=	0		;flags set after line number
linc	=	blinef+bstatf+ctunf ;flags cleared after line number
sig	=	2		;siginicant digit flag in atof
expn	=	10		;atof flag for having seen e in number
dotf	=	20		;atof flag for having seen . in number
; some from the editor

blklen	=1024.*2		;core block length 
linlen	=256.			;line buffer length, in bytes
ttylen	=90.			;tty buffer length, in bytes

;editor flag assignments

edgofl	=     1			;load and go
edapnd	=     2			;append this file to current stuff
edcomp	=    10			;compile input file
edfirs	=    20			;1 = presence of .tmp been investigated
edetmp	=    40			;if so, this is answer:  1=it exists
edeoff	=   100			;end statement encountered
edcont	=   200			;if continue allowed
ckebit	=   400			;checkpass error --inhibit run-ing
ckdefb	=  1000			;def so far without enddef -- ckpass
edpres	=  2000			;variables have been zeroed
edimed	= 10000			;rts running in immediate mode for job
trnker	= 40000			;text set in tag before error call
reeror	=100000			;reentered error processor

;editor channel assignments

baschn	=14.*2			;channel 14 (*2)
basch	=14.			;version for rts
bacchn	=15.*2			;channel for .bac file work
bacch	=15.			;version for sso
tmpchn	=13.*2			;channel 13 (*2)
tmpch	=13.			;for .tmp file work

; static virtual address area (first 256. words)

	org	ucore
tmptag	=	.		;starting here...

$.def.	usrorg	,000		;start of sp stack area
$.def.	key	,2		;jobs status
$.def.	firqb	,fqbsiz		;file request block
$.def.	xrb	,xrbsiz		;io control parameters
$.def.	corcmn	,1.+127.	;core common string (len+up to 127. bytes)
$.def.	edflag	,2		;editor bit flag word
$.def.	runlvl	,2		;running level (0=errors;1=ed;2=rts)
;*** following 15. words (r5ring to oasl) are the csr's
;*** saved in .bac files and must appear together and in order
$.def.	r5ring	,2		;save spot for r5 (ipc)
$.def.	r1ring	,2		;save spot for r1 (polish stack)
$.def.	scth	,2		;pointer to current text header
$.def.	spta	,2		;pointer to base of text area
$.def.	spda	,2		;pointer to base of data area
$.def.	r1corg	,2		;r1 stack origin (base)
;*** following 3 groups of 3 are ordered
$.def.	cosi	,2		;code stack initial value
$.def.	cosp	,2		; "    "    current pointer
$.def.	cosl	,2		; "    "    limit
$.def.	opsi	,2		;operator stack initial value
$.def.	opsp	,2		; "        "    current pointer
$.def.	opsl	,2		; "        "    limit
$.def.	oasi	,2		;operand stack initial value
$.def.	oasp	,2		; "       "    current pointer
$.def.	oasl	,2		; "       "    limit
$.def.	scafac	,2		;scaling pointer
$.def.	scaval	,1		;scaling value
$.def.	scaupv	,1		;user program scaling value
$.def.	r1cont	,2		;r1 stack saved for "cont"
$.def.	xxmore	,1		;more to come token spot
$.def.	xcdchn	,1		;channel to close on max core exceeded
$.def.	endres	,usrorg+1000-tmptag	;1st free word in static area
$.def.	nstorg	,0		;start of nonstatic area
$.def.	gok1	,usrorg+1400-tmptag	;junk
$.def.	r1sorg	,0		;r1 stack origin
$.def.	gok2	,usrorg+2000-tmptag	;junk
$.def.	pdaorg	,0		;program data start
$.def.	gok3	,usrorg+7400-tmptag	;still more junk!
$.def.	ptaorg	,0		;program text start
$.def.	gok	,usrorg+10000-tmptag	;junk
$.def.	cailen	,0		;end of initial user core area
; relative to pta

.macro	$pta	x,y
x	=	tmptag
.list
	x	=	x
.nlist
tmptag	=	tmptag+2
.endm

tmptag	=	4

$pta	badbyt,	ppbadc*256.!ppbadc	;pop for bad stmt (in minsta)
$pta	proptr,	endpta-begpta		;pludyn
$pta	tagptr,	-taglen			;last used word in statement header area
$pta	prolim,	cailen-tgsorg		;plulim
$pta	taglim,	-tagsiz			;limit of statement header area
; relative to pda

.macro	$pda	x,y
x	=	tmptag
.list
	x	=	x
.nlist
tmptag	=	tmptag+2
.endm

.macro	$pdab	x,y
x	=	tmptag
.list
	x	=	x
.nlist
tmptag	=	tmptag+1
.endm

tmptag	=	0

$pda	pda,	dumstr			;pointer to last and dummy string
;core allocation parameters
$pda	psd,	endstt-begpda
$pda	stat,	+blinef			;lex analyzer status flags
$pda	nexstr,	endstt-begpda		;next available word in the string area
	pdd	=	nexstr
$pda	nexfre,	beghdr-begpda		;points to last cell used in string header area
	mdd	=	nexfre
$pda	strlim,	tgsorg-tagsiz-pdaorg	;string limit -- leave room for a few tags
	pld	=	strlim
$pda	spclim,	r1sorg-pdaorg		;string header limit with 24 words slop
	mld	=	spclim
$pda	aryptr,	base			;first i/o array header item
;do not disturb cell order back to begpda
$pda	eddumm,	+0			;string for noname.bas
	tmptag=tmptag+12
;permanent variable area--------------------------------------------
;core allocator variables-go in pda
;"nominals" are free space amounts guaranteed by ca
$pda	r1snom,	+100			;nominal for r1 stack
$pda	tagnom,	+626.			;nominal for statement headers
$pda	pronom,	+564.			;nominal for statement-push pop
$pda	hdrnom,	+342.			;nominal for string headers
$pda	strnow,	+0			;modified by ca
$pda	strnom,	+1000			;nominal for strings
;do not disturb cell order back to r1snom
$pda	sumnom,	+0			;sum of all nominals
$pda	nstrnm,	+0			;sum of all but string
$pda	base,	.=.			;length of base area
	tmptag=tmptag-2
	tmptag=tmptag+14
$pda	tlmind,	beghdr-begpda		;old value of str hdr ptr, restrd after error
$pda	rndm,	randy			;random number storage bin
	tmptag=16.*20+tmptag-4
$pda	oegtln,	0		;on error goto line number
$pda	waittm,	0		;wait time for tty i/o
;the above 2 words go in unused words in slot 15.
;rest of stuff is supossed to be 0 and is not moved into user area by catsup
$pda	resloc,	+0		;save scth for errors
$pda	currio,	0			;current io pointer
$pda	dathdr,	0			;data statement header
$pda	datcnt,	0			;data statement residual count
$pda	datptr,	0			;data statement pointer
	cntbas=datcnt-base
	ptrbas=datptr-base
$pda	intppf,	+0		;backup loc for internal pp pointer
$pda	nexdro,	+0		;drop thru "next" statement if rpterm flag on
$pda	rpterm,	+0		;treat "next" statement as terminal
$pda	matblk,	+0		;used by some of the string pushpops
	tmptag=tmptag+4
$pda	gosub,	+0	;go sub counter for stack underflow
$pda	dumstr,	0	;a dummy string and null at that
	tmptag=tmptag+4
$pda	stack,	0	;stack save location
$pda	phlb,	.=.	;lexical buffer
$pda	linbuf,	0	;as ref'd by rc
	tmptag=tmptag+linlen-2
$pda	ttybuf,	0	;tty out buffer
	tmptag=tmptag+ttylen-2
;basget and basput variables----------------------------------
$pda	basbuf,	.=.+1000		;tmp file buffer
	tmptag=tmptag+1000-2
;beginning of tr variables
$pda	dispos,	.=.			;rest are used only by compiler
$pda	bascur,	+0			;next address to be written in tmp file
$pda	getagv,	+0			;answer cell for getag subrs
$pda	vartab,	+0		;a thru z
	tmptag=25.*2+tmptag
;small data items
$pda	clb,	+0		;current beg lex buf
$pda	toke,	+0		;token (lower byte only)
$pda	toka,	+0		;address portion of token
$pda	unquot,	+0		;holds unquote char to clr quotf
$pda	cflg,	+0		;flag word for modifier routines
;tl data (in user swap area)
$pda	tlpcou,	+0	;parenthesis depth counter
$pda	tlfnbk,	+0	;temp. loc. for function block - dodef
$pda	tlfnat,	+0	;picture word acc. -dodef
$pda	prpmod,	+0	;temp. loc. for saved pmode  value
$pda	tlbiff,	+0	;built-in (1) vs user-def (0) fcn flag
$pda	ptoka,	+0	;word part of prev.token inf.
$pda	tllino,	+0	;line no. of curr. stat.
$pda	cprec,	+0	;curr. prec. value
$pda	prprec,	+0	;prev. prec. value
$pda	pmode,	+0	; current pmode value
$pda	nargs,	+0	;no. of args. in fcn. call or indexed var.
$pda	tlcttw,	+0	;comf. word temp.
$pda	tltopc,	+0	;"prog.ctr." for gen. code
$pda	tlstpc,	+0	;"prog. counter" for gen. code,curr. block
$pda	tltyct,	+0	;type (0,1, or 2) of curr. fcn. name
$pda	tlcomr,	+0	;type of tlcomf result(0=float,1=fix,2=string)
$pda	tloprp,	+0	;operator stack rel ptr
$pda	tloarp,	+0		;addr of link in firsp header
$pda	basbeg,	+0	;initial text pointer for statement header
$pda	tlgcop,	+0	;genc temp.
$pdab	saintf,	+0	;flag byte used by saint flag ops
$pdab	match,	+0	;match flag for syntax interpreter
$pdab	tloprf,	+0	;flag operand -- quit on 2nd in row
$pdab	ptoke,	+0	;flag byte of prev. token inf.
$pdab	tlfnaf,	+0	;comf flag******tlfnaf,tloptf must be one word*****
$pdab	tloptf,	+0	;flag for two operators in a row
$pdab	ptokf,	+0	;prev. token flag
$pdab	tlcofl,	+0	;condit. expression flag
$pdab	tllsfl,	+0	;"left-side" flag in dolet
$pdab	tlfnar,	+0	;number of args for function
$pdab	tlinfl,	+0	;flag - top-level=0, inside=1
$pdab	tlenby,	+0	;contains "nexts" or "halt" operator
loas=200.		;length of operand stack
lops=50.		;length of operator stack
lcos=300.		;length of code stack
	tmptag=tmptag+loas
$pda	oasb,		;operand stack
	tmptag=tmptag+lops-2
$pdab	opsb,		;operator stack
	tmptag=tmptag+lcos
$pdab	cosb,		;code stack
$pda	pdaend,	.=.			;symbol for end
;end variables belonging in swap area-------------------------------
;	string header definitions
link	=	 0	;link to next header (rel .)
pntr	=	 2	;points to data (rel .-2)
length	=	 4	;length of data (in bytes)

;	io block definitions

;link	=	 0	;
;pntr	=	 2	; as in strings
;length	=	 4	;
bytcnt	=	 6	;# of bytes remaining in buffer
curloc	=	10	;current buffer position
slot	=	12	;io channel for this header
flags	=	13	;status and device properties byte
positn	=	14	;number of chars output since last <cr>
curblk	=	16	;rndm accs device: blk at beginning of buf

;	iob flags bits definitions

;flgrnd/400=	200	;random access device
wrtary	=	100	;bit to show re-write of the buffer needed
force	=	 flgfrc/400	;force bit for user i/o buffer header flags byte
aryiob	=	 20	;bit to show header is for io and not array
;flgpos/400=	 10	;monitor keeps current line position

;	array header definitions
;link	=	 0	;
;pntr	=	 2	; as in strings
;length	=	 4	;
dim1	=	 6	;current first dimension
dim2	=	10	;current second dim
aryslt	=	12	;slot # if virtual array
aryflg	=	flags	;array/buffer control flags
arylim	=	14
maxstr	=	24	;maximum string length for virtual string array
pdim1	=	26	;permanent dim 1--reset on run,etc.
pdim2	=	30	;permanent dim 2--ditto

;	array flag bit definitions
dskary	=	200	;bit to show disk residence
;aryiob	=	 20	;0 for array header
dimary	=	 10	;bit to show array dimensioned
refary	=	  4	;bit to show array referenced
strary	=	  2	;bit to show a array of strings
fixary	=	  1	;bit to show a fixed array

;	statement header definitions
;link	=	 0	;
;pntr	=	 2	; as in strings
;length	=	 4	;
tagpus	= 2			;pointer to pushpop code
tagpul	= 4			;length of pushpop
tagtxt	= 6			;pointer to text in .tmp
tagtxl	=10			;length of text
tagtyp	=11			;one byte type code, for assignments, see dltone
tagbin	=12			;statement number in binary


iolen	=	20	;the length of an i/o buffer header
arylen	=	32	;the length of an array header
taglen	=14			;bytes per tag
strlen	=	 6	;the length of a basic string

; starting random number value

randy	=	15073		;as random as any!
.iif	ndf	$list$	.list
