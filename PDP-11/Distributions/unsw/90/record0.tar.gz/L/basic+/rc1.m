; The use and distribution of the information
; contained herein may be restricted.
;
title	rc,<run-time mainline>,24,22-jul-74,tph/mhb/jdm

$list$	=	1		;get prefix files listed

; define push-pop table initially

	org	pt,0

	zskip	256.,error
	..	ppaddi,addi	;integer +
	..	ppsubi,subi	;integer -
	..	pprsbi,rsubi	;integer reverse -
	..	pppwri,pwri	;integer ^
	..	ppeqf,.eq.f	;floating equal operator
	..	ppeqi,.eq.i	;integer equal operator
	..	ppeqs,.eq.s	;string equal oprerator
	..	ppevs,.ev.s	;string equivalence
	..	ppgtf,.gt.f	;floating >
	..	ppgti,.gt.i	;integer >
	..	ppgts,.gt.s	;string >
	..	ppgef,.ge.f	;floating >=
	..	ppgei,.ge.i	;integer >=
	..	ppges,.ge.s	;string >=
	..	ppltf,.lt.f	;floating <
	..	pplti,.lt.i	;integer <
	..	pplts,.lt.s	;string <
	..	pplef,.le.f	;floating <=
	..	pplei,.le.i	;integer <=
	..	pples,.le.s	;string <=
	..	ppnef,.ne.f	;floating <>
	..	ppnei,.ne.i	;integer <>
	..	ppnes,.ne.s	;string <>
	..	ppnegi,negi	;integer complement
	..	ppushi,pushi	;integer push
	..	ppushs,pushs	;string push
	..	pprepi,repli	;replicate integer
	..	ppreps,repls	;replicate string
	..	pplen,len	;find string length
	..	ppspac,spaces	;make string of spaces
	..	ppsbst,substr	;find substring
	..	ppsbs1,subst1	;find other substring
	..	ppinst,instr	;find if in there at all
	..	ppnum,num$	;function num$
	..	ppval,val	;function val
	..	ppuj,uj		;unconditional jump
	..	ppujx,ujx	;unconditional jump external
	..	ppifj,ifj	;if false jump
	..	ppifjx,ifjx	;if false jump external
	..	ppitj,itj	;if true jump
	..	ppitjx,itjx	;if true jump external
	..	ppushx,pushjx	;push and jump external
	..	ppopj,popj	;pop jump return
	..	ppnot,.not.	;logical not
	..	ppand,.and.	;logical and
	..	ppor,.or.	;logical or
	..	ppxor,.xor.	;logical xor
	..	ppimp,.imp.	;logical implies
	..	ppiff,.iff.	;logical if and only if
	..	ppredf,readf	;read floating
	..	ppredi,readi	;read integer
	..	ppreds,reads	;read string
	..	ppconc,concat	;string concatenate
	..	ppenda,endrpt	;end of conditional operator
	..	ppfri,fori	;for integer entry
	..	pprpi,repti	;repeat integer
	..	ppfrf,forf	;for floating
	..	pprpf,reptf	;repete floating
	..	ppfrix,forix	;for integer external
	..	pprpix,reptix	;repete integer external
	..	ppfrfx,forfx	;for floating external
	..	pprpfx,reptfx	;repeat floating external
	..	ppnxi,nexti	;next integer
	..	ppnxf,nextf	;next floating
	..	ppnxix,nextix	;next integer external
	..	ppnxfx,nextfx	;next floating external
	..	ppclos,closer	;close
	..	ppssi,ssi	;select slot for input
	..	ppsso,sso	;select slot for output
	..	ppinpl,inputl	;input line
	..	ppinpf,inputf	;input floating
	..	ppinpi,inputi	;input integer
	..	ppinps,inputs	;input string
	..	ppstop,stop	;stop execution
	..	pphalt,ujx6	;halt after immediate execution
	..	ppbadc,badcod
	..	ppuuo,uuocon	;uuo control
	..	pptab,tabf	;tab function
	..	pppos,posf	;pos function
	..	ppchr,chr$	;chr$ function
	..	ppnxts,nexts	;end of current statement go to next one
	..	ppasc,ascii	;asc function
	..	ppdat$,date$	;date function
	..	pptim$,time$	;time of day function
	..	ppshes,shells	;call shell with string (UNIX)
	..	ppslep,sleep	;sleep function
	..	ppwait,waitf	;wait function
	..	ppushc,pushc	;push imediate
	..	pprest,restor	;restore verb
	..	ppresu,resume	;resume verb
	..	pponub,onsub	;on ... gosub ...
	..	ppcsv,csv	;change string to vector
	..	ppcvs,cvs	;change vector to string
	..	ppopio,openio	;open for input and output
	..	ppopin,openi	;open for input
	..	ppopou,openo	;open for output
	..	ppname,namer	;rename
	..	ppkill,killer	;delete
	..	ppendi,endinp	;empty the input buffer
	..	ppleft,left	;initial substring
	..	ppon,onstmt	;on statement
	..	pponer,onerr	;on error goto
	..	ppsdro,setdro	;set the nexdro flag for loop ppops
	..	ppdi,dupli	;duplicate integer
	..	ppjsld,jmpsld	;jump external, then nexts, all in one
	..	ppend,ujx8	;end of program
	..	ppfix1,pushi1	;push integer 1
	..	ppkif,pftjs	;kill top floater (pop float to j-space)
	..	ppnxtl,nextl	;external jump to next numbered stmt.
	..	ppifnl,ifnl	;if false nxtl, else internal jump
	..	ppshel,shelli	;call shell for session (UNIX)
	..	ppdups,dupls	;duplicate string at top of r1 stack
	..	ppswap,swapby	;swap byte function
	..	ppcall,callfn	;function enter
	..	ppxit,exit	;function exit
	..	ppentr,error	;
	..	ppreal,realfg	;set 'real' flag (bit 15)
	..	ppcvss,cvss	;special string function
	..	ppssor,ssorec	;select slot with "record"
	..	ppstng,string	;make a string
	org	rc

	.globl	dattbl,mid9,edsave,pos000,interp,interb
	.globl	rtsent,pushs1,pushs3,dupls,trpint
	.globl	r1sout,econom,pushs,cvs3,ccint,closer,restor
	.globl	pushi1,num$00,savem,repls1,.eq.s,atoi
	.globl	rsacrg,svacrg,savreg,resreg,edrest
	.globl	lenp3,thent,pushs2,time07,readf,reads
	.globl	builds,inputf,inputs,ssix1,sso01,ssi04
	.globl	sso,opni11,opni20,clsr09,date07,mid6,cc2int
	.globl	read.,write.,getbuf,iodie

	.globl	printa,prl14,prompt,iosame,doccox,childs,childp
	.globl	intfun,atof,pstjs,fltle2,dobye
	.globl	rtsret,ederr,ederrn,zotall
	.globl	printl,atline,printi,crlf,editor
	.globl	rtsrer,pushf3,pushf1,popf1,pushf
	.globl	pushf2,mfltl2,indo1,fix,indx90,flt
	.globl	indr3,addf,subf,cmpf
	.globl	maxsig
	.globl	muli,fltlen
	.globl	scan,ederrf,basfrc,dltonr,edrsr1
	.globl	deffun,opnr20,pops1
;	the user's swap image is composed of four major parts
;	1.  the user's hardware stack (sp=%6) & static area
;	2.  the user stack (r1=%1)
;	3.  the user data area
;	4.  the user text area

;	the rsts monitor maintains the swap save area (9. words
;	starting @ swpsav) in the static area. this area also
;	contains the csr's that point to critical areas
;	in the user's image. these csr's are maintained by
;	the core setup, core allocator, and garbage collector.

;	the text and data areas are similar in structure
;	in that each has a base area that describes the
;	amount and usage of core allocated to it by the core allocator.
;	   00		a link to the first string header
;	   02		the positive static limit
;	   04		the negative static limit
;	   06		the positive dynamic limit
;	   10		the negative dynamic limit

;	the means of dynamic storage is the string header
;	it contains at least three(3) words in the form
;	1.  link word
;	2.  pntr word
;	3.  length word

;	i/o headers also contain
;	4.  slot byte
;	5.  flag byte
;	6.  bc word
;	7.  curloc word

;	array headers contain
;	4.  2 word dynamic dimensions
;	5.  slot byte if disk based
;	6.  type byte
;	7.  2 word upper limit address
;	8.  2 word additive offset
;	9.  individual item word length word
;	10. 2 word static dimensions

;	text headers contain
;	4.  ascii text pointer word
;	5.  ascii text length byte
;	6.  statement label word(1-32767)
;	7.  statement type byte
; save and restore registers routines

savreg:	mov	r4,-(sp)	;save registers r4,
	mov	r3,-(sp)	; r3,
	mov	r2,-(sp)	;  r2,
	mov	r1,-(sp)	;   r1,
	mov	r0,-(sp)	;    and r0 on sp stack.
	mov	5*2(sp),-(sp)	;now move r5 value on stack again
	rts	r5		;and exit nicely

resreg:	inc	(sp)+		;dump old r5 without changing c-bit
	mov	(sp)+,r0	;restore registers r0,
	mov	(sp)+,r1	; r1,
resrg2:	mov	(sp)+,r2	;  r2,
	mov	(sp)+,r3	;   r3,
	mov	(sp)+,r4	;    and r4 from sp stack.
	rts	r5		;now restore r5 and exit

edrest:	inc	(sp)+		;dump old r5 without changing c-bit
	mov	(sp)+,r0	;restore r0, but
	br	resrg2		;don't restore r1

; real flag setter (sets bit 15 unconditionally)

realfg:	bis	#100000,(r1)	;set flag bit
	rts	pc		;now exit
;used to invoke fn, leaves:
;	r1	old ipc
;		old scth
;		currio
;		fn blk	(is negative--flag for exit)
;		stack

callfn:	clr	r0
	bisb	(r5)+,r0
	swab	r0
	bisb	(r5)+,r0	;pick up word from prog area
	mov	spda,r2		;pick up base
	mov	stack(r2),-(r1)	;save error reset stack
	mov	r0,-(r1)	;save function block
	mov	currio(r2),-(r1);save io block
	add	r2,r0		;make it abs.
	mov	(r0),r0		;get statement
	bmi	callf1		;ck for defined
	undfni	!fatal	;undefined function called

callf1:	jsr	pc,pshjx2	;otherwise pushjx
	mov	spda,r0		;saved stack udate
	add	#2,stack(r0)	;picture word now on stack soon goes
;routine used to save old values of dummy variables and post arguments
;as current values is first op in def, always runs just after callfn
	mov	(r1)+,-(sp)	;temp move ipc
	mov	(r1)+,-(sp)	;and scth
	mov	(r1)+,-(sp)	;save currio
	mov	(r1)+,-(sp)	;function block
	add	(sp),r0		;now absolute
	mov	(r1)+,-(sp)	;save stack
	mov	2(r0),r0	;picture word
	mov	r0,-(sp)	;for later
	jsr	r5,deffun	;adjust types of arguments
	mov	r1,r4		;setup a temporary r1
	mov	(sp)+,r2	;retrieve picture
	add	#10,r5		;skip all junk at beginning stmt
entr02:	clr	r3		;will be type index
	ror	r2		;a la jfs
	rol	r3		;get first bit
	ror	r2		;to make "complement obverse"
	rol	r3		;here
	beq	entr01		;if done
	mov	(r5)+,r0	;get location-know even
	swab	r0		;and in right order
	add	spda,r0		;make absolute
	asl	r3		;times two to branch on
	add	r3,pc		;zingo!
	halt			;huh??[can't ever get here]
	br	entr05		;integer arg
	br	entr06		;floater
	cmp	(r0)+,(r4)+	;string, skip links
	add	r0,(r0)		;make both absolute
	add	r4,(r4)		;and
	mov	(r0),-(sp)	;then swap pointers
	mov	(r4),(r0)	;to the strings
	mov	(sp)+,(r4)	;and
	sub	r0,(r0)		;relativize them
	sub	r4,(r4)		;again
	cmp	(r0)+,(r4)+	;don't try auto inc in prev instructions
entr05:	mov	#1,r3		;count of additional items to move
entr04:	mov	(r0),-(sp)	;swap with no change
	mov	(r4),(r0)+	;this next
	mov	(sp)+,(r4)+	;item-part of a # or str len
	sob	r3,entr04	;count through datum
	br	entr02		;then process next arg

entr06:	mov	#fltlen,r3	;fltlen parts to a
	br	entr04		;floater

entr01:	mov	(sp)+,-(r1)	;restore stack
	mov	(sp)+,-(r1)	;restore fn blk
	mov	(sp)+,-(r1)	;currio
	mov	(sp)+,-(r1)	;and scth
	mov	(sp)+,-(r1)	;aaaand ipc
	rts	pc		;and done entring

;exit does a push of the function's value and uses the list of arguments
;in the def statement to restore all the saved dummy arg values
exit:	mov	r1,r2		;test used up stack
	add	#6,r2		;size of block put on by call
	cmp	r1,r1corg	;test for underflow--too many fnend's/returns
	bhis	1$		;ok
	tst	(r2)		;see if gosub
	bmi	3$		;ok if -, gosub leaves 0
1$:	exitnr	!fatal		;fn's & sub's badly nested

3$:	mov	(r1)+,-(sp)	;old ipc
	mov	spta,r4		;get prog base
	add	r4,(sp)		;make abs
	add	r4,(r1)		;old header
	mov	(r1)+,scth	;post it
	mov	spda,r0		;get base
	mov	r0,r2		;save it for later, too
	mov	(r1)+,currio(r0);restore rel currio
	mov	(r1)+,r0	;pick up fn blk (or gosub's zero)
	mov	(r1)+,stack(r2)	;restore pre-fn stack
	add	r2,r0		;make fnblk absolute
	mov	(r0)+,r5	;def statement header
	add	r4,r5		;absolute
	add	2(r5),r5	;pointer to pushpop
	add	#7,r5		;skipentr and fn blk
	movb	(r5)+,-(sp)	;pop value code
	mov	(r0)+,r4	;picture word
	mov	r0,-(sp)	;save fn value loc
exit07:	clr	r3		;calculate obverse
	ror	r4		;using rotate
	rol	r3		;dance
	ror	r4		;i'm getting
	rol	r3		;dizzy
	asl	r3		;make it a word address
	mov	(r5)+,r0	;take advantage of evenness
	swab	r0
	add	r2,r0		;make arg absolute
	add	r3,pc		;zingo!
	br	exit12		;done
	br	exit11		;integer
	br	exit10		;floating
	jsr	pc,pops1	;string-restore it
	br	exit07		;next saved dummy

exit10:	jsr	pc,popf1	;restore a floater
	br	exit07		;process next
exit11:	mov	(r1)+,(r0)	;pop integer
	br	exit07		;do next one
exit12:	mov	(sp)+,r0	;restore value pointer
	movb	(sp)+,r4	;code from after entr
	add	r4,pc		;and dispatch
	br	exit05		;floating
	br	exit06		;integer
	jsr	pc,pushs1	;string
	tst	(r0)+		;reset length
	clr	(r0)		;to free string space
	br	exit13
exit05:	jsr	pc,pushf2	;push the floater
	br	exit13
exit06:	mov	(r0),-(r1)	;push integer
exit13:	mov	(sp)+,r5	;old ipc
	rts	pc

edsave:	mov	r4,-(sp)	;save r4
	mov	r3,-(sp)	; and r3
	mov	r2,-(sp)	;  and r2
	mov	r0,-(sp)	;   and r0 (but not r1)
	mov	4*2(sp),-(sp)	;save r5 again
	rts	r5		;then exit

;*****************************************************
;	QUIT interrupt handler
;******************************************************
cc2int:	.sig			;renew out lease on life
	+	sigqit		;we are a quit signal
	+	cc2int		;and live here
	bic	#jfccc,jobf	;he must be in trouble
	br	ccxint		;remember us forever

;*****************************************************
;	INTERRUPT interrupt handler
;*****************************************************
ccint:	.sig			;reset our signal
	+	sigint		;we are an interrupt
	+	ccint		;and we live here
ccxint:	bis	#jfcc,jobf	;stop because interrupt hit
	rti

; unexecutable statement error

badcod:	baderr	!fatal		;call it fatal

;illegal op-code routine

error:	errerr	!fatal		;bad interpretive code

post00:	flterr			;floating point error
shut01:
;	jmp	interb		;ready set go

;	main interpreter

interb:	ifzero	eq,(r1)+,interp	;br if noninternal interpretation
	mov	r5,-(sp)	;othws, save external pp pointer
	mov	-2(r1),r5	;& use previously saved internal pointer
	br	interp		;do it one more time, unless he goofs

interl:	movb	(r5)+,r0	;get an op-code
	asl	r0		;make into an index
	jsr	pc,@pt+256.(r0)	;dispatch into handler
interp:	tst	jobf		;see if he wants us to quit
	bpl	interl		;stop if so requested
;	br	shutup		;fall thru to shut-up
;quit routine 

shutup:	clr	-(r1)		;clear internal pp flag
	tst	r5		;internal or external? (user<basic)
	bpl	3$		;it is external
	mov	r5,(r1)		;othws, save internal pp pointer
	mov	(sp)+,r5	;& replace it with external pp pointer
3$:	mov	#jobf,r4	;get a most useful pointer
	movb	(r4),r2		;see if ^c or post error
	bpl	shut00		;branch if post
	bic	#jfcc!jfrts,(r4);clear ^c flag so we can continue
	mov	spda,r2		;get program data bias
	mov	scth,r0		;get current statement header
	mov	tagbin(r0),-(sp);and the line # from that
	mov	(sp),curlin(r2)	;now set ^c line #
	ble	shut04		;abort on ^c if immediate mode
	mov	oegtln(r2),r0	;get "on error goto" line #
	beq	shut04		;none, so die
	bit	#jfccc,(r4)	;enabled for ^c?
	beq	shut04		;nope, so die also
	bic	#jfccc,(r4)	;yep, but trun it off now
	mov	#ctrlce-emt,errval(r2);set error code as ^c
	.ttrst			;cancel ^o done by ^c
	jmp	trap20		;and go to it

stop:	stperr			;programed stop
	clr	-(r1)		;clear internal pp flag
shut04:	mov	#rtsret,(sp)	;set return to "rtsret"
uuoxi0:	mov	spda,r0		;get a data pointer
	mov	currio(r0),-(r1);store the current io pointer
	mov	scth,-(r1)	;store header address
	mov	spta,r4		;get a text pointer
	sub	r4,(r1)		;make relative
	sub	r4,r5		;make ipc relative
	mov	r5,-(r1)	;save the ipc too
	mov	r1,r1cont	;save r1 for "cont"
	sub	r1corg,r1cont	;make it rel
	bis	#edcont,edflag	;he can continue because stuff saved ok
	rts	pc		;return to the editor

shut00:	bic	#-jfrts-1,r2	;clear all but our bits
	bic	#jfstop!jfrts,(r4)	;clear our bits in job flags
	add	r2,pc		;dispatch
	br	shut01		;no posting errors
	br	post00		;post error 0
	br	post01		;post error 1
;	br	post02
post02:	divby0
	br	shut01

post01:	fixerr			;number too big to be an integer
	br	shut01		;and continue

;********************************************************
;	TRAP interrupt handler
;********************************************************
trpint:	jsr	r4,savem	;save r4 ... r0
	mov	iosts,r4	;save through re-signal
	.sig			;catch again
	+	sigemt
	+	trpint
	mov	4*2(sp),r2	;get the saved pc
	movb	-2(r2),r3	;get trap even byte code
	beq	trap06		;branch if post error
	mov	spda,r2		;get data area pointer
	mov	currio(r2),-(sp);save current io pointer
	mov	runlvl,-(sp)	;save the calling level
	clr	runlvl		;then set it to 0 (errors)
	tstb	r3		;see if fatal error
	bpl	1$		;branch if non-fatal
	mov	#ederr,-(sp)	;assume error is not ioterr
	bit	#176,r3		;now see if it is ioterr
	bne	12$		;it's not (ioterr = 001)
	mov	#ederrn,(sp)	;it is--we want to go to ederrn then
12$:	mov	(sp)+,6*2(sp)	;store where return will return to
	bic	#1,r1		;make stack even for push later
	bic	#edgofl,edflag	;no go after load if error
	bic	#-177-1,r3	;clear fatal bit
	beq	trap05		;if now zero then exit
1$:	cmpb	r3,#1		;see if an io error
	bne	9$		;branch if garden varity user error
	movb	r4,r3		;add in iosts
9$:	mov	r3,errval(r2)	;store the error number
	bic	#jfrts,jobf	;insure no posting errors now
	mov	scth,r4		;get current header address
	mov	tagbin(r4),-(sp);and the line # from that
	mov	(sp),valerr(r2)	;set that line # for "erl"
	ble	trap11		;fatal error if in immediate mode
	cmp	(pc),2(sp)	;see if saved runlvl is 2 (user)
	beq	trap07		;if 2, then user running
trap11:	jsr	pc,getbuf	;get a little buffer
	clr	(r4)+		;clear the plink
	tstb	(r4)+		;skip job
	movb	#errfq,(r4)+	;stash the function
	mov	r3,(r4)+	;and the error number
	jsr	pc,fipcal	;call monitor for fip service
	clr	-(r1)		;set slot zero-console
	jsr	pc,sso		;select for message
	.ttrst			;cancel any ^o
	mov	#firqb+fqerno,r2	;message pointer
	jsr	pc,printl	;print it
	mov	(sp)+,r4	;get line # of error
	ble	4$		;don't bother print "line 0"
	mov	r4,-(r1)	;do bother printing real line
	mov	#atline,r2	;so print " at line"
	jsr	pc,printl	;use printl to print line
	jsr	pc,printi	;print the line number
4$:	jsr	pc,crlf		;finish the line
trap05:	mov	(sp)+,runlvl	;restore running level
	mov	spda,r2		;get data area pointer
	mov	(sp)+,currio(r2);restore i/o pointer
trap10:	mov	(sp)+,r0	;restore the registers
	mov	(sp)+,r2
	mov	(sp)+,r3
	mov	(sp)+,r4
	rti			;whither wanderest thou wayfarer??

trap06:	bis	(r2)+,jobf	;set error bits
	mov	r2,4*2(sp)	;update the pc
	br	trap10		;restore regs and go

trap07:	mov	oegtln(r2),r0	;get error line number
	beq	trap11		;branch if no user error routine
	cmp	r3,#errcc	;see if stop
	bhis	trap11		;exit if stoping
trap20:	mov	stack(r2),r1	;remove his junk
	add	r1corg,r1	;make absolute
	mov	r2,r4		;use r4 for a string header pointer
8$:	add	(r4),r4		;go skipping down the chain
	cmp	r4,r1		;see if on the old stack
	blo	8$		;branch if it was
	sub	r2,r4		;make first string address relative
	mov	r4,(r2)		;and store it away
	mov	scth,r5		;start of current statement
	sub	spta,r5		;make relative
	mov	r5,resloc(r2)	;save header address

	global	<usrsp>

	mov	usrsp,sp	;reset stack
	mov	#interp,-(sp)	;interpreter start up opint
	br	ujx1		;start him up
;	if (false or true) jump routine

itj:	tst	(r1)		;check sense
	beq	itj1		;if 0 (false) make -1 (true)
	mov	#-1,(r1)	;if non-0 (true) make real true (-1)
itj1:	com	(r1)		;if 0 (false) make non-0 (true)

ifj:	gwtxt	r0		;get the possible place to go
	tst	(r1)+		;test boolean value
ifj2:	bne	ifj1		;if true wxit now
	add	r0,r5		;else update ipc
ifj1:	rts	pc		;and return

pifj:	mov	spda,r2
	mov	(r1),rpterm(r2)  ;save truth value for "next" statement
	br	ifj

ifnl:	tst	(r1)+		;special pop for if statements
	beq	nextl		;nextl if false, otherwise uj

;	unconditional jump routine

uj:	movb	(r5)+,-(r1)	;get the displacement
	movb	(r5)+,-(r1)
	add	(r1)+,r5	;adjust the ipc
	rts	pc		;return

;	pop and jump routine

popj:	mov	spda,r2		;get the address of the data area
	tst	gosub(r2)	;too many returns?
	ble	popj99		;yes
	dec	gosub(r2)	;decrement the counter
	tst	6(r1)		;this word shoud be 0 iff gosub did it
	bne	popj99		;branch if an error
	mov	spta,r4		;get the text area pointer
	mov	(r1)+,r5	;get the return address
	add	r4,r5		;relocate it
	add	r4,(r1)		;relocate the header address too
	mov	(r1)+,scth	;store the old header
	cmp	(r1)+,(r1)+	;pop the two type words
	mov	r1,stack(r2)	;update error recovery stack
	sub	r1corg,stack(r2)	;must be relative
ifjx1:	rts	pc

popj99:	exittm	!fatal		;no gosub!!!!!!!!

; preceeding word must be negative!!
	.word	1.		;40.^0.
	.word	40.		;40.^1.
r50a00:	.word	1600.		;40.^2.
;	if true jump external routine
itjx:	com	(r1)		;reverse the sense
;	if false jump external routine

ifjx:	gwtxt	r0		;get the pointer location
	tst	(r1)+		;see how to go
ifjxn2:	bne	ifjx1		;if true fall thru
	br	ujx1		;play like ujx now

;variant of ifjx used by "for" rpt loops

pifjxn:	mov	spda,r2
	mov	(r1),rpterm(r2)  ;save truth value for "next" statement
	br	ifjx

;	push jump external routine

pushjx:	gwtxt	r0		;get destination address
pshjx1:	clr	-(r1)		;clear two words so we look
	inc	-(r1)		;  like function calls
	mov	spda,r2		;get data area pointer
	inc	gosub(r2)	;increment counter
pshjx2:	sub	spta,r5		;make ipc relative
	mov	scth,-(r1)	;save the statement header address
	sub	spta,(r1)	;and make it relative
	mov	r5,-(r1)	;save it for the popj
	br	ujx1		;make like ujx

onsub:	jsr	pc,onset	;do common stuff for on ... gosub ...
	br	pshjx1		;now do gosub

onstmt:	mov	#ujx1,-(sp)	;set return address
onset:	clr	r0		;clear up r0
	bisb	(r5)+,r0	;get count times 2 (no sign extend)
	mov	(r1)+,r2	;get index
	ble	1$		;<=0 is an error
	add	r2,r2		;now index is really times 2
	cmp	r2,r0		;see if in range
	blos	2$		;o.k.
1$:	onbad	!fatal		;on error

2$:	add	r0,r5		;adjust ipc
	mov	r5,r4		;and save it
	sub	r2,r4		;back to header
	movb	(r4)+,-(r1)	;now get it
	movb	(r4)+,-(r1)
	mov	(r1)+,r0	;into r0
	rts	pc		;then exit accordingly
;	unconditional jump external routine

ujx:	gwtxt	r0		;get the pointer location
ujx1:	mov	spta,r5		;start of text pointer area
	add	r0,r5		;relocate to pointer
ujx2:	bit	#edimed,edflag	;are we in immediate mode?
	bne	ujx4		;yes--don't let him enter program
	tst	length(r5)	;check for a non-zero length
	bne	ujx3		;go if non-zero
	stmerr	!fatal		;not found error

ujx4:	nrnerr	!fatal		;use run--cant't continue

resu3:	reserr	!fatal		;no error and resume used

resume:	mov	spda,r2		;get a data area pointer
	gwtxt	r5		;get the statement header
	bne	resu1		;branch if start some place else
	mov	resloc(r2),r5	;get saved location
	beq	resu3		;branch if no error and simple resume
resu1:	clr	resloc(r2)	;clear the tracks
	add	spta,r5		;make absolute
	mov	#2,runlvl	;goto user level
	br	ujx2		;and go like ujx

nextl:	bit	#edimed,edflag	;if immediate command
	bne	ujx6		;quit
	mov	scth,r5		;save orig. line number
	mov	tagbin(r5),r4	;for comparison
	beq	ujx6		;catch imed. ifthen falling thru
nextl1:	tst	(r5)		;end of stmt. list?
	beq	ujx81		;yes
	add	(r5),r5		;next one please
	tst	length(r5)	;phantom?
	beq	nextl1		;yes
	cmp	r4,tagbin(r5)	;same line number?
	beq	nextl1		;yes
	br	ujx3		;ah, new line

ujx8:	jsr	pc,zotall	;end statement closes all files
ujx81:	bic	#edcont,edflag	;clear continue
ujx6:	tst	(sp)+		;remove the interpreter's return
	jmp	rtsret		;return to the editor compiler etc
;next statement routine
;one of the principle things to do is insure that there is enough
;r1 stack for the next statement.  most statements cannot use more stack
;then two times the number of bytes in the compiled code (hart's theorem)
;the exception's to this rule are covered by the r1smin fudge
;which takes care of things like print using. to be 100% safe, we insure
;that there are r1smin+2*taglen bytes of r1 stack to spare.
 

jmpsld:	jsr	pc,ujx		;jump,slide pop used to skip fn defs
nexts:	mov	scth,r5		;get the address of the current header
nxts01:	tst	(r5)		;see if this is the end
	beq	ujx8		;if so quit and return to the editor
	add	(r5),r5		;go down the links
rtsent:	tst	length(r5)	;see if any code to do
	beq	nxts01		;go on if null
ujx3:	mov	r5,scth		;save the header address
ujx5:	mov	spda,r2		;get data area pointer
	mov	r1,r3		;copy stack
	sub	r1corg,r3	;make relative
	mov	r3,stack(r2)	;save for errors maybe
	mov	length(r5),r4	;get code length
	asl	r4		;make into guess at stack length
	add	#r1smin,r4	;else set the minimum
	mov	r1,-(sp)	;push the current r1
	sub	r4,(sp)		;see where it might go
	cmp	(sp)+,#nstorg	;see if enough room
	bhis	ujx7		;branch if no more stack needed
	asl	r4		;buy in quantity
	cmp	r4,r1snom(r2)	;is it giving us this much?
	blos	1$		;if so
	mov	r4,r1snom(r2)	;make sure core allocator knows how much is needed
1$:	jsr	pc,r1sout	;get more stack space
	mov	scth,r5		;get header back
ujx7:	add	pntr(r5),r5	;relocate to the string
	rts	pc		;return-good luck
;	logical and routine

.and.:	com	(r1)		;since bic is .not. and
	bic	(r1)+,(r1)	;complement source and do a bic
	rts	pc		;and return

;	logical equivalence routine

.iff.:	jsr	pc,.xor.	;do the xor

;	logical not routine

.not.:	com	(r1)		;a simple complement will solve the problem
	rts	pc		;and return

;	logical implies routine

.imp.:	com	2(r1)		;.imp=a.or.-b so make not b and fall thru

;	logical or routine

.or.:	bis	(r1)+,(r1)	;do the or
	rts	pc		;and return

.xor.:	mov	r1,r4		;copy the stack pointer
	mov	(r4)+,r3	;copy of the first element
	bic	(r4),(r1)	;clear common bits
	bic	r3,(r4)		;and the other way too
	br	.or.		;and finish like or(not bobby)


;	fixed point arithmetics

negi:	neg	(r1)		;negate the number
	rts	pc		;and return

rsubi:	neg	2(r1)		;negate next to top element and fall thru

addi:	add	(r1)+,(r1)	;add polish mode
	rts	pc		;that was quick wasn't it

subi:	sub	(r1)+,(r1)	;subtract polish mode
	rts	pc		;that was quick also

;	replicate integer routine

repli:	gwtxt	r0		;get the data area location
	add	spda,r0		;make it an absolute address
	mov	(r1),(r0)	;store with out the pop
	rts	pc		;and return

cmps:	mov	r1,r0		;copy stack pointer
	mov	r1,r3		;make two temp copys
	add	#strlen,r3	;r3 points to second string header
	mov	length(r0),r2	;get # 1 length
	mov	length(r3),r4	;get # 2 length
	add	pntr(r0),r0	;get address of #1
	add	pntr(r3),r3	;get address of #2
cmps0:	dec	r2		;see if any left in #1
	blt	cmps2		;fill with <sp> of none left
	dec	r4		;see if any in #2
	blt	cmps4		;fill with <sp> if none left
	cmpb	(r0)+,(r3)+	;compare the two bytes
	beq	cmps0		;if equal continue
	bhi	cmps1		;else exit if .gt.
cmps3:	ccc			;set .lt.
	rts	pc		;and return

cmps4:	cmpb	(r0)+,#40	;see if trailing spaces on #1
	beq	cmps0		;if so go again
cmps1:	ccc			;.gt.
	sen			;set lt flag
	rts	pc		;and return

cmps2:	dec	r4		;see if any in #2
	blt	cmps9		;if none then equal strings
	cmpb	#40,(r3)+	;see if trailing spaces in #2
	beq	cmps0		;if so go again
	br	cmps3		;else show .gt.

cmps9:	cmp	r2,r4		;see if equal length
	bne	cmps7		;if same with spaces exit now
	ccc			;show identical with
	+sez ! sec		; z-bit and carry
	rts	pc

cmps7:	ccc			;clear all codes
	sez			;set equal indicator
	rts	pc

dupli:	mov	(r1),-(r1)	;copy the word
	rts	pc		;and return
dupls:	mov	r1,r0		;we're going to inter poshs so set
	mov	spda,r2		;up r0 + r2 for entry at push1
	br	pushs1		;and go there

repls:	gwtxt	r0		;get user address
	add	spda,r0		;compute absolute address
repls1:	mov	length(r1),length(r0)	;copy the length
	mov	pntr(r1),r2	;get the relative pointer
	add	r1,r2		;make absolute
	sub	r0,r2		;adjust for new resting place
	mov	r2,pntr(r0)	;store it away
	rts	pc		;and return

pushs:	gwtxt	r0		;get the header location
	mov	spda,r2		;data area pointer
pushs3:	add	r2,r0		;compute the real address
pushs1:	cmp	(r0)+,(r0)+	;go to the length field
	mov	(r0),-(r1)	;store the length field
	mov	-(r0),-(r1)	;store the old pointer
	add	r0,(r1)		;remove the old bias
	sub	r1,(r1)		;and add our own
	mov	(r2),-(r1)	;get the head of the string location
pushs2:	add	r2,(r1)		;remove it's bias
	sub	r1,(r1)		;and show how it's been moved
	mov	r1,(r2)		;store the new start of all strings
	sub	r2,(r2)		;and make it relative
	rts	pc
;	push integer routine

pushi:	gwtxt	r0		;get the address
	add	spda,r0		;relocate it
	mov	(r0),-(r1)	;store it
	rts	pc		;and return
.gt.i:	cmp	(r1)+,(r1)	;compare the numbers
	blt	tru.		;branch if true
	br	fls.		;else set false

.ge.i:	cmp	(r1)+,(r1)
	ble	tru.
	br	fls.

.lt.i:	cmp	(r1)+,(r1)
	bgt	tru.
	br	fls.		;all 6 routines are

.le.i:	cmp	(r1)+,(r1)	;strikingly similar - huh?
	bge	tru.
	br	fls.

.ne.i:	cmp	(r1)+,(r1)
	beq	fls.
tru.:	mov	#-1,(r1)	;show true answer
	rts	pc		;and return

.eq.i:	cmp	(r1)+,(r1)
	beq	tru.
fls.:	clr	(r1)		;show false result
	rts	pc		;and return
;	floating relational operators

.gt.f:	jsr	pc,cmpf		;compare the numbers
	bgt	.true		;branch if condition held
	br	.false		;else make false

.ge.f:	jsr	pc,cmpf		;compare the numbers
	bge	.true		;branch if true
	br	.false		;else is no good

.lt.f:	jsr	pc,cmpf		;compare the numbers
	blt	.true		;branch to store true
	br	.false		;else is false

.le.f:	jsr	pc,cmpf		;compare the numbers
	ble	.true		;branch if true
	br	.false		;else is false no?

.eq.f:	jsr	pc,cmpf		;compare the numbers
	bne	.false		;else false
.true:	mov	#-1,r2		;set true indication
.true1:	add	#fltle2-2,r1	;correct stack
.true2:	mov	r2,(r1)		;and replace the third
	rts	pc		;and return


.ne.f:	jsr	pc,cmpf		;compare the numbers
	bne	.true		;branch if true
.false:	clr	r2		;set false indication
	br	.true1		;finish up via true
;	string compare and string relationals routines

.eq.s:	jsr	pc,cmps		;comapre the strings
	beq	.tru		;branch if true
	br	.fls		;else make false

.gt.s:	jsr	pc,cmps		;compare the strings
	bgt	.tru		;branch if true condition
	br	.fls

.ge.s:	jsr	pc,cmps		;compare the strings
	bge	.tru		;branch if true
	br	.fls		;else show false

.le.s:	jsr	pc,cmps		;compare the strings
	ble	.tru		;branch if true
	br	.fls		;else is false no?

.lt.s:	jsr	pc,cmps		;compare the stings
	blt	.tru		;branch if true
	br	.fls		;else not true

.ne.s:	jsr	pc,cmps		;do the compare
	bne	.tru		;branch if not the same
.fls:	clr	r2		;show false condition
.fls1:	mov	r1,r0		;copy the stack pointer
	add	(r0),r0		;skip down one
	add	(r0),r0		;down two strings
	sub	spda,r0		;make relative again
	mov	r0,@spda	;and store it away
	add	#strlen*2-2,r1	;remove the string pointers
	br	.true2		;store value on r1 stack

.ev.s:	jsr	pc,cmps		;see how they compare
	bcc	.fls		;not identical
.tru:	mov	#-1,r2		;show true condition
	br	.fls1		;and continue
restor:	mov	spda,r2		;get a data area pointer
	mov	@spta,dathdr(r2);store first possible data statement
	clr	datcnt(r2)	;clear bytes left
	rts	pc		;and return

readi:	jsr	r4,reader	;call common read processor
	+	inputi		;just like input--huh

readf:	jsr	r4,reader	;call read routine
	+	inputf		;do like inputf

reads:	jsr	r4,reader	;call read routine
	+	inputs		;processing routine address

read09:	odd	!fatal		;out of data

reader:	mov	spda,r2		;get a data area pointer
	mov	#base,currio(r2);set up some kind of funny io!
	mov	r2,r3		;copy spda
	add	#base+curloc,r3	;we'll use r3 a lot
	mov	datptr(r2),(r3)	;store current location
	add	spta,(r3)	;make absolute
	sub	r3,(r3)		;make relative to curloc
	add	#curloc,(r3)	;now to the header itself
	mov	datcnt(r2),-(r3);now move the counter
	beq	read05		;branch if next data statement needed
	jsr	pc,@(r4)+	;go process as input
read01:	mov	bytcnt(r4),cntbas(r4)	;store remaining count
	mov	curloc(r4),(sp)	;put the pointer on old r4
	add	r4,(sp)		;make absolute
	sub	spta,(sp)	;and noew relative to the text
	mov	(sp)+,ptrbas(r4)	;store the new pointer
endi01:	clr	bytcnt(r4)	;empty the buffer for now
	rts	pc		;and return

read05:	mov	dathdr(r2),r0	;get relative header address
	add	spta,r0		;make absolute
read06:	tst	(r0)		;see if the end of the road
	beq	read09		;branch if out of data
	add	(r0),r0		;slip down the chain
	cmpb	#4,tagtyp(r0)	;see if this is one goodie
	bne	read06		;loop if no good
	mov	r0,r3		;save its address
	sub	spta,r3		;make it relative
	add	#dathdr,r2	;go to the data addresses
	mov	r3,(r2)+	;store the address
	mov	tagpul(r0),(r2)	;store length
	dec	(r2)+		;adjust for rts overhead
	add	pntr(r0),r0	;compute address of data
	sub	spta,r0		;make it relative
	inc	r0		;skip the leading nexts
	mov	r0,(r2)+	;and store it for latter
	br	reader		;and go get it now

