; The use and distribution of the information
; contained herein may be restricted.
;
title	xcma2,<math module>,24,26-jun-74,mhb/tce/ld/tph

	org	ma

.if	df	fis
fis.in:
	.sig
	+	sigfpt
	+	fis.in
	bit	#c,2(sp)
	beq	1$
	post	,pstdv0
	br	2$
1$:	post	,pstflt
2$:	cmp	(r1)+,(r1)+
	clr	(r1)
	clr	2(r1)
	rti
.endc

.if	df	fpu
fpp.in:
	.sig			;resignal us
	+	sigfpt
	+	fpp.in
.if eq xsys
	stst	-(sp)		;not 100% right
.iff
	stst.			;100% right
.endc
	mov	r3,-(sp)
	mov	r5,-(sp)
	mov	4(sp),r3
	mov	6(sp),r5
	bit	r3,#-16-1
	bne	xxx.in
	add	r3,pc
	br	xxx.in
	br	xxx.in
	br	fpidv0
	br	fpiice
	br	fpiflo
	br	fpiflo
	br	fpiclr
	br	xxx.in
fpiice:	post,	pstfix
fpiext:	mov	(sp)+,r5
	mov	(sp)+,r3
	cmp	(sp)+,(sp)+
	rti
fpidv0:	post,	pstdv0
fpiclr:	mov	(r5),r5
	ash	#-4,r5
	bic	#-14-1,r5
	add	r5,pc
	clrf	f0
	br	fpiext
	clrf	f1
	br	fpiext
	clrf	f2
	br	fpiext
	clrf	f3
	br	fpiext
fpiflo:	post,	pstflt
	br	fpiclr
.endc

flt:	mov	r0,-(sp)
	jsr	r4,$ir
	.word	fixtwo
	.if	df	fpu
$ir:
	.if	eq	fltlen-4
$id:	setd
	.endc
	.if	ne	fltlen-4
	setf
	.endc
	seti
	ldcif	(r1)+,f0
	stf	f0,-(r1)
	jmp	@(r4)+
	.endc
	.if	ndf	fpu
$id:
$ir:
	mov	#220,r2
	mov	(r1),r0
	.if	eq	fltlen-4
	clr	(r1)
	clr	-(r1)
	mov	r0,-(r1)
	.endc
	clc
	bgt	pos
	beq	zerf
	neg	r0
pos:	rol	-(sp)
	clrb	(r1)
fnorm:	rol	r0
	bcs	normft
	dec	r2
	br	fnorm
normft:	movb	r0,1(r1)
	clrb	r0
	bisb	r2,r0
	swab	r0
	ror	(sp)+
	ror	r0
	rorb	1(r1)
zerf:	mov	r0,-(r1)
	jmp	@(r4)+
	.endc

$sbr:	add	#100000,(r1)
	br	$adr
subf:	add	#100000,(r1)
addf:	mov	#rtsloc,r4
$adr:
	.if	df	fpu
	setf
	ldf	(r1)+,f0
	addf	(r1)+,f0
	stf	f0,-(r1)
	jmp	@(r4)+
	.endc
	.if	ndf	fpu
	.if	df	fis
	fadd	r1
	jmp	@(r4)+
	.endc
	.endc

fixf:	jsr	r5,intfun
	+faf
fixf1:	mov	#rtsloc,r4
$intr:	mov	r1,r2
	.if	df	fpu
	setf	
	ldf	(r1)+,f0
	modf	one1,f0
	stf	f1,-(r1)
	jmp	@(r4)+
one1:	.word	040200,0
	.endc
	.if	ndf	fpu
	mov	(r2)+,r0
	mov	(r2)+,r1
	mov	r0,r3
	rol	r3
	clrb	r3
	swab	r3
	sub	#230,r3
	bge	done1
	cmp	#-30,r3
	blt	shift
	clr	r0
	clr	r1
	br	done1
shift:	mov	r3,-(sp)
	ashc	(sp),r0
	neg	(sp)
	ashc	(sp)+,r0
done1:	mov	r1,-(r2)
	mov	r0,-(r2)
	mov	r2,r1
	jmp	@(r4)+
	.endc


mulf:	mov	#rtsloc,r4
$mlr:
	.if	df	fpu
	setf
	ldf	(r1)+,f0
	mulf	(r1)+,f0
	stf	f0,-(r1)
	jmp	@(r4)+
	.endc
	.if	ndf	fpu
	.if	df	fis
	fmul	r1
	jmp	@(r4)+
	.endc
	.endc


divf:	mov	#rtsloc,r4
$dvr:	
	.if	df	fpu
	setf
	ldf	(r1)+,f1
	ldf	(r1)+,f0
	divf	f1,f0
	stf	f0,-(r1)
	jmp	@(r4)+
	.endc
	.if	ndf	fpu
	.if	df	fis
	fdiv	r1
	jmp	@(r4)+
	.endc
	.endc

fix:	mov	r0,-(sp)
	jsr	r4,$ri
	.word	fixtwo
fixtwo:	mov	(sp)+,r4
	mov	(sp)+,r0
	rts	pc
$ri:
	.if	df	fpu
	.if	eq	fltlen-4
$di:	setd
	.endc
	.if	ne	fltlen-4
	setf
	.endc
	seti
	ldd	(r1)+,f0
	stcdi	f0,-(r1)
	jmp	@(r4)+
	.endc
	.if	ndf	fpu
	.if	eq	fltlen-4
$di:	mov	(r1)+,2(r1)
	mov	(r1)+,2(r1)
	.endc
	clr	r2
	inc	r2
	mov	(r1)+,r0
	rol	(r1)
	rol	r0
	rol	-(sp)
	movb	r0,r3
	clrb	r0
	swab	r0
	sub	#201,r0
	blt	zero5
	beq	done2
	cmp	#15.,r0
	blt	over3
	swab	r3
	clrb	r3
	bisb	1(r1),r3
	ashc	r0,r2
done2:	neg	r2
	bvs	negm
	bgt	over3
sign2:	ror	(sp)+
	bcs	out4
	neg	r2
out4:	mov	r2,(r1)
	jmp	@(r4)+
negm:	ror	(sp)+
	bcs	out4
	tst	-(sp)
over3:	post,	pstfix
zero5:	clr	r2
	br	sign2
	.endc


cmpf:	mov	#rtsloc,r4
$cmr:	
	.if	df	fpu
	setf
	ldf	(r1)+,f0
	cmpf	(r1),f0
	cfcc
	jmp	@(r4)+
	.endc
	.if	ndf	fpu
	mov	#16601,r0
	mov	4(r1),r3
	bge	fpos
	asl	r0
	mov	(r1)+,r2
	blt	same
	br	neg
fpos:	mov	(r1)+,r2
	blt	pls
same:	cmp	r3,r2
	bne	cout
	cmp	4(r1),(r1)
	bne	cout
	clr	r0
cout:	ror	r0
	bcs	pls
neg:	neg	r0
pls:	tst	(r1)+
	tst	r0
	jmp	@(r4)+
	.endc


	.end
