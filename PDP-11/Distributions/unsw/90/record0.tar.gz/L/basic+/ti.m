; The use and distribution of the information
; contained herein may be restricted.
;
title	ti,<24 hour time>,24,26-jun-74,mhb/jdm

	org	ti

	.byte	40,40
	.byte	40,40
	.word	+0.

	.end
