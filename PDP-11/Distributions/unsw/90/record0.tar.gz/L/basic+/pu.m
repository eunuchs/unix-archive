; The use and distribution of the information
; contained herein may be restricted.
;
title	pu,<print using>,24,26-jun-74,mhb/tph/ld

	..	pprnuf,prinuf
	..	pprnui,prinui
	..	pprnus,prinus
	..	pprnue,prinue

	org	po,0		;overlay ma
	.word	prinu9
	.word	prinu8

	org	px,0		;print control
fltchr:	.byte	'$		;floating character
dotchr:	.byte	'.		;decimal point character
cmachr:	.byte	',		;comma insertion character
	.even

	org	pu

.if	df	hello
	.globl	saint					;(tr)
.endc
	.globl	flt					;(ma)
	.globl	pstjs					;(rc)
	.globl	crlf,prinu3,printl,prnfl1,prnfl2	;(pn)
	.globl	printc,prnfl3,prnf05,prnf15
	.globl	prnbuf,prinu2,prnbuc,pntuxp
.if	df	hello
; print using verb compiling

pu:	jsr	r5,saint	;enter interpreter
	rcs			;get the 'using' string
	cb	ppfix0		;and signal it
1$:	ntj	comma,2$	;comma?
	r			;skip commas
2$:	nej	4$		;if not end jump
3$:	cb	pprnue		;end print using
	cb	ppcrlf		;and cr/lf
	quit

4$:	ca			;compile anything
	copr	9$		;and set it
	ej	3$		;if end, then quit
	ntj	semico,1$	;if no ; then try for ,
	rnej	4$		;if not end, then compile
	cb	pprnue		;else end it
	quit

9$:	.byte	pprnuf,pprnui,pprnus
	.even
.endc
; for dispatches from the math package

prinu8:	tst	2(sp)		;should we go back to math package?
	bne	2$		;if flag non-0 then yes (rts pc)
	cmp	(sp)+,#prnf15	;which call was this?
	bne	3$		;call for return to "prnu15"
	cmpb	(r3)+,#'0	;leading 0?
	bne	1$		;nope
	cmpb	(r3)+,#'0	;another 0?
	bne	1$		;nope
	jmp	prnf05		;if so, the ma handles it now

1$:	dec	r3		;correct r3 pointer
	mov	#prnu40,(sp)	;set a return address
2$:	rts	pc		;and go to it

3$:	mov	#prnu15,(sp)	;set return address
	rts	pc		;and go
prcoun	=	 16			;count!!!!!!!
prmskp	=	  1			;decimal
prmske	=	  2			;exponent
prmska	=	  4			;asterisk fill
prmskc	=	 10			;comma
prmskm	=	 20			;trailing minus
prmskd	=	 40			;floating dollar
prulpf	=	100			;loop prevention bit
				;sp will be used for character
				;counter (sp), a flag to indicate
prinus:	clr	-(sp)		;last pass 2(sp), and a flag
	clr	-(r1)		;one more item to make 4...
	br	pruf1		;to indicate number or string 2(sp)

prinui:	jsr	pc,flt
prinuf:	mov	#1000,-(sp)	;number flag on, last pass off
	jsr	pc,prinu2	;"duplf" for 2-word or nop for 4-word
pruf1:	clr	-(r1)
	clr	-(r1)		;# digits to right of dec. pt.
	clr	-(r1)		;flag word for floating, int $ etc.
	clr	-(sp)		;character ctr=0
	br	prst1

prinue:	mov	#1,-(sp)	;last pass flag on
	clr	-(sp)		;char ctr.
	sub	#prcoun+2,r1	;correct r1 depth for prgetc
prst:	tst	(r1)+
prst1:	jsr	pc,prgetc
prst2:	cmpb	#'!,(r1)
	beq	prch1		;print one char from string
	cmpb	#'\,(r1)
	bne	prny		;check for # variable
prch2:	inc	(sp)		;increment char ctr
	jsr	pc,prgetb	;get next char from using string
	cmpb	#'\,(r1)
	beq	prch1		;print (sp)+1 characters of string
	cmpb	#40,(r1)
	beq	prch2
	movb	#'\,r2
	jsr	pc,printc	;print \
	jsr	pc,prspac	;print spaces
	br	prst2		;continue testing character

prerr:	prerrs	!fatal		;wrong type variable on using string

prch1:	tstb	2(sp)
	bne	prfinn		;final pass
	tstb	3(sp)
	bne	prerr		;check variable type
	inc	(sp)		;correct character count
	clr	(r1)		;remove last char. & use r1
prch5:	cmp	(r1),prcoun(r1)	;curr pos vs length of string
	blo	prch6		;still string left
	inc	(sp)		;otherwise fill out
	jsr	pc,prspac	;with spaces
	br	prch4
prch6:	mov	r1,r2		;to point to string
	add	#prcoun-4,r2	;link
	add	prcoun-2(r1),r2	;relative ptr
	add	(r1),r2		;place in string
	inc	(r1)		;step pointer to next output byte
	movb	(r2),r2
	jsr	pc,printc
	dec	(sp)
	bne	prch5		;loop on number to print
prch4:	add	#prcoun-4,r1	;remove all but string just printed
	jmp	prfin2		;pop it to j-space, and return

prny:	cmpb	(r1),fltchr
	beq	prny1
	cmpb	(r1),#'*
	beq	prny2
	cmpb	(r1),#'#
	beq	prny3
	cmpb	(r1),dotchr
	beq	prny3b		;if leading dec. pt.
	cmpb	(r1),#15
	beq	prnye		;char is cr, see if 2(sp) on
prnyz:	mov	(r1)+,r2
	jsr	pc,printc	;print any other character
	br	prst1

prnye:	tstb	2(sp)
prfinn:	bne	prny3c		;final pass
	bit	#prulpf,2(r1)	;see if we've been here before
				;if so, no #'s etc. in using string
	bne	prerr		;back with no progress made
	bis	#prulpf,2(r1)	;and don't come back
	jsr	pc,crlf		;else print crlf & continue
	br	prst

prny1:	jsr	pc,prgetb	;if next char is $, set
	cmpb	(r1),fltchr	;floating $
	beq	prny1a
	movb	fltchr,r2
prny4:	jsr	pc,printc
	br	prst2
prny1a:	bis	#prmskd,2(r1)	;set bit for float $
prny1b:	inc	4(r1)		;inc left count
prny3:	inc	4(r1)		;increment left ctr.
prny3a:	tstb	2(sp)
prny3c:	bne	prfin		;last pass
	tstb	3(sp)
	beq	prerr		;wrong variable type
	br	prny5

prny2:	jsr	pc,prgetb
	cmpb	(r1),#'*
	beq	prny2a		;* fill
	movb	#'*,r2
	br	prny4

prny3b:	jsr	pc,prgetb	;check next string character
	cmpb	(r1),#'#	;see if #
	beq	1$		;branch if yes
	movb	dotchr,r2	;no, so move . to r2
	br	prny4		;branch to print it

1$:	bis	#prmskp,2(r1)	;set dec. pt. seen flag
	inc	6(r1)		;incr right after dec. pt.
	br	prny3a		;branch to check flags

prny2a:	bis	#prmska,2(r1)	;set * fill bit
	br	prny1b

prny5a:	bit	2(r1),#prmskp
	beq	prny8
	inc	6(r1)		;inc right after dec. pt.
prny5:	jsr	pc,prgetb
	cmpb	(r1),#'#
	beq	prny5a
	cmpb	(r1),cmachr
	beq	prny5b
	cmpb	(r1),dotchr
	beq	prny5c
	cmpb	(r1),#'-
	beq	prny5d
	cmpb	(r1),#pntuxp
	beq	prny5e
prny6:	jsr	pc,prmovq	;move using ptr back 1
	tst	4(r1)		;check for 0
	bne	prny6a
	tst	6(r1)
	beq	prnyz		;and it is too
prny6a:	tst	(r1)+
	jsr	pc,prnu		;print number
	br	prfin1		;pop pc & exit.
prny5b:	bit	2(r1),#prmskp	;if no dec. pt. set
	bne	prny6		;comma bit.  if yes,
	bis	#prmskc,2(r1)	;print number
prny8:	inc	4(r1)		;inc left before dec. pt.
	br	prny5

prny5c:	bit	2(r1),#prmskp	;if no dec. pt. set
	bne	prny6		;dec. pt. bit.  if yes,
	bis	#prmskp,2(r1)	;terminate
	br	prny5

prny5d:	bis	#prmskm,2(r1)	;set trailing minus
prny9:	jsr	pc,prgetb	;adjust string pt.
	br	prny6

prny5e:	bit	#prmskd!prmska,2(r1)	;no exp w/floating $
	bne	prny6		;or * fill
	jsr	pc,prexpp
	tst	(r1)
	beq	prny6		;wasn't exp.
	bis	#prmske,2(r1)
	br	prny9		;set exp. bit.

prfin:	add	#prcoun+4,r1	;pop dummies from r1
prfin2:	jsr	pc,pstjs	;remove string
prfin1:	cmp	(sp)+,(sp)+	;and terminate
prse:	rts	pc
prspac:	dec	2(sp)		;print 2(sp)-1 spaces
	beq	prse
	movb	#40,r2
	jsr	pc,printc
	br	prspac

prgetb:	tst	(r1)+		;pop r1 first
prgetc:	mov	r1,r2		;get one char from using string
	add	#prcoun,r2	;make a pointer to the count
	mov	(r2)+,r3	;pick it up
	add	r2,r3		;making a pointer to the string
	tst	(r2)+		;now point to the pointer
	add	(r2)+,r3	;now abs ptr to string
	mov	#15,-(r1)	;in case at end
	tst	(r2)		;make sure there is some using string
	bne	prget1		;ok
	prerrs	!fatal		;print using with null using string

prget1:	cmp	(r2),-6(r2)	;end?
	beq	prrest		;yes
	movb	(r3),(r1)	;no, so pick up char from using str
	inc	-6(r2)		;point to next one
	rts	pc

prrest:	clr	2+prcoun(r1)	;reset the count
	rts	pc

prexpp:	clr	-(sp)		;one ^ seen so far
prexp3:	jsr	pc,prgetb	;try for 3 more
	inc	(sp)		;tally one more ^
	cmp	#'^,(r1)	;is this one?
	beq	prexp1		;yep
prexp2:	jsr	pc,prmovq	;no, didn't get 4, so not exp format
	dec	(sp)		;back over them, 0 value sigs not exp
	bne	prexp2
	br	prexp4

prexp1:	cmp	(sp),#3		;enough?
	bne	prexp3		;nope
prexp4:	mov	(sp)+,(r1)	;return count
	rts	pc

prmovq:	mov	r1,r2		;copy for making pointer
	add	#prcoun+2,r2	;point to count
	tst	(r2)		;if zero, must go to end
	bne	prmov1		;if non-zero
	mov	6(r2),(r2)	;otherwise set to length
	rts	pc

prmov1:	dec	(r2)		;less one
	rts	pc
;using part of setup from regular print program
prnu:	mov	(r1)+,-(sp)		;move code bits to system stack
	cmp	(r1),#prnbuf		;see if too many left format char
	ble	1$			;no, so k.k.
	jmp	prn102			;yes, so give error mes and exit

1$:	mov	(r1)+,-(sp)		;move left format chars to system stack
	mov	(r1)+,-(sp)		;move right format chars to system stack
	clr	-(sp)			;move flag onto system stack
	jmp	prinu3			;jump into regular print program

prinu9:	tst	2(sp)			;should we go back
	beq	prnu01			;no, stay here
	jmp	prnfl3			;yes, return

prnu01:	movb	prnbuf-3(r2),2(sp)	;save sign of number on system stack
	mov	r1,-(sp)		;save r1 pointer on system stack
;check for number out of range
	bit	#prmskd,12(sp)		;check $ bit
	bne	prnu18			;if set, go to decrement
	bit	#prmskm!prmska,12(sp)	;check * and terminal - bit
	bne	prnu17			;if set, don't decrement format count
	tstb	4(sp)			;test sign of number
	beq	prnu17			;if positive, don't decrement format count
prnu18:	dec	10(sp)			;subtract off non-digit char from left format
	blt	prnu40			;illegal if count is now negative
	bne	prnu17			;branch if count is ok
	bit	#prmske,12(sp)		;see if e mode
	bne	prnu40			;illegal format if so
prnu17:	mov	10(sp),r1		;pick up number of left format chars
	bit	#prmskc,12(sp)		;check , bit
	beq	prnu02			;if not set, skip comma counting
	clr	r0			;r0 is used for counting commas
prnu60:	cmp	#3,r1			;see if >3 chars in left format
	bge	prnu61			;if not, branch out
	sub	#4,r1			;subtract off for 3 digits and 1 comma
	inc	r0			;increment comma counter
	br	prnu60			;branch back

prnu61:	mov	r1,-(sp)		;save r1 on system stack
	mov	12(sp),r1		;pick up number of left format chars
	sub	r0,r1			;subtract off number of commas
	mov	(sp)+,r0		;remove temp storage from system stack
prnu02:	bit	#prmske,12(sp)		;check e bit
	bne	prnu04			;if set, skip some initial processing
	cmp	r4,r1			;compare number with format
	bgt	prnu40			;jump out if number is too big
;process for commas
	bit	#prmskc,12(sp)		;check , bit
	beq	prnu16			;if not set, skip comma processing
	mov	r4,r0			;move scale factor to r0
	clr	r1			;r1 is used for counting commas
prnu23:	cmp	#3,r0			;see if >3 digits
	bge	prnu24			;if not, jump out
	sub	#3,r0			;subtract off the three digits
	inc	r1			;increment comma counter
	br	prnu23			;loop back again

prnu73:	tst	6(sp)			;test fraction format
	beq	prnu40			;branch if no room
	br	prnu14			;else check for decimal point
prnu24:	add	r1,r4			;add number of commas
prnu16:	bit	#prmskd!prmska,12(sp)	;check * and $ bits
	bne	prnu20			;if set, initialize * output
prnu03:	cmp	#1,10(sp)		;test format count
	bge	prnu04			;if one, branch to check sign
	cmp	r4,10(sp)		;see if some spaces are needed
	bge	prnu04			;if not, branch to check on sign
	movb	#40,(r2)+		;output space
	dec	10(sp)			;decrement format count
	br	prnu03			;loop back again

prnu40:	mov	#'%,r2			;number too large--store %
	mov	2(sp),r1		;get r1 from stack
	add	#prnbuc,r1		;reset to original value
	jsr	pc,printc		;print %
	mov	#prnu41,-(sp)		;store return address on stack
	jmp	prnfl1			;print input number

;process asterisk
prnu20:	bit	#prmskm,12(sp)		;see if terminal -
	bne	prnu21			;if so, don't check sign of number
	tstb	4(sp)			;test sign of number
	beq	prnu21			;if positive, then o.k.
	jmp	prn100			;if negative, branch to error

prnu21:	bit	#prmskd,12(sp)		;check $ bit
	bne	prnu31			;if set, go to process $
	cmp	r4,10(sp)		;compare number with format
	bge	prnu06			;if >=, return to main program
	cmp	10(sp),#1		;test format count
	ble	prnu26			;if <=1, return to main program
	movb	#'*,(r2)+		;output *
	dec	10(sp)			;decrement format count
	bgt	prnu21			;loop back again
	br	prnu26

;process dollar sign
prnu31:	cmp	r4,10(sp)		;compare number with format
	bge	prnu32			;if >=, branch to output $
	cmp	10(sp),#1		;test format count
	ble	prnu32			;output $ if <=1
	movb	#40,(r2)+		;output space
	dec	10(sp)			;decrement format count
	bgt	prnu31			;loop back again
prnu32:	movb	fltchr,(r2)+		;output $
	br	prnu26			;return to main program

;check on sign
prnu04:	bit	#prmskm,12(sp)		;check terminal - bit
	bne	prnu26			;if set, output sign later
	tstb	4(sp)			;test sign of number
	beq	prnu26			;if positive, skip - output
	movb	#'-,(r2)+		;output -
prnu26:	tst	r4			;test scale factor
	bgt	prnu06			;branch out if more than one
	bit	#prmske,12(sp)		;check e bit
	bne	prnu06			;if set, don't output 0
	tst	10(sp)			;see if left side positions
	ble	prnu73			;;;;
	movb	#'0,(r2)		;output 0
	tst	6(sp)			;time to round?
	bne	1$			;don't round if more format
	tst	r4			;test scale factor
	bne	1$			;it's non-zero
	jmp	prnu72			;it's zero, so goto round

1$:	jmp	prnu71			;no round

prnu06:	bit	#prmskc,12(sp)		;check , bit
	bne	prnu50			;if set, output using commas
	tst	10(sp)			;test whether integer part
	bgt	prnu08			;if so, branch to digit output
prnu14:	bit	#prmskp,12(sp)		;check . bit
	beq	prnu10			;if not set, branch to finish
;output decimal point and leading zeros
	movb	dotchr,(r2)+		;output .
	bic	#prmskp,12(sp)		;clear . bit
	mov	6(sp),10(sp)		;replace left format by right format
	clr	6(sp)			;clear right format
prnu07:	tst	10(sp)			;test format count
	beq	prnu10			;if zero, branch to finish
	bit	#prmske,12(sp)		;check e bit
	beq	prnu00			;if not set, test for leading zeros
	add	10(sp),r4		;increment scale factor by no. of format chars
	br	prnu08			;branch to digit output

prnu00:	tst	r4			;test if leading zeros are needed
	bge	prnu08			;if not, branch to digit output
	cmp	#1,10(sp)		;see if format count is one
	beq	prnu70			;if so, branch to round
	movb	#'0,(r2)+		;output 0
	dec	10(sp)			;decrement format count
	inc	r4			;increment scale factor
	br	prnu07			;loop back again

;output digits
prnu08:	jsr	pc,prnu90		;output a digit
	dec	10(sp)			;decrement format count
	bgt	prnu08			;if non-zero, loop back
	br	prnu14			;branch to check on decimal point

;finishing
prnu10:	bit	#prmske,12(sp)		;check e bit
	beq	prnu15			;if not set, branch to check terminal -
	clr	-(sp)			;move flag onto system stack
	jmp	prnfl2			;jump into regular print program

prnu15:	tstb	4(sp)			;test sign of number
	beq	1$			;if positive, branch out
	mov	r2,r3			;copy output buffer pointer
	dec	r3			;move back one character
	cmpb	(r3),#'0		;see if last digit was 0
	bne	1$			;if not, branch out
	cmp	r3,2(sp)		;see if 0 was only character
	beq	prnu12			;yes, so output trailing space
	dec	r3			;move back 1 more character
	cmpb	(r3),#'-		;see if character is minus sign
	bne	2$			;no, so branch out
	movb	#40,(r3)		;replace - with space
	br	prnu13			;branch out

2$:	cmpb	(r3),#40		;see if character is a space
	beq	prnu12			;yes, so output trailing space
1$:	bit	#prmskm,12(sp)		;check terminal -
	beq	prnu13			;if not set, branch out
	tstb	4(sp)			;test sign of number
	beq	prnu12			;if positive, branch out
	movb	#'-,(r2)+		;output terminal -
	br	prnu13			;skip space output

prnu12:	movb	#40,(r2)+		;output space for positive number
prnu13:	clrb	(r2)+			;output trailing null for printl
	mov	2(sp),r2		;reset r2
	mov	r2,r1			;also move pointer to r1
	add	#prnbuf,r1		;reset r1
prnu41:	add	#14,sp			;reset system stack
	jmp	printl			;print buffer
;errors
prn100:	mov	2(sp),r1		;restore r1 stack pointer
	prner1	!fatal			;illegal minus sign in print using

prn101:	mov	4(sp),r1		;restore r1 stack pointer
prn102:	prner2	!fatal			;output buffer overflow in print using

;output using commas
prnu50:	tst	r0			;test remainder
prnu52:	ble	prnu51			;if <= zero, branch to check if finished
prnu53:	jsr	pc,prnu90		;output a digit
	dec	10(sp)			;decrement left format count
	dec	r0			;decrement counter
	br	prnu52			;loop back again

prnu51:	tst	10(sp)			;if <0, test left format count
	ble	prnu14			;return to main program
	movb	cmachr,(r2)+		;output ,
	mov	#3,r0			;reset 3 counter
	dec	10(sp)			;decrement left format count
	br	prnu53			;loop back again

;rounding during leading zeros
prnu70:	movb	#'0,(r2)		;output 0 without incrementing stack
	cmp	r4,#-1			;test scale factor
	bne	prnu71			;if not -1, branch out
prnu72:	cmpb	#'5,(r3)		;see if next digit >5
	bgt	prnu71			;if not, branch out
	incb	(r2)			;increment digit
prnu71:	inc	r2			;increment pointer
	br	prnu14			;branch to check on decimal point

;output a digit, rounded if necessary
prnu90:	cmp	r2,r3			;check output buffer
	bgt	prn101			;output buffer overlaps input chars
	cmp	r3,2(sp)		;see if any more significant digits
	bhi	prnu93			;if not, add training zeros
	cmp	#1,12(sp)		;see if only one format char left
	bne	prnu99			;if not, go to output
	tst	10(sp)			;check right format count
	beq	prnu80			;if zero, branch to round
prnu99:	movb	(r3)+,(r2)+		;output digit
prnu98:	dec	r4			;decrement scale factor
	rts	pc			;return

prnu93:	mov	4(sp),r3		;get head of buffer
	add	#prnbuf,r3		;add length of buffer
	cmp	r2,r3			;compare with current position
	bgt	prn101			;output buffer is full
	movb	#'0,(r2)+		;output 0
	br	prnu98			;branch to return
prnu80:	movb	(r3)+,(r2)		;store next digit on stack
	cmp	r3,2(sp)		;see if there is a remaining digit
	bhi	prnu81			;if not, branch to return
	cmpb	#'5,(r3)		;see if digit >5
	ble	prnu89			;if so, branch to round up
prnu81:	inc	r2			;increment pointer
	br	prnu98			;branch to return

prnu89:	mov	r2,-(sp)		;save current pointer
prnu85:	cmpb	#'9,(r2)		;check for 9
	beq	prnu92			;if so, branch to carry
	cmpb	#'0,(r2)		;check for other digits
	ble	prnu88			;if so, branch to increment digit
	cmpb	dotchr,(r2)		;check for .
	beq	prnu87			;if so, branch to skip over char
	cmpb	cmachr,(r2)		;check for ,
	beq	prnu87			;if so, branch to skip over char
	cmpb	#'*,(r2)		;check for *
	beq	prnu82			;if so, branch to insert carried 1
	cmpb	#40,(r2)		;check for space
	beq	prnu82			;if so, branch to insert carried 1
	cmpb	fltchr,(r2)		;check for $
	beq	prnu84			;if so, branch to move it
	cmpb	#'-,(r2)		;check for -
	beq	prnu84			;if so, branch to move it
prnu83:	cmp	(sp)+,(sp)+		;decrement stack pointer
	jmp	prnu40			;branch to process too large of number

prnu88:	incb	(r2)			;increment digit
	br	prnu91			;branch back

prnu92:	movb	#'0,(r2)		;replace 9 by 0
prnu87:	cmp	r2,4(sp)		;see if at top of stack
	beq	prnu83			;if so, branch to reset
	dec	r2			;decrement pointer
	br	prnu85			;branch to look at previous char

prnu84:	cmpb	#40,-1(r2)		;see if preceded by space
	bne	prnu83			;if not, branch to reset
	movb	(r2),-1(r2)		;move $
prnu82:	movb	#'1,(r2)		;output 1
prnu91:	mov	(sp)+,r2		;reset pointer
	br	prnu81			;branch back
	.end
