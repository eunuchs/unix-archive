; The use and distribution of the information
; contained herein may be restricted.
;
title	sc,<UNIX file scanner>,24,26-jun-54,jnr

	org	sc

;call:
;	r1	r1	stack
;	r2	channel*2
;	r4	furk-bee
;			jsr	pc,scan
;rtn:
;	r1	r1	stack
;	r4	furk-bee with name
;	r0,r2,r5 preserved
;	r1	spda

opnr20::
	jsr	pc,getbuf
scan::	mov	#pstjs,-(sp)		;pop string when done
	jsr	r5,savreg
	mov	r4,r3			;fq pointer
	cmp	(r3)+,(r3)+		;past first two words
	mov	r2,(r3)+		;channel*2
	mov	r1,-(sp)		;string pointer
	add	pntr(r1),(sp)		;make abs
	mov	(sp),-(sp)		;also end pointer
	add	length(r1),(sp)		;absolute
	mov	r3,-(sp)		;point to last byte of name(0)
	add	#77-4,(sp)
	clr	r5			;accumulated mode bits !!
	clr	r2			;flag whether mode seen yet.
1$:	cmp	4(sp),2(sp)		;bytes left?
	bhis	2$			;no
	movb	@4(sp),r0		;get char
	inc	4(sp)			;bump point
	tst	r0			;ignore nulls
	beq	1$
	cmpb	r0,#12			;also, ignore new-lines (!!)
	beq	1$			;isn't it simple?
	tstb	r2			;looking for some mode info?
	ble	5$			;suppose not.
	cmpb	r0,#'>			;see if end of mode stuff?
	bne	6$			;not so
	negb	r2			;out of mode stuff.
	br	1$			;and back for more
6$:	sub	#'0,r0			;must be an octal digit
	cmpb	r0,#7			;check that its legal
	bhi	3$			;is not kosher
	ash	#3,r5			;add it into mode
	add	r0,r5
	br	1$			;and go back for more
5$:	cmpb	r0,#'<			;see if start of mode here?
	bne	7$			;no - its an ordinary character
	incb	r2			;into protection mode field
	beq	3$			;he has already had one.
	br	1$			;now go back for more
7$:	cmpb	r0,#'$			;ugly "$" "feature"
	bne	10$			;thank god
	tst	r2			;first real character?
	bmi	3$			;no - error
	mov	#prefix,r0		;copy in the prefix
	movb	(r0)+,(r3)+		;there is enough spa ce.
	bne	.-2			;asciz terminated
	dec	r3			;eliminate null terminate
	br	11$			;do set sign bit
10$:	cmp	r3,(sp)			;room for it?
	bhis	3$			;no
	movb	r0,(r3)+
11$:	bis	#100000,r2		;set sign bit -- not first char
	br	1$			;shove it in, go back for more
3$:	movb	#badnam,iosts		;bad file name
	ioterr	!fatal			;screw 'im
2$:	add	#6,sp
	tstb	r2			;we do not allow "...<.."
	bgt	3$			;'cause we are mean
	bmi	9$			;user specified mode
	mov	#basmod,r5		;the default
9$:	bis	#100000,r5		;set REAL flag
	mov	r5,fqmode(r4)		;into firqb
	clrb	(r3)
	jsr	r5,resreg
	rts	pc			;and exit

	global	<savreg,resreg,getbuf,pstjs>

	.enabl	lc
prefix:	.asciz	+/usr/lib/bas/+
	.even
	.dsabl	lc
	.end
