; The use and distribution of the information
; contained herein may be restricted.
;
title	ma4d,<4-word decimal math package>,24,26-jun-74,mhb/jdm

.sbttl	parameters for 4-word decimal math package

fltlen	=	4
.math.	=	1
