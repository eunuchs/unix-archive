	.psect	.text.,con,shr
	.title	gmarg								;**new**
	.ident	/01/								;**new**
										;**new**
;										;**new**
; copyright 1972, digital equipment corp., maynard, mass 01754			;**new**
; copyright 1973, digital equipment corp., maynard, mass 01754			;**new**
;										;**new**
;	dec assumes no responsibility for the					;**new**
;	use or reliability of its software on					;**new**
;	equipment which is not supplied by dec.					;**new**
;										;**new**
; version 01									;**new**
;										;**new**
; b. bowering									;**new**
;										;**new**
;	modified by:								;**new**
;										;**new**
;	d.n. cutler 10-feb-73							;**new**
;										;**new**
;+										;**-271
; **-gmarg-get macro argument
; **-gmargf-alternate entry
; **-rmarg-remove macro argument
;-
gmarg::	tstarg			;test for null
	beq	gmargx		;  yes, just exit
gmargf::savreg			;save registers
	clr	r1		;clear count
	mov	#chrpnt,r2
	mov	(r2),-(sp)	;save initial character pointer
	mov	#ch.lab,r3	;assume "<>"
	mov	#ch.rab,r4
	cmp	r5,r3		;true?
	beq	11$		;  yes
	cmp	r5,#ch.uar	;up-arrow?
	beq	10$		;  yes
1$:	mov	#ct.pc,-(sp)	;set printing characters mask			;**new**
	bic	#ct.com,(sp)	;clear comma flag				;**new**
	bic	#ct.smc,(sp)	;clear semicolon flag				;**new**
	bitb	(sp)+,cttbl(r5)	;printing character?				;**new**
	beq	21$		;  no						;**-1
	getchr			;yes, move on
	br	1$
10$:	getnb			; "^", bypass it
	beq	20$		;error if null
	mov	(r2),(sp)	;set new pointer
	com	r3		;no "<" equivalent
	mov	r5,r4		;">" equivalent
11$:	getchr
	beq	20$		;  error if eol
	cmp	r5,r3		; "<"?
	beq	12$		;  yes
	cmp	r5,r4		;no, ">"?
	bne	11$		;  no, try again
	dec	r1		;yes, decrement level count
	dec	r1
12$:	inc	r1
	bpl	11$		;loop if not through
	inc	(sp)		;point past "<"
	bis	#100000,r5	;must move past in rmarg
	br	21$
20$:	error	a
21$:	mov	gmapnt,r0	;get current arg save pointer
	bne	22$		;branch if initialized
	mov	#gmablk,r0	;do so
22$:	mov	(r2),(r0)+	;save pointer
	mov	r5,(r0)+	;  and character
	clrb	@(r2)		;set null terminator
	mov	(sp)+,(r2)	;point to start of arg
	setchr			;set register 5
	mov	r0,gmapnt	;save new buffer pointer
gmargx:	return
rmarg::	mov	gmapnt,r0	;set pointer to saved items
	mov	-(r0),r5	;set character
	tst	-(r0)
	movb	r5,@(r0)	;restore virgin character
	asl	r5
	adc	(r0)
	mov	(r0),chrpnt
	setnb
	mov	r0,gmapnt
	return
	.end									;**-56
