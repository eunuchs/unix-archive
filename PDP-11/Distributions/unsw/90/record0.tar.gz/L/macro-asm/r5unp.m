	.psect	.text.,con,shr
	.title	r5unp								;**new**
	.ident	/01/								;**-1
;
; copyright 1972, digital equipment corp., maynard, mass 01754
; copyright 1973, digital equipment corp., maynard, mass 01754
;
;	dec assumes no responsibility for the
;	use or reliability of its software on
;	equipment which is not supplied by dec.
;
; version 01
;
; b. bowering
;
;	modified by:
;
;	d.n. cutler 10-feb-73
;
;+
; **-r50unp-radix 50 unpack							;**-2
;-
r50unp::mov	r4,-(sp)	;save r4					;**-11
	mov	#symbol,r4	;point to symbol storage
1$:	mov	(r4)+,r1	;get next word
	mov	#50*50,r3	;set divisor
	call	10$		;divide and stuff it
	mov	#50,r3
	call	10$		;again for next
	mov	r1,r0
	call	11$		;finish last guy
	cmp	r4,#symbol+4	;through?
	bne	1$		;  no
	mov	(sp)+,r4	;yes, restore register
	return
10$:	clr	r0
	div	r3,r0
11$:	tst	r0		;space?
	beq	23$		;  yes
	cmp	r0,#33		;test middle
	blt	22$		;alpha
	beq	21$		;dollar
	add	#22-11,r0	;dot or dollar
21$:	add	#11-100,r0
22$:	add	#100-40,r0
23$:	add	#40,r0
	movb	r0,(r2)+	;stuff it
	return
										;**-325
	.end
