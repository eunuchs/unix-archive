	.psect	.text.,con,shr
	.iif ndf mcexec,	.nlist
	.macro	genchn	zchan,zlnk,zbuf,ztype,zlb,zfb,zext
	setchn	src,	src,	src,	0,*,	fb,mac
	setchn	lst,	lst,	lst,	0,*,	fb,lst
	setchn	bin,	obj,	obj,	1,*,	fb,bin
	.if ndf	xrel
	setchn	rel,	obj,	rld,	1, ,	  ,obj
	.endc
	.if ndf	xsml
	setchn	sml,	sml,	sml,	0,sy
	.endc
	.if ndf	xcref
	setchn	crf,	crf,	crf,	0,sy,	fb,crf
	.endc
	setchn	cmo,	cmo,	lst,	 ,kb
	.endm
tmpcnt=0
	.macro	setchn	zchan,zlnk,zbuf,ztype,zlb,zfb,zext
	.list
zchan'chn=	tmpcnt
	.nlist
tmpcnt=	tmpcnt+2
	.endm
	genchn
maxchn=	tmpcnt			;just to preserve the count
	.irp	x,<init,read,write,wait,readw,writw>
	.globl	$'x
	.macro	$'x	chan
	mov	#chan'chn,r0
	call	$'x
	.endm	$'x
	.endm
	.iif ndf mcexec,	.list
