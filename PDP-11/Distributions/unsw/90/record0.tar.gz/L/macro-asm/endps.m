	.psect	.text.,con,shr
	.title	endps
	.ident	/02/								;**new**
										;**-1
;
; copyright 1972, digital equipment corp., maynard, mass 01754
; copyright 1973, digital equipment corp., maynard, mass 01754
;
;	dec assumes no responsibility for the
;	use or reliability of its software on
;	equipment which is not supplied by dec.
;
; version 02									;**new**
;										;**-1
; b. bowering
;
;	modified by:
;
;	d.n. cutler 6-feb-73
;
;+
; **-endp1-end pass 1
;-
endp1::				;ref label
	.if ndf	xrel
	call	setmax		;set max location
	.iftf
	tstb	ioftbl+binchn	;any obj file?
	beq	endp1b		;  no
	call	objini		;init output
	.ift
	mov	#blkt01,@buftbl+relchn	;set block type 1
	mov	#prgttl,r1	;set "from" index
	call	gsddmp		;output gsd block
	.if ndf	dosv4
	mov	#prgidn,r1	;point to sub-ttl buffer
	tst	4(r1)		;set?
	beq	9$		;  no
	call	gsddmp		;yes, stuff it
	.endc
9$:	clr	-(sp)		;init for sector scan
10$:	mov	(sp)+,rolupd	;set scan marker
	next	secrol		;get the next sector
	beq	endp1a		;branch if through
	mov	rolupd,-(sp)	;save marker
	mov	#sector,r1	;get address of sector
	clr	r5		;clear r5
	bisb	(r1),r5		;pick up section number
	movb	#gsdt05/400,(r1)+;set gsd type
	clr	(r1)+		;assume abs section
	bitb	#cstrel,mode	;abs section?
	beq	11$		;  oops!
	mov	(r1),-(r1)	;  rel, set max
11$:	clr	rolupd		;set for inner scan
12$:	mov	#symbol,r1
	call	gsddmp		;output this block
13$:	next	symrol		;fetch the next symbol
	beq	10$		;  finished with this guy
	bit	#glbflg,mode	;global?
	beq	13$		;  no
	cmpb	sector,r5	;yes, proper sector?
	bne	13$		;  no
	bic	#^c<defflg!relflg!glbflg>,mode	;clear most
	bis	#gsdt04,mode	;set type 4
	br	12$		;output it
endp1a:	bic	#^c<relflg>,endvec+4	;clear all but rel flag
	bis	#gsdt03+defflg,endvec+4
	mov	#endvec,r1
	call	gsddmp		;output end block
	call	objdmp		;dump it
	mov	#blkt02,@buftbl+relchn	;set "end of gsd"
	call	rlddmp
	mov	#blkt04,@buftbl+relchn	;init for text blocks
	.iftf
endp1b:
	.ift
	clr	rolupd		;set for re-init scan
31$:	next	secrol		;get the next entry
	beq	32$		;  branch if finished
	clr	value		;found, reset pc
	insert			;put back in table
	br	31$
32$:
	.iftf
	inc	pass		;set for pass 2
	return
	.ift
gsddmp:				;dump a gsd block
	mov	#4*2,r0		;four words per gsd entry
	call	tstrld		;room?
	jmp	xmit4		;we have now.  stuff entry
	.endc
;+
; **-endp2-end pass 2
;-
endp2::				;ref label
;**** special code to dump the symbol table *****
	.if	ndf	xrel
	bit	#ed.abs,edmask			;want abs output only?
	beq	symdox				;yep
	bit	#ed.stb,edmask
	bne	symdox
	mov	objpnt,r0			;get obj txt ptr
	beq	symdox				;nothing to do
	call	objdmp				;flush ze object buffer
	mov	#blksym,@buftbl+relchn		;dump header
	clr	rolupd				;new symbol
99$:	next	symrol				;new symbol please
	beq	101$				;all done
	bit	#glbflg,mode			;global?
	bne	99$				;yes, skip it
	mov	#symbol,r1			;point to new symbol
	call	gsddmp				;dump it
	br	99$				;back for more!
101$:	tst	objpnt				;any output?
	beq	102$				;nope
	call	objdmp				;flush it out
102$:	mov	#blksye,@buftbl+relchn		;sym end
	call	rlddmp				;dump end
symdox:
blksym =022
blksye =021
	.endc
	.if ndf	xrel
	call	setmax		;set max location
	.iftf
	mov	#symtxt,r1
	mov	#stlbuf,r2
	movbyt			;set "symbol table" sub-title
	tst	objpnt		;any object output?
	beq	1$		;  no
	call	objdmp		;yes, dump it
	.ift
	mov	#blkt06,@buftbl+relchn	;set end
	call	rlddmp		;dump it
	.endc
	.if ndf	xedabs
	bit	#ed.abs,edmask	;abs output?
	bne	1$		;  no
	mov	objpnt,r0
	mov	endvec+6,(r0)+	;set end vector
	mov	r0,objpnt
	call	objdmp
	.endc
1$:	tstb	lstdev		;any listing output?
	beq	endp2d		;  no
	bit	#lc.sym,lcmask	;symbol table suppression?
	bne	endp2d		;  yes
	clr	lppcnt		;force new page
	clr	rolupd		;set for symbol table scan
2$:	mov	#linbuf,r2	;point to storage
3$:	next	symrol		;get the next symbol
	beq	endp2a		;  no more
	r50unp			;unpack the symbol
	mov	#endp2t,r3
	call	endp2c
	mov	#mode,r1	;point to mode bits
	bit	#defflg,(r1)	;defined?
	beq	4$		;  no
	call	setwrd
	br	6$
4$:	mov	#stars,r1
	movbyt			;undefined, substitute ******
6$:	call	endp2c
	call	endp2x		;
	mov	#sector,r1
	cmpb	#1,(r1)
	bge	10$
	cmpb	-(r1),-(r1)
	call	setbyt
10$:	movb	#tab,(r2)+	;separator
	cmp	r2,#linbuf+50.	;enough for one line?
	blo	3$		;  no
	call	endp2b		;output line
	br	2$		;next line
endp2a:
	.if ndf	xrel
	clr	rolupd		;set for sector scan
21$:	call	endp2b		;output line
	next	secrol		;get the next entry
	beq	endp2d		;  exit if end of roll
	r50unp			;print the name,
	movb	#tab,(r2)+
	mov	#value,r1
	call	setwrd		;  the value,
	movb	#tab,(r2)+
	mov	#sector-2,r1
	call	setbyt		;  and the entry number
	br	21$
	.iff
	return
	.endc
endp2b:	clrb	(r2)
	putlp	#linbuf
	mov	#linbuf,r2	;reset to start of buffer
endp2d:	return
endp2c:	call	endp2x
endp2x:	mov	(r3)+,r0
	bit	(r3)+,mode
	bne	32$
	swab	r0
32$:	movb	r0,(r2)+
	return
	.psect	dpure,prv,con
endp2t:	.ascii	/ =/
	.word	lblflg
	.ascii	/% /
	.word	regflg
	.ascii	/r /
	.word	relflg
	.ascii	/g /
	.word	glbflg
	.ascii	/x /
	.word	dfgflg
	.psect	txtbyt,prv,con
symtxt:	.asciz	/symbol table/							;**-1
	.psect	.text.,con,shr
	.end
