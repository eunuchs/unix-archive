	.psect	.text.,con,shr
	.title	sectr
	.ident	/02/								;**new**
										;**-1
;
; copyright 1972, digital equipment corp., maynard, mass 01754
; copyright 1973, digital equipment corp., maynard, mass 01754
;
;	dec assumes no responsibility for the
;	use or reliability of its software on
;	equipment which is not supplied by dec.
;
; version 02									;**new**
;										;**-1
; b. bowering
;
;	modified by:
;
;	d.n. cutler 6-feb-73
;
; local macros
;
; generate section attribute roll entry
;
; gensat sat,flg,res
;
; where:
;
;	sat=a 1 to 3 character section attribute name.
;	flg = section entry flag bits to set
;	res = section entry flag bits to clear
;
	.macro	gensat sat,flg,res
	.rad50	/sat/
	.byte	flg,res
	.endm
	.psect	satsec,prv,gbl							;**new**,con
satbas::			;ref label					;**-1
	gensat	abs,		,cstrel
	gensat	rel,cstrel	,0
	gensat	lcl,		,cstgbl
	gensat	gbl,cstgbl	,0
	gensat	con,		,cstalo
	gensat	ovr,cstalo	,0
	gensat	shr,cstdsp	,cstbss
	gensat	prv,		,cstbss!cstdsp
	gensat	dat,		,cstins!cstbss
	gensat	ins,cstins	,0
	gensat	bss,cstbss	,cstdsp!cstins
sattop::
	.psect	.text.,con,shr
;+
; **-asect-absolute p-section
; **-csect-defaulted attribute p-section
; **-psect-programmable attribute p-section
; **-phase-phase p-section location counter
; **-depha-dephase p-section location counter
; **-secini-p-section table initialization
;-
	.if ndf	xrel
asect::	call	setmax		;close out current p-section
asectf:	mov	r50abs,symbol	;set default abs section name
	mov	r50abs+2,symbol+2;
	mov	#astflg,r3	;get default flags
	br	csectf		;
csect::	call	setmax		;close out current p-section
	mov	#cstflg,r3	;get default flags
	tstarg			;any name?
	beq	10$		;if eq no
	bis	#cstalo!cstgbl,r3;set overlaid and global
10$:	getsym			;get section name
csectf:	scan	secrol		;scan for a match
	bne	psectf		;if ne match found
	movb	r3,mode		;set mode flags
	movb	sizsec+1,sector	;set sector number
	br	psectf		;
psect::	call	setmax		;close out current p-section
	tstarg			;test for argument (set up)
	inc	argcnt		;increment argument count
	getsym			;get section name
	scan	secrol		;scan for match
	bne	10$		;if ne found match
	movb	#pstflg,mode	;set default mode flags
	movb	sizsec+1,sector	;set sector number
10$:	mov	#symbol+12,r3	;get set to stack section
	.rept	5
	mov	-(r3),-(sp)	;stack section
	.endr
20$:	tstarg			;any more arguments?
	beq	30$		;if eq no
	getsym			;get attribute symbol
	scanw	satrol		;scan for a match
	beq	psecta		;if eq error
	mov	#symbol+2,r0	;get address of argument word
	bisb	(r0),4(sp)	;set bits
	bicb	1(r0),4(sp)	;clear some bits too
	br	20$		;go again
30$:	mov	(sp)+,(r3)+	;restore section name
	mov	(sp)+,(r3)+	;
	scan	secrol		;scan sector roll
	mov	(sp)+,(r3)+	;restore section attributes
	mov	(sp)+,(r3)+	;
	mov	(sp)+,(r3)+	;
psectf:	insert			;insert section
	setpf1			;
	.if ndf,xcref
	crfref			;
	.endc
	mov	#symbol,r1	;get address of symbol
	mov	#clcnam,r2	;get location counter address
	.if ndf	xedlsb
	call	xmit5		;transfer symbol to location counter
	jmp	lsbset		;set new local symbol base
	.iff
	jmp	xmit5		;transfer symbol to location counter
	.endc
psecta:	add	#5*2,sp		;clean stack
	error	a		;set error flag
	return			;
	.if df	yphase
phase::	relexp			;evaluate relative expression
	cmpb	sector,clcsec
	bne	1$
	mov	r0,phaoff
	sub	clcloc,phaoff
	mov	r0,clcloc
	return
1$:	error	a
	return
depha::	sub	phaoff,clcloc	;subtract out phase offset
	clr	phaoff
	return
	.endc	;yphase								;**-4
	.endc	;xrel
secini::.if ndf	xrel
	call	asectf		;move onto roll
	clr	symbol		;ditto for blank csect
	clr	symbol+2
	mov	#cstflg,r3	;set default section flags
	.if ndf	xedabs
	bit	#ed.abs,edmask	;abs mode?
	bne	csectf		;  no
	return
	.iff
	br	csectf
	.endc			;xedabs
	.iff
	bit	#ed.abs,edmask
	beq	1$
	error	a
	bic	#ed.abs,edmask
1$:	return
;+
; **-limit-program limits
;-
	.ift
limit::	call	objdmp		;dump object buffer
	clr	(r4)		;clear value
	mov	#rldt11*400,-(r4)	;set rld type
	stcode
	clr	(r4)
	jmp	stcode
	.endc
	.end
