	.psect	.text.,con,shr
	.title	endln
	.ident	/d02/
										;**-1
;
; copyright 1972, digital equipment corp., maynard, mass 01754
; copyright 1973, digital equipment corp., maynard, mass 01754
;
;	dec assumes no responsibility for the
;	use or reliability of its software on
;	equipment which is not supplied by dec.
;
; version 02									;**new**
;										;**-1
; b. bowering
;
;	modified by:
;
;	d.n. cutler 9-feb-73
;	d. knight 25-may-73 -- dos changes
;
;+
; **-endlin-end of line processor
;-
endlin::savreg			;save registers
	clr	rolupd		;set to fetch from code roll
	tstb	cttbl(r5)	;eol or semi-colon?
	ble	1$		;  yes
	error	q
1$:	.if ndf	xedcdr
	movb	cdrsav,linbuf+72.	;replace borrowed char
	.endc
	mov	pass,-(sp)	;pass 1?
	beq	9$		;  yes
	mov	lstdev,(sp)	;init listing flag
	tst	errbts		;any errors?
	bne	7$		;  yes, go directly, do not collect, etc.
	tstb	(sp)		;any listing device?
	beq	9$		;  no
	bit	#lc.ld,lcflag	;listing directive?
	bne	5$		;  yes
	tst	lclvl		;test over-under ride
	blt	5$		;if <0, list only if errors
	bgt	8$		;if >0, list unconditionally
	bit	#lc.com,lcmask	;comment suppression?
	beq	2$		;  no
	mov	chrpnt,lcendl	;yes, assume we're sitting at comment
2$:	bit	#lc.src,lcmask	;line suppression?
	beq	3$		;  no
	mov	#linbuf,lcendl	;yes, point to start of buffer
3$:
	.if ndf	xmacro
	tstb	sizcod+1	;anything in code roll?
	beq	4$		;  no
	bit	#lc.meb,lcmask	;macro binary expansion?
	bne	4$		;  no
	bic	#lc.me,lcflag	;yes, ignore me flag
	.endc
4$:	bit	lcmask,lcflag	;anything suppressed?
	beq	9$		;  no, use current flags
5$:	clr	(sp)		;yes, clear listing mode
	br	9$
7$:	swab	(sp)		;error, set to error flags
	.if ndf	xlcseq
	.if ndf	xlcttm
	bit	#lc.ttm,lcmask	;teletype mode?
	bne	8$		;  no, bypass extra line
	.endc
	mov	#stars,r1	;"******"
	mov	#octbuf,r2
	movbyt			;move into octal buffer
	movb	#space,(r2)+
	call	tsterr		;set errors
	clrb	(r2)		;form asciz
	movb	(sp),lstreq
	putlin	#octbuf		;draw the user's attention
	.endc
8$:	mov	#linbuf,lcbegl	;list entire line
	mov	#linend,lcendl
9$:	call	pcroll		;process entry on code roll
endl10:	movb	(sp),lstreq	;anything requested?
	beq	endl20		;  no
	clrb	@lcendl		;set asciz terminator
	mov	#octbuf,r2
11$:	mov	#space*400+space,(r2)+	;blank fill
	cmp	#linbuf,r2	;test for end (beginning of line buffer)
	bne	11$
	.if ndf	xlcttm
	bit	#lc.ttm,lcmask	;teletype mode?
	bne	endl50		;  no
	.endc
	mov	#pf0,r1
	tst	(r1)		;anything for first print field?
	beq	14$		;  no
	mov	#octpf0,r2	;yes, point to it
	call	setwrd		;unpack into buffer
14$:	clr	(r1)		;clear pf0
	mov	#pf1,r1
	tst	(r1)		;anything for second field?
	beq	15$		;  no
	mov	#octpf1,r2
	call	setwdb		;list word or byte
	bit	#77*400,(r1)	;test for linker modification
	beq	15$
	movb	#ch.xcl,(r2)	; "'"
	bit	#glbflg,(r1)
	beq	15$
	movb	#let.g,(r2)
15$:	clr	(r1)		;clear pf1
	.if ndf	xlcseq
	mov	#octseq,r2
	mov	#linnum,r0	;point to cref line number
	mov	(r0)+,r1
	cmp	r1,(r0)		;new cref number to put out?
	beq	16$		;  no
	mov	r1,(r0)		;yes, clear flag
	bit	#lc.seq,lcmask	;suppressed?
	bne	16$		;  yes
	dnc
	mov	r2,seqend	;mark highest sequence end
16$:	movb	#space,(r2)+
	cmp	r2,seqend	;through?
	blos	16$		;  no
	.endc
	mov	#octerp,r2
	call	tsterr		;test for errors
	mov	#octbuf+16.,r2	;set for concatenation
endl19:	mov	lcbegl,r1	;point to start of listing line
	movbyt			;move over
	putlin	#octbuf		;test for header and list
endl20:
	clrb	@lcbegl		;don't dupe line
	.if ndf	xlcttm
	tst	rolupd		;finished?
	beq	endl30		;  yes, don't loop
	.endc
	call	pcroll
	beq	endl30		;exit if empty
	bit	#lc.bex,lcmask	;binary extension supressed?
	bne	endl20		;if ne yes
	bit	#lc.bin,lcmask	;binary supressed?
	beq	endl10		;  no
	br	endl20		;yes, don't list
endl30:	tst	(sp)+		;prune listing flag
	zap	codrol		;clear the code roll
	mov	clcloc,r0
	.if df	yphase
	sub	phaoff,r0
	.endc
	cmp	r0,clcmax	;new high for sector?
	blos	31$		;  no
	mov	r0,clcmax	;yes, set it
31$:	return
	.if ndf	xlcttm
endl50:	mov	#octbuf,r2	;point to start of buffer
	call	tsterr		;set error flags
	.if ndf	xlcseq
	mov	#linnum,r0
	mov	(r0)+,r1
	cmp	r1,(r0)
	beq	2$
	mov	r1,(r0)
	bit	#lc.seq,lcmask
	bne	2$
	mov	r2,r4
	dnc
	mov	#octbuf+7,r0
1$:	movb	-(r2),-(r0)
	movb	#space,(r2)
	cmp	r2,r4
	bhi	1$
	.endc
	mov	#octbuf+7,r2
2$:	movb	#tab,(r2)+
	mov	#pf0,r1
	bit	#lc.loc,lcmask
	bne	4$
	tst	(r1)
	beq	3$
	call	setwrd
3$:	movb	#tab,(r2)+
4$:	clr	(r1)
	mov	#pf1,r1
	bit	#lc.bin,lcmask
	bne	endl19
	mov	#3,r4
5$:	tst	(r1)
	beq	6$
	call	setwdb
	bit	#77*400,(r1)
	beq	6$
	movb	#ch.xcl,(r2)+
	bit	#glbflg,(r1)
	beq	6$
	movb	#let.g,-1(r2)
6$:	movb	#tab,(r2)+
	clr	(r1)
	dec	r4
	beq	endl19
	tst	rolupd
	beq	6$
	call	pcroll
	br	5$
	.endc
tsterr:	mov	errbts,r0	;any errors?
	beq	tster9		;  no
	bic	#err.,r0	;yes, ".print"?
	beq	4$		;  yes
	inc	errcnt		;bump error count
4$:	mov	#errmne-1,r1
1$:	tstb	(r1)+		;move char pntr and clear carry
	ror	errbts		;rotate error bits
	bcc	2$
	movb	(r1),(r2)+
	.if ndf	xcref
	movb	(r1),r0		;fetch character
	tstr50			;convert to rad50
	call	mulr50		;left justify
	call	mulr50
	mov	r0,symbol	;store
	clr	symbol+2
	mov	#errrol,rolndx	;prepare to cref
	crfref			;do so
	.endc
	br	1$
2$:	bne	1$
tster9:	return
	.psect	implin,prv,gbl,con 
errbts::.blkw	1		;error bits
	.psect	impure,prv,con 
	.if ndf	xedcdr
cdrsav::.blkw	1		;saved character from card format
	.endc
errcnt::.blkw	1		;error counter
octbuf:				;
octerp:	.blkb	0		;
octseq:	.blkb	2		;
octpf0:	.blkb	7		;
octpf1:	.blkb	octlen-<.-octbuf>;
	.blkw	1		;						;**new**
linbuf::.blkw	linlen/2	;
linend::.blkw	1		;
	.psect	.text.,con,shr
	.end
