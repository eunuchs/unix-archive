	.psect	.text.,con,shr
	.title	pst								;**new**
	.ident	/01/								;**new**
										;**new**
;										;**new**
; copyright 1972, digital equipment corp., maynard, mass 01754			;**new**
; copyright 1973, digital equipment corp., maynard, mass 01754			;**new**
;										;**new**
;	dec assumes no responsibility for the					;**new**
;	use or reliability of its software on					;**new**
;	equipment which is not supplied by dec.					;**new**
;										;**new**
; version 01									;**new**
;										;**new**
; b. bowering									;**new**
;										;**new**
;	modified by:								;**new**
;										;**new**
;	d.n. cutler 10-feb-73							;**new**
;										;**new**
; permanent symbol table							;**new**
;										;**new**
; equated symbols								;**new**
;										;**new**
										;**-9
dr1=	200			;destructive reference in first field
dr2=	100			;destructive reference in second field
dflgev==020			;directive requires even location		;**new**
dflgbm==010			;directive uses byte mode			;**new**
dflcnd==004			;conditional directive				;**new**
dflmac==002			;macro directive				;**new**
dflsmc==001			;mcall						;**new**
										;**-7
;										;**new**
; local macros									;**new**
;										;**new**
										;**new**
	.if df	pal11r		;pal11r subset
xmacro=	0
x40=	0
x45=	0
	.endc
	.iif df	x40&x45,	xfltg=	0
	.iif df	xmacro,	xsml=	0
	.macro	opcdef	name,	class,	value,	flags,	cond
	.if nb	<cond>
	.if df	cond
	.mexit
	.endc
	.endc
	.rad50	/name/
	.byte	flags+0
	.byte	200+opcl'class							;**-1
	.word	value
	.endm
	.macro	dirdef	name,	flags,	cond
	.rad50	/.'name/
	.byte	flags+0,	0
	.if nb	<cond>
	.if df	cond
	.word	opcerr								;**-1
	.mexit
	.endc
	.endc
	.word	name								;**-1
	.endm
										;**new**
	.macro	dirdf1 name,entry,flags,cond					;**new**
	.rad50	/.'name/							;**new**
	.byte	flags,0								;**new**
	.if nb	<cond>								;**new**
	.if df	cond								;**new**
	.word	opcerr								;**new**
	.mexit									;**new**
	.endc									;**new**
	.endc									;**new**
	.word	entry								;**new**
	.endm									;**new**
										;**new**
pstbas::			;ref label					;**new**
	opcdef	<absd  >,	01,	170600,	dr1,	x45			;**-2
	opcdef	<absf  >,	01,	170600,	dr1,	x45
	opcdef	<adc   >,	01,	005500,	dr1
	opcdef	<adcb  >,	01,	105500,	dr1
	opcdef	<add   >,	02,	060000,	dr2
	opcdef	<addd  >,	11,	172000,	dr2,	x45
	opcdef	<addf  >,	11,	172000,	dr2,	x45
	opcdef	<ash   >,	09,	072000,	dr2,	x40&x45
	opcdef	<ashc  >,	09,	073000,	dr2,	x40&x45
	opcdef	<asl   >,	01,	006300,	dr1
	opcdef	<aslb  >,	01,	106300,	dr1
	opcdef	<asr   >,	01,	006200,	dr1
	opcdef	<asrb  >,	01,	106200,	dr1
	opcdef	<bcc   >,	04,	103000,
	opcdef	<bcs   >,	04,	103400,
	opcdef	<beq   >,	04,	001400,
	opcdef	<bge   >,	04,	002000,
	opcdef	<bgt   >,	04,	003000,
	opcdef	<bhi   >,	04,	101000,
	opcdef	<bhis  >,	04,	103000,
	opcdef	<bic   >,	02,	040000,	dr2
	opcdef	<bicb  >,	02,	140000,	dr2
	opcdef	<bis   >,	02,	050000,	dr2
	opcdef	<bisb  >,	02,	150000,	dr2
	opcdef	<bit   >,	02,	030000,
	opcdef	<bitb  >,	02,	130000,
	opcdef	<ble   >,	04,	003400,
	opcdef	<blo   >,	04,	103400,
	opcdef	<blos  >,	04,	101400,
	opcdef	<blt   >,	04,	002400,
	opcdef	<bmi   >,	04,	100400,
	opcdef	<bne   >,	04,	001000,
	opcdef	<bpl   >,	04,	100000,
	opcdef	<bpt   >,	00,	000003,	   ,	x45
	opcdef	<br    >,	04,	000400,
	opcdef	<bvc   >,	04,	102000,
	opcdef	<bvs   >,	04,	102400,
	opcdef	<ccc   >,	00,	000257,
	opcdef	<cfcc  >,	00,	170000,	   ,	x45
	opcdef	<clc   >,	00,	000241,
	opcdef	<cln   >,	00,	000250,
	opcdef	<clr   >,	01,	005000,	dr1
	opcdef	<clrb  >,	01,	105000,	dr1
	opcdef	<clrd  >,	01,	170400,	dr1,	x45
	opcdef	<clrf  >,	01,	170400,	dr1,	x45
	opcdef	<clv   >,	00,	000242,
	opcdef	<clz   >,	00,	000244,
	opcdef	<cmp   >,	02,	020000,					;**-1
	opcdef	<cmpb  >,	02,	120000,
	opcdef	<cmpd  >,	11,	173400,	   ,	x45
	opcdef	<cmpf  >,	11,	173400,	   ,	x45
	opcdef	<cnz   >,	00,	000254,
	opcdef	<com   >,	01,	005100,	dr1
	opcdef	<comb  >,	01,	105100,	dr1
	opcdef	<dec   >,	01,	005300,	dr1
	opcdef	<decb  >,	01,	105300,	dr1
	opcdef	<div   >,	07,	071000,	dr2,	x40&x45
	opcdef	<divd  >,	11,	174400,	dr2,	x45
	opcdef	<divf  >,	11,	174400,	dr2,	x45
	opcdef	<emt   >,	06,	104000,
	opcdef	<fadd  >,	03,	075000,	dr1,	x40
	opcdef	<fdiv  >,	03,	075030,	dr1,	x40
	opcdef	<fmul  >,	03,	075020,	dr1,	x40
	opcdef	<fsub  >,	03,	075010,	dr1,	x40
	opcdef	<halt  >,	00,	000000,
	opcdef	<inc   >,	01,	005200,	dr1
	opcdef	<incb  >,	01,	105200,	dr1
	opcdef	<iot   >,	00,	000004,
	opcdef	<jmp   >,	01,	000100,
	opcdef	<jsr   >,	05,	004000,	dr1
	opcdef	<ldcdf >,	11,	177400,	dr2,	x45
	opcdef	<ldcfd >,	11,	177400,	dr2,	x45
	opcdef	<ldcid >,	14,	177000,	dr2,	x45
	opcdef	<ldcif >,	14,	177000,	dr2,	x45
	opcdef	<ldcld >,	14,	177000,	dr2,	x45
	opcdef	<ldclf >,	14,	177000,	dr2,	x45
	opcdef	<ldd   >,	11,	172400,	dr2,	x45
	opcdef	<ldexp >,	14,	176400,	dr2,	x45
	opcdef	<ldf   >,	11,	172400,	dr2,	x45
	opcdef	<ldfps >,	01,	170100,	   ,	x45
	opcdef	<ldsc  >,	00,	170004,	   ,	x45
	opcdef	<ldub  >,	00,	170003,	   ,	x45
	opcdef	<mark  >,	10,	006400,	   ,	x45
	opcdef	<mfpd  >,	01,	106500,	   ,	x45
	opcdef	<mfpi  >,	01,	006500,	   ,	x45
	opcdef	<modd  >,	11,	171400,	dr2,	x45
	opcdef	<modf  >,	11,	171400,	dr2,	x45
	opcdef	<mov   >,	02,	010000,	dr2
	opcdef	<movb  >,	02,	110000,	dr2
	opcdef	<mtpd  >,	01,	106600,	dr1,	x45
	opcdef	<mtpi  >,	01,	006600,	dr1,	x45
	opcdef	<mul   >,	07,	070000,	dr2,	x40&x45
	opcdef	<muld  >,	11,	171000,	dr2,	x45
	opcdef	<mulf  >,	11,	171000,	dr2,	x45
	opcdef	<neg   >,	01,	005400,	dr1
	opcdef	<negb  >,	01,	105400,	dr1
	opcdef	<negd  >,	01,	170700,	dr1,	x45
	opcdef	<negf  >,	01,	170700,	dr1,	x45
	opcdef	<nop   >,	00,	000240,
	opcdef	<reset >,	00,	000005,
	opcdef	<rol   >,	01,	006100,	dr1				;**-1
	opcdef	<rolb  >,	01,	106100,	dr1
	opcdef	<ror   >,	01,	006000,	dr1
	opcdef	<rorb  >,	01,	106000,	dr1
	opcdef	<rti   >,	00,	000002,
	opcdef	<rts   >,	03,	000200,	dr1
	opcdef	<rtt   >,	00,	000006,	   ,	x45
	opcdef	<sbc   >,	01,	005600,	dr1
	opcdef	<sbcb  >,	01,	105600,	dr1
	opcdef	<scc   >,	00,	000277,
	opcdef	<sec   >,	00,	000261,
	opcdef	<sen   >,	00,	000270,
	opcdef	<setd  >,	00,	170011,	   ,	x45
	opcdef	<setf  >,	00,	170001,	   ,	x45
	opcdef	<seti  >,	00,	170002,	   ,	x45
	opcdef	<setl  >,	00,	170012,	   ,	x45
	opcdef	<sev   >,	00,	000262,
	opcdef	<sez   >,	00,	000264,
	opcdef	<sob   >,	08,	077000,	dr1,	x45
	opcdef	<spl   >,	13,	000230,	   ,	x45
	opcdef	<sta0  >,	00,	170005,	   ,	x45
	opcdef	<stb0  >,	00,	170006,	   ,	x45
	opcdef	<stcdf >,	12,	176000,	dr2,	x45
	opcdef	<stcdi >,	12,	175400,	dr2,	x45
	opcdef	<stcdl >,	12,	175400,	dr2,	x45
	opcdef	<stcfd >,	12,	176000,	dr2,	x45
	opcdef	<stcfi >,	12,	175400,	dr2,	x45
	opcdef	<stcfl >,	12,	175400,	dr2,	x45
	opcdef	<std   >,	12,	174000,	dr2,	x45
	opcdef	<stexp >,	12,	175000,	dr2,	x45
	opcdef	<stf   >,	12,	174000,	dr2,	x45
	opcdef	<stfps >,	01,	170200,	dr1,	x45
	opcdef	<stq0  >,	00,	170007,	   ,	x45
	opcdef	<stst  >,	01,	170300,	dr1,	x45
	opcdef	<sub   >,	02,	160000,	dr2
	opcdef	<subd  >,	11,	173000,	dr2,	x45
	opcdef	<subf  >,	11,	173000,	dr2,	x45
	opcdef	<swab  >,	01,	000300,	dr1
	opcdef	<sxt   >,	01,	006700,	dr1,	x45
	opcdef	<trap  >,	06,	104400,
	opcdef	<tst   >,	01,	005700,
	opcdef	<tstb  >,	01,	105700,
	opcdef	<tstd  >,	01,	170500,	   ,	x45
	opcdef	<tstf  >,	01,	170500,	   ,	x45
	opcdef	<wait  >,	00,	000001,
	opcdef	<xor   >,	05,	074000,	dr2,	x45
	dirdef	<ascii>,	dflgbm						;**-1
	dirdef	<asciz>,	dflgbm
	dirdef	<asect>,	,	xrel
	dirdef	<blkb >
	dirdef	<blkw >,	dflgev
	dirdef	<byte >,	dflgbm
	dirdef	<csect>,	,	xrel
	.if df	yphase
	dirdef	<depha>
	.endc
	dirdef	<dsabl>
	dirdef	<enabl>
	dirdef	<end  >
	dirdef	<endc >,	dflcnd
	dirdf1	<endm >,endm,dflmac,xmacro					;**new**
	dirdf1	<endr >,endm,dflmac,xmacro					;**new**
	dirdef	<eot  >								;**-2
	dirdef	<error>
	dirdef	<even >
	dirdef	<flt2 >,	dflgev,	xfltg
	dirdef	<flt4 >,	dflgev,	xfltg
	dirdef	<globl>,	,	xrel
	dirdef	<ident>
	dirdef	<if   >,	dflcnd
	dirdf1	<ifdf >,ifdf,dflcnd						;**new**
	dirdf1	<ifeq >,ifdf,dflcnd						;**new**
	dirdef	<iff  >,	dflcnd						;**-2
	dirdf1	<ifg  >,ifdf,dflcnd						;**new**
	dirdf1	<ifge >,ifdf,dflcnd						;**new**
	dirdf1	<ifgt >,ifdf,dflcnd						;**new**
	dirdf1	<ifl  >,ifdf,dflcnd						;**new**
	dirdf1	<ifle >,ifdf,dflcnd						;**new**
	dirdf1	<iflt >,ifdf,dflcnd						;**new**
	dirdf1	<ifndf>,ifdf,dflcnd						;**new**
	dirdf1	<ifne >,ifdf,dflcnd						;**new**
	dirdf1	<ifnz >,ifdf,dflcnd						;**new**
	dirdef	<ift  >,	dflcnd						;**-9
	dirdef	<iftf >,	dflcnd
	dirdf1	<ifz  >,ifdf,dflcnd						;**new**
	dirdef	<iif  >								;**-1
	dirdef	<irp  >,	dflmac,	xmacro
	dirdef	<irpc >,	dflmac,	xmacro
	dirdef	<limit>,	dflgev,	xrel
	dirdef	<list >
	dirdf1	<macr >,macr,dflmac,xmacro					;**new**
	dirdf1	<macro>,macr,dflmac,xmacro					;**new**
	dirdef	<mexit>	,	,	xmacro
	dirdef	<narg >	,	,	xmacro
	dirdef	<nchr >	,	,	xmacro
	dirdef	<nlist>
	dirdef	<ntype>	,	,	xmacro
	dirdef	<odd  >
	dirdef	<page >
	.if df	yphase
	dirdef	<phase>
	.endc
	dirdef	<print>
	dirdef	<psect>
	dirdef	<radix>
	dirdef	<rad50>,	dflgev
	dirdef	<rem  >
	dirdef	<rept >,	dflmac,	xmacro
	dirdef	<sbttl>
	dirdef	<title>
wrdsym::			;ref label					;**new**
	dirdef	<word >,	dflgev						;**-1
psttop::			;ref label					;**new**
										;**-3
	.end
