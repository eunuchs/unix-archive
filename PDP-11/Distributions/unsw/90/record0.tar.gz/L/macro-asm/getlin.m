	.psect	.text.,con,shr
	.title	getlin
	.ident	/02/								;**new**
										;**-1
;
; copyright 1972, digital equipment corp., maynard, mass 01754
; copyright 1973, digital equipment corp., maynard, mass 01754
;
;	dec assumes no responsibility for the
;	use or reliability of its software on
;	equipment which is not supplied by dec.
;
; version 02									;**new**
;										;**-1
; b. bowering
;
;	modified by:
;
;	d.n. cutler 9-feb-73
;
;+
; **-getlin-get an input line
;-
getlin::savreg			;save registers
getl01:	call	xctlin		;init line-oriented variables
	mov	ffcnt,r0	;any reserved ff's?
	beq	31$		;  no
	add	r0,pagnum	;yes, update page number
	mov	#-1,pagext
	clr	ffcnt
	.if ndf	rsx11d
	clr	linnum		;init new cref sequence
	clr	seqend
	.endc
	tst	pass								;**-4
	beq	31$
	clr	lppcnt
31$:	mov	#linbuf,r2
	mov	r2,lcbegl	;seat up beginning
	mov	#linend,lcendl	;  and end of line markers
	call	getl20		;get physical line
	tst	r0		;test result
	blt	getl01		;re-try if .lt. 0
	bgt	getl09		;exit if .gt. 0
getl02:	mov	-(r1),r4	;get byte count
	clr	(r1)+		;set stopper
	add	r1,r4		;compute end
3$:	clrb	(r4)		;form asciz
	movb	-(r4),r5	;get last char
	cmp	r5,#cr		;if > cr
	bhi	6$
	cmp	r5,#lf		;  or < lf
	blo	6$		;  move on
	cmp	r5,#ff		;form feed?
	bne	3$		;  no, loop
	.if ndf	xsml
	tst	smllvl		;system macro?
	bne	3$		;  yes, don't tally ff
	.endc
	inc	ffcnt		;count the page
	br	3$
5$:	movb	r5,(r2)+	;move into linbuf
6$:	movb	(r1)+,r5	;fetch next char
	movb	cttbl(r5),r0	;get characteristics
	beq	7$		;questionable
	bit	#ct.lc,r0	;lower case?
	beq	5$		;  no
	.if ndf	xedlc
	bit	#ed.lc,edmask	;lower case enabled?
	bne	4$		;  no, convert to upper
	add	#240,r5		;yes, end up with "200 + lc"
	.endc
4$:	sub	#40,r5		;convert lower to upper case
	br	5$		;store
7$:	movb	r5,(r2)		;questionable, asciz null?
	beq	getl09		;  yes, all set
	error	i		;no, illegal character
	mov	#200,r5		;store zero with flag bit
	br	5$
getl09:	.if ndf	xedcdr
	movb	linbuf+72.,cdrsav	;save column 73
	bit	#ed.cdr,edmask	;card reader type?
	bne	38$		;  no
	clrb	linbuf+72.	;yes, force eol
	.endc
38$:	mov	#linbuf,chrpnt
	setnb
	bne	39$		;all set if non-null line
	tst	ffcnt		;null, form feed?
	beq	39$		;  no
	jmp	getl01		;yes, just bump page count
39$:	mov	endflg,r0	;return with "endflg" as argument
	return
getl20:
	.if ndf	xsml
	tst	smllvl		;processing system macro?
	beq	1$
	$readw	sml		;yes, read the next line
	clr	r0		;assume ok
	bit	#io$eof,ioftbl+smlchn;eof?					;**new**
	beq	2$		;  no						;**-1
	inc	r0		;yes, set r0
	bis	r0,endflg	;  and end flag
2$:	mov	buftbl+smlchn,r1	;point to buffer
	return
	.endc
1$:	.if ndf	xmacro
	mov	msbmrp,r1	;pointing to macro?
	bne	getl10		;  yes, process it
	.endc
	call	getpli		;get physical line from exec
	tst	r0		;normal?
	beq	4$		;  yes
	blt	3$		;  new file
	error	e		;eof, error
	inc	endflg		;flag it
	dec	ffcnt		;inhibit extra page eject			;**new**
3$:	inc	ffcnt		;new file, force eject
	.if ndf	xlcseq								;**new**
	mov	#-1,linnum	;start file with new sequence numbers		;**new**
	clr	seqend		;						;**new**
	.endc									;**new**
4$:	bit	#io.err,ioftbl+srcchn	;error?
	beq	5$		;  no
	error	l		;yes, flag it
5$:	mov	buftbl+srcchn,r1	;point to input buffer
	.if ndf	xlcseq
	inc	linnum		;increment line count
	.endc
	return
	.if ndf	xmacro
getl10:	call	20$		;move a character
	bgt	getl10		;loop if gt zero
	beq	19$		;end if zero
	movb	-(r2),r0	;terminator, back up pointer
	cmp	r0,#mt.max	;end of type?
	blos	22$		;  yes
	mov	r1,-(sp)	;remember read pointer
	mov	msbarg,r1
	tst	(r1)+
	mov	r2,r3		;  and write pointer
	neg	r0		;assume macro
	cmp	msbtyp,#mt.mac	;true?
	beq	12$		;  yes, use it
	mov	msbcnt,r0	;get arg number
12$:	mov	r3,r2		;reset write pointer
13$:	call	20$		;move a byte
	bgt	13$		;loop if pnz
	blt	14$		;end if less than zero
	sob	r0,12$		;loop if not through
14$:	tstb	-(r2)		;yes, back up pointer
	mov	(sp)+,r1	;reset read pointer
	br	getl10		;end of argument substitution
19$:	mov	r1,msbmrp	;end of line, save pointer
	bis	#lc.me,lcflag	;flag as macro expansion
	mov	#1,r0		;exit getlin routine
	return
20$:	bit	#bpmb-1,r1	;macro, end of block?
	bne	21$		;  no
	mov	-bpmb(r1),r1	;yes, point to next block
	tst	(r1)+		;move past link
21$:	cmp	r2,#linbuf+srclen	;overflow?
	blos	23$		;  no
	error	l		;yes, flag error
	tstb	-(r2)		;  and move pointer back
23$:	movb	(r1)+,(r2)+	;move char into line buffer
	return
22$:	call	endmac		;close macro
	mov	#-1,r0		;re-process line
	return
	.endc
	.psect	imppas,prv,gbl,con 
lppcnt::.blkw	1		;force new page when negative
ffcnt::	.blkw	1		;unprocessed ff count
pagnum::.blkw	1		;page number
pagext::.blkw	1		;page extension
										;**new**
	.if ndf	xlcseq
linnum::.blkw	2		;cref line number
seqend::.blkw	1		;
	.endc
	.psect	.text.,con,shr
	.end
