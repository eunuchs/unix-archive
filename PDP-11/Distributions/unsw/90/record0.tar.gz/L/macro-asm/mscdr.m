	.psect	.text.,con,shr
	.title	mscdr
	.ident	/05/
; abstracted from rsx version 02
										;**-1
;
; copyright 1972, digital equipment corp., maynard, mass 01754
; copyright 1973, digital equipment corp., maynard, mass 01754
;
;	dec assumes no responsibility for the
;	use or reliability of its software on
;	equipment which is not supplied by dec.
;
; version 02									;**new**
;										;**-1
; b. bowering
;
;	modified by:
;
;	d.n. cutler 6-feb-73
;	d. knight 29-jun-73
;
;+
; **-globl-global reference or definition
; **-end-end of assembly
;-
	.if ndf	xrel
globl::	gsarg			;get symbolic argument
	beq	3$		;  end
	ssrch			;no, search user symbol table
	bit	#regflg,flags	;register?
	bne	2$		;  yes, error
	bic	#dfgflg,flags	;clear default global flag bit
	bis	#glbflg,flags	;no, flag as globl
	insert			;update/insert
	crfdef
	br	globl		;
2$:	error	r
	br	globl		;
3$:	return
	.endc
end::	tst	cndlvl		;nested conditionals?
	bne	5$		;yes, can't be legal
	tst	maclvl		;in a macro?
	beq	10$		;no, must be ok.
5$:	error	o		;set error on line
	return			;and return unrecognized.
10$:	expr			;evalute transfer expression
	bne	1$		;  branch if non-null
	inc	(r4)		;null, make it a one
1$:	reltst			;no globals allowed
	inc	endflg
	setimm			;fill out block
	setpf1			;list field 1
	mov	#symbol,r1
	mov	#endvec,r2
	jmp	xmit4		;move to end vector
										;**-3
	.psect	xctprg,gbl,shr,con 
	inc	endvec+6	;default to no end vector
	.psect	.text.,con,shr
;+
; **-sethdr-set page header
; **-title-set program title
; **-sbttl-sub title
; **-print-message
; **-error-error message
; **-rem-remarks
;-
sethdr::mov	#defttl,chrpnt	;point to default heading
	movb	#cr,defstr	;set first top of page
	setchr			;make it look like the real thing
title::	getsym			;get symbol
	bne	1$		;  error if null
	error	a
	return
1$:	mov	r0,prgttl	;move into storage
	mov	symbol+2,prgttl+2
	call	setsym		;point to start of title
	mov	#ttlbuf,r2	;point to buffer
	movb	defstr,(r2)+	;store page eject
	clr	r3		;clear position conter
2$:	movb	r5,(r2)		;plunk the next char in the buffer
	beq	5$		;branch if end
	cmp	r5,#tab		;a tab?
	bne	3$		;  no
	bis	#7,r3		;yes, compensate
3$:	inc	r3		;update position counter
	cmp	r3,#ttllen	;within bounds?
	bhis	4$		;  no
	tstb	(r2)+		;yes, move pointer
4$:	getchr			;get the next character
	bne	2$		;loop if not end
5$:	movb	#tab,(r2)+	;set separator
	mov	#hdrttl,r1
	movbyt			;set version number, etc.
	.if ndf	xtime
	mov	#dattim,r1
	movbyt			;date and time
	.endc
	mov	r2,ttlbrk	;remember break point
	return
	.psect	txtbyt,prv,con 
defttl:	.asciz	/.main./	;default title
	.psect	.text.,con,shr
sbttl::	mov	#stlbuf,r2	;point to subtitle buffer
	tst	pass		;pass one?
	beq	2$		;  yes
1$:	movb	r5,(r2)+	;move character in
	beq	13$		;  branch if end
	getchr			;get the next character
	cmp	r2,#stlbuf+stllen-1	;test for end
	blo	1$
	tstb	-(r2)		;polish off line
	br	1$
2$:	bit	#lc.toc,lcmask
	bne	13$
	tstb	lstdev		;any listing device?
	beq	13$		;  no, exit
	mov	#toctxt,r1
	movbyt			;set table of contents
	call	setsym		;point to ".sbttl"
3$:	getr50			;get radix-50 char
	bgt	3$		;stop at first terminator
	mov	chrpnt,r2	;set pointer
	.if ndf	xlcseq
	mov	linnum,r0
	call	10$
	movb	#ch.sub,-(r2)
	.iff
	movb	#tab,-(r2)
	.endc
	mov	pagnum,r0
	call	10$
	movb	#space,-(r2)
	putlp	r2		;output
	return
10$:	mov	#3,r4
11$:	movb	#space,-(r2)
	mov	r0,r1
	beq	12$
	clr	r0
	div	#^d10,r0
	add	#dig.0,r1
	movb	r1,(r2)
12$:	sob	r4,11$
13$:	return
	.psect	txtbyt,prv,con 
toctxt:	.asciz	/table of contents/
	.psect	.text.,con,shr
	.enabl	lsb
print::	error	<>		;null error (don't count)
	br	1$
error::	error	p		;
1$:	setpf0			;print location field
	expr			;evaluate expression
	beq	2$		;branch if null
	setpf1			;non-null, list value
2$:	return
	.dsabl	lsb
rem::	mov	r5,r3		;set terminating character
	bne	1$		;branch if non-null
	error	a		;error, no delimiting character
	return
1$:	getchr			;get the next character
2$:	tst	r5		;end of line?
	bne	3$		;  no
	call	endlin		;yes, polish off line
	inc	getflg		;inhibit file crossing				;**new**
	call	getlin		;get next line
	dec	getflg		;enable file crossing				;**new**
	tst	r0		;test getlin return status			;**new**
	beq	2$		;loop if no eof
	return			;eof, exit
3$:	cmp	r5,r3		;is this the terminator?
	bne	1$		;  no
	jmp	getnb		;yes, bypass and exit
	.end
