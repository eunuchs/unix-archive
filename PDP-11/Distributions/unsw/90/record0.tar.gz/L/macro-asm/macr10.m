	.psect	.text.,shr,con
	.title	macro
	.ident	/d02/
;
; copyright 1972, digital equipment corp., maynard, mass 01754
; copyright 1973, digital equipment corp., maynard, mass 01754
;
;	dec assumes no responsibility for the			;
;	use or reliability of its software on			;
;	equipment which is not supplied by dec.			;
;								;
; version 02							;
;										;**-1
; b. bowering main author
;
; modified by:
;
;	d.n. cutler 20-jan-73
;		addition of register symbols and automatic resolution of
;		global symbol references.
;	d. knight 25-may-73 -- dos changes
;
;
; generate register roll symbol
;
; genreg rname,value
;
; where:
;
;	rname=a 2 character register name.
;	value=a value from 0 to 7.
;
;
; drag in some globals we need
;
;
	.globl	r50unp
	.globl	syttop
	.macro	genreg rname,value
	.rad50	/rname/
	.word	0
	.byte	defflg+regflg,0
	.word	value
	.endm
	.psect	regsec,prv,con
regbas:			;ref label
	genreg	r0,0
	genreg	r1,1
	genreg	r2,2
	genreg	r3,3
	genreg	r4,4
	genreg	r5,5
	genreg	sp,6
	genreg	pc,7
regtop:			;ref label
	.psect	.text.,shr,con
;
;	error flag definitions
;
	.psect	txtbyt,prv,con
tmpcnt=	1			;set for bit shifting
errmne::.irpc	char,< abeilmnopqrtuz>;
	.ascii	/char/
err.'char==tmpcnt
tmpcnt=	tmpcnt+tmpcnt
	.endm
	.psect	.text.,con,shr
	.sbttl		roll definitions
	.macro	genrol name,base,tope,size
	.psect	rolbas,prv,con
name'rol==.-rolbas
bas'name:
	.word	base
	.psect	roltop,prv,con
top'name:
	.word	tope
	.psect	rolsiz,prv,con
siz'name:
	.word	size*2
rs.'name=size
	.iif gt	size-maxxmt,	maxxmt=size
	.endm	genrol
	.iif ndf maxxmt,	maxxmt=	0
	.psect	rolbas,prv,con
rolbas::			;ref label
	.psect	roltop,prv,con
roltop::			;ref label
	.psect	rolsiz,prv,con
rolsiz::			;ref label
	genrol	sym,     0,     0,4	;symbol table
	.if ndf	xmacro
	genrol	mac,     0,     0,4	;macro roll
	genrol	dma,     0,     0,2	;dummy argument roll
	.endc
	.if ndf	xedlsb
	genrol	lsy,     0,     0,4	;local symbol roll
	.endc
	.globl	sizsec
	genrol	sec,     0,     0,5	;section roll
	.globl	sizcod
	genrol	cod,     0,     0,4	;code roll
	.if ndf	xmacro
	.globl	basmaa,basmab,topmab
	genrol	mab,     0,     0,bpmb/2
	genrol	maa,     0,     0,bpmb/2
	.endc
	genrol	dum,     0,     0,0	;dummy (separates variable from fixed)
	genrol	cnd,cndbas,cndtop,2	;conditional arguments
	genrol	swt,swtbas,swttop,2	;command string switches
	genrol	edt,edtbas,edttop,2	;enabl/dsabl
	genrol	lcd,lctbas,lcttop,1	;listing control
	genrol	pst,pstbas,psttop,4	;permanent symbol table
	genrol	reg,regbas,regtop,4
	genrol	sat,satbas,sattop,2
	.psect	.text.,con,shr
;
; program initialization code
;
	.psect	xctprg,gbl,shr,con
xctprg:	mov	#impure,r0	;clear impure area
1$:	clr	(r0)+		;clear impure area
	cmp	#impurt,r0
	bhi	1$
	.psect	xctprt,gbl,shr,con
	jmp	xctpas
	.psect	xctpas,gbl,shr,con
xctpas:	mov	#imppas,r0	;pass initialization
2$:	clr	(r0)+		;clear impure part
	cmp	#imppat,r0
	bhi	2$
	.psect	xctpat,gbl,shr,con
	jmp	xctlin
	.psect	xctlin,gbl,shr,con
xctlin::mov	#implin,r0	;line initialization
3$:	clr	(r0)+
	cmp	#implit,r0
	bhi	3$
	.psect	xctlit,gbl,shr,con
	return			;
	.psect	impure,prv,con
impure:				;ref label
	.psect	impurt,prv,con
impurt:				;ref label
	.psect	imppas,prv,gbl,con
imppas:				;ref label
	.psect	imppat,prv,gbl,con
imppat:				;ref label
	.psect	implin,prv,gbl,con
implin:				;ref label
	.psect	implit,prv,gbl,con
implit:				;ref label
	.psect	.text.,con,shr
	.psect	impure,prv,con
pass::	.blkw	1		;pass flag
				;next group must stay together
	.psect	imppas,prv,gbl,con
symbol::.blkw	2		;symbol accumulator
mode::				;mode/flags byte
flags::	.blkb	1		;
sector::.blkb	1		;symbol/expression type
value::	.blkw	1		;expression value
rellvl::.blkw	1		;relocation level
	.rept	maxxmt-<<.-symbol>/2>	;end of grouped data
	.blkw
	.endr
clcnam::.blkw	2		;current location counter name
clcfgs::.blkb	1		;
clcsec::.blkb	1		;
clcloc::.blkw	1		;
clcmax::.blkw	1		;
chrpnt::.blkw	1		;character pointer
symbeg::.blkw	1		;pointer to start of symbol
endflg::.blkw	1		;
	.psect	.text.,con,shr,con
;+
; assembler proper
;-
;***** this will fall at loc 0 in the text segment
;***** must be used since UNIX doesnt have a transfer
;***** address in loadable files!!!!!!!!!!!!!!!!
	.globl	start
	jmp	start		;away we go!
assem::	call	xctprg		;clear core
	.if ndf	xmacro
	bic	#bpmb-1,syttop	;macro storage must be modulo
	.endc
	mov	#dumrol,r1	;point to separator roll
1$:	mov	syttop,rolbas(r1)	;set base
	mov	syttop,roltop(r1)	;  and top
	clrb	rolsiz+1(r1)	;zero current size
	sub	#2,r1		;move down a roll
	bge	1$		;loop 'till roll #0
	return
macp1::	call	xctpas		;macro pass 1
	mov	#lst.kb*400,r0	;set error slot
	tstb	ioftbl+lstchn	;listing device?
	beq	1$		;  no
	bis	#lst.kb!100200,r0	;yes, assume teletype
	bit	#io.tty,ioftbl+lstchn	;true?
	bne	1$		;  yes
	add	#<lst.lp-lst.kb>*401,r0	;no, upgrade to lp
1$:	mov	r0,lstdev	;set flags
	call	sethdr		;set up header
	br	macp2f
macp2::	call	xctpas		;macro pass 2
macp2f:	call	secini		;init the sector roll
3$:	call	getlin		;get the next input line
	bne	4$		;  branch if eof
	call	stmnt		;process the statement
4$:	call	endlin		;polish off line
	tst	endflg		;end seen?
	beq	3$		;  no, continue
	return
	.psect	dpure,prv,con
r50abs::.rad50	/. abs./	;
r50dot::.rad50	/.     /	;
	.psect	.text.,con,shr
	.sbttl	statement processor
stmnt::				;ref label
	mov	cndwrd,r0	;in conditional?
	bis	cndmex,r0	;  or mexit?
	bne	40$		;  yes, branch if suppressed
	getsym
	beq	20$
	cmp	r5,#ch.col	; ":"
	beq	label
	cmp	r5,#ch.equ	; "="
	bne	1$		;  no
	jmp	asgmt		;yes, process it
1$:	.if ndf	xmacro
	msrch
	beq	2$
	crfref
	jmp	macroc		;macro call
	.endc
2$:	osrch
	beq	30$
	crfref
10$:	jmp	propc		;process op code
20$:
	.if ndf	xedlsb
	mov	#10.,r2		;not symbol, perhaps local symbol?
	cvtnum
	beq	30$		;  no
	cmp	r5,#ch.dol	;number, terminated by "$"?
	bne	30$		;  no
	getnb
	cmp	r5,#ch.col
	bne	30$
	mov	clcloc,r0
	sub	lsybas,r0	;compute local offset
	lsrch			;search for local symbol
	br	labelf		;exit through label processor
	.endc
30$:	setsym			;reset char pointer and flags
	tstb	cttbl(r5)
	ble	42$		;null if end of line
	mov	#wrdsym,r1	;neither, fudge ".word" directive
	mov	#symbol,r2
	call	xmit4		;move pst entry to "symbol"
	br	10$
40$:	call	setcli		;unsat conditional, test directive
	bmi	41$		;  branch if eof
	bit	#dflcnd,r0	;conditional?
	bne	10$		;  yes, process it
	bis	#lc.cnd,lcflag	;mark as unsat conditional
41$:	clr	r5
42$:	return			;ignore line
setcli::			;ref label
1$:	getsym			;try for symbol
	.if ndf	xedlsb
	bne	3$		;branch if found
	bitb	#ct.num,cttbl(r5)	;perhaps a local?
	beq	5$		;  no
2$:	getchr			;perhaps, test next
	bitb	#ct.alp,cttbl(r5);alpha?
	bne	2$		;if ne yes
	bitb	#ct.num,cttbl(r5);numeric?
	bne	2$		;  yes, try again
	setnb			;no, bypass any blanks
	.iff
	beq	5$		;  exit if no symbol
	.endc
3$:	cmp	r5,#ch.equ	;assignment (=)?
	beq	5$		;  yes, ignore this line
	cmp	r5,#ch.col	;label (:)?
	bne	4$		;  no
	getnb			;yes, bypass colon
	cmp	r5,#ch.col	;another colon?
	bne	1$		;if ne no
	getnb			;bypass second colon
	br	1$		;  and continue
4$:	osrch			;try for op-code
	mov	mode,r0		;mode to r0
	bpl	6$		;branch if directive
5$:	clr	r0		;false
6$:	return
label:				;label processor
	.enabl	lsb
	cmp	symbol,r50dot	;period?
	beq	4$		;  yes, error
	.if ndf	xedlsb
	call	lsbset		;flag start of new local symbol block
	.endc
	ssrch			;no, search the symbol table
	crfdef
labelf:	setxpr			;set expression registers
	getnb			;bypass colon
	clr	-(sp)		;assume no global definition
	cmp	r5,#ch.col	;second colon?
	bne	10$		;if ne no
	mov	#glbflg,(sp)	;set global definition bit
	getnb			;bypass second colon
10$:	bit	#defflg,(r3)	;already defined?
	bne	1$		;  yes
	mov	clcfgs,r0	;no, get current location characteristics
	bic	#377-<relflg>,r0	;clear all but relocation flag
	bis	#defflg!lblflg,r0	;flag as label
	bis	(sp),r0		;merge possible global definition flag
	bit	#dfgflg,(r3)	;default global from ref?
	beq	11$		;if eq no
	bic	#dfgflg!glbflg,(r3);clear default flags
11$:	bis	r0,(r3)		;set mode bits
	mov	clcloc,(r4)	;  and current location
	br	3$		;insert
1$:	bit	#lblflg,(r3)	;defined, as label?
	beq	2$		;  no, invalid
	cmp	clcloc,(r4)	;has anybody moved?
	bne	2$		;  yes
	cmpb	clcsec,(r2)	;same sector?
	beq	3$		;  yes, ok
2$:	error	p		;no, flag error
	bis	#mdfflg,(r3)	;flag as multiply defined
3$:	insert			;insert/update
	setpf0			;be sure to print location field
	br	5$
4$:	error	q
	br	6$		;
5$:	tst	(sp)+		;clean stack
6$:	setnb			;bypass any blanks
	mov	chrpnt,lblend	;mark end of label
	jmp	stmnt		;try for more
	.dsabl	lsb
	.sbttl	op code processor
propc::				;ref label
	mov	#mode,r4	;point to mode
	mov	(r4),r1		;leave result in r1
	clr	(r4)+		;set to zero, point to value
	mov	#clcloc,r2	;point r2 to location counter
	bit	#100000+dflgev,r1	;op code or even directive?
	beq	1$		;  no
	bit	#1,(r2)		;yes, currently even?
	beq	1$		;  yes
	inc	(r2)		;no, make it even
	error	b		;  and flag error
1$:	bit	#dflgbm,r1	;byte mode directive?
	beq	2$		;  no
	inc	bytmod		;yes, set flag
2$:	tst	r1		;op-code?
	bmi	10$		;  yes
	mov	(r4),-(sp)	;no, directive.
	clr	(r4)		;clear value
	clr	r3		;start with r3=0
	jmp	@(sp)+		;go to proper handler
10$:	mov	#077776,pcrcnt	;list location of first word only
	stcode			;stuff basic value
	.if ndf	xcref
	movb	r1,crfdfl+1	;set "*" cref markers
	.iftf
	swab	r1
	bic	#177600,r1	;clear high order bits
	mov	r1,opclas	;save class
	asl	r1
	asl	r1		;four bytes per table entry
	clr	-(sp)		;set a stopper
	mov	opjtbl+2(r1),-(sp)	;stack second arg
	bne	11$		;branch if two args
	tst	(sp)+		;one arg, prune terminator
11$:	mov	opjtbl(r1),r1	;set the first argument
	beq	14$		;branch if no args
12$:	mov	r1,-(sp)	;save a copy of the arg
	swab	(sp)		;shift count to right half
	bic	#177400,r1	;isolate low byte
	tstarg			;comma test
	clr	r0		;function register
	call	opjbas(r1)	;call proper routine
	.ift
	rolb	crfdfl+1	;move second field bit
	.endc
13$:	asl	r0		;shift result
	decb	(sp)		;count in sp, rh
	bge	13$
	ror	r0		;we went one too many
	mov	rolbas+codrol,r1
	bis	r0,6(r1)	;set expression bits
	tst	(sp)+		;prune work entry
14$:	mov	(sp)+,r1	;get next arg from stack
	bne	12$		;branch if not terminator
	.if ndf	xzerr
	mov	rolbas+codrol,r1
	mov	6(r1),r0	;set for "z" error tests
	mov	r0,r1
	bic	#000007,r1
	cmp	#000120,r1	;  jmp (r)+
	beq	22$
	bic	#000700,r1
	cmp	#004020,r1	;  jsr  x,(r1)+
	beq	22$
	mov	r0,r1
	bit	#007000,r1	;first arg type 0?
	bne	23$		;  no, ok
	bic	#100777,r1
	beq	23$
	cmp	#070000,r1	;double address type?
	beq	23$		;  no
	mov	r0,r1
	bic	#170017,r1
	cmp	#000760,r1	;  mov pc,[@]x(r)
	beq	22$
	bic	#177717,r1
	cmp	#000020,r1	;  (r)+
	beq	21$
	cmp	#000040,r1	;  -(r)
	bne	23$
21$:	mov	r0,r1
	rol	r1
	rol	r1
	swab	r1
	sub	r0,r1
	bit	#000007,r1	;  r1=r2
	bne	23$
22$:	error	z
23$:
	.endc
cpopj::	return			;
	.macro	genopj	number,subr1,sc1,subr2,sc2	;op code jump table
	.globl	opcl'number
opcl'number=	<.-opjtbl>/4
	.iif nb <subr1>,	.byte	subr1-opjbas
	.iif  b <subr1>,	.byte	0
	.byte	sc1+0
	.iif nb <subr2>,	.byte	subr2-opjbas
	.iif  b <subr2>,	.byte	0
	.byte	sc2+0
	.endm
	.psect	dpure,prv,con
opjtbl:				;op code jump table
	genopj	00
	genopj	01,	aexp
	genopj	02,	aexp,	6,	aexp
	genopj	03,	regexp
	genopj	04,	brop
	genopj	05,	regexp,	6,	aexp
	genopj	06,	trapop
	.if ndf	x45
	genopj	07,	aexp,	0,	regexp,	6
	genopj	08,	regexp,	6,	sobop
	genopj	09,	aexp,	0,	regexp,	6
	genopj	10,	markop
	genopj	11,	aexp,	0,	drgexp,	6
	genopj	12,	drgexp,	6,	aexp,	0
	genopj	13,	splop
	genopj	14,	aexp,	0,	drgexp,	6
	.endc
	.psect	implin,prv,gbl,con
opclas::.blkw	1		;op code class			;
	.psect	.text.,con,shr
opjbas:	return			;index base for following routines
regexp:	absexp			;evalute absolute
	bit	#177770,r0	;any overflow?
	beq	1$		;  no
	error	r		;yes, flag error
	bic	#177770,r0	;clear overflow
1$:	return
brop:				;branch displacement type
	relexp
	cmpb	sector,clcsec
	bne	2$
	sub	clcloc,r0
	asr	r0
	bcs	2$
	dec	r0
	movb	r0,r3		;extend sign
	cmp	r0,r3		;proper?
	beq	3$		;  yes
2$:	error	a
	mov	#000377,r0
3$:	bic	#177400,r0	;clear possible high bits
	return
trapop:				;trap type
	setxpr			;set expression registers
	mov	(r4),-(sp)	;save the value
	expr			;evaluate the expression (null ok)
	inc	bytmod		;treat as byte
	setimm
	cmpb	(r2),#200	;absolute?
	bne	1$		;  no
	tst	(sp)+		;yes, prune stack
	mov	(r4),r0		;value to merge
	return
1$:	zap	codrol		;clear code roll
	stcode			;store address
	mov	#100000,(r3)	;set for absolute byte
	swab	(sp)
	mov	(sp)+,(r4)	;set origional value
	stcode
	clr	r0
	return
	.if ndf	x45
drgexp:				;double register expression
	call	regexp		;evaluate normal
	mov	#177774,r3	;test for overflow
	br	maskr3
sobop:				;sob operator
	call	brop		;free-load off branch operator
	movb	r0,r0		;extend sign
	neg	r0		;positive for backwards
	br	maskb6		;mask to six bits
splop:				;spl type
	absexp
	mov	#177770,r3	;only three bits allowed
	br	maskr3
markop:				;mark operator
	absexp			;evaluate absolute
maskb6:	mov	#177700,r3	;set to mask high order
maskr3:	bit	r3,r0		;overflow?
	beq	1$		;  no
	error	t		;yes, flag truncation error
	bic	r3,r0		;clear excess
1$:	return
	.endc
aexp::	savreg			;save registers
	setxpr			;  and set "expression" type
	inc	expflg
	clr	-(sp)		;accumulate on top of stack
aexp02:	chscan	aextbl		;test for operator
	beq	aexp22		;  no
	jmp	(r0)		;yes, go to it
	.psect	dpure,prv,con
aextbl:				;address expression table
	gchtbl	ch.ind,	aexp03	;  "@"
	gchtbl	ch.hsh,	aexp06	;  "#"
	gchtbl	ch.sub,	aexp10	;  "-"
	gchtbl	ch.lp,	aexp12	;  "("
	.word	0		;terminator
	.psect	.text.,con,shr
aexp03:	tst	(sp)		;"@", second time around?
	beq	4$		;  no
	error	q		;  yes
4$:	bis	#am.def,(sp)	;set it
	br	aexp02
aexp06:				;literal (#)
	.if ndf	xfltg
	cmp	#opcl11,opclas	;class 11?
	bne	8$		;  no
	call	fltg1w		;yes, try for one-word floating
	bne	9$		;branch if ok
	.endc
8$:	glbexp			;evaluate expression
9$:	bis	#am.imm,(sp)	;set bits
	br	aexp32		;use common exit
aexp10:				;auto-decrement (-)
	cmp	r5,#ch.lp	;followed by "("?
	bne	aexp20		;  not a chance
	call	aexplp		;process parens
	bis	#am.dec,(sp)
	br	aexp36
aexp12:				; "("
	call	aexpl1		;evaluate register
	cmp	r5,#ch.add	;auto-increment (+)?
	bne	14$		;  no
	getnb			;yes, polish it off
	bis	#am.inc,(sp)	;set bits
	br	aexp36
14$:	bit	#am.def,(sp)	;indirect seen?
	bne	16$		;  yes
	bis	#am.def,(sp)	;no, set bit
	br	aexp36
16$:	clr	(r3)		;mode
	clr	(r4)		;  and value
	br	aexp30
aexp20:	setsym			;auto-dec failure, point to -
aexp22:	glbexp			;get an expression
	cmp	r5,#ch.lp	;indexed?
	beq	24$		;  yes
	bit	#regflg,(r3)	;flags
	bne	aexp36
	.if ndf	xedpic!xedama
	tst	(sp)
	bne	23$
	.if ndf	xedpic
	bit	#ed.pic,edmask
	bne	1$
	bit	#glbflg,(r3)
	bne	2$
	cmpb	(r2),clcsec
	beq	23$
	br	2$
1$:
	.endc
	.if ndf	xedama
	bit	#ed.ama,edmask	;absolute mode requested?
	bne	23$		;  no
	.endc
2$:	bis	#am.imm!am.def,(sp)	;ok, set abs mode
	br	aexp32
	.endc
23$:	bis	#am.rel,(sp)	;no
	setdsp			;set displacement
	br	aexp34
24$:	bit	#regflg,(r3)	;flags
	beq	26$
	error	r
	bic	#regflg,(r3)	;flags
26$:	mov	(r1)+,-(sp)	;stack current value
	mov	(r1)+,-(sp)
	mov	(r1)+,-(sp)
	mov	(r1)+,-(sp)
	call	aexplp		;process index
	mov	(sp)+,-(r1)	;restore
	mov	(sp)+,-(r1)
	mov	(sp)+,-(r1)
	mov	(sp)+,-(r1)
aexp30:	bis	r0,(sp)
	bis	#am.ndx,(sp)
aexp32:	setimm
aexp34:	stcode
	clr	r0
aexp36:	bis	(sp)+,r0
	return
aexplp:				;aexp paren processor
	getnb			;bypass paren
aexpl1:	call	regexp		;get a register expression
	cmp	r5,#ch.rp	;happy ending ")"?
	bne	1$		;  no
	jmp	getnb		;yes, bypass and exit
1$:	error	q		;no
	return
	.sbttl	expression to code-roll conversions
setimm::			;set immediate mode
	savreg			;save registers
	setxpr			;  and set "expression" type
	.if ndf	xrel
	mov	#immmod,r1	;set table index
	tst	endflg		;special for .end?
	bne	setds1		;  yes
	bitb	#glbflg,(r3)	;external?
	bne	setds4		;if ne yes-use common code
	cmpb	(r1)+,(r1)+	;move index
	bitb	#relflg,(r3)	;relocatable?
	beq	setdsx		;  no, all set
	tstb	(r1)+
	cmpb	(r2),clcsec	;yes, current sector?
	bne	setds1		;  no
	.iftf
	br	setdsx		;yes
setdsp:				;set displacement mode
	savreg			;save registers
	setxpr			;  and set "expression" type
	.ift
	mov	#dspmod,r1	;set index
	bitb	#glbflg,(r3)	;external?
	bne	setds3		;  yes, test for additive
	cmpb	(r1)+,(r1)+
	cmpb	(r2),clcsec	;current sector?
	beq	setds2		;  yes
	tstb	(r1)+
	tstb	(r2)		;looking at absolute?
	beq	setdsx		;  yes
setds1:	tstb	(r1)+
	clr	r0		;clear high order
	bisb	(r2),r0		;set sector
	imuli	rs.sec*2,r0	;multiply by bytes/block
	add	rolbas+secrol,r0	;compute base of sector roll
	mov	(r0)+,symbol	;xfer sector name to symbol
	mov	(r0)+,symbol+2
	br	setdsx
setds2:	clr	mode
	.iftf
	movb	rolsiz+codrol+1,r0	;get code roll entry number
	inc	r0
	asl	r0		;make it 4 or 6
	add	clcloc,r0
	sub	r0,(r4)
	.ift
	br	setdsx
setds3:	.if df	yphase
	sub	phaoff,(r4)	;subtract out phase offset
	.endc
setds4:	tst	(r4)		;any offset constant?
	beq	setdsx		;if eq no
	tstb	(r1)+		;yes, advance index
setdsx:
	.ift
	.if ndf	xedpic
	bit	#ed.pic,edmask
	bne	12$
	tstb	(r1)
	beq	12$
	cmpb	(r2),clcsec
	beq	10$
	cmp	r1,#dspmod
	bhis	11$
	br	12$
10$:	cmp	r1,#dspmod
	bhis	12$
11$:	error	r
12$:
	.endc
	movb	(r1),(r2)	;fill in type
	.iftf
	tst	bytmod		;in byte mode?
	beq	4$		;  no
	tstb	(r4)+		;move to high byte of "value"
	movb	(r4),r0		;any high order bites?
	beq	1$		;  no, ok
	inc	r0		;yes, all ones?
	bne	2$		;  no, you lose
1$:	.ift
	cmpb	(r2),#rldt01	;error if rld type 1
	beq	2$
	cmpb	(r2),#rldt15	;  or 15
	bne	3$
	.iff
	br	3$
	.iftf
2$:	abserr			;flag error
3$:	clrb	(r4)
	bisb	#200,(r2)	;flag as byte
4$:	return
	.ift
	.psect	txtbyt,prv,con
immmod:	.byte	rldt02,	rldt05,	rldt00,	rldt01,	rldt15,	0
dspmod:	.byte	rldt04,	rldt06,	rldt00,	rldt03,	rldt16,	0
	.endc
	.psect	implin,prv,gbl,con
bytmod:	.blkw			;byte mode if non-zero
	.psect	.text.,con,shr
macp0::				;save output switches
	mov	#lcsave,r1	;reverse of above
	mov	#lcsbak,r2
	mov	#xmit0,-(sp)	;get base address of move vector
	sub	#lcsavl,(sp)	;calculate proper offset
	call	@(sp)+		;move block
	mov	edmask,edmbak	;ditto for enabl/dsabl
	return
	.sbttl	utilities
setxpr::			;set expression registers
	mov	#symbol,r1
	mov	#sector,r2
	mov	#mode,r3
	mov	#value,r4
	return
savreg::			;save registers
	mov	r3,-(sp)
	mov	r2,-(sp)
	mov	r1,-(sp)
	mov	6.(sp),-(sp)	;place return address on top
	mov	r4,8.(sp)
	call	tststk		;test stack
	call	@(sp)+		;return the call
	mov	(sp)+,r1	;restore registers
	mov	(sp)+,r2
	mov	(sp)+,r3
	mov	(sp)+,r4
	tst	r0		;set condition codes
	return
	.rept	maxxmt-7
	mov	(r1)+,(r2)+	;pad to max needed
	.endr
xmit7::	mov	(r1)+,(r2)+	;move vector
xmit6::	mov	(r1)+,(r2)+	;
xmit5::	mov	(r1)+,(r2)+	;
xmit4::	mov	(r1)+,(r2)+	;
xmit3::	mov	(r1)+,(r2)+	;
xmit2::	mov	(r1)+,(r2)+	;
xmit1::	mov	(r1)+,(r2)+	;
xmit0::	return			;
movbyt::			;move byte string
1$:	movb	(r1)+,(r2)+	;move one
	bne	1$		;loop if non-null
	tstb	-(r2)		;end, point back to null
	return
opcerr::	error	o;op-code error			;**-9
	return
	.end
