	.psect	.text.,con,shr
	.title	asgmt								;**new**
	.ident	/01/								;**new**
										;**new**
;										;**new**
; copyright 1972, digital equipment corp., maynard, mass 01754			;**new**
; copyright 1973, digital equipment corp., maynard, mass 01754			;**new**
;										;**new**
;	dec assumes no responsibility for the					;**new**
;	use or reliability of its software on					;**new**
;	equipment which is not supplied by dec.					;**new**
;										;**new**
; version 01									;**new**
;										;**new**
; b. bowering									;**new**
;										;**new**
;	modified by:								;**new**
;										;**new**
;	d.n. cutler 6-feb-73							;**new**
;										;**new**
;+										;**new**
; **-asgmt-assignment processor							;**new**
; **-asgmtf-alternate entry							;**new**
;										;**new**
;-										;**new**
										;**new**
asgmt::	getnb			;bypass "="					;**new**
	clr	-(sp)		;assume no global definition			;**-1148
	cmp	r5,#ch.equ	;second equal sign?
	bne	10$		;if ne no
	mov	#glbflg,(sp)	;set global definition bit
	getnb			;bypass second equal sign
10$:	mov	#symbol+4,r1	;set address of mode,sector
	mov	-(r1),-(sp)	;stack symbol
	mov	-(r1),-(sp)
	relexp			;get non-external expression
	mov	(sp)+,(r1)+	;restore symbol
	mov	(sp)+,(r1)+
	br	asgmt1		;branch around secondary entry
asgmtf::clr	-(sp)		;clear global definition flag			;**new**
asgmt1:	setpf1			;set listing field				;**-1
	setxpr			;set expression registers
	bit	#err.u,errbts	;any undefined symbols?				;**new**
	bne	20$		;if ne yes					;**new**
	bit	#err.a,errbts	;address error?					;**new**
	beq	30$		;if eq no					;**new**
20$:	clr	(sp)		;clear possible global definition flag		;**new**
	br	40$		;						;**new**
30$:	bis	#defflg,(r3)	;flag as defined				;**new**
40$:	mov	(r3),-(sp)	;stack flags and value				;**new**
	mov	(r4),-(sp)							;**-4
	ssrch			;search symbol table
	mov	(sp)+,(r4)	;restore value
	bit	#dfgflg,(r3)	;defaulted global from ref?
	beq	11$		;if eq no
	bic	#dfgflg!glbflg,(r3);clear default flags
11$:	bic	#^c<glbflg>,(r3);clear all but global flag
	bis	(sp)+,(r3)
	cmp	(r1),r50dot	;messing with the pc?
	beq	1$		;  yes
	bis	(sp),(r3)	;merge possible global definition bit
	insert			;insert new value
	br	3$		;
1$:	cmpb	(r2),clcsec	;same sector?
	bne	2$		;  no, error
	mov	(r4),clcloc	;yes, set new location
	br	3$		;
2$:	error	m
3$:	tst	(sp)+		;clean stack
	crfdef
	return
	.end									;**new**
