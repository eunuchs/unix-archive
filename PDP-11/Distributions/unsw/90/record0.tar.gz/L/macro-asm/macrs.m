	.psect	.text.,con,shr
	.title	macrs
	.ident	/d02/
; abstracted from rsx base level 02
;
; copyright 1972, digital equipment corp., maynard, mass 01754
; copyright 1973, digital equipment corp., maynard, mass 01754
;
;	dec assumes no responsibility for the
;	use or reliability of its software on
;	equipment which is not supplied by dec.
;
; version 02
;
; b. bowering
;
;	modified by:
;
;	d.n. cutler 6-feb-73
;	d. knight 25-may-73 -- dos changes
;
;
; equated symbols
;
	.if ndf	xmacro
mt.rpt=	177601
mt.irp=	177602
mt.mac==177603
mt.max==177603
;+
; **-rept-repeat handler
; **-endmac-end of macro processing
; **-endm-end of macro
; **-endr-end of repeat
;-
rept::	absexp			;evalute expression
	mov	r0,-(sp)	;save count
	setpf1			;mark the listing
	call	getblk		;get a storage block
	clr	(r2)+		;start in third word
	clr	-(sp)		;no arguments
	mov	r0,-(sp)	;  and start of block
	call	endlin		;polish off line
	zap	dmarol		;no dummy args for repeat
	call	promt		;use macro stuff
	mov	#mt.rpt,r5	;fudge an "end of repeat"
reptf:	call	wcimt
	call	mpush		;push previous macro block
	mov	(sp)+,(r2)+	;store text pointer
	mov	(sp)+,(r2)+	;store arg pointer
	clr	(r2)+		;counter
	mov	(sp)+,(r2)+	;max
	setchr			;restore character
endmac::mov	#msbcnt,r0	;set pointer to count
	inc	(r0)		;bump it
	cmp	(r0)+,(r0)+	;through?
	bgt	1$		;  yes
	mov	msbtxt,(r0)	;no, set read pointer
	add	#4,(r0)		;bypass link
	return
1$:	clr	cndmex		;clear mexit flag
	jmp	mpop
endm::				;ref label
endr:					;ref label
opcerr:	error	o
	return
;+
; **-macro-macro definition
; **-macr-macro definition
; **-macroc-macro call
;-
macro:				;ref label
macr::	gsarg			;get the macro name
	beq	opcerr		;  error if null
macrof:	tstarg			;bypass possible comma
	mov	symbol,macnam
	mov	symbol+2,macnam+2
	msrch			;search the table
	mov	(r4),r0		;get the pointer
	beq	1$		;branch if null
	call	decmac		;decrement the reference
1$:	call	getblk		;get a storage block
	mov	r0,-(sp)	;save pointer
	msrch			;getblk might have moved things
	mov	(sp)+,(r4)	;set pointer
	insert			;insert in table
	crfdef
	call	proma		;process dummy args
	clr	(r2)+		;clear level count
	mov	argcnt,(r2)+	;keep number of args
	mov	macgsb,(r2)+	;  and generated symbol bits
	bis	#lc.md,lcflag
	call	endlin		;polish off line
	call	promt		;process the text
	getsym
	beq	3$
	cmp	r0,macnam
	bne	2$
	cmp	symbol+2,macnam+2
	beq	3$
2$:	error	a
3$:	mov	#mt.mac,r5
	call	wcimt		;set end marker
	setchr
	return
macroc::setpf0			;mark location
	mov	value,r0	;get block pointer
	beq	opcerr		;  error if null
	mov	r0,-(sp)
	call	incmac		;increment reference
	cmp	(r0)+,(r0)+	;move up a couple of slots
	mov	(r0)+,argmax	;set number of args
	mov	(r0)+,macgsb	;  and generated symbol bits
	mov	r0,-(sp)	;save pointer
	call	promc		;process call arguments
	mov	r0,r3		;save block pointer
	mov	#mt.mac,r5
	call	mpush		;push nesting level
	mov	(sp)+,msbmrp
	mov	(sp)+,(r2)+	;set text pointer
	mov	r3,(r2)+	;  and argument pointer
	mov	argcnt,(r2)	;fill in argument count
	mov	(r2)+,(r2)+	;  and replecate
	setchr
	return
;+
; **-irpc-indefinite repeat character
; **-irp-indefinite repeat
;-
irpc::	inc	r3		;set character flag
irp::	call	gmarg		;get macro argument
	beq	1$
	call	proma
	call	rmarg
	call	gmarg
	beq	1$
	mov	#177777,argmax	;any number of arguments
	call	promcf
	mov	r0,r3
	call	rmarg
	call	getblk
	clr	(r2)+
	mov	argcnt,-(sp)
	mov	r3,-(sp)
	mov	r0,-(sp)
	call	endlin
	call	promt
	mov	#mt.irp,r5
	jmp	reptf
1$:	error	a
	return
;+
; internal subroutines
;-
proma:	zap	dmarol		;clear dummy argument roll
	clr	argcnt		;get a fresh start with arguments
	clr	macgsb		;clear generated bit pattern
	mov	#100000,-(sp)	;stack first generated symbol bit
1$:	tstarg			;any more args?
	beq	3$		;  no, quit and go home
	cmp	#ch.qm,r5	;yes, generated type?
	bne	2$		;  no
	bis	(sp),macgsb	;yes, set proper bit
	getnb			;bypass it
2$:	call	gsargf		;get symbolic argument
	append	dmarol		;append to dma roll
	clc
	ror	(sp)		;shift generated sym bit
	br	1$
3$:	tst	(sp)+		;prune stack
	return
promc:	clr	r3
promcf:	clr	argcnt		;clear argument count
	call	getblk
	mov	r0,-(sp)
	tst	r3
	bne	7$
1$:	cmp	argmax,argcnt
	blos	10$
	tstarg			;bypass any comma
	bne	9$		;ok if non-null
	tst	macgsb		;null, any generated stuff left?
	beq	10$		;  no, through
9$:	cmp	#ch.bsl,r5	; "\"?
	beq	20$		;  yes
	call	gmargf		;get argument
	.if ndf	xedlsb
	tst	r5		;any arguments?
	bne	2$		;  yes
	tst	macgsb		;no, generation requested?
	bmi	30$		;  yes
	.endc
2$:
3$:	call	wcimt
	beq	4$
	getchr
	br	3$
4$:	call	rmarg
5$:	asl	macgsb		;move generation bit over one
	br	1$
6$:	inc	argcnt
	getchr
7$:	call	wcimt
	beq	10$
	clr	r5
	call	wcimt
	br	6$
10$:	com	r5
	call	wcimt
	com	r5
	bit	#lc.mc,lcmask	;macro call suppression?
	beq	12$		;  no
	mov	lblend,r0	;yes, have we a label?
	beq	11$		;  no, suppress entire line
	mov	r0,lcendl	;yes, list only label
	br	12$
11$:	bis	#lc.mc,lcflag
12$:	mov	(sp)+,r0
	return
20$:	getnb			; "\", bypass
	absexp			;evaluate expression, abs
	mov	r5,-(sp)	;stack character
	mov	r3,-(sp)
	mov	cradix,r3	;break out in current radix
	mov	r0,r1		;value to r1
	call	40$		;convert to ascii
	clr	r5
	call	wcimt
	mov	(sp)+,r3	;restore regs
	mov	(sp)+,r5
	br	5$
	.if ndf	xedlsb
30$:	inc	lsgbas		;generated symbol, bump count
	mov	lsgbas,r1	;fetch it
	add	#^d<64-1>,r1	;start at 64.
	mov	r5,-(sp)	;stack current char
	mov	r3,-(sp)	;and r3
	mov	#10.,r3		;make it decimal
	call	40$		;convert to ascii
	mov	#ch.dol,r5
	call	wcimt		;write "$"
	clr	r5
	call	wcimt
	mov	(sp)+,r3	;restore regs
	mov	(sp)+,r5
	br	4$		;return
	.endc
40$:	clr	r0		;macro number convertor
	div	r3,r0
	mov	r1,-(sp)	;stack remainder
	mov	r0,r1		;set new number
	beq	41$		;down to zero?
	call	40$		;  no, recurse
41$:	mov	(sp)+,r5		;get number
	add	#dig.0,r5	;convert to ascii
	jmp	wcimt		;write in tree and exit
promt:	clr	r3		;
1$:	inc	getflg		;inhibit file crossing
	call	getlin		;get next line
	dec	getflg		;enable file crossing
	tst	r0		;test getlin return status
	bne	2$
	bis	#lc.md,lcflag
	call	setcli
	bit	#dflmac,r0
	beq	63$
	inc	r3
	cmp	@(pc)+,(pc)+	;.endm or .endr?
	.word	symbol		;
	.rad50	/.en/		;
	bne	3$
	sub	#2,r3		;reduce level count
	bpl	3$
2$:	return
63$:
	.if ndf	xsml
	tst	smllvl		;in system macro?
	beq	3$		;  no
	bit	#dflsmc,r0	;yes, nested?
	beq	3$		;  no
	call	smltst		;yes, test for more
	.endc
3$:	mov	#linbuf,chrpnt
	setchr
4$:	getsym
	beq	7$
	scan	dmarol
	mov	r0,r4
	beq	5$
	mov	rolupd,r5
	neg	r5
	dec	concnt
	call	wcimt
	dec	concnt
5$:	setsym
6$:	tst	r4
	bne	61$
	call	wcimt
61$:	getr50
	bgt	6$
7$:	cmp	r5,#ch.xcl
	beq	8$
	call	wcimt
	bne	9$
	call	endlin
	br	1$
8$:	inc	concnt
9$:	getchr
	br	4$
;+
; **-mexit-exit from macro
;-
mexit::	mov	maclvl,cndmex	;in macro?
	bne	1$		;  yes, pop
	error	o		;  no, error
1$:	return
;+
; internal subroutines
;-
wcimt:	dec	concnt		;any concatenated chars pending?
	bmi	1$		;  no
	mov	r5,-(sp)	;yes, stack current character
	mov	#ch.xcl,r5
	call	2$
	mov	(sp)+,r5
	br	wcimt
1$:	clr	concnt
2$:	bit	#bpmb-1,r2	;room in this block?
	bne	3$		;  yes
	sub	#bpmb,r2	;no, point to link
	mov	r2,-(sp)
	call	getblk
	mov	r0,@(sp)+	;set new link
3$:	movb	r5,(r2)+	;write, leaving flags set
	return
getblk:	mov	macnxt,r0	;test for block in garbage
	bne	1$		;  yes, use it
	append	mabrol		;no, get block in roll
	mov	basmab,r0	;get start
	mov	r0,topmab	;zap mab roll
	mov	r0,basmaa	;award space to maa
	br	2$
1$:	mov	(r0),macnxt	;set new chain
2$:	mov	r0,r2
	clr	(r2)+		;clear link cell, point past it
	return
incmac:	inc	2(r0)		;increment macro reference
	return
decmac:	dec	2(r0)		;decrement macro storage
	bpl	remmax		;just exit if non-negative
remmac:	mov	r0,-(sp)	;save pointer
1$:	tst	(r0)		;end of chain?
	beq	2$		;  yes
	mov	(r0),r0		;no, link
	br	1$
2$:	mov	macnxt,(r0)
	mov	(sp)+,macnxt
remmax:	return
mpush:	call	getblk		;get a storage block
	tst	-(r2)		;point to start
	mov	#msbblk,r1	;pointer to start of prototype
	mov	r2,-(sp)	;save destination
	mov	r1,-(sp)	;  and core pointers
1$:	mov	(r1),(r2)+	;xfer an item
	clr	(r1)+		;clear core slot
	cmp	#msbend,r1	;through?
	bne	1$		;  no
	mov	(sp)+,r2	;yes, make core destination
	mov	r5,(r2)+	;save type
	mov	(sp)+,(r2)+	;  and previous block pointer
	inc	maclvl		;bump level count
	return			;return with r2 pointing at msbtxt
mpop:	mov	#msbarg+2,r2	;point one slot past argument
	mov	-(r2),r0	;get pointer to arg block
	beq	1$		;branch if null
	call	remmac		;remove it
1$:	mov	-(r2),r0	;point to text block
	beq	2$		;branch if null
	call	decmac		;decrement level
2$:	mov	-(r2),r1	;get previous block
	tst	-(r2)		;point to start
	mov	r1,r0		;save block pointer
	mov	#xmit0,-(sp)	;get base of move vector
	sub	#msblgh,(sp)	;calculate move address
	call	@(sp)+		;move block
	clr	(r0)		;clear link
	call	remmac		;return block for deposit
	dec	maclvl		;decrement level count
	return
;+
; **-mcall-macro library call
;-
	.if ndf	xsml
mcall::	call	smltst		;test for undefined arguments
	beq	5$		;  branch if none
	tst	pass		;found some, pass one?
	bne	4$		;  no, error
1$:	call	inisml		;get another file
	beq	4$		;  error if none
2$:	clr	r3		;set count to zero
3$:	call	getlin		;get a new line
	bne	1$		;try another file if eof
	call	setcli		;test for directive
	bit	#dflmac,r0	;macro/endm?
	beq	3$		;  no
	mov	#value,r4	;set for local and macrof
	dec	r3		;yes, assume .endm
	cmp	@(pc)+,(pc)+	;.endm or .endr?
	.word	symbol		;
	.rad50	/.en/		;
	beq	3$		;  yes
	add	#2,r3		;bump level count
	cmp	#1,r3		;outer level?
	bne	3$		;  no
	gsarg			;yes, get name
	beq	4$		;  error if null
	msrch			;search table
	beq	3$		;ignore if not there
	tst	(r4)		;found, value of zero?
	bne	3$		;  no, not interested
	call	macrof		;good, define it
	dec	smllvl		;decrement count
	bgt	2$		;loop if more to go
	br	5$		;ok, clean up
4$:	error	u
5$:	clr	smllvl		;make sure count is zapped
	clr	endflg		;ditto for end flag
	jmp	finsml		;be sure files are closed
smltst:	gsarg			;fetch next argument
	beq	3$		;  exit if through
	msrch			;ok, test for macros
	bne	2$		;  found, not interested
	insert			;insert with zero pointer
	inc	smllvl		;bump count
2$:	crfdef			;cref it
	br	smltst		;
3$:	mov	smllvl,r0	;finished, count to r0
	return
	.endc
	.endc
	.end
