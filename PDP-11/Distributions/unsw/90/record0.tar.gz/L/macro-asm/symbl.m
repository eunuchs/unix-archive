	.psect	.text.,con,shr
	.title	symbl
	.ident	/d02/								;**new**
										;**-1
;
; copyright 1972, digital equipment corp., maynard, mass 01754
; copyright 1973, digital equipment corp., maynard, mass 01754
;
;	dec assumes no responsibility for the
;	use or reliability of its software on
;	equipment which is not supplied by dec.
;
; version 02									;**new**
;										;**-1
; b. bowering
;
;	modified by:
;
;	d.n. cutler 10-feb-73
;	d. knight 25-may-73 -- dos changes
;
;+
; **-dnc-decimal number conversion
; **-dncf-alternate entry for another base
;-										;**-1
dnc::	mov	#10.,r3		;set divisor
dncf:	clr	r0		;clear high part of dividend
	div	r3,r0		;divide r1
	mov	r1,-(sp)	;save remainder
	mov	r0,r1		;set for next divide
	beq	1$		;  unless zero
	call	dncf		;recurse
1$:	mov	(sp)+,r1	;retrieve number
	add	#dig.0,r1	;convert to ascii
	movb	r1,(r2)+	;store
	return
										;**-26
;+
; **-div-software divide
; **-mul-software multilpy
;-
	.if ndf	pdpv45
div::	mov	#16.,-(sp)	;set loop count
	clr	-(sp)		;result
1$:	asl	(sp)		;shift result
	asl	r1		;shift work registers
	rol	r0		;  double register
	cmp	r0,r3		;big enough for operation?
	blt	2$		;  no
	sub	r3,r0		;yes
	inc	(sp)		;bump result
2$:	dec	2(sp)		;test for end
	bne	1$
	mov	r0,r1		;place remainder in r1
	mov	(sp)+,r0	;result to r0
divxit:	tst	(sp)+		;prune stack
	return
mul::	mov	r0,-(sp)	;get first number
	clr	r0		;clear results
	clr	r1
1$:	tst	(sp)		;through?
	beq	divxit		;  yes
	ror	(sp)
	bcc	2$
	add	r3,r1
	adc	r0
2$:	asl	r3
	br	1$
	.endc
;+
; **-getsym-get symbol
; **-mulr50-multiply rad50
; **-getr50-get rad50 character
; **-setr50-set rad50 character
; **-tstr50-test rad50 character
;-
getsym::savreg			;save registers
	mov	chrpnt,symbeg	;save in case of rescan
	mov	#symbol+4,r1
	clr	-(r1)
	clr	-(r1)
	bitb	cttbl(r5),#ct.alp	;alpha?
	beq	5$		;  no, exit false
	mov	#26455,r2
	setr50
1$:	call	mulr50
2$:	asr	r2
	bcs	1$
	add	r0,(r1)
3$:	getr50
	ble	4$
	asr	r2
	bcs	2$
	beq	3$
	tst	(r1)+
	br	1$
4$:	setnb
5$:	mov	symbol,r0
	return
mulr50::imuli	50,r0		;multilpy r0*50
	return
getr50::getchr			;get next character
setr50:	mov	r5,r0		;
tstr50::bitb	#ct.alp!ct.num!ct.sp,cttbl(r0);alpha, number or space?
	beq	1$		;  no, exit minus
	cmp	r0,#ch.dol	;yes, try dollar
	blo	2$		;space
	beq	3$		;dollar
	cmp	r0,#let.a
	blo	4$		;dot or digit
	br	5$		;alpha
1$:	mov	#100000+space,r0	;invalid, force minus
2$:	sub	#space-11,r0	;space
3$:	sub	#11-22,r0	;dollar
4$:	sub	#22-100,r0	;dot, digit
5$:	sub	#100,r0		;alphabetic
	return
;+
; **-cvtnum-convert text to numeric
;
; inputs:
;
;	r2=radix.
;
; outputs:
;
;	high bit of r0=overflow flag.
;	high byte of r0=character count.
;	low byte of r0=oversize count.
;-
cvtnum::savreg			;save registers
	clr	r0		;result flag register
	clr	r1		;numeric accumulator
	mov	chrpnt,symbeg	;save for rescan
1$:	mov	r5,r3		;get a copy of the current char
	sub	#dig.0,r3	;convert to absolute
	cmp	r3,#9.		;numeric?
	bhi	9$		;  no, we're through
	cmp	r3,r2		;yes, less than radix?
	blo	2$		;  yes
	inc	r0		;no, bump "n" error count
2$:
	.if ndf	pdpv45
	mov	r2,r4		;copy of current radix
	clr	-(sp)		;temp ac
3$:	asr	r4		;shift radix
	bcc	4$		;branch if no accumulation
	add	r1,(sp)		;add in
4$:	tst	r4		;any more bits to process?
	beq	5$		;  no
	asl	r1		;yes, shift pattern
	bcc	3$		;branch if no overflow
	bis	#100000,r0	;oh, oh.  flag it
	br	3$
5$:	mov	(sp)+,r1	;set new number
	.iff
	mul	r2,r1
	.endc
	add	r3,r1		;add in current number
	getchr			;get another character
	add	#000400,r0	;tally character count
	br	1$
9$:	mov	r1,value	;return  result in "value"
	return			;return, testing r0
;+
; **-gsarg-get symbolic argument
; **-gsargf-alternate entry
; **-tstarg-test for symbolic argument
;-
gsarg::	.enabl	lsb		;
	tstarg			;test general
	beq	2$		;  exit null
gsargf::getsym			;get a symbol
	beq	1$		;  error if not symbol
	cmp	r0,r50dot	;  "."?
	bne	2$		;  no, ok
1$:	error	a
	clr	r0		;treat all errors as null
2$:	return
	.dsabl	lsb
tstarg::movb	cttbl(r5),r0	;get characteristics
	ble	12$		;through if eol or semi-colon
	tst	argcnt		;first argument?
	beq	11$		;  yes, good as is
	bit	#ct.com,r0	;no, comma?
	bne	10$		;  yes, bypass it
	tst	expflg		;no, was one required?
	beq	2$		;  no
	error	a		;yes, flag error
2$:	cmp	chrpnt,argpnt	;did anybody use anything?
	bne	11$		;  yes, ok
3$:	getchr			;no, bypass to avoid loops
	bitb	#ct.pc+ct.sp+ct.tab-ct.com-ct.smc,cttbl(r5)
	bne	3$		;  yes, bypass
	setnb			;no, set to non-blank
	error	a		;flag error
	br	tstarg		;try again
10$:	getnb			;bypass comma
11$:	inc	argcnt		;increment argument count
12$:	clr	expflg
	mov	chrpnt,argpnt	;save pointer
	bic	#177600,r0	;set flags
	return
;+
; **-setsym-set symbol for rescan
; **-getnb-get nonblank character
; **-setnb-set nonblank character
; **-getchr-get character
; **-setchr-set character
; **-chscan-scan by character
;-
setsym::mov	symbeg,chrpnt	;reset pointer
	br	setchr		;set character and flags
getnb::	inc	chrpnt		;bump pointer
setnb::	setchr			;set registers and flags
	bitb	#ct.sp!ct.tab,cttbl(r5)	;blank?
	bne	getnb		;  yes, bypass
	br	setchr		;exit, setting flags
getchr::inc	chrpnt		;bump pointer
setchr::movb	@chrpnt,r5	;set registers and flags
	.if ndf	xedlc
	bpl	1$		;ok if no sign bit
	sub	#177600+40,r5	;try for lower case map
	.endc
	bmi	getchr		;loop if invalid character
1$:	return
chscan::tst	(r0)+		;end?
	beq	2$		;  yes
	cmp	(r0)+,r5	;this the one?
	bne	chscan		;if ne no
	tst	-(r0)		;yes, move pointer back
	mov	chrpnt,symbeg	;save current pointer
	getnb			;get next non-blank
2$:	mov	-(r0),r0	;move addr or zero into r0
	return
;										;**-68
; character classification definitions
;
ct.eol=000			;end of line
ct.com==001			;comma
ct.tab=002			;tab
ct.sp=004			;space
ct.pcx=010			;printing character
ct.num==020			;number
ct.alp==040			;alphabetic, dot, or dollar
ct.lc==100			;lower case alphabetic
ct.smc==200			;semicolon
ct.pc==ct.com!ct.smc!ct.pcx!ct.num!ct.alp;printing characters
ct.spt==ct.sp!ct.tab		;space or tab
	.macro	genctt	arg	;generate character type table
	.irp	a,	<arg>
	.byte	ct.'a
	.endm
	.endm
	.psect	dpure,prv,con 
cttbl::				;ref label
	genctt	<eol, eol, eol, eol, eol, eol, eol, eol>
	genctt	<eol, tab, eol, eol, eol, eol, eol, eol>
	genctt	<eol, eol, eol, eol, eol, eol, eol, eol>
	genctt	<eol, eol, eol, eol, eol, eol, eol, eol>
	genctt	<sp , pcx, pcx, pcx, alp, pcx, pcx, pcx>
	genctt	<pcx, pcx, pcx, pcx, com, pcx, alp, pcx>
	genctt	<num, num, num, num, num, num, num, num>
	genctt	<num, num, pcx, smc, pcx, pcx, pcx, pcx>
	genctt	<pcx, alp, alp, alp, alp, alp, alp, alp>
	genctt	<alp, alp, alp, alp, alp, alp, alp, alp>
	genctt	<alp, alp, alp, alp, alp, alp, alp, alp>
	genctt	<alp, alp, alp, pcx, pcx, pcx, pcx, pcx>
	genctt	<eol, lc , lc , lc , lc , lc , lc , lc >
	genctt	<lc , lc , lc , lc , lc , lc , lc , lc >
	genctt	<lc , lc , lc , lc , lc , lc , lc , lc >
	genctt	<lc , lc , lc , eol, eol, eol, eol, eol>
	.psect	implin,prv,gbl,con 
argcnt::.blkw	1		;argument count
argpnt:	.blkw	1		;start of last argument
expflg::.blkw	1		;set when comma required
	.psect	.text.,con,shr
	.end
