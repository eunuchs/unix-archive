#
/*
 * cross referencer for link output
 */
#define max 100
struct {
	char ref[6];
	char flag;
} buffer[max];

char name[6];
char ref[6];
char flag;
char old[6];

main()
{
	int i;
	i = 0;

	getrec();
	copy(name,old);
	goto loop;
	while (getrec()) {
loop:
		if (eq(name,old)) {
			copy(ref,buffer[i].ref);
			buffer[i].flag = flag;
			i++;
			continue;
		}
		if(i) {
			printf("%.6s: ",old);
			dump(i);
		}
		copy(name,old);
		i = 0;
		goto loop;
	}
	printf("%.6s: ",old);
	dump(i);
}

getrec()
{
	int i;

	for (i = 0; i < 6; i++)
		if(read(0,name+i,1)) continue;
		else return(0);
	read(0,&i,1);
	for (i = 0; i < 6; i++)
		if (read(0,ref+i,1)) continue;
		else return(0);
	read(0,&flag,1);
loop:	read(0,&i,1);
	if (i != '\n') goto loop;
	return(1);
}

eq(s1,s2)
	char *s1,*s2;
{
	int i,ans;

	ans = 1;
	for (i = 0; i<6; i++)
		if (s1[i] != s2[i]) ans = 0;
	return(ans);
}

copy(s1,s2)
	char *s1,*s2;
{
	int i;

	for (i=0; i<6; i++)
		s2[i] = s1[i];
}

dump(i)
{
	int j;
	int k;
	j = 0;
	for (k = 0; k<i; k++) {
		putchar(buffer[k].flag);
		printf("%.6s ",buffer[k].ref);
		if ((j++ & 7) == 7)
			printf("\n	");
	}
	putchar('\n');
	putchar('\n');
}
