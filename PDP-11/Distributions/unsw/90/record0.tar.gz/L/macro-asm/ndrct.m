	.psect	.text.,con,shr
	.title	ndrct								;**new**
	.ident	/01/								;**new**
										;**new**
;										;**new**
; copyright 1972, digital equipment corp., maynard, mass 01754			;**new**
; copyright 1973, digital equipment corp., maynard, mass 01754			;**new**
;										;**new**
;	dec assumes no responsibility for the					;**new**
;	use or reliability of its software on					;**new**
;	equipment which is not supplied by dec.					;**new**
;										;**new**
; version 01									;**new**
;										;**new**
; b. bowering									;**new**
;										;**new**
;	modified by:								;**new**
;										;**new**
;	d.n. cutler 10-feb-73							;**new**
;										;**new**
;+										;**new**
; **-narg-number of arguments							;**new**
; **-nchr-number of characters							;**new**
; **-ntype-type of expression							;**new**
;-										;**new**
										;**new**
	.if ndf	xmacro								;**new**
narg::	call	gsarg		;get symbolic argument				;**new**
	beq	ntyper		;error if missing				;**-4428
	mov	msbcnt+2,r3	;set number
	br	ntypex
nchr::	call	gsarg		;get symbolic argument				;**new**
	beq	ntyper		;  error id no symbol				;**-2
	call	gmarg		;isolate argument
	beq	ntypex		;  zero if null
	tst	r5		;quick test for completion
	beq	2$		;  yes
1$:	inc	r3		;bump count
	getchr			;get the next character
	bne	1$		;loop if not end
2$:	call	rmarg		;remove arg delimiters
	br	ntypex
ntype::	call	gsarg		;get symbolic argument				;**new**
	beq	ntyper		;  error					;**-2
	tstarg			;bypass any commas
	mov	#symbol,r1
	mov	(r1)+,-(sp)	;preserve symbol
	mov	(r1)+,-(sp)
	call	aexp		;evaluate
	mov	r0,r3		;set result
	zap	codrol		;clear any generated code
	mov	(sp)+,-(r1)	;restore symbol
	mov	(sp)+,-(r1)
ntypex:	clr	mode		;clear mode
	mov	r3,value	;  and set value
	jmp	asgmtf		;exit through assignment
ntyper:	error	a
	br	ntypex
	.endc									;**new**
										;**new**
	.end									;**new**
