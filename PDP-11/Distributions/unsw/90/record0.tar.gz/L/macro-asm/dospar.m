	.psect	.text.,con,shr
	.iif ndf mcexec , .nlist
narrow=0		;default listing size is narrow
yphase=0
	.iif ndf mcexec , .list
xrun=0
xcref=0
xbaw=0
xsml=0
xtime= 0
