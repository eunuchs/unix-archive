	.psect	.text.,con,shr
	.title	lstng
	.ident	/d05/
;abstracted from rsx version 03
										;**-1
;
; copyright 1972, digital equipment corp., maynard, mass 01754
; copyright 1973, digital equipment corp., maynard, mass 01754
;
;	dec assumes no responsibility for the
;	use or reliability of its software on
;	equipment which is not supplied by dec.
;
; version 02; version 03
;										;**-1
; b. bowering
;
;	modified by:
;
;	d.n. cutler 6-feb-73
;	d. knight 25-may-73
;
;+
; **-setpf0-set print field zero
; **-setpf1-set print field one
; **-setwdb=set word or byte
; **-setwrd-set word
; **-setbyt-set byte
;-
setpf0::mov	clcfgs,pf0	;set current location flags
	bisb	#100,pf0+1	;assume word
	mov	clcloc,pf0+2	;set location
	return
setpf1::mov	mode,pf1	;set mode of current value
	bisb	#100,pf1+1	;assume word
	mov	value,pf1+2
	return
setwdb::tst	(r1)		;positive?
	bmi	setbyt		;  no, byte
setwrd::mov	r1,-(sp)	;stack index
	mov	2(r1),r1	;get actual value
	movb	#dig.0/2,(r2)	;set primitive
	asl	r1
	rolb	(r2)+		;move in bit
	mov	#5,r0
	br	setbyx
setbyt::mov	r1,-(sp)	;stack index
	movb	2(r1),r1	;get value
	mov	#space,r0
	movb	r0,(r2)+	;pad with spaces
	movb	r0,(r2)+
	movb	r0,(r2)+
	swab	r1		;manipulate to left half
	rorb	r1		;get the last guy
	clc
	ror	r1
	mov	#3,r0
setbyx:	swab	r0
	add	#3,r0
	movb	#dig.0/10,(r2)
1$:	asl	r1
	rolb	(r2)
	decb	r0
	bgt	1$
	tstb	(r2)+
	swab	r0
	sob	r0,setbyx
	mov	(sp)+,r1
	return
	.psect	implin,prv,gbl,con 
pf0::	.blkw	2		;
pf1::	.blkw	2		;
	.psect	.text.,con,shr
;+
; **-putkb-list on kb
; **-putlp-list on lp
; **-putkbl-list on kb and lp
; **-putlin-output line
;-
putkb::	mov	#lst.kb,lstreq	;set request					;**-3
	br	putlin
putkbl:	mov	#lst.kb,lstreq	;set request
putlp::	bisb	lstdev,lstreq	;set lp request
putlin::savreg			;save registers
	mov	r0,r1		;arg to r1
	movb	lstreq,r4	;get request
	clr	lstreq		;clear it
	tst	r4
	beq	putli9		;just exit if empty
	bgt	putli2		;omit header if not listing
	dec	lppcnt		;yes, decrement count
	bgt	putli2		;skip if not time
putli1:	mov	#lpp,lppcnt	;reset count
	mov	r1,-(sp)	;stack current pointer
	mov	ttlbrk,r2	;get end of preset title
	tst	pass
	beq	11$
	mov	#pagmne,r1
	movbyt			;move "page" into position
	mov	pagnum,r1
	dnc			;convert to decimal
	inc	pagext
	beq	11$
	movb	#'-,(r2)+	;set separator					;**new**
	mov	pagext,r1	;get current page extension number		;**new**
	dnc			;convert to decimal				;**new**
11$:	clrb	(r2)								;**-1
	putlp	#ttlbuf		;print title
	putlp	#stlbuf		;  sub-title,
	putlp	#crlf		;  and a blank line
	$wait	lst
	movb	#ff,defstr	;reset page character
	movb	defstr,ttlbuf
	mov	(sp)+,r1
putli2:	$wait	lst		;wait on previous output
	mov	buftbl+lstchn,r2	;set destination index
	mov	r2,r3		;save a copy
21$:	movb	(r1)+,(r2)+	;move character to output buffer
	bgt	21$		;loop if nothing special
	movb	-(r2),r0	;special, back up and set r0
	beq	22$		;end if null
	.if ndf	xedlc
	bicb	#200,-(r1)	;clear sign bit in source
	bne	21$		;re-store if lower case
	movb	#ch.qm,(r1)	;must be error
	.iff
	movb	#ch.qm,-(r1)	;illegal char, set "?"
	.endc
	br	21$
22$:	cmp	r2,r3		;at beginning?
	beq	24$		;  yes, don't retreat
	movb	-(r2),r0	;fetch preceding char
	bitb	#ct.spt,cttbl(r0);space or tab?
	bne	22$		;  yes, trim it
	cmpb	#vt,(r2)+	;move to end, a vt?
	beq	23$		;  yes, no cr/lf
24$:	movb	#cr,(r2)+	;stuff cr
	movb	#lf,(r2)+	;set lf
23$:	sub	r3,r2		;compute character count
	mov	r2,@cnttbl+lstchn	;set count
	asr	r4		;kb requested?
	bcc	25$		;  no
	$writw	cmo		;type the line
25$:	asr	r4		;listing requested?
	bcc	putli9		;  no
	$write	lst		;list it
putli9:	return
	.psect	impure,prv,con 
lstreq::.blkw	1		;list request flags
lstdev::.blkb	2		;error(lh), listing (rh)
	.psect	txtbyt,prv,con 
pagmne:	.ascii	/ page /	;
crlf:	.asciz	//		;
	.psect	.text.,con,shr
;+
; **-crfdef-cref definition
; **-crfref-cref reference
;-
	.if ndf	xcref
crfdef::incb	crfdfl		;cref definition
crfref::tst	crfpnt		;any cref output at this time?
	beq	9$		;  no
	savreg
	mov	crfpnt,r2	;preset buffer pointer
	tst	crfver		;version number sent yet?
	bne	1$		;  yes
	mov	#cr.ver,r1
	mov	r1,crfver	;set flag
	call	crftst		;test and deposit
	swab	r1
	movb	r1,(r2)+	;stuff version number
1$:	cmp	crfpag,pagnum	;new page?
	bhis	2$		;  no
	mov	#cr.pag,r1	;yes, send flag
	call	crftst
	inc	crfpag
	clr	crflin
	br	1$
2$:	cmp	crflin,linnum	;new line number?
	bhis	3$		;  no
	mov	#cr.lin,r1
	call	crftst
	inc	crflin
	br	2$
3$:	mov	#crftyp,r1
	mov	crfflg,r0
4$:	asr	r0
	cmpb	rolndx,(r1)+	;map roll number to cref type
	bne	4$
	asr	r0
	bcc	8$
	sub	#crftyp+1-cr.sym,r1
	call	crftst
	r50unp
5$:	cmpb	#space,-(r2)	;trim trailing blanks
	beq	5$
	tstb	(r2)+
	mov	crfdfl,r1	;set "#" bit
	bpl	6$		;branch if no "*"
	bis	#2,r1
6$:	bis	#cr.sym,r1	;set terminator
	movb	r1,(r2)+
8$:	mov	r2,crfpnt	;store new pointer
9$:	clrb	crfdfl
	return
cr.ver=	001+<001*400>		;type 1, version #1
cr.pag=	002			;new page
cr.lin=	003			;new line
cr.sym=	020			;symbol
errrol==1			;dummy roll
										;**new**
	.psect	impure,prv,con 
crfver:	.blkw	1		;version flag
crfpag:	.blkw	1		;
crflin:	.blkw	1		;
	.psect	implin,prv,gbl,con 
crfdfl::.blkb	2		;"#" and #*" flags
	.psect	txtbyt,prv,con 
crftyp:
	.byte	symrol
	.if ndf	xmacro
	.byte	macrol
	.iff
	.byte	-1
	.endc
	.byte	pstrol
	.byte	secrol
	.byte	errrol
	.psect	.text.,con,shr
	.endc
	.end
