	.psect	.text.,con,shr
	.title	rolhd								;**new**
	.ident	/d02/								;**new**
										;**new**
;										;**new**
; copyright 1972, digital equipment corp., maynard, mass 01754			;**new**
; copyright 1973, digital equipment corp., maynard, mass 01754			;**new**
;										;**new**
;	dec assumes no responsibility for the					;**new**
;	use or reliability of its software on					;**new**
;	equipment which is not supplied by dec.					;**new**
;										;**new**
; version 01									;**new**
;										;**new**
; b. bowering									;**new**
;										;**new**
;	modified by:								;**new**
;										;**new**
;	d.n. cutler 10-feb-73							;**new**
;	d. knight 25-may-73 -- dos changes
;
;+										;**new**
; **-ssrch-symbol roll search							;**new**
; **-osrch-op-code roll search							;**new**
; **-msrch-macro roll search							;**new**
; **-lsrch-local symbol roll search						;**new**
; **-search-binary search roll							;**new**
; **-next-get next entry in roll						;**new**
; **-scanw-scan roll by first word						;**new**
; **-scan-scan roll								;**new**
; **-append-append to roll							;**new**
; **-insert-insert in roll							;**new**
; **-zap-clear roll								;**new**
; **-setrol-set roll registers							;**new**
;-										;**new**
										;**new**
ssrch::	search	symrol		;search symbol roll				;**new**
	return									;**-3794
osrch::	search	pstrol		;search op-code roll				;**new**
	return									;**-2
	.if ndf	xmacro
msrch::	search	macrol		;search macro roll				;**new**
	return									;**-1
	.endc
	.if ndf	xedlsb
lsrch::	tst	lsyflg		;flag set?					;**new**
	beq	1$		;  no						;**-2
	clr	lsyflg		;yes, clear it
	inc	lsybkn		;bump block number
1$:	mov	#symbol,r0
	mov	lsybkn,(r0)+	;move into "symbol"
	mov	value,(r0)
	bne	3$		;if ne okay
	error	t		;zero flag error
3$:	search	lsyrol		;search the roll
	return
	.psect	imppas,prv,gbl							;**new**,con
lsyflg:	.blkw	1		;bumped at "label::"				;**new**
lsybkn:	.blkw	1		;block number					;**new**
lsybas::.blkw	1		;section base					;**new**
lsgbas::.blkw	1		;base for generated symbols			;**new**
	.psect	.text.,con,shr
										;**-8
	.enabl	lsb
lsbtst::bne	2$		;bypass if /ds					;**new**
	br	1$								;**-1
lsbset::bit	#ed.lsb,edmask	;in lsb override?				;**new**
	beq	2$		;  yes						;**-1
1$:	inc	lsyflg		;flag new block
	mov	clcloc,lsybas	;set new base
	bic	#1,lsybas	;be sure its even
	clr	lsgbas		;clear generated symbol base
2$:	return
	.dsabl	lsb
	.endc
search:	setrol			;binary search					;**new**
	bit	#ed.reg,edmask	;register definition enabled?			;**-2
	bne	10$		;if ne no
	cmp	r5,#symrol	;symbol roll?
	bne	10$		;if ne no
	bit	#7,(r4)		;make ruff ruff test bypass 90%
	bne	10$		;if ne don't check for register
	scan	regrol		;scan register roll
	mov	r5,rolndx	;restore roll index
	tst	r0		;find symbol?
	beq	10$		;if eq no find em
	return			;
10$:	mov	r1,-(sp)	;save roll base
	cmp	r1,r2		;any in roll?
	beq	5$		;if eq no
	sub	r3,r2		;calculate high and low bounds
	mov	r1,r0		;
	bic	#177770,(sp)	;
1$:	mov	r0,r1		;calculate trial index
	add	r2,r1		;
	ror	r1		;halve result
	bic	#7,r1		;clear garbage bits
	bis	(sp),r1		;
	cmp	(r1),(r4)	;compare high parts
	bhi	3$		;if hi set new high limit
	blo	2$		;if lo set new low limit
	cmp	2(r1),2(r4)	;compare low parts
	beq	6$		;if eq hit
	bhi	3$		;if hi set new high limit
2$:	mov	r1,r0		;set new low limit
	add	r3,r0		;reduce by one more
	cmp	r0,r2		;any more to search?
	blos	1$		;if los yes
	add	r3,r1		;point to proper entry
	br	5$		;exit
3$:	mov	r1,r2		;se new high limit
	sub	r3,r2		;reduce by one more
	cmp	r0,r2		;any more to search?
	blos	1$		;if los yes
5$:	clr	r0		;set false flag
6$:	tst	(sp)+		;clean stack
	br	scanx		;vammoosa
next::	setrol			;get next entry					;**new**
	mov	rolupd,r0							;**-5
	add	r0,r1
	add	r3,r0
	cmp	r1,r2
	blo	scanx
	br	scanxf
scanw::	setrol			;scan one word					;**new**
	clr	r0		;assume false					;**-2
1$:	inc	r0		;tally entry count
	cmp	(r4),(r1)	;match?
	beq	scany		;  yes
	add	r3,r1		;no, increment pointer
	cmp	r1,r2		;finished?
	blo	1$		;  no
	clr	r0
	return			;yes, exit false
scan::	setrol			;linear scan					;**new**
	clr	r0		;assume false					;**-2
1$:	cmp	r2,r1		;end?
	beq	scanxf		;  yes, exit false
	inc	r0
	cmp	(r4),(r1)	;no, match on first words?
	bne	2$		;  yes
	cmp	2(r4),2(r1)	;no, how about second?
	beq	scanx		;  yes
2$:	add	r3,r1		;increment by size
	br	1$
	.enabl	lsb
scanxf:	clr	r0		;false exit
scanx:	mov	r1,rolpnt	;set entry pointer
	mov	r0,rolupd	;save flag
	beq	1$		;branch if not found
scany:	mov	r4,r2		;pointer to "symbol"
	neg	r3		;negate entry size
	jmp	xmit0(r3)	;found, xfer arguments
1$:	cmp	(r4)+,(r4)+	;bypass symbol itself
	asr	r3		;get word count
	sub	#2,r3		;compensate for above cmp
	ble	3$		;branch if end
2$:	clr	(r4)+		;clear word
	sob	r3,2$
3$:	return
	.dsabl	lsb
append::setrol			;append to end of roll				;**new**
	mov	r2,rolpnt	;set pointer					;**-2
	clr	rolupd
	br	inserf
insert::call	setrof		;insert in roll					;**new**
inserf:	mov	rolpnt,r0	;points to proper slot				;**new**
	tst	rolupd		;was search true?				;**-3
	bne	5$		;  yes
	incb	rolsiz+1(r5)	;update entry count
	add	r3,roltop(r5)	;update top pointer
	cmp	r2,rolbas+2(r5)	;gap between rolls?
	bne	5$		;  yes, just stuff it
	.if ndf	fixstk
	mov	sp,r1		;"from" address
	sub	r3,sp		;we're about to move stack
	mov	sp,r2		;"to" address
	.iff
	.globl	tstsyt
	call	tstsyt		;test for room
	mov	rolbas,r1	;ditto for separate stack
	mov	r1,r2
	sub	r3,r2
	.iftf
	sub	r1,r0		;compute byte count
	asr	r0		;  now word count
	.iff
	beq	4$		;branch if first time
	.endc
2$:	mov	(r1)+,(r2)+	;move an entry down
	sob	r0,2$
4$:	sub	r3,rolbas(r5)	;decrement pointers
	sub	r3,roltop(r5)
	sub	#2,r5		;more rolls?
	bge	4$		;  yes
	mov	r2,r0		;point to insertion slot
5$:	asr	r3		;halve size count
6$:	mov	(r4)+,(r0)+	;move an entry into place
	sob	r3,6$		;loop if not end
	return
zap::	setrol			;empty a roll					;**new**
	mov	r1,roltop(r5)	;make top = bottom				;**-2
	clrb	rolsiz+1(r5)	;clear entry count
	return
setrol:	mov	r0,rolndx	;set argument					;**new**
setrof:	mov	(sp)+,r0	;save return address				;**new**
	savreg			;save registers					;**-3
	mov	r5,-(sp)	;  and current character
	mov	rolndx,r5	;set index
	mov	rolbas(r5),r1	;current base
	mov	roltop(r5),r2	;current top
	movb	rolsiz(r5),r3	;entry size
	mov	#symbol,r4	;pointer to symbol
	call	(r0)		;call proper routine
	mov	(sp)+,r5	;restore current character
	return			;  and rest of regs
	.psect	impure,prv							;**new**,con
rolndx::.blkw	1		;roll index					;**new**
rolpnt:	.blkw	1		;roll pointer					;**new**
rolupd::.blkw	1		;roll update					;**new**
	.psect	.text.,con,shr
										;**new**
	.end									;**new**
