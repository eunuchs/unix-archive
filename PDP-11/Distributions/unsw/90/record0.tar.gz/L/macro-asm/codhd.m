	.psect	.text.,con,shr
	.title	codhd								;**new**
	.ident	/d01/
										;**new**
;										;**new**
; copyright 1972, digital equipment corp., maynard, mass 01754			;**new**
; copyright 1973, digital equipment corp., maynard, mass 01754			;**new**
;										;**new**
;	dec assumes no responsibility for the					;**new**
;	use or reliability of its software on					;**new**
;	equipment which is not supplied by dec.					;**new**
;										;**new**
; version 02
;										;**new**
; b. bowering									;**new**
;										;**new**
;	modified by:								;**new**
;										;**new**
;	d.n. cutler 6-feb-73							;**new**
;	d. knight 25-may-73 -- dos changes
;
;+										;**new**
; **-stcode-store code								;**new**
; **-pcroll-process code roll							;**new**
;-										;**new**
										;**new**
stcode::append	codrol		;append to code roll				;**new**
	return									;**-2892
pcroll::next	codrol		;get next code roll entry			;**new**
	beq	pcrol3		;  end						;**-2
	savreg
	clr	r5		;assume byte
	clr	r4
	bisb	sector,r4	;get the rld type
	bmi	1$		;branch if byte
	inc	r5		;  word, bump to 1
1$:	tst	pass		;pass one?
	beq	pcrol2		;  yes, just update pc
	inc	pcrcnt		;extension line?
	bmi	2$		;  yes
	setpf0			;list column zero
2$:	setpf1			;set print field one
	aslb	r4		;byte?
	tst	objpnt		;any object code called for?
	beq	pcrol2		;  no
	.if ndf	xedpnc
	bit	#ed.pnc,edmask	;punch disabled?
	bne	pcrol2		;  yes
	.endc
	.if ndf	xrel
	mov	pcrtbl(r4),r4	;get proper table entry
	cmpb	clcsec,objsec	;sector change?
	beq	10$		;  no
	mov	#4*2,r0
	call	tstrld		;soften up rld buffer
	mov	#rldt07,(r2)+	;set rld type 7
	mov	clcnam,(r2)+	;  and new sector name
	mov	clcnam+2,(r2)+
	movb	clcsec,objsec
	br	12$
	.iftf
10$:	cmp	clcloc,objloc	;did pc move on us?
	beq	14$		;  no
	.ift
	mov	#2*2,r0
	call	tstrld		;make room
	mov	#rldt10,(r2)+
12$:	.iftf
	mov	clcloc,(r2)	;set new pc
	.if df	yphase
	sub	phaoff,(r2)
	.endc
13$:	call	objdmp		;dump buffer
14$:	mov	objpnt,r0	;get code pointer
	add	r5,r0		;compute new end
	sub	buftbl+binchn,r0
	cmp	r0,#objlen-1	;room?
	bhi	13$		;  no
	.ift
	movb	r4,r0		;yes, get rld size
	call	tstrld		;be sure we have room
	.iftf
	mov	objpnt,r1
	cmp	r1,buftbl+binchn	;first item?
	bne	16$		;  no
	.ift
	.if ndf	xedabs
	bit	#ed.abs,edmask	;abs output?
	beq	15$		;  yes
	.endc
	mov	#blkt03,(r1)+	;no, set block type
15$:	.if df	yphase
	mov	clcloc,(r1)	;get current pc
	sub	phaoff,(r1)+	;subtract out phase offset
	.iff
	mov	clcloc,(r1)+	;set new pc
	.endc
16$:	.ift
	asl	r4		;any rld?
	bcc	pcrol1		;  no
	movb	sector,(r2)+	;yes, set code
	mov	r1,r0
	sub	buftbl+binchn,r0	;compute index
	movb	r0,(r2)+
pcrol1:	asl	r4		;any symbol requested?
	bcc	21$		;  no
	mov	symbol,(r2)+	;yes, move it
	mov	symbol+2,(r2)+
21$:	asl	r4		;any value?
	bcc	22$		;  no
	mov	value,(r2)+	;yes, move it
22$:	.endc
	movb	value,(r1)+
	tst	r5
	beq	29$		;branch if byte instruction
	movb	value+1,(r1)+
29$:	mov	r1,objpnt
pcrol2:	inc	r5		;make count 1 or 2				;**-1
	add	r5,clcloc	;update pc
	mov	clcloc,objloc	;set sequence break
	setnz	r0		;set true return
pcrol3:	return
	.psect	implin,prv,gbl							;**new**,con 
pcrcnt::.blkw	1		;extension line flag				;**new**
										;**new**
	.if ndf	xrel								;**-3
	.psect	dpure,prv								;**new**,con 
pcrtbl:			;ref label					;**new**
	.word	0								;**-2
	.word	120004		;rldt01
	.word	140006		;rldt02
	.word	120004		;rldt03
	.word	140006		;rldt04
	.word	160010		;rldt05
	.word	160010		;rldt06
	.word	0
	.word	0
	.word	100002		;rldt11 (.limit)
	.word	0
	.word	0
	.word	0
	.word	160010		;rldt15
	.word	160010		;rldt16
	.endc
	.psect	imppas,prv,gbl							;**new**,con 
	.odd									;**-1
objsec:	.blkb	1		;object file sector				;**new**
objloc:	.blkw	1		;object file location				;**new**
										;**-2
	.psect	xctpas,gbl,shr							;**new**,con 
	comb	objsec		;force sequence break				;**-1
	.psect	.text.,con,shr
										;**-1
	.if ndf	xedpnc
pncset::movb	#-1,objsec	;force sequence break				;**new**
	return									;**-3
	.endc
										;**new**
;+										;**new**
; **-objdmp-dump object buffer							;**new**
; **-rlddmp-dump relocation buffer						;**new**
; **-tstrld-test relocation buffer						;**new**
;-										;**new**
										;**new**
objdmp::mov	objpnt,@cnttbl+binchn;point to count slot			;**new**
	beq	objinx		;exit if not pre-set				;**-3
	sub	buftbl+binchn,@cnttbl+binchn	;compute actual count
	beq	1$		;  empty, forget it
	$writw	bin		;write it out and wait
1$:
	.if ndf	xrel
	mov	buftbl+relchn,r0
	tst	(r0)+		;ignore first word
	cmp	rldpnt,r0	;anything in rld?
	blos	objini		;  no, just init
rlddmp::			;ref label					;**new**
	.if ndf	xedabs								;**-1
	bit	#ed.abs,edmask	;abs output?
	beq	objini		;  yes, no rld
	.endc
	mov	rldpnt,@cnttbl+relchn
	sub	buftbl+relchn,@cnttbl+relchn	;compute byte count
	$writw	rel
	.iftf
objini::mov	buftbl+binchn,objpnt;set buffer pointer				;**new**
	.ift									;**-1
	mov	buftbl+relchn,rldpnt
	add	#2,rldpnt	;reserve word for block type
	.iftf
objinx:	return
	.ift
tstrld::mov	r0,-(sp)	;save byte count				;**new**
	add	rldpnt,r0							;**-2
	sub	buftbl+relchn,r0
	cmp	r0,#rldlen	;room to store?
	blos	1$		;  yes
	call	objdmp		;no, dump current
1$:	mov	rldpnt,r2	;return with pointer in r2
	add	(sp)+,rldpnt	;update pointer
	return
	.iftf
	.psect	impure,prv							;**new**,con 
objpnt::.blkw	1		;						;**new**
	.ift									;**-2
rldpnt:	.blkw	1		;						;**new**
	.endc									;**-1
	.psect	.text.,con,shr
										;**new**
	.end									;**new**
