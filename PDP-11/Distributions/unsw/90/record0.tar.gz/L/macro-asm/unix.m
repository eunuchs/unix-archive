	.psect	.text.,con,shr
	.sbttl	unix definitions
	u.read	=	1
	u.write	=	2
	u.eof	=	4
	dotdot='.
	swit='-
	upnlen=32
	swclen=32
	unxfd=upnlen
	unxmod=upnlen+2
	space=' 
	protct=0644
	.sbttl	miscellaneous globals
	.globl	assem,macp0,iniof,inip1,finp1
	.globl	inip2,edmask,savreg,finp2,setdn
	.globl	macp1,endp1,macp2,endp2,prosw,linbuf
	.globl	absexp,putkb,putlp,xmit0,pass,ed.abs
