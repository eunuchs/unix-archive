	.psect	.text.,con,shr
	.title	setmx								;**new**
	.ident	/01/								;**new**
										;**new**
;										;**new**
; copyright 1972, digital equipment corp., maynard, mass 01754			;**new**
; copyright 1973, digital equipment corp., maynard, mass 01754			;**new**
;										;**new**
;	dec assumes no responsibility for the					;**new**
;	use or reliability of its software on					;**new**
;	equipment which is not supplied by dec.					;**new**
;										;**new**
; version 01									;**new**
;										;**new**
; b. bowering									;**new**
;										;**new**
;	modified by:								;**new**
;										;**new**
;	d.n. cutler 10-feb-73							;**new**
;										;**new**
;+										;**new**
; **-setmax-set maximum location counter					;**new**
;-										;**new**
										;**new**
	.if ndf	xrel								;**new**
setmax::savreg			;save registers					;**new**
	mov	#clcnam,r1							;**-1779
	mov	#symbol,r2
	call	xmit2		;move name to symbol
	scan	secrol		;scan sector roll
	call	xmit3		;set remainder of entries
	jmp	insert		;update roll and exit
	.endc									;**new**
										;**new**
	.end									;**new**
