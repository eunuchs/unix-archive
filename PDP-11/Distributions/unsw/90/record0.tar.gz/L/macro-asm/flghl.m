	.psect	.text.,con,shr
	.iif ndf mcexec , .nlist
;
; equated symbols
;
; character codes
;
ch.ior=	'!
ch.qtm=	'"
ch.hsh=	'#
ch.dol=	'$
ch.pct=	'%
ch.and=	'&
ch.xcl=	''
ch.lp=	'(
ch.rp=	')
ch.mul=	'*
ch.add=	'+
ch.com=	',
ch.sub=	'-
ch.dot=	'.
ch.div=	'/
ch.col=	':
ch.smc=	';
ch.lab=	'<
ch.equ=	'=
ch.rab=	'>
ch.qm=	'?
ch.ind=	'@
ch.bsl=	'\
ch.uar=	'^
let.a=	'a
let.b=	'b
let.c=	'c
let.d=	'd
let.e=	'e
let.f=	'f
let.g=	'g
let.o=	'o
let.z=	'z
dig.0=	'0
dig.9=	'9
lst.kb=1
lst.lp=2
tab=11
lf=12
vt=13
ff=14
cr=15
space=40
;
; relocation bit definitions
;
	.if ndf	xrel
rldt00=	00	; absolute data
rldt01=	01	; internal relocation		tst	#c
rldt02=	02	; global relocation		tst	#g
rldt03=	03	; internal displaced relocation	tst abs
rldt04=	04	; global displaced relocation	tst	x
rldt05=	05	; global additive relocation	tst	#x+6
rldt06=	06	; global additive displaced relocation	tst	#x+6
rldt07=	07	; new csect
rldt10=	10	; sequence break
rldt11=	11	; limit
rldt15=	15	; sector additive relocation	tst	#o
rldt16=	16	; sector additive displaced relocation	tst	#o+6
gsdt00=	00*400		; object module name
gsdt01=	01*400		; program section name
gsdt02=	02*400		; internal symbol table
gsdt03=	03*400		; transfer address
gsdt04=	04*400		; symbol declaration
gsdt05= 05*400		; program section name
gsdt06=	06*400		; version identification
blkt01=	01		; gsd
blkt02=	02		; gsd end
blkt03=	03		; text block
blkt04=	04		; rld block
blkt05=	05		; isd
blkt06=	06		; module end
	.endc
;
;flags used in symbol table mode
;
defflg=	000010		;defined
dfgflg= 000020		;defaulted global reference
relflg=	000040		;relocatable
glbflg=	000100		;global
regflg=	000001		;register
lblflg=	000002		;label
mdfflg=	000004		;multilpy defined
;
; program section attribute flag bit definitions
;
cstacc=000020			;access (1=ro, 0=rw)
cstalo=000004			;allocation (1=ovr, 0=con)
cstgbl=000100			;scope (1=global, 0=local)
cstrel=000040			;relocation (1=rel, 0=abs)
csttyp=000200			;type (1=data, 0=instruction)
cstmem=000001			;memory speed (1=high, 0=low)
;
; default section flags
;
astflg=cstalo!cstgbl!defflg	;abs section
cstflg=cstrel!defflg		;csect section
pstflg=cstflg			;psect section
;
;address mode flags
;
am.def=	10		;deferred mode
am.inc=	20		;auto-increment mode
am.dec=	40		;auto-decrement mode
am.ndx=	60		;index mode
am.pc=	07		;pc mode addressing
am.imm=	am.inc+am.pc	;immediate mode
am.rel=	am.ndx+am.pc	;relative mode
	.iif ndf mcexec , .list
