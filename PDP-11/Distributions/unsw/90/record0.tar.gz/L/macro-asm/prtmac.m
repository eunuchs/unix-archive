	.psect	.text.,con,shr
	.nlist
;
; submit file to print symbiont
;
; print$ fdb,err
;
; where:
;
;	fdb=address of fdb of file to submit.
;	err=address of error routine.
;
	.macro	print$ fdb,err
	.mcall	call,close$,ldr0$,sdrq$s
	ldr0$	fdb		;load fdb address into r0
	tst	f.bdb(r0)	;file open?
	beq	9999$		;if eq no
	bitb	#fd.rec,f.rctl(r0);unit record device?
	bne	9999$		;if ne yes
	mov	r1,-(sp)	;save r1 and r2
	mov	r2,-(sp)	;
	mov	(pc)+,-(sp)	;push symbiont name
	.rad50	/.../		;
	mov	(pc)+,-(sp)	;
	.rad50	/prt/		;
	mov	sp,r1		;set pointer to task name
	mov	r0,r2		;copy fbd address				;**-1
	add	#f.fnb,r2	;point to filename block
	mov	n.did+4(r2),-(sp);push directory id				;**new**
	mov	n.did+2(r2),-(sp);						;**new**
	mov	n.did(r2),-(sp)	;						;**new**
	mov	n.fid+4(r2),-(sp);push file id
	mov	n.fid+2(r2),-(sp);
	mov	n.fid(r2),-(sp)	;
	mov	n.unit(r2),-(sp);push unit number
	mov	n.dvnm(r2),-(sp);push device name
	mov	n.fver(r2),-(sp);push file version
	mov	n.ftyp(r2),-(sp);push file type
	mov	n.fnam+4(r2),-(sp);push filename
	mov	n.fnam+2(r2),-(sp);
	mov	n.fnam(r2),-(sp);
	mov	sp,r2		;set pointer to send buffer
	close$	r0		;close file
	sdrq$s	r1,,,,,r2	;send and request print symbiont
	ror	r1		;save carry
	add	#<13.*2>+<2*2>,sp;clean stack
	rol	r1		;restore carry
	mov	(sp)+,r2	;restore r1 and r2
	mov	(sp)+,r1	;
	.if nb	err
	bcc	9999$		;if cc okay
	call	err		;call error routine
	.endc
9999$:				;ref label
	.endm
	.list
