	.psect	.text.,con,shr
	.title	datdr
	.ident	/02/								;**new**
										;**-1
;
; copyright 1972, digital equipment corp., maynard, mass 01754
; copyright 1973, digital equipment corp., maynard, mass 01754
;
;	dec assumes no responsibility for the
;	use or reliability of its software on
;	equipment which is not supplied by dec.
;
; version 02									;**new**
;										;**-1
; b. bowering
;
;	modified by:
;
;	d.n. cutler 10-feb-73
;
;+
; **-ident-program identification
;-
ident::	call	rad50		;treat as rad50
	clr	rolupd		;point to start of code-roll
	mov	#prgidn,r2	;  and to ident block
1$:	next	codrol		;get next item
	mov	value,(r2)+	;store it
	cmp	r2,#prgidn+4	;processed two words?
	blo	1$		;  no
	.if ndf	xrel
	mov	#gsdt06,(r2)+	;yes, set gsd type
	.endc
	zap	codrol		;clear code roll
	return
;+
; **-blkw-block word
; **-blkb-block byte
; **-even-even location
; **-odd-odd location
; **-radix-conversion radix
; **-eot-end of tape
;-
blkw::	inc	r3		;flag word type
blkb::	expr			;evaluate expression
	bne	1$		;branch if non-null
	inc	(r4)		;null, make it one
1$:	abstst			;must be absolute
2$:	add	r0,(r2)		;update pc
	asr	r3		;word?
	bcs	2$		;  yes, double value
	return
even::	inc	(r2)		;increment current pc
	bic	#1,(r2)		;clear if no carry
	return
odd::	bis	#1,(r2)		;set low order bit in pc
eot::	return			;
radix::	mov	cradix,r2	;save in case of failure
	mov	#10.,cradix
	absexp
	cmp	r0,#2.
	blt	1$
	cmp	r0,#10.
	ble	2$
1$:	error	a
	mov	r2,r0
2$:	mov	r0,cradix
	jmp	setpf1
;+
; **-word-generate word data
; **-byte-generate byte data
;-
word::	inc	r3		;set word flag (2)
byte::	inc	r3		;set byte flag (1)
	mov	(r2),-(sp)	;stack current pc
1$:	tstarg			;test for argument
	beq	2$		;  end
	expr			;process general expression
	setimm			;convert to object format
	stcode			;put on code roll
	add	r3,(r2)		;update pc
	br	1$		;test for more
2$:	mov	(sp)+,(r2)	;restore initial pc
dgtest:	tstb	sizcod+1	;any code generated?
	bne	1$		;  yes
	clr	mode		;no, store a zero
	clr	value
	setimm
	stcode
1$:	return
;+
; **-asciz-generate ascii data with trailing zero byte
; **-ascii-generate ascii data
; **-rad50-generate radix 50 data
;-
asciz::	inc	r3		;set asciz flag (1)
ascii::	inc	r3		;set ascii flag (0)
rad50::	dec	r3		;set rad50 flag (-1)
	call	23$		;init regs
1$:	mov	r5,r2		;set terminator
	beq	8$		;error if eol
2$:	cmp	r5,#ch.lab	; "<", expression?
	beq	10$		;  yes
3$:	getchr			;no, get next char
	mov	r5,r0		;set in work register
	beq	8$		;error if eol
	cmp	r5,r2		;terminator?
	beq	5$		;  yes
	tst	r3		;no
	bmi	9$		;branch if rad50
	.if ndf	xedlc
	mov	chrpnt,r0	;fake for ovlay pic
	movb	(r0),r0		;fetch possible lower case
	bic	#177600,r0	;clear possible sign bit
	.endc
	br	4$
9$:	tstr50			;test radix 50
4$:	call	20$		;process the item
	br	3$		;back for another
5$:	getnb			;bypass terminator
6$:	tstb	cttbl(r5)	;eol or comment?
	bgt	1$		;  no
	br	7$
8$:	error	a		;error, flag and exit
7$:	clr	r0		;yes, prepare to clean up
	tst	r3		;test mode
	beq	24$		;normal exit if .ascii
	bpl	20$		;one zero byte if .asciz
	tst	r1		;.rad50, anything in progress?
	beq	24$
	call	20$		;yes, process
	br	6$		;loop until word completed
10$:	mov	(r4),-(sp)	;"<expression>", save partial
	abstrm			;absolute term, setting r0
	mov	(sp)+,(r4)	;restore partial
	call	20$		;process byte
	br	6$		;test for end
20$:	tst	r3		;rad50?
	bpl	22$		;  no
	cmp	r0,#50		;yes, within range?
	blo	21$		;  yes
	error	t		;no, error
21$:	mov	r0,-(sp)	;save current char
	mov	(r4),r0		;get partial
	call	mulr50		;multiply
	add	(sp)+,r0	;add in current
	mov	r0,(r4)		;save
	inc	r1		;bump count
	cmp	r1,#3		;word complete?
	bne	24$		;  no
22$:	mov	r0,(r4)		;stuff in value
	setimm			;convert to obj mode
	stcode			;stow it
23$:	clr	r1		;clear loop count
	clr	(r4)		;  and value
24$:	return
	.psect	xctpas,gbl,shr							;**-3,con 
	mov	#8.,cradix	;set radix to octal
	.psect	.text.,con,shr
	.end
