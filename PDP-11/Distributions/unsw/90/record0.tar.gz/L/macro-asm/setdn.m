	.psect	.text.,con,shr
	.title	setdn
	.ident	/d04/
; abstracted from rsx base level 02
;
; copyright 1972, digital equipment corp., maynard, mass 01754
; copyright 1973, digital equipment corp., maynard, mass 01754
;
;	dec assumes no responsibility for the
;	use or reliability of its software on
;	equipment which is not supplied by dec.
;
; version 02
;
; b. bowering
;
;	modified by:
;
;	d.n. cutler 10-feb-73
;	d. knight 16-jul-73 -- dos changes
;
; macro library calls
;
	.if ndf xrun
	.mcall	.run
	.endc
	.macro	xmit	wrdcnt	;move small # of words
	call	xmit0-<wrdcnt*2>
	.endm	xmit
	.macro	findev	from,to		;fin devices
	jsr	r5,findev
	.if nb	<from>
	.byte	from'chn
	.iff
	.byte	0
	.endc
	.if nb	<to>
	.byte	to'chn
	.iff
	.byte	maxchn
	.endc
	.endm	findev
;
; local data
;
	.nlist	bex
	.psect	txtbyt,prv,con
finmsg:	.asciz	/errors detected:  /;
finms2:	.asciz	/. words/	;
	.psect	.text.,con,shr
	.list	bex
;+
; **-setdn-set done-end of program clean up
;-
setdn::	mov	#finmsg,r1	;set for final message
	mov	#linbuf,r2
	call	movbyt		;move into linbuf
	mov	errcnt,r1
	mov	r1,-(sp)
	call	dnc		;print in decimal
	clrb	(r2)
	putlp	#linbuf		;list to lp
	tst	(sp)
	beq	2$		;branch if no errors
	putkb	#linbuf		;else put on kb
2$:
	.if ndf	xrun
	tst	crfflg		;cref?
	beq	9$		;no
	tst	crfngf		;no-go?
	bne	9$		;yes
	findev			;release all devices
	sub	#<5+6+5+6+10>*2,sp
	mov	sp,r2
	mov	#lstlnk-2,r1
	xmit	5
	mov	#lstfil-4,r1
	xmit	6
	mov	#crflnk-2,r1
	xmit	5
	mov	#crffil-4,r1
	xmit	6
	.run	#runblk
	halt
	.endc
9$:
fin::	findev			;close all files 
	104401			;sys 'exit' - end of assembly!
	.end
