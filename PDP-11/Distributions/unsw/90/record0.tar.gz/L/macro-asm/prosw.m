	.psect	.text.,con,shr
	.title	prosw
	.ident	/02/								;**new**
										;**-1
;
; copyright 1972, digital equipment corp., maynard, mass 01754
; copyright 1973, digital equipment corp., maynard, mass 01754
;
;	dec assumes no responsibility for the
;	use or reliability of its software on
;	equipment which is not supplied by dec.
;
; version 02									;**new**
;										;**-1
; b. bowering
;
;	modified by:
;
;	d.n. cutler 10-feb-73
;
; local macros
;
;the macro "genswt" is used to specify  a command
;string switch (1st argument) and the address of
;the routine to be called when encountered (2nd arg).
;
	.macro	genswt	mne,addr,?label
label:	.asciz	/mne/
.	=	label+2		;trim to one word
	.word	addr
	.endm
	.psect	swtsec,prv,gbl							;**new**,con 
swtbas::			;ref label					;**-1
	.if ndf	xcref
	genswt	cr,crfset
	.endc
	genswt	ds,dsabl
	genswt	en,enabl
	genswt	li,list
	genswt	nl,nlist
	genswt	pa,passsp
swttop::			;ref label
	.psect	.text.,con,shr
;+
; **prosw-process switch
;
; inputs:
;
;	r0=two character ascii switch.
;-
prosw::	savreg			;save registers
	setxpr			;set expression-type registers
	mov	r0,(r1)+	;set "symbol"
	call	xctlin		;zero line-oriented flags
	scanw	swtrol		;scan for switch
	beq	1$		;  not found, exit zero
	clr	(r3)		;clear "mode"
	mov	(r1),(r4)	;address to "value"
	mov	#linbuf,chrpnt	;point to start of line
	setnb			;set r5
	inc	exmflg		;flag exec mode
	call	propc		;process as op-code
	clr	r0		;assume error
	bis	errbts,r5	;error or not terminator?
	bne	1$		;  yes, error
	com	r0		;ok, set .ne. zero
1$:	return
	.end									;**-5
