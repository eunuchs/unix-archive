char chartab[] {

	' ','a','b','c','d','e','f','g','h','i',
	'j','k','l','m','n','o','p','q','r','s',
	't','u','v','w','x','y','z','$','.','!',
	'0','1','2','3','4','5','6','7','8','9',

};
r50toa(r50,ascii)
char *ascii;
int r50[3];
{
	int i,j,wkno,sgn;
	char *sascii;
	sascii=ascii;
	ascii =- 3;
	for(i=0; i<3; i++) {
		if(i==2) {
			ascii =+ 3;
			*ascii++ = '.';
			ascii =- 3;
		}
		ascii =+ 6;
		for(j=0; j<3; j++) {
			sgn = r50[i] & 0100000;
			wkno = ((r50[i] & 077777)>>3);
			if(sgn) wkno =| 010000;
			wkno = (wkno/5)*40;
			wkno = r50[i]-wkno;
			if(wkno<0) wkno = -wkno;
			*(--ascii) = chartab[wkno%40];
			r50[i] = ((r50[i] & 077777)>>3);
			if(sgn) r50[i] =| 010000;
			r50[i] =/ 5;
		}
	}
	sascii[10] = '\0';
	return(sascii);
}

main()
{
	int oct[3];

	char ascii[100];

goo:
	inputf("octal(3) ","ooo",&oct[0],&oct[1],&oct[2]);
	printf("radix= %s\n",r50toa(oct,ascii));
	goto goo;
}
