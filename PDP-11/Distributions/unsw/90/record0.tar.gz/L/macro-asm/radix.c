char chartab[] {

	' ','a','b','c','d','e','f','g','h','i',
	'j','k','l','m','n','o','p','q','r','s',
	't','u','v','w','x','y','z','$','.','!',
	'0','1','2','3','4','5','6','7','8','9',

};

setup(ascii,output)
char *ascii,*output;
{
	int i;
	i=0;
	while(*ascii) {
		if(*ascii == '.') {
			for(; i<6; i++) 
				*output++ = 040;
			goto ext;
		}
		i++;
		*output++ = *ascii++;
	}
	for(; i<9; i++) *output++ = 040;
	return;
ext:	ascii++;
	while(*ascii) {
		*output++ = *ascii++;
		i++;
	}
	for(; i<9; i++) *output++ = 040;
}

r50toa(r50,ascii)
char *ascii;
int r50[3];
{
	int i,j,wkno,sgn;
	char *sascii;
	sascii=ascii;
	ascii =- 3;
	for(i=0; i<3; i++) {
		if(i==2) {
			ascii =+ 3;
			*ascii++ = '.';
			ascii =- 3;
		}
		ascii =+ 6;
		for(j=0; j<3; j++) {
			sgn = r50[i] & 0100000;
			wkno = ((r50[i] & 077777)>>3);
			if(sgn) wkno =| 010000;
			wkno = (wkno/5)*40;
			wkno = r50[i]-wkno;
			if(wkno<0) wkno = -wkno;
			*(--ascii) = chartab[wkno%40];
			r50[i] = ((r50[i] & 077777)>>3);
			if(sgn) r50[i] =| 010000;
			r50[i] =/ 5;
		}
	}
	sascii[10] = '\0';
	return(sascii);
}

ator50(ascii,r50)
char *ascii;
int r50[3];
{
	char ac[11],*a;
	int i,j,pos,sum,power;
	a=ac;
	power=1;
	setup(ascii,a);
	a =+ 2;
	for(pos=0; pos<3; pos++) {
		sum=0;
		for(i=0; i<3; i++) {
			for(j=0; j<40; j++)
				if(*a == chartab[j]) goto found;
			error("illegal file name");
		found:	sum =+ j*power;
			power =* 40;
			a--;
		}
		r50[pos] = sum;
		a =+ 6;
		power=1;
	}
}

main()
{
	char str[3];
	int ary[3];
	inputf("string: ","s",str);
	ator50(str,ary);
	printf(" %o %o %o\n",ary[0],ary[1],ary[2]);
}
error(s)
	char *s;
{
	printf("%s\n",s);
	exit();
}
