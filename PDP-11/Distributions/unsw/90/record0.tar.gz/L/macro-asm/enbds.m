	.psect	.text.,con,shr
	.title	enbds
	.ident	/02/								;**new**
										;**-1
;
; copyright 1972, digital equipment corp., maynard, mass 01754
; copyright 1973, digital equipment corp., maynard, mass 01754
;
;	dec assumes no responsibility for the
;	use or reliability of its software on
;	equipment which is not supplied by dec.
;
; version 02									;**new**
;										;**-1
; b. bowering
;
;	modified by:
;
;	d.n. cutler 7-feb-73
;
; local macros
;
; generate .enabl/.dsabl argument roll
;
; genedt mne,subr,init
;
; where:
;
;	mne=a 1 to 3 character argument mneumonic.
;	subr=address of subroutine to be called when argument mneumonic
;		is encountered. this argument is optional.
;	init=if non-null, then default is disable.
;
	.macro	genedt	mne,subr,init
	.rad50	/mne/								;**-2
	.if nb	subr
	.word	subr
	.iff
	.word	cpopj
	.endc
	.endm	genedt								;**-1
										;**-2
	.psect	edtsec,prv,gbl							;**new**,con
edtbas::			;ref label					;**-1
	.if ndf	xedcdr
	genedt	cdr,,1
	.endc
	.if ndf	xedama
	genedt	ama,,1
	.endc
	.if ndf	xedpic
	genedt	pic,,1
	.endc
	.if ndf	xrel
	.ift
	.if ndf	xedabs
	genedt	abs,secini,1
	.endc
	.iff
	genedt	abs,secini,1
	.endc
	.if ndf	xedfpt
	genedt	fpt,,1
	.endc
	.if ndf	xedpnc
	genedt	pnc,pncset
	.endc
	.if ndf	xedlc
	genedt	lc,,1
	.endc
	.if ndf	xedlsb
	genedt	lsb,lsbtst,1
	.endc
	genedt	gbl
	genedt	reg
	genedt	stb
edttop::			;ref label
	.psect	.text.,con,shr
;+
; **-disable function
; **-enable function
;-
dsabl::	com	r3		;r3=-1
enabl::	gsarg			;get symbolic argument
	beq	8$		;end if null
	scanw	edtrol		;search the table
	beq	7$		;  not there, error
	clr	r2		;compute bit position
	sec
2$:	rol	r2
	sob	r0,2$
	tst	exmflg		;called from command string?
	beq	3$		;  no
	bis	r2,edmcsi	;yes, set disable bits
	br	4$		;  and bypass test
3$:	bit	r2,edmcsi	;over-ridden from csi?
	bne	enabl		;if ne yes-ignor
4$:	bic	r2,edmask	;no, clear selected bit
	tst	r3		;endble?
	beq	5$		;  yes, leave it clear
	bis	r2,edmask	;no, clear it
5$:	mov	symbol+2,-(sp)	;make it pic
	tst	r3		;set flags
	call	@(sp)+		;call routine
	br	enabl
7$:	error	a
8$:	return
										;**-11
	.psect	xctpas,gbl,shr,con
	mov	edmbak,edmask	;set each pass
	.psect	.text.,con,shr
	.end
