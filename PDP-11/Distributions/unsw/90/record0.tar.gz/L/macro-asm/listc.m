	.psect	.text.,con,shr
	.title	listc
	.ident	/02/								;**new**
										;**-1
;
; copyright 1972, digital equipment corp., maynard, mass 01754
; copyright 1973, digital equipment corp., maynard, mass 01754
;
;	dec assumes no responsibility for the
;	use or reliability of its software on
;	equipment which is not supplied by dec.
;
; version 02									;**new**
;										;**-1
; b. bowering
;
;	modified by:
;
;	d.n. cutler 6-feb-73
;
; local macros
;
	.macro	genlct	mne,init	;generate listing control table
	.rad50	/mne/								;**-4
	.endm									;**-3
	.psect	lctsec,prv,gbl							;**new**,con 
lctbas::			;ref label					;**-3
	genlct	seq
	genlct	loc
	genlct	bin
	genlct	src
	genlct	com
	genlct	bex
	genlct	md
	genlct	mc
	genlct	me ,1
	genlct	meb,1
	genlct	cnd
	genlct	ld ,1
	.if df	narrow
	genlct	ttm
	.iff
	genlct	ttm,1
	.endc
	genlct	toc
	genlct	sym
	genlct	<   >		;null
lcttop::			;ref label
	.psect	.text.,con,shr
;+
; **-nlist-no listing
; **-list-list
; **-page-page eject
;-
nlist::	com	r3		;make r3 -1
list::	asl	r3		;r3 0/-2
	inc	r3		;now 1/-1
1$:	tstarg			;test for another argument
	bne	2$		;  valid
	tst	argcnt		;null, first?
	bne	7$		;  no, we're through
	inc	argcnt		;yes, mark it
2$:	getsym			;try for a symbol
	scanw	lcdrol		;look it up in the table
	beq	6$		;  error if not found
	clr	r2
	sec
3$:	rol	r2
	sob	r0,3$
	tst	exmflg		;called from command string?
	beq	11$		;  no
	bis	r2,lcmcsi	;yes, set disable bits
	br	12$		;  and skip test
11$:	bit	r2,lcmcsi	;this flag off limits?
	bne	5$		;  yes
12$:	bic	r2,lcmask
	bit	r2,#lc.		;null?
	beq	4$		;  no
	call	pagex		;set listing control
	add	r3,lclvl	;yes, update level count
	beq	5$		;don't set flag if back to zero
4$:	tst	r3
	bpl	5$		;.list, branch
	bis	r2,lcmask
5$:	br	1$		;try for more
6$:	error	a
7$:	return
page::	inc	ffcnt		;simulate form feed after this line
pagex:	bis	#lc.ld,lcflag	;flag as listing directive
	return
	.psect	xctpas,gbl,shr							;**new**,con 
	mov	#lcsbak,r1	;reset listing flags				;**new**
	mov	#lcsave,r2	;						;**new**
	mov	#xmit0,-(sp)	;get base address of move vector		;**new**
	sub	#lcsavl,(sp)	;calculate proper offset			;**new**
	call	@(sp)+		;move block					;**new**
	.psect	.text.,con,shr
										;**new**
	.end
