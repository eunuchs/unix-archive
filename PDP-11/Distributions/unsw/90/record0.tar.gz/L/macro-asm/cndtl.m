	.title	cndtl
	.ident	/d02/
										;**-1
;
; copyright 1972, digital equipment corp., maynard, mass 01754
; copyright 1973, digital equipment corp., maynard, mass 01754
;
;	dec assumes no responsibility for the
;	use or reliability of its software on
;	equipment which is not supplied by dec.
;
; version 02									;**new**
;										;**-1
; b. bowering
;
;	modified by:
;
;	d.n. cutler 6-feb-73
;	d. knight 25-may-73 -- dos changes
;
; local macros
;
;
;the macro "gencnd" is used to specify conditional
;arguments.  it takes two or three arguments:
;
;	1-	mnemonic
;	2-	subroutine to be called
;	3-	if non-blank, complement condition

	.macro	gencnd	mne,subr,toggle	;generate conditional
	.rad50	/mne/
	.if b	<toggle>
	.word	subr
	.iff
	.word	subr+1
	.endc
	.endm

	.psect	cndsec,prv,gbl,con
cndbas::			;ref label					;**new**
	gencnd	eq,	tconeq							;**new**
	gencnd	ne,	tconeq,	f						;**new**
	gencnd	z,	tconeq							;**new**
	gencnd	nz,	tconeq,	f						;**new**
	gencnd	gt,	tcongt							;**new**
	gencnd	le,	tcongt,	f						;**new**
	gencnd	g,	tcongt							;**new**
	gencnd	lt,	tconlt							;**new**
	gencnd	ge,	tconlt,	f						;**new**
	gencnd	l,	tconlt							;**new**
	gencnd	df,	tcondf							;**new**
	gencnd	ndf,	tcondf,	f						;**new**
	gencnd	b,	tcb							;**new**
	gencnd	nb,	tcb,	f						;**new**
	gencnd	idn,	tcid							;**new**
	gencnd	dif,	tcid,	f						;**new**
cndtop::			;ref label					;**new**
	.psect	.text.,shr,con
										;**new**
;+
; **-iif-immediate if
; **-if-micro programmed conditional
; **-ift-if true
; **-iff-if false
; **-iftf-if true or false
; **-endc-end conditional
;-

iif::	call	tcon		;test argument
	tst	r3
	bmi	3$		;  branch if unsatisfied
	cmp	#ch.com,r5	;comma?
	bne	1$		;  no
	getchr			;yes, bypass
1$:	mov	chrpnt,r1	;save current location
	setnb			;set to nom-blank
	bit	#lc.cnd,lcmask	;conditional suppression?
	beq	2$		;  no
	mov	r1,lcbegl	;yes, suppress all up to comma
2$:	clr	argcnt
	jmp	stmnt		;back to statement
3$:	clr	r5		;false, but no "q" error
	br	endcx

	.globl	ifdf
	.irp	arg,	<eq,ge,gt,le,lt,ne,g,l,nz,z,df,ndf>
if'arg:
	.endm

	mov	symbol+2,symbol	;treat second half as argument
	call	tconf		;examine it
	br	if1		;into the main stream
if::	call	tcon		;test argument
if1:	mov	#cndlvl,r1	;point to level
	cmp	(r1),#15.	;room for another?
	bgt	ifoerr		;  no, error
	inc	(r1)		;yes, bump level
	asl	r3		;set carry to true (0) or false (1)
	ror	-(r1)		;rotate into cndmsk
	asl	r3
	ror	-(r1)		;ditto for cndwrd
	br	endcx
ift::	mov	cndmsk,r3	;get current condition
	br	iftf		;  and branch
iff::	mov	cndmsk,r3	;get current condition
	com	r3		;use complement and fall through
iftf::	tst	cndlvl		;condition in progress?
	ble	ifoerr		;  no, error
	asl	cndwrd		;move off current flag
	asl	r3		;set carry
	ror	cndwrd		;mov on
	br	endcx
endc::	mov	#cndlvl,r1	;point to level
	tst	(r1)		;in conditional?
	ble	ifoerr		;  no, error
	dec	(r1)		;yes, decrement
	asl	-(r1)		;reduce mask
	asl	-(r1)		;  and test word
endcx:	bit	#lc.cnd,lcmask	;suppression requested?
	beq	2$		;  no
	mov	lblend,r0	;yes, any label?
	beq	1$		;  no, suppress whole line
	mov	r0,lcendl	;yes, list only label
	br	2$
1$:	bis	#lc.cnd,lcflag	;mark conditional
2$:	return
ifoerr:	error	o		;condition error
	return
tcon:	gsarg			;get a symbolic argument
tconf:	scanw	cndrol		;scan for argument
	beq	ifaerr		;  error if not found
	mov	symbol+2,r1	;get address
	asr	r1		;low bit used for toggle flag
	sbc	r3		;r3 goes to -1 if odd
	asl	r1		;back to normal (and even)
	tst	cndwrd		;already unsat?
	bne	ifaerx		;  yes, just exit
	tstarg			;bypass comma
	jmp	(r1)		;jump to handler
ifaerr:	error	a
ifaerx:	clr	r5		;no "q" error
	return
tconeq:	absexp			;eq/ne, test expression
	beq	tcontr		;branch if sat
tconfa:	com	r3		;  false, toggle
tcontr:	return			;true, just exit
tcongt:	absexp
	bgt	tcontr
	br	tconfa
tconlt:	absexp
	blt	tcontr
	br	tconfa
tcondf:	mov	r3,r1		;save initial condition
	clr	r2		;set "&"
	clr	r3		;start off true
1$:	getsym			;get a symbol
	beq	ifaerr		;  error if not a sym
	ssrch			;search user symbol table
	crfref
	clr	r0		;assume defined
	bit	#defflg,mode	;good guess?
	bne	2$		;  yes
	com	r0		;no, toggle
2$:	cmp	r0,r3		;yes, match?
	beq	3$		;  yes, all set
	mov	r2,r3		;  no
	com	r3
3$:	mov	r1,r2		;assume "&"
	cmp	r5,#ch.and	; "&"
	beq	4$		;  branch if good guess
	cmp	r5,#ch.ior	;perhaps or?
	bne	5$		;  no
	com	r2		;yes, toggle mode
4$:	getnb			;bypass op
	br	1$		;try again
5$:	tst	r1		;ifdf?
	beq	6$		;  yes
	com	r3		;no, toggle
6$:	return
tcb:	beq	tcberx		;ok if null
	call	gmargf		;isolate argument
	setnb			;bypass any blanks
	beq	tcidt		;true if pointing at delimiter
	br	tcidf		;else false
tcberr:	error	a		;naughty
tcberx:	return
tcid:	beq	tcberr		;error if null
	call	gmargf		;isolate first arg
	mov	chrpnt,r1	;save character pointer
	tst	-(r0)
	mov	-(r0),r2	;pointer to terminator
	call	rmarg		;return this arg
	call	gmarg		;get the next
	beq	tcberr
1$:	movb	(r1),r0		;set character from first field
	cmp	r1,r2		;is it the last?
	bne	2$		;  no
	clr	r0		;yes, clear it
2$:	cmp	r0,r5		;match?
	bne	tcidf		;  no
	tst	r5		;yes, finished?
	beq	tcidt		;  yes, good show
	getchr			;no, get the next character
	inc	r1		;advance first arg pointer
	br	1$		;try again
tcidf:	com	r3		;false, toggle condition
tcidt:	jmp	rmarg		;ok, restore argument

	.end									;**-27
