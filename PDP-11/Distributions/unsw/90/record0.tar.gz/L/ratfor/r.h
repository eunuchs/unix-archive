#
extern	int	contfld;
extern	int	dbg;
extern	int	yyval;
extern	int	*yypv;
extern	int	yylval;
extern	int	peek;
extern	int	errorflag;
