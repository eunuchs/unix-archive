#

#define opt_OFF	0
#define opt_ON	1
int opt_fcc;
int opt_fcb;
int opt_fdb;

#include	"mas.h"


extern struct symbol *symtab;
extern lab;
extern noaddr;
extern char tch, line[], *linep;
extern char symbuf[];

extern unsigned spc, pc;
extern unsigned text;
extern unsigned data;
extern unsigned bss;

extern char seg;
extern char peekc;

extern char obuff[], rbuff[];
extern char *odp, *orp;

extern int ofile, rfile;
extern int otfile, odfile, rtfile, rdfile;

endsegment()
{
	if(odp != obuff)
	{
		write(ofile, obuff, (odp - obuff)*sizeof obuff[0]);
		write(rfile, rbuff, (orp - rbuff)*sizeof rbuff[0]);
		odp = obuff;
		orp = rbuff;
	}

	switch(seg)
	{
	case TEXT:
		text = pc;
		break;
	case DATA:
		data = pc;
		break;
	case BSS:
		bss = pc;
	}
}


pseudop(opc)
char opc;
{
register char c;
register char *l;
register n;
int *p, k, m;
int save[100];

	switch ( opc ) {
	case o_TEXT:
		endsegment();
		pc = text;
		ofile = otfile;
		rfile = rtfile;
		seg = TEXT;
		lcomm();
		break;

	case o_DATA:
		endsegment();
		pc = data;
		ofile = odfile;
		rfile = rdfile;
		seg = DATA;
		lcomm();
		break;

	case o_BSS:
		endsegment();
		pc = bss;
		ofile = -1;
		rfile = -1;
		seg = BSS;
		lcomm();
		break;

	case o_EQU:
		n = getexpr();
		if ( symtab[lab].s_def <= EXP ) {
			symtab[lab].s_def = ABS;
			symtab[lab].s_pc = n;
		}
		else
		if (symtab[lab].s_pc != n)
		{
			write(2, "o_EQU\n", 6);
			syserr();
		}
		lcode3(n);
		lcomma();
		return;

	case o_FCB:
		c = getnonbl();
		n = getitem(c);
		outbyte(n);
		lcode2(n);
		k = 0;
		p = save;
		while ( tch == COMMA ) {
			n = getitem( getch() );
			outbyte(n);
			if ( k < 100 ) {
				*p++ = n;
				k++;
			}
		}
		lcomm();
		p = save;
		tch = NL;
		if( opt_fcb == opt_ON )
			while ( k-- ) {
				lcode2(*p++);
				linep = line+l_C2+2;
				*linep++ = NL;
				spc++;
				lcomm();
			}
		else
			spc =+ k;
		return;

	case o_FDB:
		c = getnonbl();
		n = getitem(c);
		outword(n);
		lcode3(n);
		k = 0;
		p = save;
		while ( tch == COMMA ) {
			n = getitem( getch() );
			outword(n);
			if ( k < 100 ) {
				k++;
				*p++ = n;
			}
		}
		lcomm();
		p = save;
		tch = NL;
		if( opt_fdb == opt_ON )
			while ( k-- ) {
				lcode3(*p++);
				linep = line+l_C2+4;
				*linep++ = NL;
				spc++; spc++;
				lcomm();
			}
		else
			spc =+ 2*k;
		return;

	case o_FCC:
		p = save;
		k = 0;
		c = getnonbl();
		while ( (c = getch()) != SLASH ) {
			if ( c == BACKSL ) {
				if ( (n = fcchar(c = getch())) == -1 ) {
					outbyte(BACKSL);
					if ( k < 100 ) {
						k++;
						*p++ = BACKSL;
					}
					outbyte(c);
					if ( k < 100 ) {
						k++;
						*p++ = c;
					}
				}
				else {
					outbyte(n);
					if ( k < 100 ) {
						k++;
						*p++ = n;
					}
				}
			}
			else {
				outbyte(c);
				if ( k < 100 ) {
					k++;
					*p++ = c;
				}
			}
		}
		p = save;
		lcode2(*p++);
		--k;
		lcomm();
		tch = NL;
		if (opt_fcc == opt_ON)
			while ( k-- ) {
				lcode2(*p++);
				spc++;
				linep = line+l_C2+2;
				*linep++ = NL;
				lcomm();
			}
		else
			spc =+ k;
		return;

	case o_RMB:
		n = getexpr();
		pc =+ n;
		lcomm();
		return;

	case o_ZMB:
		n = getexpr();
		while ( n-- )
		 	outbyte(0);
		lcomm();
		return;

	case o_OPT:
		if ((c = tch) != NL)
			c = getnonbl();
		if ((tch = c) != NL) {
			getsym(c);
			options();
		}

	default:
		lcomma();
		if (opc == o_PAG)
			lpage();
		return;
	}
}




fcchar(ch)
register char ch;
{
	register  char  num,ct;

	switch ( ch ) {
	case BACKSL:
		return(BACKSL);

	case SLASH:
		return(SLASH);

	case 'n':
		return(NL);

	case 'r':
		return(CR);

	case 's':
		return(SP);

	case 't':
		return(TAB);

	case '0':
		ct = 0;
		num = 0;
		while( ((ch = getch()) >= '0') && (ch <= '7') && (++ct < 4 ))
			num = num*8 + ch - '0';
		peekc = ch;
		return(num);
	}

	return(-1);
}



struct option {
	char *optstr;
	int opttype;
};

#define FCCOFF	1
#define FCCON	2
#define SYMOFF	3
#define SYMON	4
#define FCBOFF  5
#define FCBON   6
#define FDBOFF  7
#define FDBON   8

struct option opttab[] {
	"fccoff",	FCCOFF,
	"fccon",	FCCON,
	"symoff",	SYMOFF,
	"symon",	SYMON,
	"fcboff",	FCBOFF,
	"fcbon",	FCBON,
	"fdboff",	FDBOFF,
	"fdbon",	FDBON,
	0,	0,
};

int opt_sym 1;
int opt_fcc 0;
int opt_fcb 0;
int opt_fdb 0;

options()
{
register struct option *o;
register char *s, c;

	s = symbuf;
	while (c = *s)
		*s++ = c | 040;

	o = opttab;
	for (s = o->optstr; s != 0; s = (++o)->optstr)
		if (symmat(s))
			switch (o->opttype) {
			case FCCOFF:
				opt_fcc = opt_OFF;
				return;
			case FCCON:
				opt_fcc = opt_ON;
				return;

			case SYMOFF:
				opt_sym = opt_OFF;
				return;
			case SYMON:
				opt_sym = opt_ON;
				return;
			case FCBOFF:
				opt_fcb = opt_OFF;
				return;
			case FCBON:
				opt_fcb = opt_ON;
				return;
			case FDBOFF:
				opt_fdb = opt_OFF;
				return;
			case FDBON:
				opt_fdb = opt_OFF;
				return;
			}
}


symmat(s1)
char *s1;
{
register char *s, c;

	s = symbuf;
	while ((c = *s++) == *s1++)
		if (c == '\0')
			return(1);
	return(0);
}
