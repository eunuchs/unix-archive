#

#include	"mas.h"


extern struct mnems mnem[];
extern  type, opct;
extern struct symbol *symtab;
extern hashtab[];
extern int lc, numsym;
extern int nmnem;
extern char symbuf[];
extern int nsym;





lookup()
{
register j;
register struct symbol *sym  ;
register char *s;
char loc;
char *s1;
int m;
int t;

	loc = 0;
	s = symbuf;
	j = hash(s);
	t = j;
	if ( hashtab[j] != 0 ) {
		j = hashtab[j];
		do {
			sym = &symtab[j];
			if (compar(&sym->s_name[0],s))
				return(j);
		}	while ( (j = sym->s_chain) != 0 );
		sym->s_chain = numsym;
	}
	else
		hashtab[j] = numsym;
	if(numsym >= nsym)
	{
		write(2,"symbol table overflow\n",22);
		syserr(); /* no return */
	}
	sym = &symtab[numsym];
	s1 = &sym->s_name[0];
	j = 0;
	while ((*s != '\0') && (j++ < 8))
		*s1++ = *s++;
	sym->s_pc = lc;
	sym->s_seg = CABS;
	return(numsym++);
}
 
 
 
hash(a)
char *a;
{
register char *s;
register char c;
register h;
	h = 0;
	s = a;
	while ( (c = *s++) != '\0' )
		h =+ (c - 61) * 29;
	if (h < 0)
		h = -h;
	return( h % 127 );
}
 
 
 
compar(a1, a2)
char *a1, *a2;
{
register char *s1, *s2;
register char c;
int	i;
	s1 = a1;
	s2 = a2;
	i = 0;

	while ( (c = *s1++) == *s2++ )
		if ((++i == 8) || (c == '\0' ))
			return(1);
	return(0);
}


mnemlook()
{
	register struct mnems *first, *last, *mid;
	first = &mnem[0];
	last = &mnem[nmnem];

	while(first+1 < last)
	{
/*		printf("%s:f=%o,l=%o\n",symbuf,first,last);*/
		mid = first + (last - first)/2;
		if(less(mid->mn,symbuf))
			first = mid;
		else
			last = mid;
	}
	if(mncompar(last->mn, symbuf))
	{
		type = last->mtyp;
		opct = last->mopc;
		return type;
	}
	type = o_BAD; return(0);
}

less( p1, p2)
register char *p1, *p2;
{
	register i 0;
	while(i++ < 6)
	{
		if(*p2 == *p1)
		{
			if(*p1 == '\0')
				return 0;
			p2++; p1++;
			continue;
		}
		return *p1 < *p2;
	}
	return 0;
}

mncompar(p1, p2)
register char *p1, *p2;
{
	register i 0;

	while(i++ < 6)
	{
		if(*p2 == *p1)
		{
			if(*p1++ == '\0')
				return 1;
			p2++;
			continue;
		}
		return 0;
	}
	return 1;
}
