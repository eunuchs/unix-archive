#
#include "mas.h"


extern ofile;
extern rfile;

extern unsigned pc;

char obuff[BUFSIZ];
char rbuff[BUFSIZ];

char *odp obuff;
char *orp rbuff;

extern relocation;

extern struct symbol *symtab;
extern int numsym;
extern int otfile;
extern int ftext, fdata;
outbyte(b)
{
	outb(b);
	outr(0);
}

outb(b)
{
	register char *p;

	pc++;
	p = odp;
	*p++ = b;
	if(p == &obuff[BUFSIZ])
	{
		write(ofile, obuff, BUFSIZ * sizeof obuff[0]);
		p = obuff;
	}
	odp = p;
}


outword(w)
{

	outb(w >> 8);
	outb(w);
	outr((relocation >> 8) & 0377);
	outr(relocation & 0377);
}

outr(r)
{
	register char *p;

	p = orp;
	*p++ = r;
	if( p == &rbuff[BUFSIZ])
	{
		write(rfile, rbuff, BUFSIZ * sizeof rbuff[0]);
		p = rbuff;
	}

	orp = p;
}

bcd1(n)
{
	register j;

	j = (n >> 4) & 017;
	return(j < 10 ? j+'0' : j+'A'-10);
}

bcd2(n)
{
	register j;

	j = n & 017;
	return(j < 10 ? j+'0' : j+'A'-10);
}

writesyms()
{

	register struct symbol *p;
	struct {
		char s[8];
		char t;
		char p;
		int  v;
	} nextsym;
	register fd;

	fd = otfile;
	seek(fd, TEXTOFFSET + (ftext + fdata)*2, 0);

	nextsym.p = 0;
	for(p = &symtab[1]; p < &symtab[numsym]; p++)
	{

		scopy(p->s_name, nextsym.s);
		nextsym.v = p->s_pc;
		nextsym.t = p->s_seg;
		if(p->s_def & GLBL)
			nextsym.t =+ EXTERNAL;

		write(fd, &nextsym, sizeof nextsym);
	}
}

scopy(s1, s2)
register char * s1, *s2;
{

	register i;

	i = 0;
	while(i++ < 8)
		*s2++ = *s1++;
}
