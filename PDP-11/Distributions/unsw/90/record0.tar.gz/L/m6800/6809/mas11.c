#

# include	"mash.c"



char *symtmp, *fbtmp;
int sfile, fbfile;

char *itmp, *atmp, *etmp;
int afile, efile, ifile;
int acount, icount;

char *ltmp;

extern struct aform abuf[];
extern struct iform ibuf[];
extern mist[][5];
struct aform *abptr;
struct iform *iptr;

extern char inbuf[];
char *fins;
extern struct symbol *symtab;
extern int nsym;
extern int nmnem;
extern hashtab[];
extern mnemlook();
extern getoper(), getregop();
extern struct mnems mnem[];
int type, opct, mode;

struct evalx r;

extern struct fb *fbtable;

struct expr exptab[10];


struct segment segopt;



extern curfb[];
int nextfb;
int lc,errc,err2;

int regi, ofstbts, postbyte;
int pc,pc_def;
int numsym;
char *nextch, tch;
int lab;
int accvalid;
int gargc;
char **gargv;
extern char symbuf[];
int findes, nchar;

main(argc, argv)
char **argv;
{
	register char c;
	register n, l;
	int testflag;
	char *p;

	gargc = argc;
	gargv = argv;
	n = NSYM;

	testflag = 0;
	while(gargv[1][0] == '-')
	{
		switch(gargv[1][1])
		{
		case 't':
				testflag++;
				break;
		case 's':
				p = &gargv[1][2];
				if(*p == 0)
					n = BNSYM;
				else
				{
					n = 0;
					while((*p >= '0') && (*p <= '9'))
						n = n*10 + *p++ -'0';
				}
				if(n < NSYM)
					n = NSYM;
				n =& ~1;
				if(n > MAXSYM)
				{
					printf("WARNING MAXSYM = %d\n", MAXSYM);
					n = MAXSYM;
				}

				break;
		}
		gargc--;
		gargv++;
	}
	if((l =symtab = alloc(n * sizeof *symtab)) == -1
		|| (l = fbtable = alloc (n/2 * sizeof *fbtable)) == -1)
	{
		printf("pass1 out of memory\n");
		exit();
	}
	nsym = n;
	{
		register char *sp;
		for(sp=symtab;sp<&symtab[nsym];sp++)
		{
			*sp = 0;
		}
	}
	{
		register char *fbp;
		for(fbp=fbtable;fbp<&fbtable[nsym/2];fbp++)
			*fbp = 0;
	}

	findes = dup(0);	/* give newfile something to close */
	if ( newfile() == 0 )
		exit();

	ltmp = "/tmp/motma.5";	/* lock file */
	c = 'a';
	while (creat(ltmp,0000) == -1)
		if ((*(ltmp+9) = ++c) > 'z')
			help();
	symtmp = "/tmp/motmx.0";
	fbtmp = "/tmp/motmx.1";
	itmp = "/tmp/motmx.2";
	atmp = "/tmp/motmx.3";
	etmp = "/tmp/motmx.4";
	*(symtmp+9) = c;
	*(fbtmp+9) = c;
	*(itmp+9) = c;
	*(atmp+9) = c;
	*(etmp+9) = c;

	if ( ((afile = creat(atmp,0600)) == -1) ||
	     ((efile = creat(etmp,0600)) == -1) )
		help();
	if ( (ifile = creat(itmp,0600)) == -1 )
		help();
	close(afile);
	close(efile);
	if ( ((afile = open(atmp,2)) == -1) ||
	     ((efile = open(etmp,2)) == -1) )
		help();

	abptr = abuf;
	iptr = ibuf;

	numsym = 1;
	pc_def = ABS;

	nextfb = 20;
	for ( n=0; n<20; n++ )
		curfb[n] = n;

	{
		register struct mnems *p;

		p = &mnem[0];
		while(p->mn[0] != 0)
		{
			p++;
			nmnem++;
		}
	}
	if ( (c = getch()) == '#' ) {
		lc++;
		while ( ((c = getch()) == SP) || (c == TAB) );
		if ( getsym(c) != 3 )
			segerr();
		if ( mnemlook() != o_SEG )
			segerr();
		if ( (tch != SP) && (tch != TAB) )
			segerr();
		while ( ((c = getch()) == SP) || (c == TAB) );
		if ( (l = getsym(c)) == 0 ) {
			if ( tch != MINUS )
				segerr();
			if ( (l = getsym(0)) == 0 )
				segerr();
			segopt.segtype = 2;
		}
		else
			segopt.segtype = 1;

		if ( l != 1 )
			segerr();
		c = symbuf[0];
		if ( digit(c) )
			segerr();
		segopt.segchar = c;
		segopt.segcount++;
		getcomm();
	}
	else
		nextch--;	/* set back to first char */

	for(;;) {			/* start of main loop when NL read */
		setexit();
		lc++;
		lab = 0;
		if ( (c = getch()) == EOF ) {
			if ( newfile() )
				continue;
			break;
		}

		switch ( c ) {
		
		case NL:
			continue;

		case SP:
		case TAB:
			break;

		case STAR:
			tch = c;
			getnl();

		default:
			getlabel(c);
		}

		while ( ((c = getch()) == SP) || (c == TAB) );
		if ( c == NL )
			continue;
		if ( c == EOF )
			eoferr();

		getmnem(c);	/* read operator field */
		getcomm();	/* reset */
	}

	pass1a();		/* pass1 completed */
	newif(i_REL);

	close(afile);
	close(efile);
	unlink(etmp);
	unlink(atmp);

	if ( err2 ) {		/* don't run pass2 if errors */
		unlink(itmp);
		unlink(ltmp);
		exit();
	}

	write(ifile, ibuf, icount<<2);		/* write rest of long form */
	close(ifile);

	if ( (sfile = creat(symtmp,0600)) == -1 )
		help();
	if ( (fbfile = creat(fbtmp,0600)) == -1 )
		help();
	write(fbfile, fbtable, nextfb<<2 );
	write(sfile, hashtab, 256);
	write(sfile, symtab, numsym*14);
	close(fbfile);
	close(sfile);

	argv[argc] = 0;
	argv[0][0] = *(ltmp+9);
	if(testflag)
	{
		if(execv("mas209",argv) == -1)
		{
			printf("no mas209\n");
			unlink(ltmp);
		}
	}
	else
	{
		if(execv("/lib/mas209",argv)== -1)
		{
			printf("mas209 has gone \n");
			unlink(ltmp);
		}
	}
}



newfile()
{
	close(findes);
	if ( --gargc ) {
		fins = *++gargv;
		if ( (findes = open(fins,0)) == -1 ) {
			printf("Cannot open: %s\n",fins);
			return(newfile());
		}
		nchar = read(findes, nextch=inbuf, 512);
		lc = 0;
		errc = 0;
		return(1);
	}
	return(0);
}



getlabel(ch)
char ch;
{
register char c;
register l;

	if ( (l = getsym(c = ch)) == 0 )
		syntax();
	if ( digit(c) ) {
		if ( l != 1 )
			syntax();
		deffb(c - '0');
	}
	else
	if ( accsym(l,c) )
		error("acc symbol");
	else
	defsym();

	if ( (c = tch) == NL )
		reset();
	if ( (c != SP) && (c != TAB) && (c != COLON) )
		syntax();
}



getmnem(ch)
char ch;
{
register char c;
register n;
char mode;
	n = getsym(c = ch);
	if ( n > 5 ){
	    	syntax(); /* no return */
		}
	symbuf[n] = '\0';

	mnemlook();
	switch (type){

	case o_A:
		mode = getoper();
		
		switch(mode){

		case m_IM1:
		case m_IM2:
			pc =+ 2;
			if (mist[opct][m_IM1] == 1 ){
				mode = m_IM2;
				pc++;
				}
			if (mist[opct][mode] > 0xff)
				pc++;
			break;
		case m_EXT:
			pc ++;
		case m_DIR:
			pc =+ 2;
			if (mist[opct][m_DIR] > 0xff )
				pc++;
			break;
		case m_IND:
		case m_PCR:
			pc =+ 2;
			if (mist[opct][m_IND] > 0xff )
				pc++;
			pc =+ ofstbts;
			mode = m_IND;
			break;

		case m_BAD:
		default:
			amoderr();
			break;
		}
		if ( mist[opct][mode] == 1 )  amoderr();
		break;
	case o_BNCH:
		pc =+ 2;
	chkbnch:
		if(getoper() != m_EXT)
			syntax();
		break;
	case o_LB:
		pc =+ 3;
		if (opct > 0xff)
			pc++;
		goto chkbnch;
	case o_INH:
		pc++;
		break;
	case o_INH2:
		pc =+ 2;
		break;
	case o_RR:
		pc =+ 2;
		getregop();
		break;
	case o_PP:
		pc =+ 2;
		getPP();
		break;
	case o_BAD:
		syntax();
		pc++;
		break;
	case o_JBRS:
		getexpr(0);
		outaform(a_JBRS);
		pc =+ 3;
		pc_def = EST;
		break;
	case o_JEQS:
		getexpr(0);
		outaform(a_JEQS);
		pc =+ 4;
		pc_def = EST;
		break;
	default:
		if ( type >= PSEUDO ) {
			pseudop(type);
			return;
		}
		else
			syntax();

	}
}




outaform(at)
{
register n;
register struct expr *x;
register struct aform *ab;

	ab = abptr;
	ab->a_pc = pc;
	ab->a_def = n = at;
	if ( (n >= a_EQU) || (n == a_JEQS) || (n == a_JBRS) 
		|| (n == a_PCR) || (n == a_INDX) || (n == a_DINDX) || (n == a_DPCR) ) {
		for ( x = exptab; x->e_rator; x++ );
		x++;
		write(efile, &exptab[0], (x-&exptab[0]) << 2);
	}

	abptr++;
	if ( ++acount == 128 ) {
		write(afile, abuf, 512);
		acount = 0;
		abptr = abuf;
	}
}



defsym()
{
register struct symbol *sym;

	sym = &symtab[(lab = lookup())];
	if ( sym->s_def )
		error("m*");
	else {
/*		printf("%s:\n",symbuf);*/
		sym->s_def = pc_def;
		sym->s_pc = pc;
	}
}



deffb(ind)
{
register struct fb *fbp;
register i, n;

	i = ind;
	n = curfb[i] = curfb[i+10];
	fbp = &fbtable[n];
	fbp->fb_pc = pc;
	fbp->fb_def = pc_def;
	if(nextfb >= nsym/2)
	{
		write(2, "fb table overflow\n", 18);
		syserr();
	}
	n = curfb[i+10] = nextfb++;
	fbp = &fbtable[n];
	fbp->fb_lab = i;
}



segerr()
{
	error("seg");
	exit();
}



syntax()
{
	error("syntax");
	getnl();
}



numerr()
{
	error("number");
	getnl();
}


charerr()
{
	error("char constant");
	getnl();
}


amoderr()
{
	error("addr mode");
	getnl();
}



eoferr()
{
	error("eof ?");
	exit();
}




help()
{
	printf("help: can't open temp files\n");
	exit();
}



error(s)
char *s;
{
	if ( errc == 0 )
		printf("%s:\n", fins);
	printf("%5.d\t%s\n", lc, s);
	errc++;
	err2++;
}


syserr()
{
	printf("assembler error\n");
	exit();
}



relerr()
{
	error("relocation");
	exit();
}

undefexp()
{
	error("undefined expression");
	getnl();
}
