#include "draft.h"

main(ac, av)
int ac; char **av;
{

	struct object *cc;   /* current command object */

	if(!build(predef) || !build(udef))
		exit(1);

	init(stdout);
	/*
		args
		xxx
	*/

	do
	{
		cc = getcommand();
		(cc->cm.func)(cc);
		if(!cm->sflag)
			freeobj(cc);
		else
		{
			/* add the current object to the object list */
			if(head = NULL)
				head = cc;
			tail.nextobj = cc;
			tail = cc;
		}
	}
	while(!exitflag);

	finish();
}
struct item *getpoint(c,x,y)
char c;
float x, y;
{
	register struct item *p;
	p = ealloc(sizeof(*p));
	p->point.c = c;
	p->point.x = x;
	p->point.y = y;
	return(p);
}

struct string *getstring(s)
char *s;
float x, y;
{
	register struct string *p;

	p = ealloc(sizeof(*p));
	p->string = s;
	return(p);
}
struct item *getn(n)
int n;
{
	register struct item *p;

	p = ealloc(sizeof(*p));
	p->n = n;
	return(p);
}
struct item *getz(z)
float z;
{
	register struct item *p;

	p = ealloc(sizeof(*p));
	p->z = z;
	return(p);
}
freeobj(p)
struct object *p;
{
	struct item *t, *u;

	t = p->itemlist;
	free(p);
	while(t != NULL)
	{
		u = t->next;
		free(t);
		t = u;
	}
}
terminal()
{
	char c;
	float x,y;

	c = ucursor(&x, &y);
	/*
		xxx
	if(eof)
		return(NULL);
	else
	*/
		return(getpoint(c,x,y));
}




readstring(s)
char *s;
{
	prompt();
	fgets(stdin, s);
}
readn()
{
	static int n;

	prompt();
	fscanf(stdin, "%d", &n);
	return(n);
}
float readz()
{
	float z;

	prompt();
	fscanf(stdin, "%f", &z);
	return(z);
}
prompt()
{
}

build(defs)
struct command *defs;
{
	register char *p;
	register struct nametree *l;

	while( (p=(def->iname)) != NULL )
	{
		l = head;
	  next:
		while( c = *p++ )
		{
			while(l->succ != NULL)
			{
				if(l->ch == c)
				{
					l=l->alt;
					goto next;
				}
				l = l->succ;
			}
			l->succ = ealloc(sizeof(*l));
			l = l->succ;
			l->ch = c;
		}
		if(l->alt != NULL)
		{
			fprintf(stderr, "fatal error: %s multiply defined\n", defs->iname);
			return(0);
		}
		l->alt = ealloc(sizeof(*l));
		l->alt->ch = '\0';
		l->alt->succ = defs++;
	}
	return(1);
}
struct object *getobject()
{
}
ealloc(n)
unsigned n;
{
	return(calloc(n));
}
