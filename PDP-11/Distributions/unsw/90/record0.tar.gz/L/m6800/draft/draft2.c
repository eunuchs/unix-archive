struct xxx predef[]
{
	"a", "draw complete board"
	"r", "draw current window"
	"fw", "write to file"
	"fr", "read from file"
	"ff", "define current file"
	"d",	"delete"
	"m",	"point"
	"v",	"vector"
	"g",	"grid"
	"h",	"command listing"
	"bb"	"rectangle"
	"cc"	"circle"
	"arc"	"arc"
	"ww",	"define window"
	0, 0
};
