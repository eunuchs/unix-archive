#include "cplot.h"

upointa(x,y)
float x,y;
{
	g_chtscr(g_px = x,g_py = y);
	g_point();

}
