#include "cplot.h"

g_put( c )
char c;
{
	putc( c, g_out );
}
