# define NUMA	14
# define NUMC 128
# define NUMS 3
# define SIZA	8
# define SIZC	2
# define SIZS	8
# define PTRI 509
# define CHARI 4000
# define PTRX 5147
# define CHARX 40000
# define CONT	0
# define COLL	1
# define SAVE	2
# define OUT	3
# define EGOBL	4
# define SHARP	5
# define PNO	6

# define SKIP	0
# define COLLECT	1
# define SKIP2	2
#define	CREATC	0644
