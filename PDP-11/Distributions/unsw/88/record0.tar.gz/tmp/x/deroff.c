/*
 *	Author Andrew Hume (got sick of /usr/lib/translate)
 */
#include	<stdio.h>

int word[128] =
{
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0
};

main()
{
	register char c;

	for(c = get(); c != EOF;)
	{
		if((c == '.') || (c == '\''))
		{
			/* for time being throw line away */

			while((c != '\n') && (c != EOF)) c = get();
			if(c == '\n') c = get();
		}
		else
		{
			while(1)
			{
				while(c == ' ') c = get();
				while(word[c])
				{
					putchar(c);
					c = get();
				}
				putchar('\n');
				if((c == '\n') || (c == '\0')) break;
				c = get();	/* throw away word sep */
			}
			if(c == '\n') c = get();
		}
	}
}

get()
{
	register char c;

	c = getchar();
	if(c == '\\')
	{
		while(c == '\\') c = getchar();
		switch(c)
		{
		case '*':
			c = getchar();
			if(c == '(')
			{
				getchar();
				getchar();
			}
			break;
		case 'f':
			getchar();
			break;
		case ' ':
			return(' ');
			break;
		case 'n':
			break;
		default:
			break;
		}
		return(getchar());
	}
	else
	{
		return(c);
	}
}
