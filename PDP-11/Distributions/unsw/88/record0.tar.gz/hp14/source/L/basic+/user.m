; The use and distribution of the information
; contained herein may be restricted.
;
.iif	ndf	$list$	.nlist
title	user,<user mode definitions>,24,26-jun-74,mhb/jdm
;
.sbttl	these definitions describe the running job's data area
.sbttl	as maintained by the monitor and the locations for the
.sbttl	critical pointers in the run-time system's pure code
.sbttl	area.
.sbttl					
.sbttl	the running job's unique data area
	org	ucore

tmptag	=	.		;starting here...

$.def.	usrorg	,010		;origin of user's image
$.def.	key	,2		;keyword of job's current status
$.def.	firqb	,fqbsiz		;file request block
$.def.	xrb	,xrbsiz		;transfer control block

$.equ.	jobf	,key		;keyword area
$.equ.	iosts	,firqb		;word of i/o status for errors
$.equ.	job	,firqb+fqjob	;byte of running job number times 2

.iif	ndf	$list$	.list
