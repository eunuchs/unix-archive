; The use and distribution of the information
; contained herein may be restricted.
;
title	px,<print using print control>,24,26-jun-74,mhb/jdm

	org	px

;$$$$$$$$$$3	floating,decimal point,separator	delete 3 for "clean"
fltchr:	.byte	'f	;floating character
dotchr:	.byte	',	;decimal point character
cmachr:	.byte	'.	;comma insertion character
	.even

	.end
