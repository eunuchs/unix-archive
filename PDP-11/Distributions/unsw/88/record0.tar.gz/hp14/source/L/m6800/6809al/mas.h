#


#define	STAR	'*'
#define	TAB	'\t'
#define	SP	' '
#define COLON	':'
#define NL	'\n'
#define CR	'\r'
#define BS	'\b'
#define EOF	'\0'
#define MINUS	'-'
#define PLUS	'+'
#define SLASH	'/'
#define LPAR	'['
#define RPAR	']'
#define QUOTE	'\''
#define COMMA	','
#define PERCEN	'%'
#define BACKSL	'\\'
#define AMPER	'&'
#define AT	'@'
#define DOLLAR	'$'
#define HATCH	'#'
#define EQUAL	'='
#define LTHAN	'<'
#define GTHAN	'>'

#define e_CON	0
#define e_SYM	1
#define e_TL	2
#define e_PC	3

#define e_TERM	0
#define e_PLUS	1
#define e_MINUS	2
#define e_SLASH	3
#define	e_STAR	4
#define e_AMPER	5
#define e_LTHAN	6
#define e_GTHAN	7
#define o_BAD	0
#define o_DUAL	1
#define o_STA	2
#define o_AEI	3
#define o_PUSH	4
#define o_IDEI	5
#define o_DEI	6
#define o_JMPS	7
#define o_BNCH	8
#define o_JBRS	10
#define o_JEQS	11
#define o_A	12
#define o_INH	13
#define o_INH2	14
#define o_LB	15
#define o_RR	16
#define o_PP	17

#define m_IM1	0
#define m_IM2	1
#define m_DIR	2
#define m_EXT	3
#define m_IND	4
#define m_A	5
#define m_BAD	13


#define PSEUDO	100
#define o_BSS	101
#define o_COMM	102
#define o_DATA	103
#define o_END	104
#define o_EQU	105
#define o_FCB	106
#define o_FCC	107
#define o_FDB	108
#define o_GLBL	109
#define o_MON	110
#define o_NAM	111
#define o_OPT	112
#define o_PAG	113
#define o_RMB	114
#define o_TEXT	115
#define o_ZMB	116

#define UND	0
#define EXP	1
#define ABS	2
#define EST	3
#define GLBL	020
#define COMM	040

#define NSYM 200
#define BNSYM 400
#define MAXSYM 1200

#define EXPERR	-1
#define UNDEF	0
#define CABS	1
#define TEXT	2
#define DATA	3
#define BSS	4
#define EXTERNAL 040

#define RTEXT	0100000
#define RDATA	0120000
#define RBSS	0140000
#define REXT	0160000
#define RREL	0010000

#define SMASK	017

struct	symbol {
	char s_name[8];
	unsigned s_pc;
	int s_chain;
	char s_def;
	char s_seg;
};


struct mnems {
	char mn[6];
	char mtyp;
	int mopc;
};


#define NFB  400
struct	fb {
	unsigned fb_pc;
	char fb_def;
	char fb_lab;
	char fb_seg;
};


struct	aform {
	int a_pc;
	int a_def;
};


#define a_EQU	100
#define a_LONG	0
#define a_JBRS	1
#define a_JEQS	2
#define a_DIR	3
#define	a_INDX	4
#define	a_DINDX	6



struct iform {
	int i_pc;
	int i_def;
};

#define i_LONG	1
#define i_DIR	2
#define i_REL	3
#define i_O16	4
#define	i_O8	5
#define	i_O5	6
#define	i_O0	7


struct 	expr {
	char e_rator;
	char e_rand;
	int  e_val;
};



struct	evalx {
	int r_val;
	char r_seg;
	char r_type;
};


/* offsets from listbuf */

#define l_UND	6
#define l_ADR	8
#define l_C1	15
#define l_C4	19
#define l_C2	22
#define l_LAB	32
#define l_EOL	131

/* table sizes */
#define ASIZ	128	/* aform table */
#define ISIZ	128	/* iform table */
#define BUFSIZ	512	/* general buffer size */
#define LBUFSIZ	512	/* listing buffer size */
#define LINSIZ	140	/* output line size */
#define HASHSIZ	128	/* hash table size */

/* output file offsets */
#define TEXTOFFSET 020
