int common[3];

cs1(zz1, zz2, ncount, a1, a2)
int *a1, *a2;
{
	int ww;
	int fs1();

	ww = *a1 + *a2;
	printf("Answer is %d\n", ww);

	fcall(fs1, 2, a1, a2);
}

cs2(zz1, zz2, ncount, a1, a2)
int *a1, *a2;
{
	printf("Arguments are %d %d\n", *a1, *a2);
}
