; The use and distribution of the information
; contained herein may be restricted.
;
title	ccl,<ccl analyzer>,24,26-jun-74,mhb/jdm

.sbttl ccl lexical analyzer

	org	ccl
ccl:	mov	clb(r0),r1	;get lex buffer pointer (current)
	cmp	r1,#phlb	;at start of buffer?
	bne	4$		;nope, so no ccl here
	tst	tllino(r0)	;in immediate mode?
	bne	4$		;nope, so no ccl here either
	bit	stat(r0),#linumf;check for this stat bit
	beq	4$		;no ccl if bit off
	add	r0,r1		;make it absolute
	mov	ccltbl,r4	;get our ccl table pointer
1$:	movb	(r4),r2		;snag offset to next entry
	beq	4$		;if none, then no ccl
	mov	r1,r5		;get temp character pointer
	mov	r4,r3		;and temp table pointer
2$:	tstb	-(r3)		;end of compares?
	bmi	3$		;all matched up if so (found)
	cmpb	(r3),(r5)+	;else compare this character
	beq	2$		;continue if still a match
	add	r2,r4		;else index to next in table
	br	1$		;and continue through table

3$:	mov	stat(r0),r4	;get la's status word for la
	mov	#qzr1,r1	;fake status for la
	sub	r0,r5		;unbais pointer to remainder
	mov	r5,clb(r0)	;and save in ahndy place
	mov	#perccl,(sp)	;change return address for found
4$:	rts	pc		;now exit

global	<qzr1,perccl>

	org	ccltbl
ccltbl:	.word	1$		;pointer to 1st entry
1$:	.byte	0		;no entries in table as yet...
	.even

	.end
