#include "apl.h"

ex_scn0()
{
	fetch1();
	scan0(0);
}

ex_scan()
{
	register struct item *p;

	p = fetch1();
	scan0(p->rank-1);
}

ex_scnk()
{
	register i;

	i = topfix() - thread.iorg;
	scan0(i);
}

scan0(k)
{
	register struct item *p;
	int param[2];
	int scan1();

	p = fetch1();
	if(p->type != DA)
		error("scan T");

	bidx(p);
	colapse(k);
	if(idx.dimk == 0)
		error("scan identity");
	param[0] = p->datap;
	param[1] = exop[*pcp++];
	forloop(scan1, param);
}

scan1(param)
int param[];
{
	register i;
	register data *dp;
	data d;
	data (*f)();

	dp = param[0];
	f = param[1];
	dp =+ access() + (idx.dimk - 1) * idx.delk;
	d = *dp;
	for(i = 1; i < idx.dimk; i++) {
		dp =- idx.delk;
		*dp = d = (*f)(*dp, d);
	}
}

data scalex  1.0;
data scaley  1.0;
data origx  6.0;
data origy  6.0;

int ox, oy;

ex_plot()
{
	register struct item *p;
	register data *dp;
	register i;
	int ic;
	int x, y;
	int sx, sy;

	p = fetch1();
	if(p->type != DA)
		error("plot T");
	if(p->rank != 2)
		error("plot R");
	if(p->dim[1] != 2)
		error("plot C");

	ic = 3;
	sx = ox = -origx*scalex*60.;
	sy = oy = -origy*scaley*48.;

	dp = p->datap;
	if ((i = p->dim[0]) == 0) return;
	ngraph(ox,oy);
	while(i--) {
		x = 60.0 * scalex * *dp++;
		y = 48.0 * scaley * *dp++;
		plot(x,y,ic);
		ic=2;
	}
	plot(sx,sy,3);
	endplt();
}
