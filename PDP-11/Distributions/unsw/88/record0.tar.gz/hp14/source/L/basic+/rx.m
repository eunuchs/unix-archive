; The use and distribution of the information
; contained herein may be restricted.
;
title	rx,<run-time messages>,24,26-jun-74,tph/jdm

.sbttl	***** warning, this source contains lower case characters
.sbttl					

	.enabl	lc

	.csect	rx

	.globl	crlf0,asknew,askold,asknam,readym,prompt,atline
crlf0:	.byte	12,0

asknew:	.asciz	"New"

askold:	.asciz	"Old"

asknam:	.asciz	" file name--"

readym:	.byte	12
	.ascii	"Ready"
	.byte	12,12,00

prompt:	.asciz	"? "

atline:	.asciz	" at line"

	.even

	.end
