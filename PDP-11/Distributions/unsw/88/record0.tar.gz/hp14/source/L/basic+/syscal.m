; The use and distribution of the information
; contained herein may be restricted.
;
; macro to perform unix-style 'indirect' sys calls
	.macro	sys	operator,arg1,arg2,arg3,arg4,arg5
	.if	nb arg1
	mov	arg1,syscb+2
	.endc
	.if	nb arg2
	mov	arg2,syscb+4
	.endc
	.if	nb arg3
	mov	arg3,syscb+6
	.endc
	.if	nb arg4
	mov	arg4,syscb+10
	.endc
	.if	nb arg5
	mov	arg5,syscb+12
	.endc
	mov	#operator,syscb
	indir.
	 +	syscb		; do the call
	.endm	sys
; the unix sys calls defined
	.macro	$$$sys
	.macro	$$$def	name,operator
	.iif gt operator-377,.error	<bad 'sys' call format>
	name'.	=	104400+operator
	.endm	$$$def
	$$$def	break,17.
	$$$def	creat,8.
	$$$def	csw,38.
	$$$def	chdir,12.
	$$$def	chmod,15.
	$$$def	chown,16.
	$$$def	close,6.
	$$$def	dup,41.
	$$$def	exec,11.
	$$$def	exit,1.
	$$$def	fork,2.
	$$$def	fstat,28.
	$$$def	clktim,40.
	$$$def	nostack,50.
	$$$def	fpstat,51.
	$$$def	getgid,47.
	$$$def	getpid,20.
	$$$def	getuid,24.
	$$$def	gtty,32.
	$$$def	indir,0.
	$$$def	kill,37.
	$$$def	link,9.
	$$$def	mknod,14.
	$$$def	mount,21.
	$$$def	nice,34.
	$$$def	open,5.
	$$$def	pipe,42.
	$$$def	profil,44.
	$$$def	read,3.
	$$$def	seek,19.
	$$$def	setgid,46.
	$$$def	setuid,23.
	$$$def	signal,48.
	$$$def	sleep,35.
	$$$def	stat,18.
	$$$def	stime,25.
	$$$def	stty,31.
	$$$def	sync,36.
	$$$def	time,13.
	$$$def	times,43.
	$$$def	umount,22.
	$$$def	unlink,10.
	$$$def	wait,7.
	$$$def	write,4.
	.endm	$$$sys
	$$$sys				; define the calls
