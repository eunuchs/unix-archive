; The use and distribution of the information
; contained herein may be restricted.
;
; signals defined
	.macro	$$$sig	name
sig'name=	tmptag
	tmptag = tmptag + 1
	.endm
	tmptag = 1
	$$$sig	hup
	$$$sig	int
	$$$sig	qit
	$$$sig	ins
	$$$sig	trc
	$$$sig	iot
	$$$sig	emt
	$$$sig	fpt
	$$$sig	kil
	$$$sig	bus
	$$$sig	seg
	$$$sig	sys
	$$$sig	pip
	$$$sig	ter
	$$$sig	clk
	$$$sig	cpu
	$$$sig	par
