; The use and distribution of the information
; contained herein may be restricted.
;
	.title	ccl table


	.macro	ccltbl	u,xarg,a,b,c,d,e,f,g,h,i,j,k,l,m,n

		$$$$$ = .-1
		.psect	ccltbl
			.byte	200+tmptag,122,-1
			.ascii	!'n'm'l'k'j'i'h'g'f'e'd'c'b'a'!
			.byte	$$$$$-.
		.psect	cclprg
			.word	xarg
			.word	'r-''u
		.psect	ccltbl
		tmptag = tmptag+4
	.endm

tmptag = 0

	.psect	ccltbl
ccltbl:	.word	cclend
	.byte	0



;*********************************************************************

	ccltbl	u,catarg,c,a,t
	ccltbl	u,catarg,c,a,t,a,l,o,g
	ccltbl	u,catarg,c,a,t,a,l,o,g,u,e
	ccltbl	r,jnkarg,j,u,n,k


;++++++ the argument tables specified above.
;++++++ RSTS format:
;++++++    arg ->   .byte  # of bytes in file name
;++++++             .ascii +filename+
;
;++++++ UNIX format:
;++++++    arg ->   address of word where the rest of command line's address is to be placed
;			(in the argument list, of course)
;		    the pointers to the arguments, ended, as is proper, with a zero.
;			(the zero'th argument must be the program name)

	.psect	cclstr
	.enabl	lc

catarg:	.word	2$
	.word	1$
	.word	3$
2$:	.blkw
	.word	0
1$:	.asciz	+/bin/ls+
3$:	.asciz	+-l+
	.even

jnkarg:	.byte	5
	.ascii	+$junk+
	.even

	.dsabl	lc
;*********************************************************************

	.psect	ccltbl
cclend = .-1
	.even
	.end
