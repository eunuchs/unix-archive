
/*  program to convert a.out files to gtload format for remote loading */
/* Note that the bss segment is NOT initialised in UNIX, and does not appear
   in an a.out file */

int inbuf[259];		/* input buffer */
int outbuf[259];	/* output buffer */
int p;			/* packing buffer */
int s[4];
int sum;		/* check sum */

main(argc,argv)
int argc;
char **argv;

{
int psize,dsize,bsize,ssize,rbsf,blength,length,i;

if (argc != 3)
	{printf("Usage: utg inputfile outputfile\n"); exit(1); }
if (fopen(argv[1],inbuf)<0)
	{printf("Cannot open input file"); exit(1); }
fcreat(argv[2],outbuf);

if (getw(inbuf) != 0407)
	{printf("File not accepted a.out format"); exit(1); }

psize=getw(inbuf); dsize=getw(inbuf); bsize=getw(inbuf); ssize=getw(inbuf);
getw(inbuf); getw(inbuf); rbsf=getw(inbuf);

length=psize+dsize;
blength=length+6;

init();
putc('}',outbuf); putc('R',outbuf); putc('}',outbuf); putc('L',outbuf);
for (i=1; i<=8; i++) putc('@',outbuf);
cput(0); cput(1); cput(0);
cput(blength & 0377); cput(blength >> 8);
cput(0); cput(0);
for (i=1; i <= length; i++) {cput(getc(inbuf));}
cput(0400-(sum & 0377));   

for (i=1;i<=6;i++) cput(0);


cput(1); cput(0); cput(6); cput(0);
cput(0); cput(0); cput(0371);

squirt(); fflush(outbuf);

}

cput(c)
int c;
{

sum =+ c;
if (p>3)
	{ putsix(s[1]>>2);
	  putsix(s[1]<<4|s[2]>>4);
	  putsix(s[2]<<2|s[3]>>6);
	  putsix(s[3]); p=1; }
s[p++]=c; }


squirt()
{
int i;
for (i=1; i<4; i++) cput(0);		/* pad remainder with nulls */
}


init()
{sum= 0; p=1;}


putsix(c)
char c;
{c=c & 077; putc(c<040?c+0100:c,outbuf);}

