/*
 *	A simple drafting system
 *
 *		Adrian Freed
 *
 *	For Tektronix terminals with cross-hair cursors
 *	and GT40's
 *
 */

#include <cplot.h>


#define TRUE 1
#define FALSE 0
struct object
{
	struct iteml *itemlist;
	struct command *cm;
	struct object *nextobject;
};

struct iteml
{
	struct item *val;
	struct iteml *link;
};

struct pt
{
	float x, y;
	char c;
};
union item
{
	struct pt point;
	char *string;
	int n;
	float z;
};
struct command
{
	char *iname;	/* invokation name */
	char *desc;	/* description string */
	char sflag;	/* saveable command */
	int (*func)();
};

/* binary tree for command search */
struct nametree
{
	char ch;
	struct nametree *succ;
	struct nametree *alt;
};

char exitflag = FALSE;

struct objext *head, *tail;	/* the head and tail of the object list */
