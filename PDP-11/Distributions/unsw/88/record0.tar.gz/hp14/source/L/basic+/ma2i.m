; The use and distribution of the information
; contained herein may be restricted.
;
title	ma2i,<2-word math with fis>,24,26-jun-74,mhb/jdm

.sbttl	parameters for fis 2-word math package

fltlen	=	2
.math.	=	0
;no fpu
fis	=	1
