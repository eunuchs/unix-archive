	.sbttl	order the csects in core
	.sbttl	establish proper default attributes


	.psect	unx,shr,rel,ovr,gbl
	.psect	pt,shr,rel,ovr,gbl
	.psect	rc,shr,rel,ovr,gbl
	.psect	ui,shr,rel,ovr,gbl
	.psect	ti,shr,rel,ovr,gbl
	.psect	ec,shr,rel,ovr,gbl
	.psect	sctbl,shr,rel,ovr,gbl
	.psect	pn,shr,rel,ovr,gbl
	.psect	sc,shr,rel,ovr,gbl
	.psect	scdsp,shr,rel,ovr,gbl
	.psect	su,shr,rel,ovr,gbl
	.psect	mi,shr,rel,ovr,gbl
	.psect	la,shr,rel,ovr,gbl
	.psect	ccl,shr,rel,ovr,gbl
	.psect	xt,shr,rel,ovr,gbl
	.psect	pu,shr,rel,ovr,gbl
	.psect	tr,shr,rel,ovr,gbl
	.psect	ed,shr,rel,ovr,gbl
	.psect	zt,shr,rel,ovr,gbl
	.psect	cclprg,shr,rel,ovr,gbl
	.psect	cclstr,prv,rel,ovr,gbl
	.psect	usodt,shr,rel,ovr,gbl
	.psect	rx,shr,rel,ovr,gbl
	.psect	po,shr,rel,ovr,gbl
	.psect	ma,shr,rel,ovr,gbl
	.psect	xf,shr,rel,ovr,gbl
	.psect	dm,shr,rel,ovr,gbl
	.psect	mf,shr,rel,ovr,gbl
	.psect	up,shr,rel,ovr,gbl
	.psect	io,shr,rel,ovr,gbl
	.psect	px,shr,rel,ovr,gbl
	.psect	mx,shr,rel,ovr,gbl
	.psect	ccltbl,shr,rel,ovr,gbl
	.psect	pa,shr,rel,ovr,gbl
	.psect	fiptbl,shr,rel,ovr,gbl
	.psect	emtend,shr,rel,ovr,gbl
	.psect	udata,prv,con,gbl
	.psect	ucore,bss,ovr,gbl
	.blkb	<kcore*cormin>
	.even
	.end
