#


#include	"mash.c"


char *symtmp, *fbtmp, *itmp, *ltmp;
int sfile, fbfile, ifile;

struct iform *iptr;
int icount;
extern struct iform ibuf[];

extern char listbuf[], line[];
char *lbp, *linep;
char *head;
int lfile;

int obfile;

extern char inbuf[];
char *nextch;
char tch;
extern struct symbol *symtab;
extern int nsym;
extern struct mnems mnem[];
extern int nmnem;
int type, opct, mode;
extern mist[][5];

extern hashtab[];
extern struct fb *fbtable;
extern curfb[];
extern char symbuf[];

int gargc;
char **gargv;


int numsym;
int ofstbts,postbyte,regi;
int lab, undef;
int list;

struct segment segopt;

int nextfb;

int findes;
int nchar;
char *fins;
int qcompar();


int spc, pc, fls 0;
int lc;
int pl 44 /* default page length */;
extern lpc;
int operand;
int errf;


main(argc, argv)
char **argv;
{
	register char *s, c;
	register n;
	int l;
	char *p;

	write(2,"pass2\n",6);
	ltmp = "/tmp/motmx.5";
	c = *(ltmp+9) = argv[0][0];	/* temp file char */
	gargc = --argc;
	gargv = ++argv;
	n = NSYM;

	while(*gargv[0] == '-')
	{
		switch(gargv[0][1])
		{
		case 'l':
				if(gargv[0][2] == 'm')
					pl = 58;
				list = 1;
				break;
		case 's':
				p = &gargv[0][2];
				if(*p == 0)
					n = BNSYM;
				else
				{
					n = 0;
					while((*p >= '0') && (*p <= '9'))
					{
						n = n*10 + *p++ -'0';
					}
				}
				if(n < NSYM)
					n = NSYM;
				n =& ~1;
				if(n > MAXSYM)
					n = MAXSYM;
				break;
		}
		gargv++;
		gargc--;
	}
	if((l = symtab = alloc(n * sizeof *symtab)) == -1
		|| (l = fbtable = alloc (n/2 * sizeof *fbtable)) == -1)
	{
		printf("pass2 out of memory\n");
		exit();
	}
	findes = dup(0);	/* give newfile something to close */

	symtmp = "/tmp/motmx.0";
	fbtmp = "/tmp/motmx.1";
	itmp = "/tmp/motmx.2";
	*(symtmp+9) = c;
	*(fbtmp+9) = c;
	*(itmp+9) = c;

	if ( (sfile = open(symtmp,0)) == -1 )
		help();
	if ( (fbfile = open(fbtmp,0)) == -1 )
		help();
	read(sfile, hashtab, 256);
	s = symtab;
	do {
		n = read(sfile, s, 512);
		s =+ n;
		numsym =+ n;
	}
	while ( n == 512 );
	numsym =/ 14;

	s = fbtable;
	do {
		n = read(fbfile, s, 512);
		s =+ 512;
	}
	while ( n == 512 );

	close(sfile);
	close(fbfile);
	unlink(symtmp);
	unlink(fbtmp);

	if ( (ifile = open(itmp, 0)) == -1 )
		help();
	icount = read(ifile, ibuf, 512);
	iptr = ibuf;
	icount =>> 2;

	if ( (obfile = creat("m.out",0644)) == -1 )
		help();

	if( list &&  ((lfile = creat("m.lst",0644)) == -1 ))
		help();

	nextfb = 20;
	for ( n=0; n<20; n++ )
		curfb[n] = n;

	{
		register struct mnems *p;

		p = &mnem[0];

		while(p->mn[0] != 0)
		{
			p++;
			nmnem++;
		}
	}
	s = "L\nM6809\n";
	write(obfile, s, 8);
	newrec();
	if ( newfile() == 0 )
		help();
	lbp = listbuf;
	lcopy(&line);
	head= "\n Motorola 6809 Assembler                                                                                                 Page    \n\n\n";
	{
		register char *s1, *s2;
		char *ijtime();
		s1 = &head[90];
		s2 = ijtime();
		s2[24] = '\0'; /* get the newline */
		s2 = &s2[4];   /* get the day */
		while(*s2)
			*s1++ = *s2++;
	}
	linep = &line[l_LAB];
	if ( (c = getch()) == '#' ) {
		lc++;
		getsym(getnonbl());
		if ( (c = getnonbl()) == MINUS ) {
			c = getch();
			segopt.segtype = 2;
		}
		else
			segopt.segtype = 1;
		segopt.segchar = c;
		segopt.segcount++;
		tch = getch();
		lcomma();
	}
	else
		nextch--;

	for (;;)		/* main loop */ {
		spc = pc;
		undef = lab = 0;
		header();
		lc++;
		lpc++;
		linep = &line[l_LAB];
		if ( (c = tch = getch()) == EOF ) {
			if ( newfile() )
				continue;
			break;
		}

		switch (c) {
		case NL:
			lcomma();
			continue;

		case SP:
		case TAB:
			tch = c;
			break;

		case STAR:
			lcoml();
			continue;

		default:
			getsym(c);
			if ( digit(c) )
				deffb(c-'0');
			else
			{
				lab = lookup();
			}
		}

		if ( (c = tch) != NL )
			c = getnonbl();
		if ( (tch = c) == NL ) {
			lcomm();
			continue;
		}

		if ( (n = getmnem(c)) == -1 )	/* get op code */
			continue;		/* -1 means done */
		lcomm();
	}

	if ( iins(i_REL) == 0 )
	{
		write(2, "main\n", 5);
		syserr();
	}
	outrec();
/*
	endrec();
*/
	if ( n = segopt.segcount )
		llocals(n);
	lglobals();
	unlink(itmp);
	unlink(ltmp);
	exit();
}



outopc(opc)
{
	if(opc > 0xff)
		outbyte(opc >> 8);
	outbyte(opc);
}






deffb(ind)
{
register i;

	i = ind;
	curfb[i] = curfb[i+10];
	curfb[i+10] = nextfb++;
}



newfile()
{
	close(findes);
	if ( gargc-- ) {
		fins = *gargv++;
		if ( (findes = open(fins,0)) == -1 )
			return(newfile());
		nchar = read(findes, nextch=inbuf, 512);
		lc = 0;
		errf = 0;
		return(1);
	}
	return(0);
}




getmnem(ch)
char ch;
{
register char acc;
register opc;
register  n;
int adrm;
long lm;

	n = getsym(ch);

	symbuf[n] = 0;
	mnemlook();
	switch ( type ) {
	case o_A:
		mode = getoper();
		switch(mode){
		case m_IM1:
		case m_IM2:
			if (mist[opct][m_IM1] == 1){
				mode = m_IM2;
				}
			lcode1(opc = mist[opct][mode]);
			outopc(opc);
			if(mode == m_IM2) {
				lcode3(operand);
				outword(operand);
			}
			else {
				lcode2(operand);
				outbyte(operand);
			}
			break;
		case  m_EXT:
		case m_DIR:
			lcode1(opc = mist[opct][mode]);
			outopc(opc);
			if(mode == m_DIR) {
				lcode2(operand);
				outbyte(operand);
			}
			else {
				lcode3(operand);
				outword(operand);
			}
			break;
		case m_IND:
		case m_PCR:
			lcode1(opc = mist[opct][m_IND]);
			outopc(opc);
			lcode4(postbyte);
			outbyte(postbyte);
			if(mode == m_PCR)
				operand =- pc+ofstbts; /*get the offset */
			mode = m_IND;
			if(ofstbts == 2) {
				lcode3(operand);
				outword(operand);
			}
			if(ofstbts == 1) {
				lcode2(operand);
				outbyte(operand);
			}
			break;
		case m_BAD:
		default:
			write(2, "getmnem\n", 8);
			syserr();
		}
		opc = mist[opct][mode];
		break;
	case o_PP:
		getPP();
		goto rr;
	case o_RR:
		getregop();
	rr:
		lcode1(opct);
		outopc(opct);
		lcode2(postbyte);
		outbyte(postbyte);
		break;
	case o_INH2:
	case o_INH:
		opc = opct;
		lcode1(opc);
		outopc(opc);
		break;
	case o_LB:
		opc = opct;
	longbr:
		lcode1(opc);
		outopc(opc);
		n = getexpr(0);
		laddr(n);
		n =- pc+2;
		lcode3(n);
		outword(n);
		break;
	case o_BNCH:
		opc = opct;
	brnch:
		lcode1(opc);
		outopc(opc);
		operand = n = getexpr(0);
		if ( undef )
			n = -2;
		else
		{
			laddr(n);
			n =- pc+1;
			if ( (n < -128) || (n > 127) ) {
				brerr();
				n = 0;
			}
		}
		operand = n & 0377;
		lcode2(operand);
		outbyte(operand);
		break;

	case o_JBRS:
		if (iins(i_LONG)) {
			opc = opct >> 8;
			goto longbr;
		}
		else {
			opc = opct & 0xff;
			goto brnch;
		}
	case o_JEQS:
		if ( iins(i_LONG) ) {
			opc = opct;
			goto longbr;
		}
		else {
			opc = opct & 0xff;
			goto brnch;
		}

	default:
		pseudop(type);
		return(-1);
	}

	return(opc);
}



help()
{
	printf("help - temp files lost\n");
	unlink(ltmp);
	unlink(symtmp);
	unlink(fbtmp);
	unlink(itmp);
	exit();
}




iins(i)
char i;
{
	if ( (iptr->i_def == i) && (spc == iptr->i_pc) ) {
		if ( --icount ) {
			iptr++;
			return(1);
		}
		icount = read(ifile, ibuf, 512);
		icount =>> 2;
		iptr = ibuf;
		return(1);
	}
	return(0);
}



syserr()
{
	error("assembler error",0);
}


error(s, f)
char *s;
{
	if(errf == 0)
	{
		printf("%s:\n", fins);
		errf = 1;
	}
	if(f)
		printf("%5.d\t%s %s\n", lc, s, symbuf);
	else
		printf("%5.d\t%s\n", lc, s);
}


brerr()
{
	error("branch error",0);
	line[l_UND] = 'B';
}


fbund()
{
register char *s;
	error("Ufb", 1);
}


underr()
{
register char *s;

	error("U", 1);
}
