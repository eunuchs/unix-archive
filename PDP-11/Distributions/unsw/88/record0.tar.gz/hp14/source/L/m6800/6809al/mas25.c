#

#include	"mas.h"


extern struct mnems mnem[];
extern int nmnem;
extern  type, opct;
extern struct symbol *symtab;
extern hashtab[];
extern int numsym;
extern char symbuf[];




mnemlook()
{
	register struct mnems *first, *last, *mid;
	first = &mnem[0];
	last = &mnem[nmnem];

	while(first+1 < last)
	{
		mid = first + (last - first)/2;
		if(less(mid->mn,symbuf))
			first = mid;
		else
			last = mid;
	}
	if(mncompar(last->mn, symbuf))
	{
		type = last->mtyp;
		opct = last->mopc;
		return type;
	}
	type = o_BAD; return(0);
}

less( p1, p2)
register char *p1, *p2;
{
	register i 0;
	while(i++ < 6)
	{
		if(*p2 == *p1)
		{
			if(*p1 == '\0')
				return 0;
			p2++; p1++;
			continue;
		}
		return *p1 < *p2;
	}
	return 0;
}

mncompar(p1, p2)
register char *p1, *p2;
{
	register i 0;

	while(i++ < 6)
	{
		if(*p2 == *p1)
		{
			if(*p1++ == '\0')
				return 1;
			p2++;
			continue;
		}
		return 0;
	}
	return 1;
}

lookup()
{
register j;
register struct symbol *sym  ;
register char *s;
char loc;

	loc = 0;
	s = symbuf;
	j = hashtab[ hash(s) ];
	do {
		sym = &symtab[j];
		if (compar(&sym->s_name[0],s))
			return(j);
	}	while ( (j = sym->s_chain) != 0 );
	write(2, "lookup\n", 7);
	syserr();
}
 
 
 
hash(a)
char *a;
{
register char *s;
register char c;
register h;
	h = 0;
	s = a;
	while ( (c = *s++) != '\0' )
		h =+ (c - 61) * 29;
	if (h < 0)
		h = -h;
	return( h % 127 );
}
 
 
 
compar(a1, a2)
char *a1, *a2;
{
register char *s1, *s2;
register char c;
int	i;
	s1 = a1;
	s2 = a2;
	i = 0;

	while ( (c = *s1++) == *s2++ )
		if(( ++i == 8) || ( c == '\0' ))
			return(1);
	return(0);
}
