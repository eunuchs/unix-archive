#include <sgtty.h>

struct sgttyb tty;

main(c,v)
char **v;
{
	gtty(1, &tty);
	tty.ispeed = B9600;
	tty.ospeed = B9600;
	stty(1, &tty);
}
