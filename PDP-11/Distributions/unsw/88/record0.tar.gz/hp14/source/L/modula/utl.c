/* Program to convert a.out format files to standard absolute
   loader format for remote loading LSI11's.      NPH         */

int inbuf[259];		/* input buffer */
int outbuf[259];	/* output buffer */
int sum;		/* check sum */

main(argc,argv)
int argc;
char **argv;

{
int psize,dsize,bsize,ssize,rbsf,blength,length,i;

if (argc != 3)
	{printf("Usage: UTL inputfile outputfile\n"); exit(1); }
if (fopen(argv[1],inbuf)<0)
	{printf("Cannot open input file"); exit(1); }
fcreat(argv[2],outbuf);

if (getw(inbuf) != 0407)
	{printf("File not accepted a.out format"); exit(1); }

psize=getw(inbuf); dsize=getw(inbuf); bsize=getw(inbuf);
ssize=getw(inbuf); getw(inbuf); getw(inbuf); rbsf=getw(inbuf);

/* The length calculation following does not include 'bsize'
   because otherwise we will start reading the symbol table
   and that may contain spurious block header flags */

length=psize+dsize;
blength=length+6;

sum=0;
cput(1); cput(0); /* block header flag */
cput(blength & 0377); cput(blength >> 8); /* byte count */
cput(0); cput(0); /* load address */
for (i=1; i <= length; i++) {cput(getc(inbuf));}
cput(0400-(sum & 0377)); /* checksum byte */   

for (i=1;i<=6;i++) cput(0); /* some filler nulls between blocks */

/* Final block including start address */
cput(1); cput(0); cput(6); cput(0);
cput(0); cput(0); cput(0371);

fflush(outbuf);

}

cput(c)
int c;
{
sum =+ c;
putc(c,outbuf);
}
