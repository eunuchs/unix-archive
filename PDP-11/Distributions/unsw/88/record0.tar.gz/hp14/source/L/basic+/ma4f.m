; The use and distribution of the information
; contained herein may be restricted.
;
title	ma4f,<4-word math with fpu>,24,26-jun-74,mhb/jdm

.sbttl	parameters for fpu 4-word math package

fltlen	=	4
.math.	=	0
decmap	=	1
fpu	=	1
fpv	=	1
f0	=	%0
f1	=	%1
f2	=	%2
f3	=	%3
f4	=	%4
f5	=	%5
;no fis
