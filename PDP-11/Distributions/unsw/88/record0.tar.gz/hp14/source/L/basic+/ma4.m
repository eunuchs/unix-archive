; The use and distribution of the information
; contained herein may be restricted.
;
title	ma4,<4-word math>,24,26-jun-74,mhb/jdm

.sbttl	parameters for non-fpu/fis 4-word math package

fltlen	=	4
.math.	=	0
decmap	=	1
;no fpu
;no fis
