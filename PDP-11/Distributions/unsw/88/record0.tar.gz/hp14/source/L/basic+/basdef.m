; The use and distribution of the information
; contained herein may be restricted.
;
.title	basic definitions
.sbttl		definitions for unix basic-plus
.sbttl		constants, conditional assembly code, etc.

	.nlist	me
	xsys	=	0			;extended system support
	alrm	=	1			;has alarum
	chnmax	=	15.			;max channel number
	basopn	=	2			;basic open type
	wrtopn	=	1			;write only
	roopen	=	0			;read only
	timzon	=	0.			;time zone
	flgopn	=	1			;open flag
	flgodt	=	2			;ddt flag
	flgin	=	4			;open for input
	flgou	=	10			;open for output
	ermlen	=	32.			;length of error msg
	errmax	=	50.			;max UNIX error code
	cormin	=	8.			;initial core --- 8Kw
				; 64 was 15, it should ask for lots this way
				; especially since i&d space separation is used
	cormax	=	64.			;maximum core --- 64Kw
	kcore	=	1024.*2.		;1k = 1024w x 2b
	dskbfl	=	512.			;disk buffer length
	kbbfl	=	128.			;KB: buffer length
	basmod	=	604			;file creation mode
	exemod	=	705			;executable file
	arrow	=	137			;continuation (arrow)
	crbit	=	1			;<cr> flag bit
	nlbit	=	2			;<nl> flag bit
