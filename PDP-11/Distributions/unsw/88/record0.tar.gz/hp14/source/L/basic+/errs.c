main()
{
	char	 line[64];
	int	of;
	register int n;
	register char c,*cp;

	of = creat("/usr/lib/basic.errf",0644);

	do {
		n = 64;
		cp = line;
		do *cp++ = 0; while(--n);
		cp = line;
		while((c = getchar()) && c != '\n') *cp++ = c;
		write(of,line,32);
	} while(c);
	close(of);
}
