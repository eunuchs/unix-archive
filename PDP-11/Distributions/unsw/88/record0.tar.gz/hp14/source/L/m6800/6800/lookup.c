#include	"mas0.h"
#include	"table1"
#include	"table2"


char symbuf[18];

main(argc, argv)			/* mnemlook */
char **argv;
{
	register char *s;
	register j;
	register char *s1;

	for(;;)
	{
		printf("\nEnter mnemonic: ");
		s = symbuf;
		while ((*s = getchar()) != '\n')
		{
			if (*s++ == '\0')
			{
				putchar('\n');
				exit();
			}
		}
		*s = 0;
		s = symbuf;
		while (*s) *s++ =| 040;
		s = symbuf;
		j = (*s++ - 80) * 188;
		j =+ (*s++ - 80) * 15;
		s = *s - 80;
		s =~ s;
		j =+ s << 5;
		j =% 511;
		if (j < 0) j = -j;
		s = symbuf;
		s1 = mnemtab[j];
		printf("mnemtab[%d] = %s\ttype: %2d (0%o)\tcode: X'%2x\n",
			j, s1, maddr[j], maddr[j], mcode[j]);
	}
}
