; The use and distribution of the information
; contained herein may be restricted.
;
.iif	ndf	$list$	.nlist
title	sypp,<push-pop definitions>,24,26-jun-74,mhb/jdm
;
.macro	..	qq1,qq2		;enter push-pop table entry
	org	pt,qq1+128.*2
	.word	qq2
.endm

; push-pop code definitions

.macro	$ppdef	name,dummy
name	=	tmptag
.list
name	=	name
.nlist
tmptag	=	tmptag+1
.endm

tmptag	=	-128.		;start the list here

	$ppdef	ppaddf,addf	;floating +
	$ppdef	ppaddi,addi	;integer +
	$ppdef	ppsubf,subf	;floating -
	$ppdef	ppsubi,subi	;integer -
	$ppdef	pprsbf,rsubf	;floating reverse -
	$ppdef	pprsbi,rsubi	;integer reverse -
	$ppdef	ppmulf,mulf	;floating *
	$ppdef	ppmuli,muli	;integer *
	$ppdef	ppdivf,divf	;floating /
	$ppdef	ppdivi,divi	;integer /
	$ppdef	pprad$,rad50$	; radix 50 function
	$ppdef	ppswap,swapby	;integer swap byte function
	$ppdef	pppwrf,pwrf	;floating ^
	$ppdef	pppwri,pwri	;integer ^
	$ppdef	ppeqf,.eq.f	;floating equal operator
	$ppdef	ppeqi,.eq.i	;integer equal operator
	$ppdef	ppeqs,.eq.s	;string equal oprerator
	$ppdef	ppevs,.ev.s	;string equivalence
	$ppdef	ppgtf,.gt.f	;floating >
	$ppdef	ppgti,.gt.i	;integer >
	$ppdef	ppgts,.gt.s	;string >
	$ppdef	ppgef,.ge.f	;floating >=
	$ppdef	ppgei,.ge.i	;integer >=
	$ppdef	ppges,.ge.s	;string >=
	$ppdef	ppltf,.lt.f	;floating <
	$ppdef	pplti,.lt.i	;integer <
	$ppdef	pplts,.lt.s	;string <
	$ppdef	pplef,.le.f	;floating <=
	$ppdef	pplei,.le.i	;integer <=
	$ppdef	pples,.le.s	;string <=
	$ppdef	ppnef,.ne.f	;floating <>
	$ppdef	ppnei,.ne.i	;integer <>
	$ppdef	ppnes,.ne.s	;string <>
	$ppdef	ppnegf,negf	;floating complement
	$ppdef	ppnegi,negi	;integer complement
	$ppdef	ppushf,pushf	;floating push
	$ppdef	ppushi,pushi	;integer push
	$ppdef	ppushs,pushs	;string push
	$ppdef	ppopf,popf	;floating pop
	$ppdef	ppopi,popi	;integer pop
	$ppdef	ppops,pops	;string pop
	$ppdef	pprepf,replf	;replicate floating
	$ppdef	pprepi,repli	;replicate integer
	$ppdef	ppreps,repls	;replicate string
	$ppdef	ppido1,indo1	;index operand one subscript on stack
	$ppdef	ppido2,indo2	;index operand two subscripts on stack
	$ppdef	ppidr1,indr1	;index result one subscript on stack
	$ppdef	ppidr2,indr2	;index result two subscripts on stack
	$ppdef	ppirr1,indl1	;index, replicate one subscr.
	$ppdef	ppirr2,indl2	;index, replicate two subscrs.
;the following 12 ops should occur consecutively
;with ppflpf first and ppflr2 last
	$ppdef	ppflpf,fpopf	;float+popf
	$ppdef	ppfipi,ipopi	;fix+popi
	$ppdef	ppflrf,freplf	;float+replf
	$ppdef	ppfiri,irepli	;fix+repli
	$ppdef	ppfid1,iinr1	;fix+indr1
	$ppdef	ppfld1,finr1	;float+indr1
	$ppdef	ppfir1,iinl1	;fix+inrr1
	$ppdef	ppflr1,finl1	;floatnrr1
	$ppdef	ppfid2,iinr2	;fix+indr2
	$ppdef	ppfld2,finr2	;float+indr2
	$ppdef	ppfir2,iinl2	;fixnrr2
	$ppdef	ppflr2,finl2	;float+inrr2
	$ppdef	ppfix0,pushi0	;push an integer 0
	$ppdef	ppfix,fix	;fix a floating point number
	$ppdef	ppflt,flt	;float an integer
	$ppdef	ppflt1,flt1	;special float
	$ppdef	ppsin,sin	;calculate the sine
	$ppdef	ppcos,cos	;calculate the cosine
	$ppdef	ppatan,atan	;calculate inverse tangent
	$ppdef	ppsqrt,sqrt	;calculate square root
	$ppdef	ppexp,exp	;calculate exponential 
	$ppdef	ppln,log	;calculate logririthm
	$ppdef	pplg10,log10	;claculate logrithm of 10
	$ppdef	pprnd,rnd	;find a random number
	$ppdef	ppfixf,fixf	;fix function
	$ppdef	pptan,tan	;calculate tangent
	$ppdef	pplen,len	;find string length
	$ppdef	ppspac,spaces	;make string of spaces
	$ppdef	ppsbst,substr	;find substring
	$ppdef	ppsbs1,subst1	;find other substring
	$ppdef	ppinst,instr	;find if in there at all
	$ppdef	ppnum,num$	;function num$
	$ppdef	ppval,val	;function val
	$ppdef	ppsgnf,sgnf	;sign function
	$ppdef	ppintf,intf	;int function
	$ppdef	ppabsf,absf	;abs function
	$ppdef	ppuj,uj		;unconditional jump
	$ppdef	ppujx,ujx	;unconditional jump external
	$ppdef	ppifj,ifj	;if false jump
	$ppdef	ppifjx,ifjx	;if false jump external
	$ppdef	ppitj,itj	;if true jump
	$ppdef	ppitjx,itjx	;if true jump external
	$ppdef	ppentr,entr	;enter function
	$ppdef	ppxit,exit	;exit from function
	$ppdef	ppushx,pushjx	;push and jump external
	$ppdef	ppopj,popj	;pop jump return
	$ppdef	ppnot,.not.	;logical not
	$ppdef	ppand,.and.	;logical and
	$ppdef	ppor,.or.	;logical or
	$ppdef	ppxor,.xor.	;logical xor
	$ppdef	ppimp,.imp.	;logical implies
	$ppdef	ppiff,.iff.	;logical if and only if
	$ppdef	ppredf,readf	;read floating
	$ppdef	ppredi,readi	;read integer
	$ppdef	ppreds,reads	;read string
	$ppdef	ppconc,concat	;string concatenate
	$ppdef	ppenda,endrpt	;end of conditional operator
;	the following 12 opcodes are position dependent
;	do not change the order
	$ppdef	ppfri,fori	;for integer entry
	$ppdef	pprpi,repti	;repeat integer
	$ppdef	ppfrf,forf	;for floating
	$ppdef	pprpf,reptf	;repete floating
	$ppdef	ppfrix,forix	;for integer external
	$ppdef	pprpix,reptix	;repete integer external
	$ppdef	ppfrfx,forfx	;for floating external
	$ppdef	pprpfx,reptfx	;repeat floating external
	$ppdef	ppnxi,nexti	;next integer
	$ppdef	ppnxf,nextf	;next floating
	$ppdef	ppnxix,nextix	;next integer external
	$ppdef	ppnxfx,nextfx	;next floating external
	$ppdef	ppclos,closer	;close
	$ppdef	ppssi,ssi	;select slot for input
	$ppdef	ppsso,sso	;select slot for output
	$ppdef	ppinpl,inputl	;input line
	$ppdef	ppinpf,inputf	;input floating
	$ppdef	ppinpi,inputi	;input integer
	$ppdef	ppinps,inputs	;input string
	$ppdef	pprinf,printf	;print floating
	$ppdef	pprini,printi	;print integer
	$ppdef	pprins,prints	;print string
	$ppdef	ppcoma,nxtzon	;print comma thing
	$ppdef	ppcrlf,crlf	;print <cr><lf>
	$ppdef	ppstop,stop	;stop execution
	$ppdef	pphalt,ujx6	;halt after immediate execution
	$ppdef	ppbadc,badcod	;illegal statement
	$ppdef	ppuuo,uuocon	;uuo control
	$ppdef	pptab,tabf	;tab function
	$ppdef	pppos,posf	;pos function
	$ppdef	ppchr,chr$	;chr$ function
; *** !!! *** warning: bad pun forces ppnxts=12 ***
	$ppdef	ppnxts,nexts	;end of current statement go to next one
	$ppdef	ppasc,ascii	;asc function
	$ppdef	ppdat$,date$	;date function
	$ppdef	pptim$,time$	;time of day function
	$ppdef	pptime,timef	;general timer functions
	$ppdef	ppshes,shells	;call shell immediate (UNIX)
	$ppdef	ppslep,sleep	;sleep function
	$ppdef	ppwait,waitf	;wait function
	$ppdef	ppushc,pushc	;push imediate
	$ppdef	pprand,random	;randomize verb
	$ppdef	pprest,restor	;restore verb
	$ppdef	ppresu,resume	;resume verb
	$ppdef	pponub,onsub	;on ... gosub ...
	$ppdef	ppcsv,csv	;change string to vector
	$ppdef	ppcvs,cvs	;change vector to string
	$ppdef	ppmrd,matrd	;mat read
	$ppdef	ppmprn,matprn	;mat print ;
	$ppdef	ppmprt,matprt	;mat print
	$ppdef	ppminp,matinp	;mat input
	$ppdef	ppmzr,matzro	;mat zero
	$ppdef	ppmc1,matc1	;mat con
	$ppdef	ppmid,matid	;????
	$ppdef	ppmtrn,mattrn	;mat transpose
	$ppdef	ppminv,matinv	;mat inverse
	$ppdef	ppsmpf,matsmf	;mat scalar multiply floating
	$ppdef	ppsmpi,matsmi	;mat scalar multiply integer
	$ppdef	ppmcpy,matcpy	;mat copy
	$ppdef	ppmmul,matmul	;mat multiply
	$ppdef	ppmadd,matadd	;mat add
	$ppdef	ppmsub,matsub	;mat sub
	$ppdef	ppopio,openio	;open for input and output
	$ppdef	ppopin,openi	;open for input
	$ppdef	ppopou,openo	;open for output
	$ppdef	ppname,namer	;rename
	$ppdef	ppkill,killer	;delete
	$ppdef	ppendi,endinp	;empty the input buffer
	$ppdef	ppchai,rrrrr	;chain entry
	$ppdef	ppleft,left	;initial substring
	$ppdef	ppon,onstmt	;on statement
	$ppdef	pponer,onerr	;on error goto
	$ppdef	ppsdro,setdro	;set the nexdro flag for loop ppops
	$ppdef	ppcall,callfn	;pp for function calls
	$ppdef	ppdi,dupli	;duplicate integer
	$ppdef	ppijs,pitjs	;pop integer to j space
	$ppdef	ppjsld,jmpsld	;jump external, then nexts, all in one
	$ppdef	ppend,ujx8	;end of program
	$ppdef	ppmprc,matprc	;column print array
	$ppdef	ppzsma,zsmadd	;addf with small result dummied to 0
	$ppdef	pprdim,rowdim	;get matrix row dimension
	$ppdef	ppcdim,coldim	;get matrix column dimension
	$ppdef	ppbegn,beginp	;substitiue integer 1 unless 0
	$ppdef	ppmpus,matpus	;push matrix entry - matrix routines
	$ppdef	ppmpop,matpop	;pop  matrix entry - matrix routines
	$ppdef	ppevf,.ev.f	;approximately equals (??)
	$ppdef	pprnuf,prinuf	;print floater using
	$ppdef	pprnui,prinui	;print integer using
	$ppdef	pprnus,prinus	;print string using
	$ppdef	pprnue,prinue	;exit from print using
	$ppdef	ppexit,exitpp	;return to normal execution of ppcode
	$ppdef	ppcals,callpp	;ppcode subroutine call - matrix stuff
	$ppdef	ppcoru,corupp	;ppcode coroutine call - matrix stuff
	$ppdef	ppcali,calipp	;rub call indirect thru r1 - "    "
	$ppdef	pprts,rtspp	;honest ppcode sub exit -   "   "
	$ppdef	ppreor,reorpp	;"or" top 2 words, removing neither
	$ppdef	ppcmpi,cmpipp	;dimerr if top 2 words not =; othws, pops one
	$ppdef	ppfflt,ffltpp	;fetch floater just below top word
	$ppdef	ppmpr,matpr	;print individual matrix entry
	$ppdef	ppufl0,pushf0	;push floating 0
	$ppdef	ppufl1,pushf1	;push floating 1
	$ppdef	ppmrd0,matrd0	;read individual item for matrix stuff
	$ppdef	ppmain,matin	;input individual item for matrix stuff
	$ppdef	ppfix1,pushi1	;push integer 1
	$ppdef	ppkif,pftjs	;kill top floater (pop float to j-space)
	$ppdef	ppffuf,ffuf	;get next lower floater to top
	$ppdef	pptst,tstfl	;special flag test in matinv
	$ppdef	ppemc,emcode	;exit to machine code
	$ppdef	ppabxf,absf00	;floating abs value sans type ck
	$ppdef	ppnxtl,nextl	;external jump to next numbered stmt.
	$ppdef	ppifnl,ifnl	;if false nxtl, else internal jump
	$ppdef	ppcvis,cvis	;integer to 2-byte string
	$ppdef	ppcvfs,cvfs	;floater to byte string
	$ppdef	ppcvsi,cvsi	;2-byte string to integer
	$ppdef	ppcvsf,cvsf	;byte string to floater
	$ppdef	pplset,lset	;left-justified string set
	$ppdef	ppils1,m1lset	;same to singly indexed array
	$ppdef	ppils2,m2lset	;same to doubly indexed array
	$ppdef	pprset,rset	;right-justified string set
	$ppdef	ppirs1,m1rset	;same to singly indexed arrray
	$ppdef	ppirs2,m2rset	;same to doubly indexed array
	$ppdef	ppfset,field	;field statement
	$ppdef	ppifs1,m1fset	;with singly indexed string var
	$ppdef	ppifs2,m2fset	;with doubly indexed string var
	$ppdef	ppput,put	;output record
	$ppdef	ppget,get	;input record
	$ppdef	ppdups,dupls	;duplicate string at top of r1 stack
	$ppdef	ppshel,shelli	;call shell extended (UNIX)
	$ppdef	ppuloc,untloc	;unlock file segment
	$ppdef	ppxlte,xlate	;translate function
	$ppdef	ppreal,realfg	;set 'real' flag (bit 15)
	$ppdef	ppcvss,cvss	;special string function
	$ppdef	ppssor,ssorec	;select slot with "record"
	$ppdef	ppstng,string	;make string
	$ppdef	ppbufn,bufn	;get buffer size function

.iif	ndf	$list$	.list
