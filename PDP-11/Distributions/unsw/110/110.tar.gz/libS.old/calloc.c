#include "stdio.h"
/*	calloc - allocate and clear memory block
*/
/* #define BYTESPERWD (sizeof(int)/sizeof(char))

	our C compiler does not like the sizeof(int)
	sizeof(char) expression so I have changed it to what
	it evaluates to here
					perry
*/
#define BYTESPERWD 2

int *malloc();

int *calloc(num, size)
unsigned num;
{
	register *p, *q;
	register m;
	num =* size;
	if((p=malloc(num)) != NULL) {
		q = p;
		m = (num+BYTESPERWD-1)/BYTESPERWD;
		while(--m>=0)
			*q++ = 0;
	}
	return(p);
}

cfree(p)
int *p;
{
	free(p);
}
