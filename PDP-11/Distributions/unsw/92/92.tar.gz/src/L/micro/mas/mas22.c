#


#include	"mas0.h"


#define	IMMED	000
#define	DIRECT	020
#define	INDEX	040
#define	EXTEND	060



extern	char symbuf[];
extern FILE *list;
extern	curfb[];
extern	ppc;
extern	struct symbol symtab[];
extern	struct fb fbtable[];
char line[], *linep;
int	peekc;
int	lc;


extern FILE *input;
extern	undef;
extern	operand;

int	accum;



getch()							/* mod021 */
{
	register c;

	if (c = peekc)
	{
		peekc = 0;
		return c;
	}
	if (((c = getc(input)) != EOF) && (list != NULL))
		*linep++ = c;
	return c;
}



getsym()
{
	register char c, *s;
	register n;

	s = symbuf;
	n = 0;
	while ((c = getch()) >= 'a' || DIGIT(c) || c == '$' || c == '_' || c >= 'A' && c <= 'Z')
	{
		if (++n <= LMAX) *s++ = c;		/* mod006 */
	}
	peekc = c;
	*s = '\0';
	return (n);
}




getnonbl()
{
	register char c;

	while ((c = getch()) == SP || c == TAB);
	return (c);
}



getacc()						/* mod021 */
{
	register char c;

/*	c = getnonbl();						mod022 */
/*	tch = getch();						mod022 */
	return (getnonbl() | 040);
}



getitem()							/* mod022 */
{
	register char c, c1;
	register n;
	int rator;
	unsigned total;					/* mod023 */

	accum = undef = total = rator = n = 0;

	if ((c = getch()) == MINUS)
		rator = c;				/* mod021 */
	else peekc = c;

	do
	{
		if (getsym() == 0)
		{
			if ((c = getch()) == STAR) n = ppc;
			else if (c == QUOTE)
			{
				if ((n = getch()) == SLOSH) n = spech(getch());
			}
			else
			{
				peekc = c;
				return 0;
			}
		}
		else
		{
			c = symbuf[0];
			if ((peekc = getch()) == QUOTE)		/* x', o', b' */
			{
				peekc = 0;			/* mod022 */
				n = getnum(c);
			}
			else if (DIGIT(c))
			{
				c1 = symbuf[1] | 040;
				if (c1 == 'f' || c1 == 'b')
				{
					if (c1 == 'f') c =+ 10;
					n = curfb[c-'0'];
					if (fbtable[n].fb_def == UND)
					{
						if (fbtable[n].fb_pc)
						{
							fbund();
							fbtable[n].fb_pc = 0;
						}
						n = 0;
						undef++;
					}
					n = fbtable[n].fb_pc;
				}
				else n = getdec();
			}
			else if (accsym())
			{
				accum++;
				return (-1);
			}
			else
			{
				n = lookup();		/* symbol table index */
				if (symtab[n].s_def == UND)
				{
					if (symtab[n].s_pc)
					{
						symtab[n].s_pc = 0;
						underr();
					}
					n = 0;
					undef++;
				}
				else n = symtab[n].s_pc;
			}
		}
		switch (rator)
		{
	    case 0:	total = n; break;
	
	    case PLUS:	total =+ n; break;
	
	    case MINUS:	total =- n; break;
	
	    case SLASH:	total =/ n; break;	/* unsigned */
	
	    case STAR:	total =* n; break;

		}

	} while ((rator = c = getch()) == PLUS || c == MINUS || c == STAR
		|| c == SLASH || c == SLOSH );
	peekc = c;
	return (undef ? 0 : total);
}



getnum(ch)
char ch;
{
	register char *s;
	register char c;
	register number;
	int fac;

	number = fac = 0;
	s = symbuf;
	switch (ch | 040)		/* make lower case */
	{
    case 'x':	s =+ getsym();
		while (--s >= symbuf)
		{
			c = *s;					/* mod012 */
			if (DIGIT(c)) number =+ (c-'0') << fac;
			else { c =| 040; number =+ (c-'W') << fac; }
			fac =+ 4;
		}
		break;

    case 'b':	s =+ getbin();
		while (--s >= symbuf) number =+ (*s-'0') << fac++;
		break;

    case 'o':	s =+ getsym();
		while (--s >= symbuf) { number =+ (*s-'0') << fac; fac =+ 3; }
	}

/*	lrand();			mod021 */
	return (number);
}



getbin()						/* mod022 */
{
	register char *s, c;
	register n;

	s = symbuf;
	n = 0;
	while ((c = getch()) == '1' || c == '0')
	{
		n++;
		*s++ = c;
	}
	peekc = c;
	*s = '\0';
	return (n);
}



getdec()
{
	register char *s;
	register n, fac;

	s = symbuf;
	while (*s++);
	--s;
	n = 0;
	fac = 1;
	while (--s >= symbuf) { n =+ (*s-'0') * fac; fac =* 10; }
/*	lrand();		mod021 */
	return (n);
}




getimm(pcinc)
{
	register char *l;
	register n;
	register k;

	if ((peekc = getnonbl()) != PERCEN) return (getdirec());	/* mod022 */
	peekc = 0;						/* mod022 */
/*	l = &line[l_OPR];					mod021 */
/*	*l++ = c;						mod021 */
/*	linep = l;							*/
	operand = getitem();
	ppc =+ pcinc;
	return (IMMED);
}




getdirec()						/* mod022 */
{
/*	linep = &line[l_OPR];				mod021 */
	if (getind() == EXTEND)					/* mod022 */
	{
		ppc =- 3;
		if (iins(i_DIR)) { ppc =+ 2; return (DIRECT); }
		ppc =+ 3;
		return (EXTEND);
	}
	return (INDEX);
}




getind()							/* mod022 */
{
	register char c;
	register n;

/*	linep = &line[l_OPR];				mod021 */
	peekc = c = getnonbl();					/* mod022 */
	if ((operand = getitem()) == -1 && accum)
	{
		ppc++;
		c =| 040;
		if (c == 'a') return (0);
		if (c == 'd') return (4);		/* mod016 - lsr d */
		return (020);
	}
	if ((peekc = getch()) == LPAR)
	{
		peekc = 0;
/*		if (linep < &line[l_EOL]) *linep++ = getch();	mod021 */
		getch();				/* RPAR, mod022 */
		ppc =+ 2;
		return (INDEX);
	}
	ppc =+ 3;
	return (EXTEND);
}




getexpr()
{

/*	linep = &line[l_OPR];				mod021 */
	peekc = getnonbl();					/* mod022 */
	return (getitem());					/* mod022 */
}




spech(ch)
char ch;
{
	switch (ch)
	{
    case SLOSH:		return (SLOSH);

    case 'n':		return (NL);

    case 's':		return (SP);

    case 't':		return (TAB);

    case '0':		return ('\0');

    case 'r':		return (CR);		/* mod004 */

    case 'b':		return (BACKSP);		/* mod004 */
	}
	return (SLOSH);
}



accsym()
{
register char c;

	if (symbuf[1] == '\0')
	{
		c = symbuf[0] | 040;
		if (c == 'a' || c == 'b' || c == 'd' || c == 'x') return (1);	/* mod016 */
	}
	return (0);
}
