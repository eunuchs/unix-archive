#include	"mas0.h"


int opt_sym SYMON;		/* mod014 */
int opt_fcc FCCOFF;		/* mod014 */


extern	struct symbol symtab[];
extern	lab;
extern	noaddr;
extern	struct segment segopt;

extern	char line[], *linep;
extern	char symbuf[];
char	tsymbuf[32];				/* mod011 */
extern FILE *input;
extern FILE *list;
char	*fins;					/* mod011 */
int	lc;				/* mod011 */
extern FILE *tsav;
extern char *tsavfn;
extern int   tsavlc;
extern	npc, spc;
extern	bytec;
int	peekc;




pseudop(opc)
{
	register char c;
	register n, k;
	char *l;					/* mod021 */
	int *p, *tp, m;
	int save[100];

	switch (opc)
	{
    case o_SEG:	llocals(segopt.segcount++);
		break;						/* mod022 */

    case o_EQU:	n = getexpr();
		if (symtab[lab].s_def <= EXP)
		{
			symtab[lab].s_def = ABS;
			symtab[lab].s_pc = n;
		}
		else if (symtab[lab].s_pc != n) syserr(4);
		lcode3(n);
		break;						/* mod022 */

    case o_ORG:	if (iins(i_REL) == 0) syserr(5);
		npc = spc = getexpr();
		if (bytec > 3) outrec();		/* mod001 */
		newrec();
		lcomm();
		return;

    case o_FCB:	k = 0;					/* mod014, 022 */
		p = save;
		do
		{
			n = getexpr();
			outbyte(n);
			if (k < 100) { *p++ = n; k++; }
		} while ((c = getch()) == COMMA);		/* mod022 */
		peekc = c;
		p = save;
		while (k)
		{
			n = print3(k, p);
			p =+ n;
			k =- n;
		}
		return;

    case o_FDB:	k = 0;
		p = save;
		do
		{
			n = getexpr();				/* mod022 */
			outword(n);
			if (k < 100) { k++; *p++ = n; }
		} while ((c = getnonbl()) == COMMA);
		peekc = c;
		p = save;
		while (k--)
		{
			lcode3(*p++);
			lcomm();
			if (k)
			{
				peekc = NL;
				*linep++ = peekc;
				spc++; spc++;
			}
		}
		return;

    case o_FCC:	p = save;				/* mod021 */
		k = 0;
		getnonbl();		/* read leading '/', mod021 */
		while ((c = getch()) != SLASH)
		{
/*			if (l < &line[l_EOL]) *l++ = c;		mod021 */
			if ((n = c) == SLOSH)
			{
				if ((n = fcchar(c = getch())) == -1)
				{
					outbyte(SLOSH);
					if (k < 100) { k++; *p++ = SLOSH; }
					n = c;
				}
/*				if (l < &line[l_EOL]) *l++ = c;	mod021 */
			}
			outbyte(n);
			if (k < 100) { k++; *p++ = n; }
		}
/*		if (l < &line[l_EOL]) *l++ = c;	mod021 *//* terminating slash */
/*		linep = l;			mod021 */
		p = save;
		n = print3(k, p);
		if (opt_fcc == FCCON)
			while (k =- n)
			{
				p =+ n;
				n = print3(k, p);
			}
		else if (k != n)
		{
			peekc = 0;		/* truncate, fcc is off */
			--linep;
		}
		return;

    case o_RMB:	if (bytec > 3) outrec();		/* mod001 */
		npc =+ getexpr();
		newrec();
		lcomm();
		return;

    case o_ZMB:	n = getexpr();
		while (n--) outbyte(0);
		lcomm();
		return;

    case o_TXT:	c = getnonbl();				/* mod011 */
		l = tsymbuf;
		while (c != SP && c != TAB && c != NL)
		{
			*l++ = c;
			c = getch();
		}
		*l = '\0';
/*		if (c != NL) while (getch() != NL);		mod022 */
/*		lcopy();				/* mod021, 022 */
		peekc = c;					/* mod022 */
		lcoml();
		tsav = input;
		tsavlc = lc;
		tsavfn = fins;
		input = fopen(tsymbuf, "r");
		lc = 0;
		return;

    case o_OPT:	if ((peekc = getnonbl()) != NL)			/* mod022 */
		{
			getsym();
/*			linep = &line[l_OPR];			mod021 */
/*			lrand();					*/
			options();
		}
		break;

    case o_PAG:	lcoml();
		putc(PAGE, list);				/* mod022 */
		return;
	}
	lcoml();						/* mod022 */
}




fcchar(ch)
register char ch;
{
	switch (ch)
	{
    case SLOSH: return (SLOSH);

    case SLASH:	return (SLASH);

    case 'n':	return (NL);

    case 's':	return (SP);

    case 't':	return (TAB);

    case '0':	return ('\0');

    case 'r':	return (CR);		/* mod004 */

    case 'b':	return (BACKSP);		/* mod004 */
	}
	return (-1);
}



struct option
{
	char *optstr;
	int opttype;
};


struct option opttab[] =
{
	"fccoff",	FCCOFF,
	"fccon",	FCCON,
	"symoff",	SYMOFF,
	"symon",	SYMON,
	0,	0,
};


options()
{
	register struct option *o;
	register char *s, c;

	s = symbuf;
	while (c = *s) *s++ = c | 040;
	o = opttab;
	for (s = o->optstr; s != 0; s = (++o)->optstr)
		if (symmat(s))
			switch (s = o->opttype)
			{
		    case FCCOFF:			/* mod014 */
		    case FCCON:		opt_fcc = s; return;

		    case SYMOFF:			/* mod014 */
		    case SYMON:		opt_sym = s; return;
			}
}


symmat(s1)
register char *s1;
{
	register char *s, c;

	s = symbuf;
	while ((c = *s++) == *s1++) if (c == '\0') return (1);
	return (0);
}


print3(k, p)			/* mod014 */
register k;
register int *p;
{
	register n;

	for (n = 0; n < 3; n++, --k)
	{
		if (k == 0) break;
		lcode2(*p++, n);
	}
	lcomm();
	if (k)
	{
		peekc = NL;
		*linep++ = peekc;
		spc =+ n;
	}
	return (n);
}
