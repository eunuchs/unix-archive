main(argc, argv)
char *argv[];
{
	register fd;
	int	 null;

	null = 0;

	fd = open(argv[1], 2);
	if(fd < 0)
	{
		perror(argv[1]);
		exit(1);
	}

	lseek(fd, 6L, 0);
	write(fd, &null, 2);
	return 0;
}
