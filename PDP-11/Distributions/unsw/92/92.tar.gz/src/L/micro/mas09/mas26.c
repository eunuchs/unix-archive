#

#define PAGE	12
#include	"mas.h"


extern lfile;
extern struct segment segopt;
extern undef, spc;
extern numsym;
char bcd1();
char bcd2();
extern char *lbp;
extern char listbuf[];
extern struct symbol symtab[];
extern char line[];
extern char *linep;
extern char symbuf[];
extern char tch;
extern lc;
extern pl;

extern opt_sym;
#define opt_OFF	0


char sline[80];



int pn;
int lpc;
extern char *head;
extern char *fins;

header()
{
	register char *c1, *c2;
	register i;
	char *c3, *c4;
	if(lpc%pl != 0)
		return;
	c1 = head;
	c2 = line;
	if(lpc != 0)
	{
		lpc = 0;
		*c2++ = '\014';
	}
	c3 = &c2[125];
	c4 = &c2[50];
	while(*c1)
		*c2++ = *c1++;
	if((i = (++pn / 100) % 10) != 0)
	{
		c3[0] = i + '0';
		c3[1] = (pn / 10) % 10 + '0';
		c3[2] = pn % 10 + '0';
	}
	else
	if((i = (pn/10)%10) != 0)
	{
		c3[1] = i + '0';
		c3[2] = pn % 10 + '0';
	}
	else
		c3[2] = pn % 10 + '0';
	c1 = fins;
	while(*c1)
		*c4++ = *c1++;
		lcopy(--c2);
}
lcomm()			/* for comments at end-of-lines */
{
register n;
register char *l;

	l = line+l_ADR;
	n = spc >> 8;
	n &= 0377;
	*l++ = bcd1(n);
	*l++ = bcd2(n);
	n = spc & 0377;
	*l++ = bcd1(n);
	*l++ = bcd2(n);
	lcomma();
}




lcomma()
{
register char *l;
register tlc;

	l = line + 4;
	tlc = lc % 10000;
	for(;;)
	{
		*l-- = tlc % 10 + '0';
		tlc = tlc / 10;
		if(tlc == 0)
			break;
	}
	if ( undef )
		line[l_UND] = 'U';
	if(tch != NL)
		while(getch() != NL);
	lcopy(linep);
}



lcoml()			/* for comment lines */
{
register char *l;
register tlc;

	while(getch() != NL);
	l = line + 4;
	tlc = lc % 10000;
	for(;;)
	{
		*l-- = tlc % 10 + '0';
		tlc = tlc / 10;
		if(tlc == 0)
			break;
	}
	lcopy(linep);
}



lcopy(eol)
char *eol;
{
register char *l, *s;

	if ( lfile == 0 )
		return;

	s = lbp;
	for ( l = line; l < eol; ) {
		*s++ = *l++;
		if ( s >= listbuf+512 ) {
			write(lfile, listbuf, 512);
			s = listbuf;
		}
	}
	lbp = s;

	for ( l = line; l <= line+l_EOL; )
		*l++ = SP;
}


laddr(addr) /* list the address the branch will goto */
{
register n;
register char *l;

	l = line+l_BA;
	n = (addr >> 8) & 0xff;
	*l++ = bcd1(n);
	*l++ = bcd2(n);
	n = addr & 0xff;
	*l++ = bcd1(n);
	*l++ = bcd2(n);
}
lcode3(opc)
{
register n;
register char *l;

	l = line+l_C2;
	n = (opc >> 8) & 0xff;
	*l++ = bcd1(n);
	*l++ = bcd2(n);
	n = opc & 0xff;
	*l++ = bcd1(n);
	*l++ = bcd2(n);
}

lcode4(opc)
{
register n;
register char *l;

	l = line+l_C4;
	*l++ = bcd1(n=opc);
	*l++ = bcd2(n);
}


lcode2(ran)
{
register n;
register char *l;

	l = line+l_C2;
	n = ran & 0377;
	*l++ = bcd1(n);
	*l++ = bcd2(n);
}



lcode1(opc)
{
register n;
register char *l;

	l = line+l_C1;
	n = (opc >> 8) & 0377;
	if (n) {
		*l++ = bcd1(n);
		*l++ = bcd2(n);
	}
	else {
		*l++ = *l++ = SP;
	}
	n = opc & 0377;
	*l++ = bcd1(n);
	*l++ = bcd2(n);
}



lglobals()
{
register struct symbol *sym;
register char *s, *l;
int n, z, k;
int qcompar();

	if(lfile == 0)
		return;

	if (opt_sym == opt_OFF) {
		write(lfile, listbuf, lbp-listbuf);
		return;
	}
	l = sline;
	if ( segopt.segcount == 0 )
		*l++ = PAGE;
	n = numsym-1;
	sym = &symtab[1];
	qsort((char *)sym, (unsigned)n, sizeof( struct symbol), qcompar);
	z = 0;
	while ( n-- ) {
		if ( sym->s_seg == 0 ) {
			s = &sym->s_name[0];
			k = 0;
			while ( (*l++ = *s++ ) && (++k < 8));
			if(k != 8)
				l[-1] = TAB;
			*l++ = SP;
			if ( sym->s_def == UND )
				*l++ = 'u';
			else {
				k = sym->s_pc >> 8;
				k &= 0377;
				*l++ = bcd1(k);
				*l++ = bcd2(k);
				k = sym->s_pc & 0377;
				*l++ = bcd1(k);
				*l++ = bcd2(k);
			}
			if ( z++ > 1 ) {
				*l++ = NL;
				slcopy(l);
				z = 0;
				l = sline;
			}
			else {
				*l++ = TAB;
				*l++ = TAB;
			}
		}
		sym++;
	}

	if ( z ) {
		--l;
		--l;
		*l++ = NL;
	}
	slcopy(l);
	if(lfile)
		write(lfile, listbuf, lbp-listbuf);
}



slcopy(eol)
char *eol;
{
register char *s, *l;

	if ( lfile == 0 )
		return;

	s = lbp;
	for ( l = sline; l < eol; ) {
		*s++ = *l++;
		if ( s >= listbuf+512 ) {
			write(lfile, listbuf, 512);
			s = listbuf;
		}
	}

	lbp = s;
}


qcompar(a1, a2)
char *a1, *a2;
{
register char c, *s1, *s2;

	s1 = a1;
	s2 = a2;
	while ( (c = *s1++) == *s2++ )
		if ( c == '\0' )
			return(0);
	if ( c < *--s2 )
		return(-1);
	return(1);
}




llocals(seg)
int seg;
{
register struct symbol *sym;
register char *s, *l;
int n, z, k;

	if (opt_sym == opt_OFF)
		return;
	l = sline;
	for ( k=0; k<4; k++ )
		*l++ = NL;
	n = numsym-1;
	sym = &symtab[1];
	z = 0;
	while ( n-- ) {
		if ( sym->s_seg == seg ) {
			s = &sym->s_name[0];
			*l++ = segopt.segchar;
			while ( *l++ = *s++ );
			--l;
			*l++ = TAB;
			*l++ = SP;
			if ( sym->s_def == UND )
				*l++ = 'u';
			else {
				k = sym->s_pc >> 8;
				k &= 0377;
				*l++ = bcd1(k);
				*l++ = bcd2(k);
				k = sym->s_pc & 0377;
				*l++ = bcd1(k);
				*l++ = bcd2(k);
			}
			if ( z++ > 1 ) {
				*l++ = NL;
				slcopy(l);
				z = 0;
				l = sline;
			}
			else {
				*l++ = TAB;
				*l++ = TAB;
			}
		}
		sym++;
	}

	if ( z ) {
		--l;
		--l;
		*l++ = NL;
	}
	*l++ = PAGE;
	slcopy(l);
}



lpage()
{

	lpc = pl;
}
