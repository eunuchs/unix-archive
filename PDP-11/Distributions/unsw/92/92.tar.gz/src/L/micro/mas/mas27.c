#include	"mas0.h"

#include	"table1"			/* mod023 */

#include	"table2"			/* mod023 */




struct iform ibuf[128];


int hashtab[128];

struct symbol symtab[NSYMBOL];		/* mod008 */
struct fb fbtable[NFB];			/* mod008 */
int curfb[20];

char symbuf[18];

char line[l_EOL + 1];			/* mod001 */
