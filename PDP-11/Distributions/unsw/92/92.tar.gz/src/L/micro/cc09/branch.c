#include	"mfile2"
#define SE	03	/* see codegen.c */
unsigned xx;

extern char srch;
int negrel[] = { NE, EQ, GT, GE, LT, LE, UGT, UGE, ULT, ULE } ;  /* negatives of relationals */

char *ccbranches[] = {
	"	jeq	L%d\n",
	"	jne	L%d\n",
	"	jle	L%d\n",
	"	jlt	L%d\n",
	"	jge	L%d\n",
	"	jgt	L%d\n",
	"	jls	L%d\n",
	"	jlo	L%d\n",
	"	jhs	L%d\n",
	"	jhi	L%d\n",
	};

cbranch( p, true, false ) NODE *p; {
	/* evaluate p for truth value, and branch to true or false
	/* accordingly: label <0 means fall through */

	register o, lab, flab, tlab;
	int	conopflag = 0;

	lab = -1;

	switch( o=p->in.op ){

	case ULE:
	case ULT:
	case UGE:
	case UGT:
	case EQ:
	case NE:
	case LE:
	case LT:
	case GE:
	case GT:
		if(true < 0)
		{
			o = p->in.op = negrel[ o-EQ ];
			true = false;
			false = -1;
		}
		p->bn.label = true;
		if((p->in.left->in.op == ICON && (short)(p->in.left->tn.lval) == 0) ||
		  (p->in.right->in.op == ICON && (short) (p->in.right->tn.lval) == 0))
			if(o == EQ || o == NE)
			{
				if(p->in.left->in.op == ICON)
					ind(p->in.right), test(p->in.right, o, true, false);
				else
					ind(p->in.left), test(p->in.left, o, true, false);
				return;
			}
		if(addr(p->in.right))
		{
			char buf[20];

			ind(p->in.left);
			printf("\tcmp%c\t%s\n", reg(p->in.right->in.type), amode(p->in.right, buf, SE));
		}
		else
		{
			stck(p->in.right);
			ind(p->in.left);
			if(bast(p->in.left->in.type)==INT)
				printf("\tcmpb\t,s+\n");
			else
				printf("\tcmpd\t,s++\n");
		}
		printf(ccbranches[o - EQ], true);
		if(false >= 0)
			printf("\tjbr\tL%d\n",  false);
		break;

	case ANDAND:
		lab = false<0 ? getlab() : false ;
		cbranch( p->in.left, -1, lab );
		cbranch( p->in.right, true, false );
		if( false < 0 ) deflab( lab );
		return;

	case OROR:
		lab = true<0 ? getlab() : true;
		cbranch( p->in.left, lab, -1 );
		cbranch( p->in.right, true, false );
		if( true < 0 ) deflab( lab );
		return;

	case NOT:
		cbranch( p->in.left, false, true );
		break;

	case QUEST:
		flab = false<0 ? getlab() : false;
		tlab = true<0 ? getlab() : true;
		cbranch( p->in.left, -1, lab = getlab() );
		cbranch( p->in.right->in.left, tlab, flab );
		deflab( lab );
		cbranch( p->in.right->in.right, true, false );
		if( true < 0 ) deflab( tlab);
		if( false < 0 ) deflab( flab );
		return;

	case GOTO:
		printf("\tjbr\tL%d\n", -p->in.left->tn.rval);
		return;

	case ICON:
		if( p->in.type != FLOAT && p->in.type != DOUBLE ){

			if( p->tn.lval || p->in.name[0] ){
				/* addresses of C objects are never 0 */
				if( true>=0 ) printf("\tjmp\tL%d\n",  true );
				}
			else if( false>=0 ) printf("\tjmp\tL%d\n",  false );
			return;
			}
	default:

		if(true < 0)
		{
			o = EQ;
			true = false;
			false = -1;
		}
		else
			o = NE;
		if(addr(p) && bast(p->in.type)==INT)
		{
			char buf[20];

			printf("\ttst\t%s\n", amode(p, buf, SE));
			printf("\tj%s\tL%d\n", o==EQ ? "eq" : "ne", true);
			if(false != -1)
				printf("\tjbr\tL%d\n", false);
		}
		else
		{
			ind(p);
			test(p, o, true, false);
		}
		}

	}


test(p, d, labt, labf)
NODE *p;
{
	if(bast(p->in.type) == INT)
		printf("\ttstb\n");
	else
		printf("\taddd\t#0\n");
	printf("\tj%s\tL%d\n", d==EQ ? "eq" : "ne", labt);
	if(labf != -1)
		printf("\tjbr\tL%d\n", labf);
}
# define BITMASK(n) ((1L<<n)-1)

/* logical relations when compared in reverse order (cmp R,L) */

genlog(p)
NODE *p;
{
	int m, m1, o;

	switch(p->in.op)
	{

	case CBRANCH:
		o = p->in.right->tn.lval;
		cbranch( p->in.left, -1, o );
		break;
	case QUEST:
		cbranch( p->in.left, -1, m=getlab() );
		p->in.right->in.left->tn.rall = p->tn.rall;
		ind(p->in.right->in.left);
		printf("\tjbr\tL%d\n",  m1 = getlab() );
		deflab( m );
		ind( p->in.right->in.right );
		deflab( m1 );
		break;

	case EQ:
	case NE:
	case LE:
	case LT:
	case GE:
	case GT:
	case ULT:
	case UGT:
	case ULE:
	case UGE:
	case ANDAND:
	case OROR:
	case NOT:  /* logical operators */
		/* if here, must be a logical operator for 0-1 value */
		cbranch( p, -1, m=getlab() );
		printf("\tldb\t#1\n");
		printf("\tjbr\tL%d\n", xx=getlab());
		deflab(m);
		printf("\tclrb\n");
		deflab(xx);
		break;
	default:
		cerror("probablem in cbbrranch");
	}
}
