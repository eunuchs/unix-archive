#include	<stdio.h>
#include	<setjmp.h>

#define	STAR	'*'
#define	TAB	'\t'
#define	SP	' '
#define COLON	':'
#define NL	'\n'
#define CR	'\r'				/* mod004 */
#define BACKSP	'\b'				/* mod004 */
#define PAGE	014				/* mod020 */
#define MINUS	'-'
#define PLUS	'+'
#define SLASH	'/'
#define LPAR	'('
#define RPAR	')'
#define QUOTE	'\''
#define COMMA	','
#define PERCEN	'%'
#define SLOSH	'\\'


#define e_CON	0
#define e_SYM	1
#define e_TL	2
#define e_PC	3

#define e_TERM	0
#define e_PLUS	1
#define e_MINUS	2
#define e_SLASH	3
#define	e_STAR	4

#define UND	0
#define EXP	1
#define ABS	2
#define EST	3

#define	FCCOFF	1				/* mod014 */
#define	FCCON	2				/* mod014 */
#define	SYMOFF	3				/* mod014 */
#define	SYMON	4				/* mod014 */


#define	A	'a'				/* mod016 */
#define	B	'b'
#define	D	'd'
#define	X	'x'

#define o_INH	0		/* aba cba clc cli clv daa des dex ins inx */
				/* nop rti rts sba sec sei sev swi tab tap */
				/* tba tpa tsx txs wai			   */
#define o_DUAL	1		/* adc and bit cmp eor lda ora sbc	   */
#define	o_ADDD	2		/* add sub				   */
#define o_STA	3		/* sta					   */
#define o_AEI	4		/* asr clr com dec inc neg rol ror tst	   */
#define	o_LSLD	5		/* asl lsr				   */
#define o_PUSH	6		/* psh pul				   */
#define o_IDEI	7		/* cpx lds ldx				   */
#define o_DEI	8		/* sts stx				   */
#define o_JMPS	9		/* jmp jsr				   */
#define o_BNCH	10		/* bcc bcs beq bge bgt bhi bhs ble blo bls */
				/* blt bmi bne bpl bra bsr bvc bvs	   */
#define o_JBRS	11		/* jbr jbs				   */
#define o_JEQS	12		/* jcc jcs jeq jge jgt jhi jhs jle jlo jls */
				/* jlt jmi jne jpl jvc jvs		   */

#define	o_ABX	o_INH + 0x80	/* abx mul */
#define	o_LSL	o_LSLD + 0x80	/* lsl	   */
#define	o_LDD	o_IDEI + 0x80	/* ldd	   */
#define	o_STD	o_DEI + 0x80	/* std	   */

#define o_SEG	100
#define o_END	101
#define o_EQU	102
#define o_FCB	103
#define o_FCC	104
#define o_FDB	105
#define o_MON	106
#define o_NAM	107
#define o_OPT	108
#define o_ORG	109
#define o_PAG	110
#define o_RMB	111
#define o_ZMB	112
#define o_SPC	113
#define	o_TXT	114



struct segment
{
	char segchar;		/* segmentation char. */
	char segtype;		/* 2 if '-' sign used; else 1 */
	char segcount;
};



#define	NSYMBOL	600			/* mod008 - number of symbols + 1 */
#define LMAX	7			/* mod006 - maximum label field length */

struct	symbol
{
	char s_name[LMAX+1];				/* mod006 */
	int s_pc;
	int s_chain;
	char s_def;
	char s_seg;
};


#define	NFB	400

struct	fb
{
	int fb_pc;
	char fb_def;
	char fb_lab;
};


struct	aform
{
	int a_pc;
	int a_def;
};


#define a_EQU	100
#define a_LONG	0
#define a_JBRS	1
#define a_DIR	2
#define a_JEQS	3


struct iform
{
	int i_pc;
	int i_def;
};

#define i_LONG	1
#define i_DIR	2
#define i_REL	3


struct	expr
{
	char e_rator;
	char e_rand;
	int e_val;
};


struct	evalx
{
	int r_val;
	char r_type;
};


/* offsets from listbuf */

/*#define l_UND	0					mod021 */
#define l_ADR	0
#define l_C1	6
#define l_C2	9
#define l_LAB	16

/*#define l_CL	20					mod021 */
/*#define l_MNE	27					mod021 */
/*#define l_ACC	31					mod021 */
/*#define l_OPR	34					mod021 */
/*#define l_COM	52					mod021 */

#define l_EOL	131					/* mod001 */


#define DIGIT(ch)	ch >= '0' && ch <= '9'		/* mod012 */
