/* (c) 1979 Regents of the University of California */
#include "0x.h"
#include "E.h"

/*
 * allocate a block of storage on the heap
 * mod ianh 28aug80 the following routines palloc and pfree were borrowed
 * mod ianh 28aug80 from the VAX px to implement new and dispose decently
 * mod ianh 28aug80 all calls to alloc and free were modified to call
 * mod ianh 28aug80 palloc and pfree
 */
char	*palloc(need, initvalue)

unsigned	need;
int		initvalue;

{
extern	 char *malloc();
register char *memblk;
register short *ptr;

memblk = malloc( (need+1)&~01 );
if (memblk == 0)
	error(EOUTOFMEM);
if (memblk == (char *)(-1))
	error(ETRASHHEAP);
for(ptr=(short *)memblk; ((char *)ptr)<memblk+need; ptr++)
	*ptr = initvalue;
return(memblk);
}



/*
 * Free a block of storage on the stack
 */
pfree(ptr)

char	*ptr;

{
extern	long free();

if (ptr == 0)
	error(ENILPTR);
else if (free(ptr) == -1)
	error(ETRASHHEAP);
}
setmem()
{
	bottmem = memptr = sbrk(0);
	stklim();
}

stklim()
{
	/* mod ianh 28aug80 the original value of 07777 used in the
		line below was incorrect each page contains 8kbytes
		not 4kbytes */
	/* mod ianh 28aug80 yet again - to use sbrk */
	maxstk = ((sbrk(0) + 017777) &~ 017777) + (22*64); /*mod ianh 26aug80 */
/*	maxstk = ((memptr + 07777) &~ 07777) + 512; mod ianh 26aug80 */
}
