#
/*
**	program to load object from card reader
**
**	each card contains a self-contained binary image,
**		one byte per column.
**		cols 0, 1	:	load address
**		col  2		:	count
**		cols 3->count+3	:	data
**		col  count+3	:	sum (bytewise sumcheck of card)
int	lpc;
int	sum;


main()
{
	register char	*addr;
	register	count;

	for(;;)
	{
		nextcard();

		addr = getcol() | (getcol()<<8);

		lpc = 0;
		sum = 0;

		if ( count = getcol() )
		{
			do
				*addr++ = getcol();
			while
				( --count );
		}
		else
			count++;

		if ( sum != getcol() || lpc != getcol() )
			halt();

		if ( count )
			goto addr;
	}
}
