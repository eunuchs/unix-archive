# w
# (c) 1979 Regents of the University of California
/usr/ucb/finger -sf $*
