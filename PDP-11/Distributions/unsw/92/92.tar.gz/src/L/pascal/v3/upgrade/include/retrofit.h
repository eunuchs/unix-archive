#define	fstat	_fstat
#define	stat	_stat
#define	getuid	_getuid
#define	gtty	_gtty
#define	stty	_stty
