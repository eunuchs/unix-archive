14c
#define	HSHSIZ	500
.
