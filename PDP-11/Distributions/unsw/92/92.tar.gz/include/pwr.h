/*
**	The necessary declarations for using the password routines
*/ 

#include	<local-system>
#include	<passwd.h>

extern	char	*etcpasswd;
extern	short	pwfd,
		pwfl;
