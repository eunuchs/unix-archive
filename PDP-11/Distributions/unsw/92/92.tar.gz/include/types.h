typedef	unsigned short	ushort;
typedef	long		daddr_t;	/* disk address */
typedef	char *		caddr_t;	/* core address */
typedef	unsigned int	ino_t;		/* i-node number */
typedef	ushort		uid_t;
typedef	long		time_t;		/* a time */
typedef	int		dev_t;		/* device code */
typedef	long		off_t;		/* offset in file */
	/* selectors and constructor for device code */
#define	major(x)	(int)(((unsigned)x>>8))
#define	minor(x)	(int)(x&0377)
#define	makedev(x,y)	(dev_t)((x)<<8|(y & 0377))

#define	TYPES_DEFINED	1
