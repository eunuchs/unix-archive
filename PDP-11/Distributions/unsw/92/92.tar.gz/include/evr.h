/*
**	Eviction reasons
*/

#define	EVR_0		"reason unknown"
#define	EVR_DUSED	1
#define	EVR_1		"disk usage too large"
#define	EVR_BOOK	2
#define	EVR_2		"evicted by booking suite"
#define	EVR_CLOSE	3
#define	EVR_3		"logged on after close down"
#define	EVR_EXPIRE	4
#define	EVR_4		"account expired"
#define	EVR_UNUSED	5
#define	EVR_5		"account unused"
#define	EVR_TEMP	6
#define	EVR_6		"temporarily"
#define	EVR_SPEC	7
#define	EVR_7		"Special Account"

#ifdef	EVR_DATA
char *	evr[] =
{
	EVR_0,
	EVR_1,
	EVR_2,
	EVR_3,
	EVR_4,
	EVR_5,
	EVR_6,
	EVR_7
};
#define	EVR_N	((sizeof evr)/(sizeof evr[0]))
#endif	EVR_DATA
