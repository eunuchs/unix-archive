/*
 *	Structure used by L_DEADLIM option to limits system call
 */

struct retlim
{
	struct lnode r_lnode;
	struct xproc r_proc;
};
