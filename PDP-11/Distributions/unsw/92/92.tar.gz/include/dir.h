/*
 * structure of directory entries
 * define DIRSIZ to be 15 and zero the last location of d_name
 * if you want to ensure there is a trailing null
 */
#ifndef	DIRSIZ
#define	DIRSIZ	14
#endif
struct	direct
{
	ino_t	d_ino;
	char	d_name[DIRSIZ];
};
