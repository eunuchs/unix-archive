/*LINTLIBRARY*/

/*
**	Convert integer arg to ascii string
*/

char *
itoa( i )
	register int	i;
{
	static char	buf[12];
	register char *	cp = buf;
	extern char *	_itoa();

	if ( i < 0 )
	{
		*cp++ = '-';
		i = -i;
	}

	cp = _itoa( i, cp );
	*cp = '\0';

	return buf;
}

static char *
_itoa( n, cp )
	register int	n;
	register char	*cp;
{
	register int	d;

	if ( d = n/10 )
		cp = _itoa( d, cp );
	*cp++ = n%10 + '0';
	return cp;
}
