/*
 *	strclr for the pdp11
 */

strclr(s, n)
register char *s;
register n;
{
	register char *cp;

	cp = s;
	while(n-- > 0)
		*cp++ = 0;
	return(s);
}
