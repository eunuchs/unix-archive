/*
**	defines to describe physical layout of the
**
**		Okdata 3300 Disc Drive
*/

#define	NOKCYL		339
#define	NOKSEC		32
#define	NOKHDS		12
