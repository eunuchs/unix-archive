XXXXX	XXXXXX	XXXXXX	   X	X    X	XXXXXX	 XXXX
X    X	X	X	   X	XX   X	X	X
X    X	XXXXX	XXXXX	   X	X X  X	XXXXX	 XXXX
X    X	X	X	   X	X  X X	X	     X
X    X	X	X	   X	X   XX	X	X    X
XXXXX	XXXXXX	X	   X	X    X	XXXXXX	 XXXX



#include "defines.agsm"

		XXXXX	  XX	XXXXX	  XX	X    X
		X    X	 X  X	X    X	 X  X	XX  XX
		X    X	X    X	X    X	X    X	X XX X
		XXXXX	XXXXXX	XXXXX	XXXXXX	X    X
		X	X    X	X   X	X    X	X    X
		X	X    X	X    X	X    X	X    X



#include "param.agsm"

		XXXXX	   X	X    X	   X	 XXXXX
		X    X	   X	XX   X	   X	   X
		XXXXX	   X	X X  X	   X	   X
		X    X	   X	X  X X	   X	   X
		X    X	   X	X   XX	   X	   X
		XXXXX	   X	X    X	   X	   X



#include "binit.h"

		XXXXX	X    X	XXXXXX
		X    X	X    X	X
		XXXXX	X    X	XXXXX
		X    X	X    X	X
		X    X	X    X	X
		XXXXX	 XXXX	X



#include "buf.h"

		 XXXX	   X	X    X	   X	 XXXXX
		X    X	   X	XX   X	   X	   X
		X	   X	X X  X	   X	   X
		X	   X	X  X X	   X	   X
		X    X	   X	X   XX	   X	   X
		 XXXX	   X	X    X	   X	   X



#include "cinit.h"

		 XXXX	 XXXX	X    X	XXXXXX
		X    X	X    X	XX   X	X
		X	X    X	X X  X	XXXXX
		X	X    X	X  X X	X
		X    X	X    X	X   XX	X
		 XXXX	 XXXX	X    X	X



#include "conf.h"

		XXXXXX	 XXXX	 XXXXX	  XX	XXXXX	X    X	XXXXX
		X	X	   X	 X  X	X    X	X    X	X    X
		XXXXX	 XXXX	   X	X    X	XXXXX	X    X	X    X
		X	     X	   X	XXXXXX	X    X	X    X	XXXXX
		X	X    X	   X	X    X	X    X	X    X	X   X
		XXXXXX	 XXXX	   X	X    X	XXXXX	 XXXX	X    X



#include "estabur.h"

		XXXXXX	   X	X	XXXXXX
		X	   X	X	X
		XXXXX	   X	X	XXXXX
		X	   X	X	X
		X	   X	X	X
		X	   X	XXXXXX	XXXXXX



#include "file.h"

		XXXXXX	   X	X	 XXXX	 X   X	 XXXX
		X	   X	X	X	  X X	X
		XXXXX	   X	X	 XXXX	   X	 XXXX
		X	   X	X	     X	   X	     X
		X	   X	X	X    X	   X	X    X
		X	   X	XXXXXX	 XXXX	   X	 XXXX



#include "filsys.h"

		   X	   X	X    X	   X	 XXXXX
		   X	   X	XX   X	   X	   X
		   X	   X	X X  X	   X	   X
		   X	   X	X  X X	   X	   X
		   X	   X	X   XX	   X	   X
		   X	   X	X    X	   X	   X



#include "iinit.h"

		   X	X    X	 XXXX
		   X	XX   X	X    X
		   X	X X  X	X    X
		   X	X  X X	X    X
		   X	X   XX	X    X
		   X	X    X	 XXXX



#include "ino.h"

		   X	X    X	 XXXX	XXXXX	XXXXXX
		   X	XX   X	X    X	X    X	X
		   X	X X  X	X    X	X    X	XXXXX
		   X	X  X X	X    X	X    X	X
		   X	X   XX	X    X	X    X	X
		   X	X    X	 XXXX	XXXXX	XXXXXX



#include "inode.h"

		X	X    X	 XXXX	XXXXX	XXXXXX
		X	XX   X	X    X	X    X	X
		X	X X  X	X    X	X    X	XXXXX
		X	X  X X	X    X	X    X	X
		X	X   XX	X    X	X    X	X
		XXXXXX	X    X	 XXXX	XXXXX	XXXXXX



#include "lnode.h"

		XXXXX	XXXXX	 XXXX	 XXXX
		X    X	X    X	X    X	X    X
		X    X	X    X	X    X	X
		XXXXX	XXXXX	X    X	X
		X	X   X	X    X	X    X
		X	X    X	 XXXX	 XXXX



#include "proc.h"

		XXXXX	XXXXXX	 XXXX	X    X	XXXXX
		X    X	    X	X    X	XX  XX	X    X
		X    X	   X	X    X	X XX X	XXXXX
		XXXXX	  X	X    X	X    X	X    X
		X	 X	X    X	X    X	X    X
		X	XXXXXX	 XXXX	X    X	XXXXX



#include "pzomb.h"

		XXXXX	XXXXXX	 XXXX
		X    X	X	X    X
		X    X	XXXXX	X
		XXXXX	X	X  XXX
		X   X	X	X    X
		X    X	XXXXXX	 XXXX



#include "reg.h"

		 XXXX	XXXXXX	 XXXX
		X	X	X    X
		 XXXX	XXXXX	X
		     X	X	X  XXX
		X    X	X	X    X
		 XXXX	XXXXXX	 XXXX



#include "seg.h"

		 XXXX	 X   X	 XXXX	 XXXXX	X    X
		X	  X X	X	   X	XX  XX
		 XXXX	   X	 XXXX	   X	X XX X
		     X	   X	     X	   X	X    X
		X    X	   X	X    X	   X	X    X
		 XXXX	   X	 XXXX	   X	X    X



#include "systm.h"

		 XXXXX	XXXXXX	X    X	 XXXXX
		   X	X	 X  X	   X
		   X	XXXXX	  XX	   X
		   X	X	  XX	   X
		   X	X	 X  X	   X
		   X	XXXXXX	X    X	   X



#include "text.h"

		 XXXXX	 XXXXX	 X   X
		   X	   X	  X X
		   X	   X	   X
		   X	   X	   X
		   X	   X	   X
		   X	   X	   X



#include "tty.h"

		X    X	 XXXX	XXXXXX	XXXXX
		X    X	X	X	X    X
		X    X	 XXXX	XXXXX	X    X
		X    X	     X	X	XXXXX
		X    X	X    X	X	X   X
		 XXXX	 XXXX	XXXXXX	X    X



#include "user.h"

