Here are the system .h's which were used to make

go.sample
