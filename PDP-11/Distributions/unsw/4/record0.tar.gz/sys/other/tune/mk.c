char buf [15000];
main(){
	write(1,buf,15000);
}
