#define SIGINTR 2
#define SIGQUIT 3
