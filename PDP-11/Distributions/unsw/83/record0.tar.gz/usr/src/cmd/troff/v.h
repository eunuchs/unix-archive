struct v {int pn,nl,yr,hp,ct,dn,mo,dy,dw,ln,dl,st,sb,cd;
	int vxx[NN-NNAMES];} v ;
