#
/*
 *
 *	UNIX debugger - small version
 *
 */

subpcs(modif)
{
	prints("sub processes not supported\n");
}

delbp()
{;}

endpcs()
{;}
