#

	/*
	 *	GPAC TABLET GW ROUTINES
	 */


#include "../gpac.h"
#include "../error_codes.h"
#include "tab.h"

track(n)
	char n;
	{
	int arg[3];
	register i;

	valid_segment;
	if(Gseg_table[n].start_address == 0)
		return(Gerror(NOEXIST_ERR, "track", n));
	post(n);
	Gtablet.trk_seg = n;
	GOOD_RETURN;
	}


untrack()
	{
	int arg[3];

	if(Gtablet.trk_seg != 0)
		{
		unpost(Gtablet.trk_seg);
		Gtablet.trk_seg = 0;
		}
	}


