#

	/*
	 *	GPAC TEK ROUTINES
	 */


#include "../gpac.h"
#include "../error_codes.h"
#include "tek.h"

whereis(n, addx, addy)
	int n;
	double *addx, *addy;
	{
	register *a;

	valid_segment;
	if(Gseg_table[n].start_address)
		{
		a = Gseg_table[n].start_address+1;	
		while((*a & 0170000) != 0100000)
			a++;
		screentouser((*a & 07777)>>2, (*(a+1) & 07777)>>2, addx, addy);
		}
	   else
		return(Gerror(NOEXIST_ERR, "whereis", n));
	GOOD_RETURN;
	}
