#

	/*
	 *	GPAC TABLET GW ROUTINES
	 */


#include "../gpac.h"
#include "../error_codes.h"
#include "tek.h"
#include "tab.h"

clearink()
	{
	register *p;
	register i;

	if(Gevent.type == INKING)
		{
		Gcontrol_status =| CLEAR_SCREEN;
		update();
		}
	if(p = Gtablet.buf_addr+1+Gtablet.curr_ink_size)
		for(i = 0; i < Gtablet.curr_ink_size; i++)
			*--p = TERM;
	}


