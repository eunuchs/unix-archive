#

#include "../gpac.h"
#include "../error_codes.h"
#include "tek.h"
#include "tab.h"


readposition()
	{
	int arg;
	char buf[6];

	update();
	Ginput();
	Gevent.type = READPOSITION;
	return(&Gevent);
	}
