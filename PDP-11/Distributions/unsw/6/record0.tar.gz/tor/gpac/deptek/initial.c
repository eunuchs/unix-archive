#

#include "../gpac.h"
#include "../error_codes.h"


double Gvcx 511.5;
double Gvsx 389.5;
double Gvcy 389.5;
double Gvsy 389.5;
double Gsx .76148582;
double Gsy .76148582;
double Gwvx 122.0;
double Gwvy 0.0;
int Gvx_right 1023;
int Gvy_top 779;

int Gdev_file 1;
int Gblank_line BVECTOR;

int Gcharsiz 14;
char Glhiy -1;
char Glloy -1;
char Glhix -1;
char Gllox -1;

int Gwv_mod 1;
double Givxmin -.1516;
double Givxmax 1.1516;
double Givymin 0.0;
double Givymax 1.0;
