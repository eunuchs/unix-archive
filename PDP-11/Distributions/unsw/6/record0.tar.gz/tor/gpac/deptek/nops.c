
scroller()
	{

	}


depth()
	{

	}


rgb()
	{

	}


background()
	{

	}


resetintens()
	{

	}



ink_parms()
	{

	}


cursor()
	{

	}


tabsize()
	{

	}


tabclear()
	{

	}


intens()
	{

	}


lwidth()
	{

	}


colour()
	{

	}


fillbegin()
	{

	}


fillend()
	{

	}


schars()
	{

	}
