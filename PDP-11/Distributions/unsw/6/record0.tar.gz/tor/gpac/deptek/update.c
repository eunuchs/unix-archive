#


#include "../gpac.h"
#include "tek.h"
extern int Gtekmode;

update()
	{
	register i, *addr, *a;
	int *nxt_seg;

	if(Gcontrol_status & CLEAR_SCREEN)
		{
		Gtekclear();
		}
	Gtekmode = MLTO;
	Gtekout(100000);	/*  generate an initial moveto 0, 0  */
	Gtekout(0);
	for(i = 1; i <= Gmax_segs; i++)
		if((addr = Gseg_table[i].start_address) && (Gpda_table[i] & POST)
					&& (Gcontrol_status & CLEAR_SCREEN
						|| (Gpda_table[i] & UPDATABLE)))
			{
			nxt_seg = Gnxt_seg(Gseg_table[i].end_address);
			do
				{
				for(a = addr+1; *a != TERM; a++)
					Gtekout(*a);
				}  while((addr = Gnxt_blk(addr)) != nxt_seg);
			}
	Gtekmoveto(0, 760);	/*  Home up  */
	Gputc(ENTER_ALPHA);
	for(i = 0; i <= Gmax_segs; i++)
		Gpda_table[i] =& ~UPDATABLE;
	Gcontrol_status =& ~CLEAR_SCREEN;
	GOOD_RETURN;
	}
