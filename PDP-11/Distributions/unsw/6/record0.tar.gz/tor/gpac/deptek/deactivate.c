#

	/*
	 *	GPAC TABLET GW ROUTINES
	 */


#include "../gpac.h"
#include "../error_codes.h"
#include "tab.h"

deactivate(evnt_type)
	int evnt_type;
	{
	int argument[3], rest;
	register i;

	if(evnt_type < INTRVL1 || evnt_type > RANGE_IN)
		return(Gerror(DEACT_INVALERR, evnt_type));
	Gactevnt[evnt_type] = OFF;
	GOOD_RETURN;
	}


