#

	/*
	 *	GPAC TABLET GW ROUTINES
	 */


#include "../gpac.h"
#include "../error_codes.h"
#include "tab.h"

get_event(signal_seg)
	int signal_seg;
	{
	register struct event *rep;

	for(;;)
		switch((rep = Ginput())->status)
			{
		   case '3' :
			if(Gactevnt[INKING] == ON)
				return(ink());
			if(Gactevnt[BUTTON3_DOWN] == ON)
				{
				Gevent.type = BUTTON3_DOWN;
				return(rep);
				}
			break;
		   case '2' :
			if(Gactevnt[BUTTON2_DOWN] == ON)
				{
				Gevent.type = BUTTON2_DOWN;
				return(rep);
				}
			break;
		   case '1' :
			if(Gactevnt[BUTTON1_DOWN] == ON)
				{
				Gevent.type = BUTTON1_DOWN;
				return(rep);
				}
			break;
		   case 'z' :
			if(Gactevnt[Z_AXIS_DOWN] == ON)
				{
				Gevent.type = Z_AXIS_DOWN;
				return(rep);
				}
			}
	}
