#


	/*
	 *  TABLET DEPENDANT ROUTINES OF GPAC
	 *  Bill Reeves  -  July 1975
	 */


#include "../gpac.h"
#include "../error_codes.h"
#include "tab.h"


Ginit_tab(dtb_size)
	int dtb_size;
	{

	if(dtb_size <= 0)
		Gtablet.state = OFF;
	   else
		{
		Gtablet.state = ON;
		Gtablet.trk_seg = 0;
		Gtablet.desired_ink_size = dtb_size;
		}
	}
