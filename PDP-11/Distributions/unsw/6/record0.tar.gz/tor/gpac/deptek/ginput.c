#

#include "../gpac.h"
#include "../error_codes.h"
#include "tek.h"
#include "tab.h"


Ginput()
	{
	int arg;
	char buf[6];

	Gputc(ENTER_GIN1);
	Gputc(ENTER_GIN2);
	read(0, buf, 6);
	Gevent.x = (((buf[1]&037)<<5) | (buf[2]&037));
	Gevent.y = (((buf[3]&037)<<5) | (buf[4]&037));
	Gevent.status = buf[0];
	return(&Gevent);
	}
