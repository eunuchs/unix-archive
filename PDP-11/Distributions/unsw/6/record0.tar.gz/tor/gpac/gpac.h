#


/*
 *	GPAC Header File
 */

#define ERROR_RETURN return(-1)
#define GOOD_RETURN return(0)
#define ERROR -1
#define cycle for(;;)
#define valid_segment if(n<=0||n>Gmax_segs) return(Gerror(ISERR, n));

#define ERROR_FILE "/lib/gpac/gpac_errors"

#define SEG_OPEN 01
#define APPEND_FLAG 02
#define ERR_FLAG 04
#define SC_FLAG 010
#define CLEAR_SCREEN 020

#define BLANK 01
#define NON_BLANK 02

#define CODE_Q_LEN 06

#define CONTROL 0
#define VECTOR 01
#define BVECTOR 02
#define BPOINT 04
#define VPOINT 010
#define CHARACTER 020
#define INTENSITY 040
#define COLOUR 0100
#define LWIDTH 0200
#define FILLBEGIN 0400
#define FILLEND 01000

#define CORE_FULL 01
#define CORE_AVAILABLE 02

#define ON 1
#define OFF 0


int Gfil_size;
int *Gfil_start, *Gfil_end;
int Gcontrol_status, Gmem_status;
int Gblank_line;
int Gcur_seg;
int Gmax_segs;
int *Gcur_start;
double Gx_beg, Gy_beg, Gtransx_beg, Gtransy_beg,;
int Gx_abs, Gy_abs;
int Gfill;
double Gctma, Gctmb, Gctmc, Gctmd, Gctme, Gctmf;
int Gctm_pu;
double Gwx_left, Gwx_right, Gwy_bottom, Gwy_top;
double Gwcx, Gwcy, Gwsx, Gwsy;
double Gvcx, Gvcy, Gvsx, Gvsy;
double Givxmin, Givxmax, Givymin, Givymax;
int Gvx_right, Gvy_top;
double Gsx, Gsy, Gwvx, Gwvy;
int Gctm_mod, Gwv_mod;

struct ctm_stack
	{
	int *nxt_ctm;
	double a;
	double b;
	double c;
	double d;
	double e;
	double f;
	int ctm_mod;
	};
struct ctm_stack *Gctm_sp;

struct state_stack
	{
	struct state_stack *next_state;
	int colour;
	int lwidth;
	int intensity;
	double xxx;
	double yyy;
	double wcx, wcy, wsx, wsy;
	double vcx, vcy, vsx, vsy;
	int wv_mod;
	};

struct state_stack *Gstate_sp;

int Gdev_file;
char *Gfont;
int Gcharsiz;
int Gblksize;
int *Gblkptr, *Gcodep;
int Gintensity;
int Gcolour;
int Glwidth;

struct code_queue
	{
	int c_type;
	int xpos;
	int ypos;
	} Gcode_queue[CODE_Q_LEN];

int Gq_ptr, Gcode_mode;

struct segment
	{
	int *start_address;
	int *end_address;
	int *back_address;
	};

struct segment *Gseg_table;
