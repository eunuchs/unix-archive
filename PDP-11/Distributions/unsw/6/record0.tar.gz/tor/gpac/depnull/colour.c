#


#include "../gpac.h"
#include "null.h"
extern int Gfirst;

colour(colr)
	int colr;
	{

	if((colr =& 0377) == Gcolour && !Gfirst)
		GOOD_RETURN;
	if((Gcontrol_status & SEG_OPEN) && !(Gmem_status & CORE_FULL))
		Gadd_queue(COLOUR, colr, 0);
	Gcolour = colr;
	Gintensity = colr/16;
	GOOD_RETURN;
	}
