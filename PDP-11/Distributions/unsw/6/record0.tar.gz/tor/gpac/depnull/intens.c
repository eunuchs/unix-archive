#


#include "../gpac.h"
#include "null.h"
extern int Gfirst;

intens(in)
	int in;
	{

	if((in =% 16) == Gintensity && !Gfirst)
		GOOD_RETURN;
	if((Gcontrol_status & SEG_OPEN) && !(Gmem_status & CORE_FULL))
		Gadd_queue(COLOUR, in*16, 0);
	Gintensity = in;
	Gcolour = in*16;
	GOOD_RETURN;
	}
