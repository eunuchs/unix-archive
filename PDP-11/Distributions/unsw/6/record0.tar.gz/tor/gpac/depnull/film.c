#


#include "../gpac.h"
#include "../error_codes.h"
#include "null.h"

Gfilm_term()
	{

	Gframe_insert(UPDATE_COMMAND);
	}


Gblk_copy(blk_ptr)
	int *blk_ptr;
	{
	register *p;

	p = blk_ptr;
	while(*p != TERM)
		Gframe_insert(*p++);
	}
