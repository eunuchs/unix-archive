#


#include "../gpac.h"
#include "../error_codes.h"
#include "null.h"

post(n)
	int n;
	{
	register i;

	valid_segment;
	i = n;
	if((Gcontrol_status & SEG_OPEN) && (Gcur_seg == i))
		gclose();
	if(Gseg_table[i].start_address)
		Gpda_table[i] =| (POST|UPDATABLE);
	   else
		return(Gerror(NOEXIST_ERR, i));
	GOOD_RETURN;
	}


unpost(n)
	int n;
	{
	register i;

	valid_segment;
	i = n;
	if(Gseg_table[i].start_address)
		{
		if(Gpda_table[i] & POST)
			{
			Gcontrol_status =| CLEAR_SCREEN;
			Gpda_table[i] =& ~POST;
			}
		}
	   else
		return(Gerror(NOEXIST_ERR, n));
	GOOD_RETURN;
	}
