#

	/*
	 *	HEADER FOR NULL DEVICE ROUTINES
	 */


#define STANDARD_FORMAT_MAGIC_NUMBER 046033

#define JUMP 0
#define TERM 077400

#define POST 01
#define UPDATABLE 02

#define NOP 0
#define SET_VALUE 1
#define SET_THICK_COLOUR 2
#define ESCAPE 7
#define DUMMY_BIG_NUMBER 100

#define CLEAR_COMMAND 071000
#define UPDATE_COMMAND 074000
#define FILL_COMMAND 073400
#define CHARACTER_COMMAND 072000
#define SET_FONT 072400
#define END_OF_DATA_COMMAND 070000

char *Gpda_table;
int Garg1, Garg2, Garg3, Garg4, Garg5, Gop, Gmoveto;
int Gfill;
double Gfillx, Gfilly;
