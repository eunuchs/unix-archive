#


#include "../gpac.h"
#include "null.h"
extern int Gfirst;

lwidth(width)
	int width;
	{

	if((width =% 16) == Glwidth && !Gfirst)
		GOOD_RETURN;
	if((Gcontrol_status & SEG_OPEN) && !(Gmem_status & CORE_FULL))
		Gadd_queue(LWIDTH, width, 0);
	Glwidth = width;
	GOOD_RETURN;
	}
