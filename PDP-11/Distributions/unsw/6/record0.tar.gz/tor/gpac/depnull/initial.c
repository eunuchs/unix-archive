#

#include "../gpac.h"
#include "../error_codes.h"


double Gvcx 2047.5;
double Gvsx 2047.5;
double Gvsy 2047.5;
double Gsx 4.00293;
double Gsy 4.00293;
double Gwvx 0.0;
double Gwvy 0.0;
int Gvx_right 4095;
int Gvy_top 4095;
double Gvcy 2047.5;

int Gdev_file 1;
int Gblank_line BVECTOR;
int Gx_abs -1;
int Gy_abs -1;

int Gwv_mod 1;
double Givxmin 0.0;
double Givxmax 1.0;
double Givymin 0.0;
double Givymax 1.0;
