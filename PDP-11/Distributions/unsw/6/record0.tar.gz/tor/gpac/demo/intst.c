#

/*
 *	Simple program to draw intensity
 *	grids on the screen.
 */

int df[4*1024] {0, 0};

int nlines;
double dx, dy;


main()
	{
	int arg[3];
	register i;
	register j;

	init(4*1024, 0, 10, "fontf.k");
	beginfilm("intfilm");
	for(;;)
		{
		printf("numer of lines ? ");
		nlines = rin();
		if(nlines == 0)
			{
			printf("num frames %d\n", endfilm());
			finish();
			exit();
			}
		nlines = (nlines>>4)<<4;
		printf("give you %d\n", nlines);
		gopen(1);
		dx = 975./nlines;
		dy = 975.;
		moveto(25., 25.);
		for(i = 0; i < 16; i++)
			{
			intens(i);
			for(j = 0; j < nlines>>4; j++)
				{
				line(0.0, dy);
				move(dx, -dy);
				}
			}
		post(1);
		frame(100);
		include(1);
		}
	}
