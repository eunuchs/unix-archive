#

/*
 *	Program to draw petals.
 *	A good sequence is: 
 *		344, 8192, 16, 0, 0, -360, 3
 */

int df[8*1024] { 0, 0 };

#define dpr (3.14159265358/1440.)

double fx(petal, style, cnt)
	int petal, style, cnt;
	{
	int t, tt;
	double x, r;
	double cos();

	t = lrem(hmul(cnt,style), cnt*style, 2880);
	tt = lrem(hmul(petal,t), petal*t, 2880);
	r = cos(tt*dpr);
	x = 400.*cos(t*dpr)*r+512.;
	return(x);
	}

double fy(petal, style, cnt)
	int petal, style;
	{
	int t, tt;
	double y, r;
	double sin(), cos();

	t = lrem(hmul(cnt, style), cnt*style, 2880);
	tt = lrem(hmul(petal, t), petal*t, 2880);
	r = cos(tt*dpr);
	y = 400.*sin(t*dpr)*r+512.;
	return(y);
	}
main(argc, argv)
	int argc;
	char *argv[];
	{
	int i, j, k;
	int petal, style;
	int d_petal, d_style, minvec, maxvec, delay;
	int absmaxvec;
	double x, y;
	char string[20];

	init(8*1024, 0*1024, 10, "fixed.k");
	printf("style ?");
	style = rin();
	printf("petal ?");
	petal = rin();
	printf("d_style ?");
	d_style = rin();
	printf("d_petal ?");
	d_petal = rin();
	printf("minvec ? ");
	minvec = rin();
	printf("maxvec ?");
	maxvec = rin();
	absmaxvec = (maxvec < 0 ? -maxvec : maxvec);
	printf("delay ?");
	delay = rin();
	for(;;)
		{
		i = nsegs(style, petal);
		if(maxvec < 0 && i > -maxvec) i = -maxvec;
		if(i >= minvec && i <= absmaxvec)
			{
			gopen(3);
			moveto(350., 1000.);
			chars("# OF VECTORS IS ");
			numstr(i, string);
			move(225., 0.);
			chars(string);
			post(3);
			gopen(2);
			moveto(912., 512.);
			post(2);
			for(j = 1; j <= i; j++)
				{
				x = fx(petal,style,j);
				y = fy(petal,style,j);
				append(2);
				lineto(x, y);
				gclose();
				}
			}
		sleep(delay);
		style =+ d_style;
		petal =+ d_petal;
		}
	finish();
	}

nsegs(style, petal){
	register n;
	n=2880/gcd(2880,style);
	if(!(n&1) && petal&1)
		return(n>>1);
	return(n);
}

gcd(aa, bb){
	register a, b;
	a=aa;
	b=bb;
	while(a!=b)
		if(a>b)
			a =- b;
		else
			b =- a;
	return(a);
}


numstr(num, str)
	int num;
	char *str;
	{
	int i,j;
	char inver[10];
	char *rev, *cptr;

	rev = inver;
	cptr = str;
	while(num != 0)
		{
		*rev++ = (num%10) +'0';
		num =/ 10;
		}
	while(rev > inver)
		*cptr++ = *--rev;
	*cptr = '\0';
	}
