#

	/*
	 * CONTROL MODULE FOR GPAC
	 */

#include "../gpac.h"
#include "../error_codes.h"

append(n)
	int n;
	{

	valid_segment;
	if(Gcontrol_status & SEG_OPEN)
		return(Gerror(MUL_SEGERR, "append", n));
	if(Gseg_table[n].start_address == 0)
		return(Gerror(NOEXIST_ERR, "append", n));
	Gcur_seg = n;
	Gcontrol_status =| (APPEND_FLAG | SEG_OPEN);
	if((Gcur_start = Gopenseg()) == ERROR)
		ERROR_RETURN;
	   else
		{
		Gcode_mode = CONTROL;
		GOOD_RETURN;
		}
	}
