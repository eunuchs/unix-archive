#
#include "../gpac.h"
#include "../error_codes.h"

curveto(n, array)
	int n;
	float array[];
	{
	register float *fp;
	register i;
	double old_x, old_y, x, y;

	if((Gcontrol_state & SEG_OPEN) && !(Gmem_status & CORE_FULL))
		{
		if(Gctm_pu)
			Gctm_update();
		fp = array;
		moveto(*(fp), *(fp+1));
		n--;
		fp++;	fp++;
		old_x = Gtransx_beg;
		old_y = Gtransy_beg;
		for(i = 0; i < n; i++)
			{

			x = *fp++;
			y = *fp++;
			if(Gctm_mod)
				Gctm_trans(&x, &y);
			/*
			 * clip the line please
			 */
			Gclip(old_x, old_y, x, y);
			old_x = x;
			old_y = y;
			}
		Gy_beg = *--fp;
		Gx_beg = *--fp;
		Gtransx_beg = x;
		Gtransy_beg = y;
		GOOD_RETURN;
		}
	   else
		return(Gerror(SEG_COREERR));
	}

