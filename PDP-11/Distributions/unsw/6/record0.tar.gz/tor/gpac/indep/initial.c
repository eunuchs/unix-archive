#

/*
 *	INITIALIZATIONS FOR GPAC
 */

#include "../gpac.h"
#include "../error_codes.h"


int Gintensity 15;
int Gcolour 15*16;
int Glwidth 1;

double Gwcx 511.5;
double Gwsx 511.5;
double Gwcy 511.5;
double Gwsy 511.5;
double Gwx_left 0.;
double Gwx_right 1023.;
double Gwy_bottom 0.;
double Gwy_top 1023.;

double Gctma 1.0;
double Gctmb 0.0;
double Gctmc 0.0;
double Gctmd 0.0;
double Gctme 1.0;
double Gctmf 0.0;

int Gcontrol_status ERR_FLAG|CLEAR_SCREEN;
