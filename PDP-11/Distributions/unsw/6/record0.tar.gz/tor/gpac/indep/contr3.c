#

	/*
	 * CONTROL MODULE FOR GPAC
	 */

#include "../gpac.h"
#include "../error_codes.h"

clear()
	{
	register i;

	for(i = 1; i <= Gmax_segs; i++)
		if(Gseg_table[i].start_address)
			unpost(i);
	GOOD_RETURN;
	}


erase()
	{
	register i;

	for(i = 1; i <= Gmax_segs; i++)
		if(Gseg_table[i].start_address)
			delete(i);
	GOOD_RETURN;
	}


errors(code)
	int code;
	{
	if(code)
		Gcontrol_status =| ERR_FLAG;
	   else
		Gcontrol_status =& ~ERR_FLAG;
	GOOD_RETURN;
	}
