#


#include "../gpac.h"
#include "../error_codes.h"


chars(string)
	char *string;
	{
	register cstart, count;
	register char *cptr;
	int ix, iy, cend;
	double xl, xr, y, d;

	if((Gcontrol_status & SEG_OPEN) && !(Gmem_status & CORE_FULL))
		{
		cptr = string;
		for(count = 0; *cptr++; count++);
		if(Gctm_pu)
			Gctm_update();
		xl = Gtransx_beg;
		y = Gtransy_beg;
		if(Gwv_mod)
			Gwv_trans(&xl, &y);
		xr = xl + Gcharsiz*count;
		if(Gvcy-Gvsy <= y && Gvcy+Gvsy >= y && Gvcx-Gvsx <= xr && Gvcx+Gvsx >= xl)
			{
			if((d = Gvcx-Gvsx) > xl)
				{
				cstart = (d-xl)/Gcharsiz+.999;
				Gadd_queue(Gblank_line, (ix = xl+cstart*Gcharsiz+.5), (iy = y+.5));
				}
			   else
				cstart = 0;
			if((d = Gvcx+Gvsx) < xr)
				cend = count-((xr-d)/Gcharsiz+.999);
			   else
				cend = count;
			Gchars(&string[cstart], cend-cstart);
			}
		}
	   else
		return(Gerror(SEG_COREERR));
	GOOD_RETURN;
	}
