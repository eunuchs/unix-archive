#

/*
 *	TRANSFORMATION MODULE OF GPAC
 */

#include "../gpac.h"
#include "../error_codes.h"

Gctm_trans(ax, ay)
	double *ax, *ay;
	{
	double t;

	t = Gctma*(*ax)+Gctmb*(*ay)+Gctmc;
	*ay = Gctmd*(*ax)+Gctme*(*ay)+Gctmf;
	*ax = t;
	}


Gctm_update()
	{

	Gtransx_beg = Gx_beg;
	Gtransy_beg = Gy_beg;
	Gctm_trans(&Gtransx_beg, &Gtransy_beg);
	}


