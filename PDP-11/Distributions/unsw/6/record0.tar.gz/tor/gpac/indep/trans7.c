#

/*
 *	MULTIPLICATION OF CURRENT TRANSFORMATION MATRIX
*/

#include "../gpac.h"
#include "../error_codes.h"

multmat(array)
	double array[3][2];
	{
	double b[3][2];
	
	Gctm_pu++;
	Gctm_mod++;
	
	b[0][0] = array[0][0]*Gctma + array[1][0]*Gctmd;
	b[1][0] = array[0][0]*Gctmb + array[1][0]*Gctme;
	b[2][0] = array[0][0]*Gctmc + array[1][0]*Gctmf + array[2][0];
	b[0][1] = array[0][1]*Gctma + array[1][1]*Gctmd;
	b[1][1] = array[0][1]*Gctmb + array[1][1]*Gctme;
	b[2][1] = array[0][1]*Gctmc + array[1][1]*Gctmf + array[2][1];
	Gctma=b[0][0];
	Gctmb=b[1][0];
	Gctmc=b[2][0];
	Gctmd=b[0][1];
	Gctme=b[1][1];
	Gctmf=b[2][1];
	GOOD_RETURN;
	}
