#

	/*
	 * CONTROL MODULE FOR GPAC
	 */

#include "../gpac.h"
#include "../error_codes.h"

defined_seg(n)
	int n;
	{

	valid_segment;
	if(Gseg_table[n].start_address)
		return(1);
	return(0);
	}
