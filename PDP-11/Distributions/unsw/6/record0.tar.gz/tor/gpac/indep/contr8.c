#

	/*
	 * CONTROL MODULE FOR GPAC
	 */

#include "../gpac.h"
#include "../error_codes.h"

opened_seg()
	{
	if(Gcontrol_status & SEG_OPEN)
		ERROR_RETURN;
	   else
		return(Gcur_seg);
	}
