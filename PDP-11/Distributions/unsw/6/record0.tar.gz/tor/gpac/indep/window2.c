#

/*
 *	WINDOW VIEWPORT MODULE OF GPAC
 */

#include "../gpac.h"
#include "../error_codes.h"

Gwv_trans(ax, ay)
	double *ax, *ay;
	{

	*ax = *ax*Gsx+Gwvx;
	*ay = *ay*Gsy+Gwvy;
	}
