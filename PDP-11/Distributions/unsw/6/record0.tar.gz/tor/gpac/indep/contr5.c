#

	/*
	 * CONTROL MODULE FOR GPAC
	 */

#include "../gpac.h"
#include "../error_codes.h"

extern int fout;

Gerror(err_num, arg1, arg2, arg3, arg4, arg5)
	int err_num;
	int arg1, arg2, arg3, arg4, arg5;
	{
	register char *cp;
	register cnt;
	register efile;
	char cbuf[60];
	char c;
	int save_fout;

	if(Gcontrol_status & ERR_FLAG || err_num == CORE_FULL_ERR)
		switch(err_num)
			{
			case SEG_COREERR :
				if(Gcontrol_status & SC_FLAG)
					break;
				Gcontrol_status =| SC_FLAG;
			default :
				if((efile = open(ERROR_FILE, 0)) < 0)
					{
					write(2, "GPAC ERROR - Gerror : Cant read error file\n", 43);
					ERROR_RETURN;
					}
				cnt = 0;
				while(cnt++ != err_num)
					do
						{
						read(efile, &c, 1);
						}  while(c != '\n');
				cp = cbuf;
				do
					{
					read(efile, &c, 1);
					*cp++ = c;
					}  while(c != '\n');
				*cp = '\0';
				save_fout = fout;
				fout = 2;
				printf(cbuf,arg1,arg2,arg3,arg4,arg5);
				fout = save_fout;
				close(efile);
			}
	ERROR_RETURN;
	}
