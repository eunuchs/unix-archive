#

	/*
	 * CONTROL MODULE FOR GPAC
	 */

#include "../gpac.h"
#include "../error_codes.h"

next_avail_seg()
	{
	register struct segment *rsp;

	for(rsp = &Gseg_table[1]; rsp <= &Gseg_table[Gmax_segs]; rsp++)
		if(rsp->start_address == 0)
			return(rsp-&Gseg_table[0]);
	ERROR_RETURN;
	}
