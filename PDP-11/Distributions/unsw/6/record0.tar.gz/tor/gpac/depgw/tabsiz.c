#

	/*
	 *	GPAC TABLET GW ROUTINES
	 */


#include "../gpac.h"
#include "../error_codes.h"
#include "tab.h"

tabsize(resolution)
	int resolution;
	{
	int arg[3];

	TAB_OPEN(tab_siz);
	arg[0] = RESOLUTION;
	arg[2] = resolution;
	if(Gstty(Gtablet.fd, arg) < 0)
		return(Gerror(TAB_BADSIZE, resolution));
	GOOD_RETURN;
	}
