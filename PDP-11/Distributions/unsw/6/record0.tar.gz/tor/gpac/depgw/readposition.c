#

	/*
	 *	GPAC TABLET GW ROUTINES
	 */


#include "../gpac.h"
#include "../error_codes.h"
#include "tab.h"

readposition()
	{

	TAB_OPEN(readposition);
	if(gtty(Gtablet.fd, &Gevent.x) < 0)
		return(Gerror(READ_ERR, "readposition"));
	Gevent.type = READPOSITION;
	Gevent.x =+ 512;
	Gevent.y =+ 512;
	return(&Gevent);
	}
