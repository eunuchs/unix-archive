#

	/*
	 *	GPAC GW ROUTINES
	 */


#include "../gpac.h"
#include "../error_codes.h"
#include "gw.h"

Gfilm_term()
	{

	Gframe_insert(gw_term);
	}


Gblk_copy(blk_ptr)
	int *blk_ptr;
	{
	register *p;

	p = blk_ptr+2;
	while(*p != gw_term)
		Gframe_insert(*p++);
	}
