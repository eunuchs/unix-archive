#


	/*
	 *  TABLET DEPENDANT ROUTINES OF GPAC
	 *  Bill Reeves  -  July 1975
	 */


#include "../gpac.h"
#include "../error_codes.h"
#include "tab.h"


tab_rel()
	{

	Gtabclose();
	Gtablet.fd = 0;
	Gtablet.state = OFF;
	}


tab_get()
	{

	if(Gtablet.fd == 0 && Gtablet.state == OFF)
		Ginit_tab(Gtablet.desired_ink_size);
	}
