#

	/*
	 *	GPAC GW ROUTINES
	 */


#include "../gpac.h"
#include "../error_codes.h"
#include "gw.h"

whereis(n, ax, ay)
	int n;
	double *ax, *ay;
	{
	register i;
	register *ptr;
	register x;
	int y;

	i = n;
	if(Gseg_table[i].start_address)
		{
		ptr = Gseg_table[i].start_address+3;	/*  to the setxy - *** GW DEPENDANT  */
		x = (*ptr++)+512;
		y = (*ptr)+512;
		screentouser(x, y, ax, ay);
		}
	   else
		return(Gerror(NOEXIST_ERR, "whereis", i));
	GOOD_RETURN;
	}
