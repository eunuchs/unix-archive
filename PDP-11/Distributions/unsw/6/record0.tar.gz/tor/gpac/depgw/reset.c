#

	/*
	 *	GPAC GW ROUTINES
	 */


#include "../gpac.h"
#include "../error_codes.h"
#include "gw.h"

resetintens(n, in)
	int n;
	int in;
	{
	register i;
	register *ptr;

	valid_segment;
	i = n;
	if(Gseg_table[i].start_address)
		{
		ptr = Gseg_table[i].start_address+5;	/*  get to the initial setintens - **** GW DEPENDANT  */
		*ptr = gw_int_load | (in&017);
		}
	   else
		return(Gerror(NOEXIST_ERR, "resetintens", n));
	GOOD_RETURN;
	}
