#

	/*
	 *	GPAC GW ROUTINES
	 */


#include "../gpac.h"
#include "../error_codes.h"
#include "gw.h"
#include "tab.h"

double Gvcx 511.5;
double Gvsx 511.5;
double Gvcy 511.5;
double Gvsy 511.5;
double Givxmin 0.0;
double Givxmax 1.0;
double Givymin 0.0;
double Givymax 1.0;
double Gsx 1.0;
double Gsy 1.0;
double Gwvx 0.0;
double Gwvy 0.0;
int Gvx_right 1023;
int Gvy_top 1023;
int Gblank_line BPOINT;
struct inkmode Ginkmode { EQUAL_SPACE, 4, BUTTON3, 0};
int Gcharsiz 10;
