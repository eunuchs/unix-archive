#

	/*
	 *	GPAC GW ROUTINES
	 */


#include "../gpac.h"
#include "../error_codes.h"
#include "gw.h"

displace(n, dx, dy)
	int n;
	double dx, dy;
	{
	register i;
	register x;
	int y;
	double ax, ay;
	register *ptr;

	valid_segment;
	i = n;
	if(Gseg_table[i].start_address)
		{
		ptr = Gseg_table[i].start_address+3;	/*  get to the initial setxy - **** GW DEPENDENT  */
		x = (*ptr++)+512;
		y = *ptr+512;
		screentouser(x, y, &ax, &ay);
		dx =+ ax;
		dy =+ ay;
		if(Gctm_mod)
			Gctm_trans(&dx, &dy);
		if(Gwv_mod)
			Gwv_trans(&dx, &dy);
		*ptr-- = (i = dy) - 512;
		*ptr = (i = dx) - 512;
		}
	   else
		return(Gerror(NOEXIST_ERR, "displace", n));
	GOOD_RETURN;
	}


reposition(n, x, y)
	int n;
	double x, y;
	{
	register i;
	register *ptr;

	valid_segment;
	i = n;
	if(Gseg_table[i].start_address)
		{
		ptr = Gseg_table[i].start_address+3;	/*  to the setxy - *** GW DEPENDANT  */
		if(Gctm_mod)
			Gctm_trans(&x, &y);
		if(Gwv_mod)
			Gwv_trans(&x, &y);
		*ptr++ = (i = x) - 512;
		*ptr = (i = y) - 512;
		}
	   else
		return(Gerror(NOEXIST_ERR, "reposition", i));
	GOOD_RETURN;
	}
