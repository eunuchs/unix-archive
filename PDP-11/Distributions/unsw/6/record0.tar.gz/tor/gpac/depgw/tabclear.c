#

	/*
	 *	GPAC TABLET GW ROUTINES
	 */


#include "../gpac.h"
#include "../error_codes.h"
#include "tab.h"

tabclear()
	{
	int arg[3];

	TAB_OPEN(tabclear);
	arg[0] = WAIT_CLEAR;
	Gstty(Gtablet.fd, arg);
	GOOD_RETURN;
	}
