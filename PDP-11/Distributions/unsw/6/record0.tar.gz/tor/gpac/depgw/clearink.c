#

	/*
	 *	GPAC TABLET GW ROUTINES
	 */


#include "../gpac.h"
#include "../error_codes.h"
#include "tab.h"

clearink()
	{
	register *p;
	register i;

	TAB_OPEN(clearink);
	if(p = Gtablet.buf_addr+1+Gtablet.curr_ink_size)
		for(i = 0; i < Gtablet.curr_ink_size; i++)
			*--p = GW_TERM;
	}


