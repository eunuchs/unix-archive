#

	/*
	 *	GPAC GW ROUTINES
	 */


#include "../gpac.h"
#include "../error_codes.h"
#include "gw.h"

scroller(comm, arg)
	int comm;
	int *arg;
	{

	switch(comm)
		{
		case 0 :
			putchar(032);
			putchar(030);
			sleep(1);
			break;
		case 1 :
			putchar(032);
			putchar(031);
			break;
		case 2 :
			putchar(032);
			putchar(03);
			break;
		case 3 :
			printf("\032\026t%-db%-dl%-dr%-d\032\026", arg[0], arg[1], arg[2], arg[3]);
			break;
		case 4 :
			printf("\032\026s%-d\032\026", arg[0]);
			break;
		default :
			return(Gerror(SCROL_ERR, comm));
		}
	GOOD_RETURN;
	}
