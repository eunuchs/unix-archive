#

	/*
	 * GRAPHIC WONDER DEPENDENDENT ROUTINES - HEADER
	 */

#define NGW 4

#define read_it 0
#define read_write 02
#define GRAB 0
#define MAP 1
#define start 04
#define resume 05
#define dtabr 010
#define waittilcomm 012


#define gw_jump 000000
#define gw_xqt  0100001
#define gw_jms 0100000
#define gw_stpsnc 0010001
#define gw_waittil 0040001
#define gw_term 0100000
#define gw_setxy 0100222
#define gw_sviof1 0214
#define gw_iof1 0100204
#define gw_int_load 0100100
#define GW_LOAD_SCALE 0100140
#define load_long_format 0100062
#define load_med_format 0100061
#define load_short_format 0100060
#define gw_load_cmode 0100041
#define gw_unload_cmode 0100040
#define setup_character 0200
#define gw_setstate 0100223
#define gw_state 0107422
#define gw_ion 0100201
#define gw_ioff 0100202
#define gw_nop 0100360

#define short_vect 01
#define med_vect 05
#define long_vect 025

#define gw_null_character 00
#define dummy_big_number 100
#define NULL 0
/*
 * Dependent on CODE_Q_LEN  -  at least twice as big
 */
#define byte_q_len 16

int Gnum_generated;
int Gbyte_ptr;
char Gbyte_queue[byte_q_len];
int *Gtabinkptr;
