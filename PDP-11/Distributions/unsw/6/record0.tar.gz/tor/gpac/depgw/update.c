#

	/*
	 *	GPAC GW ROUTINES
	 */


#include "../gpac.h"
#include "../error_codes.h"
#include "gw.h"

update()
	{

	}
