#

	/*
	 *	GPAC TABLET GW ROUTINES
	 */


#include "../gpac.h"
#include "../error_codes.h"
#include "tab.h"

deactivate(evnt_type)
	int evnt_type;
	{
	int argument[3], rest;
	register i;

	TAB_OPEN(deactivate);
	if(evnt_type < INTRVL1 || evnt_type > RANGE_IN)
		return(Gerror(DEACT_INVALERR, evnt_type));
	Gactevnt[evnt_type] = OFF;
	if(evnt_type >= Z_AXIS_DOWN)
		{
		rest = 0;
		for(i = Z_AXIS_DOWN; i < RANGE_IN; i++)
			if(Gactevnt[i++] == ON || Gactevnt[i] == ON)
				rest =| 1<<((i-Z_AXIS_DOWN)>>1);
		if(rest != 0)
			{
			argument[0] = ACTIVATE;
			argument[1] = BUTTONS;
			argument[2] = rest;
			if(Gstty(Gtablet.fd, argument) < 0)
				return(Gerror(DEACT_ERR));
			GOOD_RETURN;
			}
		evnt_type = BUTTONS;
		}
	argument[0] = DEACTIVATE;
	argument[2] = evnt_type;
	if(Gstty(Gtablet.fd, argument) < 0)
		return(Gerror(DEACT_ERR));
	GOOD_RETURN;
	}


