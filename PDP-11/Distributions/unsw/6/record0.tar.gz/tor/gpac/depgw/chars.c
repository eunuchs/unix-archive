#

	/*
	 *	GPAC GW ROUTINES
	 */


#include "../gpac.h"
#include "../error_codes.h"
#include "gw.h"

Gchars(c_ptr, c_count)
	char *c_ptr;
	int c_count;
	{
	int i, next_word;

	if(!(Gmem_status & CORE_FULL))
		{
		Ggenerate(Gq_ptr);
		if(Gcode_mode != CHARACTER)
			if(Gmake_room(3) != ERROR)
				{
				Ginsert_code(gw_load_cmode);
				Ginsert_code(gw_ion);
				Ginsert_code(load_short_format);
				Gcode_mode = CHARACTER;
				}
		for(i = 1; i<=c_count; i =+ 2)
			{
			next_word = (*c_ptr&0377) | ((i+1<=c_count ? *(c_ptr+1) 
						: gw_null_character)<<8);
			c_ptr =+ 2;
			if(Gmake_room(1) != ERROR)
				Ginsert_code(next_word);
			}
		}
	}
