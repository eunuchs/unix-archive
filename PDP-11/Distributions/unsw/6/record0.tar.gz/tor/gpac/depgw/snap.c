#

	/*
	 *	GPAC GW ROUTINES
	 */


#include "../gpac.h"
#include "../error_codes.h"
#include "gw.h"

snap(device)
	char *device;
	{
	register file, i;
	int zero;

	if((file = creat("snap.tmp", 0644)) < 0)
		return(Gerror(OPEN_ERR, "snap.tmp"));
	write(file, &Gfil_start, 2);
	zero = 0;
	write(file, &zero, 2);
	i = Gfil_start;
	i =+ (Gfil_size<<1)-4;
	write(file, 0, i);
	close(file);
	if((i = fork()) < 0)
		return(Gerror(FORK_ERR, "snap"));
	if(i == 0)
		{
		close(Gdev_file);
		execl("/usr/graf/gwtost", "gwtost", "snap.tmp", "snap.out", 0);
		exit();
		}
	if(wait(&zero) != i)
		printf("WAIT error: %o\n", zero);
	if(!(device[0] == 'n' && device[1] == 'u' && device[2] == 'l' && device[3] == 'l'))
		{
		if((i = fork()) < 0)
			return(Gerror(FORK_ERR, "snap"));
		if(i == 0)
			{
			close(Gdev_file);
			switch(device[0] | (device[1] << 8))
				{
				case 'vp' :
					execl("/bin/opr", "opr", "-vp", "-t", "snap.out", 0);
				case 'gw' :
					execl("/usr/graf/stogw", "stogw", "snap.out", 0);
				case 'cv' :
					break;
				default :
					execl("/bin/mv", "mv", "snap.out", device, 0);
				}
			exit();
			}
		if(wait(&zero) != i)
			printf("WAIT error2: %o\n", zero);
		unlink("snap.out");
		}
	unlink("snap.tmp");
	GOOD_RETURN;
	}
