#

	/*
	 *	GPAC TABLET GW ROUTINES
	 */


#include "../gpac.h"
#include "../error_codes.h"
#include "tab.h"

get_event()
	{
	int arg[3];
	register i, bit, initial;
	int new, old, shift;
	int err_flag;

	TAB_OPEN(get_event);
again :
	arg[0] = GET_EVENT;
	arg[2] = &Gevent;
	err_flag = 0;
	if(Gstty(Gtablet.fd, arg) < 0)
		if(Gevent.type == INKING)
			err_flag++;
		   else
			return(Gerror(TAB_EVNTERR));
	switch(Gevent.type)
		{
		case INKING :
			if(Gdissa_ink() == ERROR)
				ERROR_RETURN;
			break;
		case BUTTONS :
			initial = Gevent.ink_ptr;
			for(i = Z_AXIS_DOWN; i <= RANGE_IN; i++)
				{
				if(i%2)
					{
					new = 0;
					old = 1;
					}
				   else
					{
					new = 1;
					old = 0;
					}
				shift = (i-Z_AXIS_DOWN)>>1;
				bit = 1<<shift;
				old =<< shift;
				new =<< shift;
				if((Gactevnt[i] == ON) && ((bit&Gevent.tablet_status) == new)
					&& ((bit&initial) == old))
						goto aha;
				}
			if(Gtablet.trk_seg)
				track(Gtablet.trk_seg);
			goto again;
		aha :
			Gevent.type = i;
		}	/*  EOS  */
	Gevent.x =+ 512;
	Gevent.y =+ 512;
	if(err_flag)
		Gevent.type = -Gevent.type;
	return(&Gevent);
	}
