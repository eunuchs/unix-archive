#

	/*
	 *	GPAC GW ROUTINES
	 */


#include "../gpac.h"
#include "../error_codes.h"
#include "gw.h"

colour(colr)
	int colr;
	{

	}


lwidth(width)
	int width;
	{

	}


depth()
	{

	}


rgb()
	{

	}


background()
	{

	}


fillbegin()
	{

	}


fillend()
	{

	}
