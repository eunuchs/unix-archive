#

#include "../gpac.h"
#include "../error_codes.h"
#include "gw.h"


schars(scale, string)
	int scale;
	char *string;
	{

	if((Gcontrol_status & SEG_OPEN) && !(Gmem_status & CORE_FULL))
		{
		Ggenerate(Gq_ptr);
		if(Gmake_room(1) != ERROR)
			Ginsert_code(GW_LOAD_SCALE | (scale%16));
		chars(string);
		if(Gmake_room(1) != ERROR)
			Ginsert_code(GW_LOAD_SCALE | 8);
		}
	   else
		return(Gerror(SEG_COREERR));
	GOOD_RETURN;
	}
