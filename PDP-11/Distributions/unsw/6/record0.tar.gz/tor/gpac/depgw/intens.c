#

	/*
	 *	GPAC GW ROUTINES
	 */


#include "../gpac.h"
#include "../error_codes.h"
#include "gw.h"

intens(in)
	int in;
	{

	if((Gcontrol_status & SEG_OPEN) && !(Gmem_status & CORE_FULL))
		Gadd_queue(INTENSITY, in, 0);
	   else
		Gintensity = in;
	GOOD_RETURN;
	}
