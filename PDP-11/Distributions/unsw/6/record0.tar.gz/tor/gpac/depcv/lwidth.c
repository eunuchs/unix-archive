#


#include "../gpac.h"
#include "cv.h"

lwidth(width)
	int width;
	{

	width =% 16;
	if((Gcontrol_status & SEG_OPEN) && !(Gmem_status & CORE_FULL))
		Gadd_queue(LWIDTH, width, 0);
	Glwidth = width;
	GOOD_RETURN;
	}
