#


#include "../gpac.h"
#include "../error_codes.h"
#include "cv.h"

depth(n, dep)
	int n;
	int dep;
	{

	valid_segment;
	Gdepth_table[n] = dep;
	GOOD_RETURN;
	}
