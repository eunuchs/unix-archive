reposition()
	{

	}


displace()
	{

	}


scroller()
	{

	}




rgb()
	{

	}


background()
	{

	}


resetintens()
	{

	}


activate()
	{

	}


deactivate()
	{

	}


ink()
	{

	}


ink_parms()
	{

	}


get_event()
	{

	}


clearink()
	{

	}


track()
	{

	}

untrack()
	{

	}


cursor()
	{

	}


tabsize()
	{

	}


tabclear()
	{

	}
