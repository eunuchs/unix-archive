#

#include "../gpac.h"
#include "../error_codes.h"


double Gvcx 127.5;
double Gvsx 127.5;
double Gvsy 127.5;
double Gsx .249633;
double Gsy .249633;
double Gwvx 0.0;
double Gwvy 0.0;
int Gvx_right 255;
int Gvy_top 255;
double Gvcy 127.5;

int Gdev_file;
int Gblank_line BVECTOR;
int Gx_abs -1;
int Gy_abs -1;

int Gwv_mod 1;
 double Givxmin 0.0;
 double Givxmax 1.0;
 double Givymin 0.0;
 double Givymax 1.0;
