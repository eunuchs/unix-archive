#


#include "../gpac.h"
#include "cv.h"

intens(in)
	int in;
	{

	in =% 16;
	if((Gcontrol_status & SEG_OPEN) && !(Gmem_status & CORE_FULL))
		Gadd_queue(INTENSITY, in, 0);
	Gintensity = in;
	GOOD_RETURN;
	}
