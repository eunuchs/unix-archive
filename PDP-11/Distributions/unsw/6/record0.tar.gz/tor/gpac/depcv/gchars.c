#


#include "../gpac.h"
#include "cv.h"

#define NULL 0

Gchars(c_ptr, c_cnt)
	char *c_ptr;
	int c_cnt;
	{
	register i, nxt_word;
	register char *cp;

	cp = c_ptr;
	Ggenerate(Gq_ptr);
	i = CHARACTER_COMMAND;
	i =| (c_cnt+1)>>1;
	if(Gmake_room(1) != ERROR)
		Ginsert_code(i);
	for(i = 1; i < c_cnt; i =+ 2)
		{
		nxt_word = *cp | ((i+1 < c_cnt ? *(cp+1) : NULL)<<8);
		cp =+ 2;
		if(Gmake_room(1) != ERROR)
			Ginsert_code(nxt_word);
		}
	}
