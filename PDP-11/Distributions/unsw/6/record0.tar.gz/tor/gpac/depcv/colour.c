#


#include "../gpac.h"
#include "cv.h"

colour(colr)
	int colr;
	{

	colr =& 0377;
	if((Gcontrol_status & SEG_OPEN) && !(Gmem_status & CORE_FULL))
		Gadd_queue(COLOUR, colr, 0);
	Gcolour = colr;
	GOOD_RETURN;
	}
