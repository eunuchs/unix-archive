#


#include "../gpac.h"
#include "../error_codes.h"
#include "cv.h"

fillbegin()
	{

	if((Gcontrol_status & SEG_OPEN) && !(Gmem_status & CORE_FULL))
		{
		if(Gfill)
			return(Gerror(FILL_ON));
		Gadd_queue(FILLBEGIN, 0, 0);
		Ggenerate(Gq_ptr);
		Gfillx = Gx_beg;
		Gfilly = Gy_beg;
		Gfill++;
		}
	   else
		return(Gerror(SEG_COREERR));
	GOOD_RETURN;
	}


fillend()
	{

	if((Gcontrol_status & SEG_OPEN) && !(Gmem_status & CORE_FULL))
		{
		if(!Gfill)
			return(Gerror(FILL_OFF));
		Ggenerate(Gq_ptr);
		Gclosefill(Gx_beg, Gy_beg);
		Gadd_queue(FILLEND, 0, 0);
		Ggenerate(Gq_ptr);
		Gfill = 0;
		}
	   else
		return(Gerror(SEG_COREERR));
	GOOD_RETURN;
	}
