char line[80];
int buf[259];
main(ac, v)
	char **v;
{
	register m, nl, j;
	int i, n;
	nl = 16;
	i = 0;
	if(*v[1] == '-') {
		ac--;
		v++;
		nl = 0;
		while(m = *++*v)
			nl = nl*10+m-'0';
		if(!nl)
			nl = 24;
	}
	n = ac-1;
	while(--ac > 0 || ac == n)
		if(ac == 0 || fopen(*++v, buf) >= 0) {
			j = 0;
			while((m = getc(buf)) >= 0) {
				line[j] = m;
				if(line[j++] == '\n') {
				count:
					if(++i == nl) {
						write(1, line, j-1);
						read(2, 0, 1);
						i = 0;
					}
					else
						write(1, line, j);
					j = 0;
				}
				else if(j == 79) {
					line[j] = '\n';
					goto count;
				}
			}
			if(j > 0)
				write(1, line, j);
			close(buf[0]);
		}
}
