#define STX 02
#define ETX 03
#define L 010
#define R 025
#define U 032
#define D 012
#define US 037
#define RUB 0177
int ar[3], l[500], p[500], fd, ll, nn, m;
char a[160], flg;
main(c, v)int c;char **v;{
register int i, n;
register char cc;
char b[20],buf[518];
gtty(0, ar);
ar[2] =| 040;
stty(0, ar);
creat("z z", 0644);
if((fd = open("z z", 2)) < 0)error("open-z");
p[0] = 0;
if(fopen(*++v, buf) < 0) {
if(fcreat(*v, buf) < 0)error("create");
nn = l[0] = 0;
}
else {
for(m = nn = 0; (a[m] = getc(buf)) > 0; m++){
if(a[m]=='`')a[++m] = '`';
else if(a[m]<' ' && a[m]!=D){
a[m+1] = a[m]+'@';
a[m++] = '`'; }
if(m>=78)a[++m] = D;
if(a[m] == D) {
a[m] = 0;
l[nn++] = m;
p[nn] = p[nn-1]+m;
if(write(fd, a, m) != m)error("write");
m = -1;
if(nn > 499)error("size");
}}}
putn(nn);
putstr(" lines read\n");
getline(0);
m = n = 0;
while((cc = getchar()) != 04)
switch(cc) {
case L:
if(m)m--;
else  {w1(R);
if(n){ putline(n);
w1(U);
getline(--n);
m = l[n];
nchar(R,m);
}}
break;
case R:
if(a[m])m++;
else w1(L);
break;
case U:
putline(n);
if(n) {
n--;
getline(n);
}
else w1(D);
break;
case D:
putline(n);
if(n+1 < nn)getline(++n);
else w1(U);
break;
case RUB:
flg = 1;
if(a[m]) {
for(i = m; a[i]; i++)a[i] = a[i+1];
w1(L);
putstr(a+m);
w1(' ');
nchar(L,l[n]-m);
l[n]--;
}
else if(n<nn-1){
ll = -1;
putline(n);
getline(n+1);
ll = -1;
flg = 1;
putline(n+1);
l[n] =+ l[n+1];
for(i = n+1; i < nn; i++) {
p[i] = p[i+1];
l[i] = l[i+1];
}
nn--;
getline(n);
}
else w1(L);
break;
case US:
putline(n);
for(i = nn; i > n; i--) {
p[i+1] = p[i];
l[i+1] = l[i];
}
p[n+1] = p[n]+m;
l[n+1] = l[n]-m;
l[n] = m;
nn++;
getline(n);
w1(D);
getline(++n);
break;
case STX: putline(n);
putstr("\031\nstring: ");
for(i=0;(b[i]=getchar())!=ETX;i++);
n = search(b,i,n);
getline(n);
break;
case ETX: putline(n);
putstr("\031\nline no.: ");
for(n=0;(cc = getchar())>='0' && cc<='9';n = n*10+cc-'0');
if(!n)n++;
getline(n = n>nn?nn-1:n-1);
break;
default: if(cc>=' '){
for(i = l[n]; i >= m; i--)a[i+1] = a[i];
a[m++] = cc;
l[n]++;
}
putstr(a+m);
nchar(L,l[n]-m);
flg = 1;
}
putline(n);
putstr("\031\nwrite? ");
ar[2] =& ~040;
stty(0, ar);
if(getchar() == 'y') {
close(buf[0]);
if(fcreat(*v, buf) < 0)
error("create");
for(n = 0; n < nn; n++) {
skrd(n);
for(m = 0; m < l[n]; m++){
if(a[m] == '`'){ m++;
if(a[m]>='@' && a[m]<='_')a[m] =- '@';
}
putc(a[m], buf); }
putc(D, buf);
}
fflush(buf);
putn(nn);
putstr(" lines written on ");
putstr(*v);
w1(D);
}
unlink("z z");
}
error(s)char *s;{
putstr(s);
putstr(" error\n");
ar[2] =& ~040;
stty(0, ar);
exit();
}
getline(n)int n;{
register int i;
ll = skrd(n);
a[l[n]] = flg = 0;
w1('\r');
putstr(a);
w1(026);
w1('\r');
m = 0;
}
putline(n)int n;{
if(flg) {
if(l[n] > ll) {
p[n] = p[nn];
p[nn] =+ l[n];
}
if(seek(fd, p[n], 0) < 0)error("putseek");
if(write(fd, a, l[n]) != l[n])error("rewrite");
ll = l[n];
}}
search(b,nb,n)int nb,n; char b[];{
register int j,i;
for(m = n+1;m!=n;m = (m+1)%nn){
if(l[m]<nb)continue;
skrd(m);
for(i=0;i+nb<=l[m];i++){
j = 0;
do if(j==nb)return(m);
while(a[i+j]==b[j++]);
}}
return(m<0?nn-1:m);
}
nchar(c,n)char c; int n;{
while(n--)w1(c);
}
skrd(n)int n;{
register int nl;
if(seek(fd, p[n], 0) < 0)
error("getseek");
if((nl = read(fd, a, l[n])) != l[n])
error("read");
return(nl);
}
