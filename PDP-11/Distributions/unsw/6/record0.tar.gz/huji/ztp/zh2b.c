/*
 program to decipher hex dump

 parameters: length of undumped files in bytes.
 output: undumped files on out1,out2...
 */ 

char ibuf[518], obuf[518];
char out[4] "out0";
/*
 decipher hex byte
 */ 
getnum() {
	int register c, n;
	n = 0;
	while((c = getc(ibuf)) == '\n')
		;
	if(c == '/' || c < 0)
		return(-1);
	n = bin(c);
	c = getc(ibuf);
	n = n*16+bin(c);
	if(n < 0) {
		printf("What!! <0\n");
		return(-1);
	}
	return(n);
}
bin(c)
	int c;
{
	if(c >= '0' && (c <= '9'))
		return(c-'0');
	if(c >= 'a')
		c =- 'a'-'A';
	if(c >= 'A' && (c <= 'F'))
		return(c-'A'+10);
	printf("error %o\n", c);
	return(-1);
}

main(c, v)
	char **v;
{
	register i, n, j;
	while(--c) {
		out[3]++;
		fcreat(out, obuf);
		n = atoi(*++v);
		for(j = 0; j < n && (i = getnum()) >= 0; j++)
			putc(i, obuf);
		fflush(obuf);
		while(j++%512 && getnum() >= 0)
			;
		close(obuf[0]);
	}
}
