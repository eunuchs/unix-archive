/*
 program to undump SCOPE chars

 parameter: length of dumped file
 output: undumped file on "out"

 each input char is taken as a 6-bit SCOPE char;
 bits are accumulated in "b" and output 8 at a time.
 escape sequences: "a0" for null, "aa" for "a".
 */ 
char cdctab[64] {
 /* SCOPE values of ascii chars */ 
	055, 066, 064, 060, 053, 076, 067, 070, /* sp - ' */ 
	051, 052, 047, 045, 056, 046, 057, 050, /* ( - / */ 
	033, 034, 035, 036, 037, 040, 041, 042, /* 0 - 7 */ 
	043, 044, 063, 077, 072, 054, 073, 071, /* 8 - ? */ 
	074, 001, 002, 003, 004, 005, 006, 007, /* @ - G */ 
	010, 011, 012, 013, 014, 015, 016, 017, /* H - O */ 
	020, 021, 022, 023, 024, 025, 026, 027, /* P - W */ 
	030, 031, 032, 061, 075, 062, 000, 065 };	/* X - _ */ 
int buf[259];
main(ac, v)
	char **v;
{
	register char c;
	register b, nbit;
	int mask;
	long nbyt, n;
	fcreat("out", buf);
	v++;
	for(n = 0; c = *((*v)++); n = n*10+(c-'0'))
		;	/* atol(*v) */ 
	nbyt = b = nbit = 0;
	while((c = getchar()) && nbyt < n) {
		if(c == '\n')
			continue;
		if(c > 0177 || c < ' ') {
			write(2, "What?!!\n", 8);
			fflush(buf);
			exit();
		}
		/* null escape */ 
		if((c == 'A' || c == 'a') && (c = getchar()) == '0')
			c = '^';
		if(c > '_')
			c =- 'a'-'A';	/* change to upper case */ 
		c = cdctab[c-' '];
		b = (b<<6)|(c&077);
		nbit =+ 6;
		if(nbit >= 8) {
			nbit =- 8;
			mask = 0377<<nbit;
			putc((b&mask)>>nbit, buf);
			b =& ~mask;
			nbyt++;
			if(nbyt%512 == 0)
				nbit = b = 0;
		}
	}
	fflush(buf);
}
