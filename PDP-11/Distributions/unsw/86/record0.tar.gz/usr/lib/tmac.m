.if n .nx /usr/lib/macros/npwbmm.m
.if t .nx /usr/lib/macros/tpwbmm.m
