/*
 * Structure of a directory
 */

struct	dir {
	int	d_ino;
	char	d_name[14];
};
