#
#include	"rt.h"

extern int	errno;

char *	progname;

main(argc,argv)
int	argc;
char *	argv[];
	{
	register int	rtfildes;
	register int	entrybc;
	register char	*ep;
	int		sector;
	struct dirseg	iobuf;
	char		ascii[10];
	int		numfree;

	progname = argv[0];
	if	(argc != 2)
		error(EINVAL);
	if	((rtfildes = open(argv[1],0)) < 0)
		error(errno);
	printf("%s\n",now2rts());
	iobuf.d_nextseg = FIRSTDIRSEG;
	while	(1)
		{
		sector = DIROFFSET + (iobuf.d_nextseg - 1) * DIRSEGSC;
		if	(seek(rtfildes,sector,3))
			error(errno);
		if	(read(rtfildes,&iobuf,sizeof iobuf) != sizeof iobuf)
			error(errno);
		entrybc = ENTRYBC + iobuf.d_xtraby;
		for	(ep = &iobuf.d_entries[0];
			(ep->e_status & S_ENDSEG) == 0;
			ep =+ entrybc)
			{
			if	(ep->e_status & (S_EMPTY | S_TENTATIVE))
				{
				printf("< UNUSED > %4d\n",ep->e_length);
				numfree =+ ep->e_length;
				}
			else	{
				r502a(ep->e_name[0],&ascii[0]);
				r502a(ep->e_name[1],&ascii[3]);
				ascii[6] = ep->e_ext ? '.' : ' ';
				r502a(ep->e_ext,&ascii[7]);
				printf("%10.10s %4d %s\n",ascii,
					ep->e_length,rtv2rts(ep->e_date));
				}
			}
		if	(iobuf.d_nextseg != NULLDIRSEG)
			printf("%\n");
		else break;
		}
	printf("%4d FREE BLOCKS\n",numfree);
	if	(close(rtfildes))
		error(errno);
	exit(0);
	}

error(arg)
int	arg;
	{
	errno = arg;
	perror(progname);
	exit(errno ? errno : -1);
	}
