rtv2rts(artv)	/*rt11-format time value to rt11-format time string*/
int	artv;			/*argument--rt11-format time value*/
	{
	register char * cp;
	register char * x;
	static char	string[10];

	cp = string;
	if	(artv == 0)
		*cp = '\0';
	else	{
		if	((*cp++ = (x = (artv >> 5) & 037)/10 + '0') == '0')
			*(cp - 1) = ' ';
		*cp++ = (x%10 + '0');
		*cp++ = '-';
		x = "JANFEBMARAPRMAYJUNJULAUGSEPOCTNOVDEC" +
			((((artv >> 10) & 037) - 1) * 3);
		*cp++ = *x++;
		*cp++ = *x++;
		*cp++ = *x++;
		*cp++ = '-';
		*cp++ = ((x = (artv & 037) + 72)/10) + '0';
		*cp++ = (x%10) + '0';
		*cp++ = '\0';
		}
	return(string);
	}

utv2rtv(autv)	/*unix time value to rt11-format time value*/
int	autv[];
	{
	register struct {
		int	t_seconds;
		int	t_minutes;
		int	t_hours;
		int	t_day;
		int	t_month;
		int	t_year;
		}	*tp;

	tp = localtime(autv);
	return((tp->t_year-72) | (tp->t_day << 5) | ((tp->t_month + 1) << 10));
	}

utv2rts(autv)	/*unix time value to rt11-format time string*/
int	autv[];
	{
	return(rtv2rts(utv2rtv(autv)));
	}

now2rtv()	/*now to rt11-format time value*/
	{
	int tvec[2];

	time(tvec);
	return(utv2rtv(tvec));
	}

now2rts()	/*now to rt11-format time string*/
	{
	return(rtv2rts(now2rtv()));
	}
