#include "cplot.h"

g_graphics()
{
	g_put(GS);
	g_status =& ~ALPHA;
}
