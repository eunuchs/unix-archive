int	yyportlib	1;

wdleng()
{
	return(16);
}
