struct Fspec {
	char Ftabs[22];
	char Fdel;
	char Flim;
	char Fmov;
	char Ffill;
};
