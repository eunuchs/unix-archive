static char Sccsid[] "@(#)clean	1.1";
/*
	Default clean_up routine for fatal and setsig.
	User defined clean_up routines are used for removing
	temporary files, etc.
*/

clean_up()
{
}
