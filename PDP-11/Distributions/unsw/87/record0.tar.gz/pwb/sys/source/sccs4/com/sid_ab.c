# include	"../hdr/defines.h"

SCCSID(@(#)sid_ab	1.2);

sid_ab(p,sp)
register char *p;
register struct sid *sp;
{
	if (*(p = satoi(p,&sp->s_rel)) == '.')
		p++;
	if (*(p = satoi(p,&sp->s_lev)) == '.')
		p++;
	if (*(p = satoi(p,&sp->s_br)) == '.')
		p++;
	p = satoi(p,&sp->s_seq);
	return(p);
}
