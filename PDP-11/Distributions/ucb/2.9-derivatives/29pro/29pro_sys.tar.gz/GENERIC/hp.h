#define	NHP	0
/* #define HP_DKN	0		/* drive # for iostat disk monitoring */
/* #define HP_DUMP	 		/* include dump routine */
