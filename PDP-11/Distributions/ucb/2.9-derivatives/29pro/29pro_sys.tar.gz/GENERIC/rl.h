#define	NRL	8
/* #define RL_DKN	0 */
/*#define	DISTRIBUTION_BINARY		/* autoconfigure swaplo for RL02's */
