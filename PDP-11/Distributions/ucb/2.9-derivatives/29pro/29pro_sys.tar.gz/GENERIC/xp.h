#define	NXP		4
#define	NXP_CONTROLLER	1
/* #define XP_DKN	0		/* drive # for iostat disk monitoring */
/* #define XP_DUMP			/* include dump routine */
#define XP_PROBE			/* check drive types at boot */
