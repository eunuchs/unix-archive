#define	NTS	1
#define	TS_IOCTL
