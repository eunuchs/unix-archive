#define	NVP	0
/* #define VP_TWOSCOMPL	/* if your interface wants two's complement bytecount */
