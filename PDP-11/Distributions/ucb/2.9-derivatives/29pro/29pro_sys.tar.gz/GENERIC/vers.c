char version[] = "Berkeley UNIX (Rev. 2.9.1) Wed Feb 17 05:00:51 GMT 1999\n";
