#define	NLP	1
