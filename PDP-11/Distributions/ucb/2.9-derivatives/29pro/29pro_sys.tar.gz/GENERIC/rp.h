#define	NRP	4
/* #define RP_DKN	0 */
