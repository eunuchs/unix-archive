#define	NRK	8
/* #define	RK_DKN	0 */
