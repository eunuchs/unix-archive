#define	NHS	0
/* #define HS_DKN	0		/* drive # for iostat disk monitoring */
