#define	NBK	0
