struct	rcdevice	{
	short	rcymd;
	short	rchm;
	short	rcsec;
	short	rccsr;
};
