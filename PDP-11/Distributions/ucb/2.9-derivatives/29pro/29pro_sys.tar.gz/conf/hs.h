#define	NHS	%NHS%
/* #define HS_DKN	0		/* drive # for iostat disk monitoring */
