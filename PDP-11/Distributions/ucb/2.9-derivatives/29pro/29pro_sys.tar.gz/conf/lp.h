#define	NLP	%NLP%
