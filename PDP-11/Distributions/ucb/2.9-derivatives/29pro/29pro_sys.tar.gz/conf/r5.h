#define NR5   %NR5%
