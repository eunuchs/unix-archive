#define	NDN	%NDN%
