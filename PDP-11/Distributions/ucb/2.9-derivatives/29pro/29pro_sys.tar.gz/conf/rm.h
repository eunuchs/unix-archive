#define	NRM	%NRM%
/* #define RM_DKN	0		/* drive # for iostat disk monitoring */
/* #define RM_DUMP	 		/* include dump routine */
