#define	NRP	%NRP%
/* #define RP_DKN	0 */
