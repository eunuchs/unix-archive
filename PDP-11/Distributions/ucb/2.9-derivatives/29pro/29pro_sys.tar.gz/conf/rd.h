#define NRD   %NRD%
