/*
 *  NKL11 includes both KL11's and DL11's.
 *  It should always be at least 1 (the console).
 */
#define	NKL	%NKL%
