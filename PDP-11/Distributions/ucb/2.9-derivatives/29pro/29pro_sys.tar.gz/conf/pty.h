#define NPTY   %NPTY%
