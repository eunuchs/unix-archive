#define	NTS	%NTS%
#define	TS_IOCTL
