#define NRA   %NRA%
