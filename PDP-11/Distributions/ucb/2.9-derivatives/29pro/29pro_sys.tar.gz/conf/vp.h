#define	NVP	%NVP%
/* #define VP_TWOSCOMPL	/* if your interface wants two's complement bytecount */
