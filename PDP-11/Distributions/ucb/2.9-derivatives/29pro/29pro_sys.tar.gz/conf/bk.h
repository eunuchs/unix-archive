#define	NBK	%NBK%
