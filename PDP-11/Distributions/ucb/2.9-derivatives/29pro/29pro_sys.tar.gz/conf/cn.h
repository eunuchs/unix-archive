#define NCN   %NCN%
