#define NPC   %NPC%
