#define	NXP		%NXP%
#define	NXP_CONTROLLER	%NXP_CONTROLLER%
/* #define XP_DKN	0		/* drive # for iostat disk monitoring */
/* #define XP_DUMP			/* include dump routine */
#define XP_PROBE			/* check drive types at boot */
