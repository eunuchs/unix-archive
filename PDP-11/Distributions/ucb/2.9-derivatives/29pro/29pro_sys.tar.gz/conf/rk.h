#define	NRK	%NRK%
/* #define	RK_DKN	0 */
