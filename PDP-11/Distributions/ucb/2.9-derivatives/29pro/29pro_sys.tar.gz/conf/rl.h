#define	NRL	%NRL%
/* #define RL_DKN	0 */
