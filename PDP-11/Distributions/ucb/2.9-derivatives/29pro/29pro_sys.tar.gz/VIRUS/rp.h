#define	NRP	0
/* #define RP_DKN	0 */
