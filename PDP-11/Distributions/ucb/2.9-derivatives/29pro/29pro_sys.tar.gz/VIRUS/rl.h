#define	NRL	0
/* #define RL_DKN	0 */
