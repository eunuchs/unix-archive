#define	NTM	1
#define	DDMT			/* software-selectable 1600 bpi */
#define	TM_IOCTL
