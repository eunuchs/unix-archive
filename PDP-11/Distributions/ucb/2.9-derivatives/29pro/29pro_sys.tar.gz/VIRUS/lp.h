#define	NLP	0
