#define	NRK	1
/* #define	RK_DKN	0 */
