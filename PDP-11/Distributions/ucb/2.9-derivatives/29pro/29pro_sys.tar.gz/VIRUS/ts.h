#define	NTS	0
#define	TS_IOCTL
