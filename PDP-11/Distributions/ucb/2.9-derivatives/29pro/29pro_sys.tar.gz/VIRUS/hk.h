#define	NHK	0
/* #define HK_DKN	0		/* drive # for iostat disk monitoring */
/* #define HK_DUMP	 		/* include dump routine */
