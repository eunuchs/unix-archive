/* These ioctl def's are for the pro3xx r5 (RX50) driver. */
#define	R5IOCSETP	(('r'<<8)|1)
#define	R5IOCGETP	(('r'<<8)|2)
