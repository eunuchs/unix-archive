#define	NTM	0
#define	DDMT			/* software-selectable 1600 bpi */
#define	TM_IOCTL
