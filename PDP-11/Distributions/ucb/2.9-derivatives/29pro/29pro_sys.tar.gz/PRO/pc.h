#define NPC   2
