#define NCN   1
