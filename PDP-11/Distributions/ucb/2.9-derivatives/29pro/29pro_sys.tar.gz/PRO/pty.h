#define NPTY   0
