#define NRD   1
