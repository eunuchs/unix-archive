char version[] = "Berkeley UNIX (Rev. 2.9.1) Tue Feb 23 06:14:34 GMT 1999\n";
