#define NRA   0
