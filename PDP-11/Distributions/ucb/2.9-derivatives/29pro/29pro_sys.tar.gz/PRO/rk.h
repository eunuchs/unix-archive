#define	NRK	0
/* #define	RK_DKN	0 */
