struct vec_s {
	int	v_func;
	int	v_br;
} ivec;

#define	IVSIZE	(sizeof ivec)

#define	NVECTOR	100		/* max. number of vectors we can set */
