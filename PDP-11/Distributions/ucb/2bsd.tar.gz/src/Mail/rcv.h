/* Copyright (c) 1979 Regents of the University of California */
#

/*
 * Mail -- a mail program
 *
 * This file is included by normal files which want both
 * globals and declarations.
 */

#include "def.h"
#include "glob.h"
