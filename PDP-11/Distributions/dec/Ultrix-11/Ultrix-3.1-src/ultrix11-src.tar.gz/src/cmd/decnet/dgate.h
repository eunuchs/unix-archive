
/**********************************************************************
 *   Copyright (c) Digital Equipment Corporation 1984, 1985, 1986.    *
 *   All Rights Reserved. 					      *
 *   Reference "/usr/src/COPYRIGHT" for applicable restrictions.      *
 **********************************************************************/

#include <stdio.h>

#define	GATEWAY		"/etc/dgateway"
#define	RSH		"/usr/ucb/rsh"
#define	DLS		"/usr/bin/dls"
#define	DCAT		"/usr/bin/dcat"
#define	DCP		"/usr/bin/dcp"
#define	DRM		"/usr/bin/drm"
#define	RDLOGIND	"/etc/dgated"
#define	RNAME		"guest"
