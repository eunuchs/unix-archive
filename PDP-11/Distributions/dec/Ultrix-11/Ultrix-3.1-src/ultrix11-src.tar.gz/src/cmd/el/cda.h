
/**********************************************************************
 *   Copyright (c) Digital Equipment Corporation 1984, 1985, 1986.    *
 *   All Rights Reserved. 					      *
 *   Reference "/usr/src/COPYRIGHT" for applicable restrictions.      *
 **********************************************************************/


/*
 * SCCSID: @(#)cda.h	3.0	4/21/86
 */
#define CDHEAD 01
#define RAINFO 02
#define BIOINFO 04
#define TKINFO 010
#define	MBLKDEV	20	/* MAX number of block devices */
