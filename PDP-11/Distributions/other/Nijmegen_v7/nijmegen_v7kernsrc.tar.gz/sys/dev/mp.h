/*#define MULTMP y  /**/
/*#define MOREMAJOR     1       /**/
/* MOREMAJOR hasn't been tested under v7. Routine mpmap should be checked */

#ifdef  MULTMP
#ifdef MOREMAJOR
#define mpm(dev) mpmap(dev)
#else
#define mpm(dev) (&mpbooks[unit(dev)])
#define unit(dev) ((minor(dev)&DEVMASK) >> DEVSHIFT)
#endif
#endif
#ifndef MULTMP
#define mpm(dev) (&mpbooks) 
#endif

#ifndef MULTMP
#define MPADDR 0170610
#define NMP     1
#endif

#ifdef MULTMP
/* array containing addresses of dr-11c's used when initializing a book */
/*               IVV 2  , IVV 3 , IVV 4 */
char *mpaddr[] { 0170550,0170560,0170610 } ;
#define NMP     (sizeof mpaddr)>>1      /* number of DR-11C's */
#ifdef MOREMAJOR
#define MPADDR book->mp_addr
#else
#define MPADDR (mpaddr[book-mpbooks])
#endif
#endif

#define MPQSIZ  100     /* queue size */
                        /* must be <128 (0200 ) */
/*
struct tty mp[33] ;

struct sizes mpsizes[NMP][3] {
        3,      &mp[0],
        3,      &mp[3],
        5,      &mp[3+3],
        3,      &mp[11],
        3,      &mp[11+3],
        5,      &mp[11+3+3],
        3,      &mp[22],
        3,      &mp[22+3],
        5,      &mp[22+3+3],
} ;
*/

struct tty mp[11] ;

struct sizes mpsizes[NMP][3] {
        3,      &mp[0],
        3,      &mp[0+3],
        5,      &mp[0+3+3],
} ;
