/*
 *    Include file for monitoring stuff - sjors
 */

#define    MN_DKF0      01
#define    MN_DKM0      02
#define    MN_DKOTHER   04
#define    MN_RF        010
#define    MN_PIPE      020
#define    MN_INO       040
#define    MN_DIR       0100
#define    MN_CORE      0200
#define    MN_SWAP      0400
#define    MN_FORK      01000
#define    MN_EXEC      02000
#define    MN_BREAK     04000
#define    MN_EXP       010000
#define    MN_DZIN      020000
#define    MN_DZOUT     040000
#define    MN_BUSY      0100000

struct  mn {
        short   mn_dkf0;
        short   mn_dkm0;
        short   mn_dkother;
        short   mn_pipe;
        short   mn_ino;
        short   mn_dir;
        short   mn_fork;
        short   mn_exec;
        short   mn_break;
        short   mn_exp;
};

extern  int     mn_monw, mn_covfl, mn_pid, mn_uid, mn_swaphi;

extern  struct  mn      mn;
