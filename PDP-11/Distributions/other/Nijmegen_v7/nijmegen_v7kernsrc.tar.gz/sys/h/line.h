/* toegevoegd voor de Math.Centrum uucp modificaties
   door h.j. thomassen; oktober 1982
   opm: entry D_next is niet meer aanwezig in de courante MC versie
    van deze software
*/
struct Devices
{
        struct Devices *D_next; /* always NULL */
        char *D_type;   /* type of connection */
        char *D_line;   /*  /dev/???          */
        char *D_calldev;
        int D_speed;
        int D_maxspeed;
        int D_file;     /* file descriptor    */
};
extern struct Devices *open_line();
