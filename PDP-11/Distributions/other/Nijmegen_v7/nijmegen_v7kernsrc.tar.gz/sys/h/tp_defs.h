char   mt[]    = "/dev/mt0";
char    tc[]    = "/dev/tapx";
char    dx[]    = "/dev/dx0";
int     flags   = flu;
char    mheader[] = "/usr/mdec/mboot";
char    theader[] = "/usr/mdec/tboot";
char    xheader[] = "/usr/mdec/xboot";
