#include <signal.h>

#define EMCOMMAND "/usr/tz/bin/em"
#define ASWITCH '<'
#define BSWITCH '>'
#define BUFSIZE 256

printf  (string)
        char *string;
{
        register char *s;
        register int n;

        for( s = string, n = 0; *s++; n++ );
        write(2, string, n);
};

main (argc, argv)
        int argc; char **argv;
{
        register int file, outindex;
        register char character;
        int apipe[2], bpipe[2], status, a, b, c, pars, process;
        char outbuff[BUFSIZE];

        pars = 2;
        pipe(apipe); pipe(bpipe);
        if( (a = fork()) == 0 ) goto processa;
        if( (b = fork()) == 0 ) goto processb;
        signal(SIGINT, SIG_IGN); signal(SIGQUIT, SIG_IGN);
        if( (c = fork()) == 0 ) goto processc;
        close(apipe[0]); close(apipe[1]);
        close(bpipe[0]); close(bpipe[1]);
        process = wait(&status);
        if( process == a ) {
                printf("ema ended\n");
                a = 0;
        } else if( process == b ) {
                printf("emb ended\n");
                b = 0;
        } else {
                kill(a, SIGKILL);
                kill(b, SIGKILL);
                exit();
        }
        process = wait(&status);
        if( process == a ) {
                printf("ema ended\n");
                kill(c, SIGKILL);
        } else if( process == b ) {
                printf("emb ended\n");
                kill(c, SIGKILL);
        } else if( a != 0 ) {
                kill(a, SIGKILL);
        } else if( b != 0 ) {
                kill(b, SIGKILL);
        }
        exit();

processa:
        dup2(apipe[0], 0);
        close(apipe[0]); close(apipe[1]);
        close(bpipe[0]); close(bpipe[1]);
        if( pars <= argc ) {
                execl(EMCOMMAND, "ema", "-i", "-p<", argv[pars-1], 0);
        } else {
                execl(EMCOMMAND, "ema", "-i", "-p<", 0);
        }
        printf("duem not possible\n");
        exit();

processb:
        dup2(bpipe[0], 0);
        close(apipe[0]); close(apipe[1]);
        close(bpipe[0]); close(bpipe[1]);
        if( pars < argc ) {
                execl(EMCOMMAND, "emb", "-i", "-p>", argv[pars], 0);
        } else {
                execl(EMCOMMAND, "emb", "-i", "-p>", 0);
        }
        printf("duem not possible\n");
        exit();

processc:
        close(apipe[0]); close(bpipe[0]);
        file = apipe[1];
        signal(SIGPIPE, SIG_IGN);
        outindex = 0;
cycle:
        character = getchar();
        if( character == ASWITCH ) {
                character = getchar();
                file = apipe[1];
        } else if( character == BSWITCH ) {
                character = getchar();
                file = bpipe[1];
        }
copy:
        outbuff[outindex++] = character;
        if( character == '\n' || outindex > BUFSIZE ) {
                write(file, outbuff, outindex);
                outindex = 0;
                if( character == '\n' ) goto cycle;
        }
        character = getchar();
        goto copy;
};
