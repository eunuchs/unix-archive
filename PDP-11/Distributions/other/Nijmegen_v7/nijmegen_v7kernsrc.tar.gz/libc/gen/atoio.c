atoio(ap)
/*
 * nijmegen, h.j. thomassen, june 1976.
 * convert octal number from ascii to integer.
 * UNIX-V7 sprintf does similar things; this routine kept for compatibility
 */
char *ap;
{
        register n,zero;
        register char *p;
        int f;

        p=ap; n=0; f=0; zero= '0';

loop:   while (*p == ' ' || *p == '     ')
                p++;
        if (*p == '-') {
                f++; p++; goto loop; }
        while ( *p >= zero && *p <= '7')
                n= n*8 + *p++ - zero;
        if (f)  n = -n;
        return(n);
}
