#include <stdio.h>

fgetc(fp)
FILE *fp;
{
        return(getc(fp));
}
