#include <stdio.h>

#define TRUE 1
#define ERROR (-1)

main()
{
        char fname[44];
        int fd;
        char c;
        long sum = 0;
        long bytcnt;
        long tbytcnt = 0;
        while(TRUE) {
                bytcnt = 0;
                printf("File name or END\n");
                gets(fname);
                if(strcmp(fname,"END") == 0)
                        break;
                if((fd = open(fname,0)) == NULL) {
                        printf("open failed.  try again.\n");
                        continue;
                }
                while(read(fd,&c,1) == 1) {
                        sum += c;
                        ++bytcnt;
                }
                close(fd);
                printf("eof. sum=%ld  file was %ld bytes\n",sum,bytcnt);
                tbytcnt += bytcnt;
        }
        printf("sum is %ld, count is %ld\n",sum,tbytcnt);
        exit(0);
}
