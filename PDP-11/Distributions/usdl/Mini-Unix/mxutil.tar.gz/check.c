#include <stdio.h>

#define ERROR (-1)

main(argc,argv)
char **argv;
int argc;
{
        int bnum;
        long pos;
        char block[512],fname[80];
        int fd,i,nn;

        strcpy(fname,*++argv);
        stcd_i(*++argv,&bnum);
        bnum--;
        printf("file %s\n",fname);
        if((fd = open(fname,0)) == ERROR) {
                printf("can't open...\n");
                exit(4);
        }
        printf("block 0...\n");
        if((nn=read(fd,block,512)) != 512) {
                printf("short read... %d\n",nn);
        }
        for(i=0; i<4; ++i)
                printf("%02x ",block[i]);
        putchar('\n');
        printf("block %d\n",bnum);
        pos = lseek(fd,(long)bnum * 512,0);
        if(pos < 0L)
                printf("seek error...\n");
        if((nn=read(fd,block,512)) != 512)
                printf("short read... %d\n",nn);
        for(i=0; i<4; ++i)
                printf("%02x ",block[i]);
        putchar('\n');
        close(fd);
        exit(0);
}
