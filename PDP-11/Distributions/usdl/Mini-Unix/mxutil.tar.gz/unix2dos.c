#include <stdio.h>

main(argc,argv)
int argc;
char *argv[];
{
	int c;

	while((c = getc(0)) != EOF) {
		printf("%c",c);
	}
}
