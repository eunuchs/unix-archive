#include <stdio.h>
#include "mxfilsys.h"

char dflag = FALSE;

main(argc,argv)
int argc;
char **argv;
{
	char fname[44];

	strcpy(fname,"/mx/bin");

	while(--argc > 0) {
		if(**++argv == '-') {
			switch(tolower((*argv)[1])) {
			case 'd':
				dflag = 1-dflag;
				break;
			case 'f':
				strcpy(fname,*++argv);
				--argc;
				break;
			default:
				printf("unkown switch: %s\n",*argv);
				break;
			}
		}
	}
	fsinit(fname);
	printdir(1,"");
	fsclose();
}

/*
	Routine to recursively print a directory tree
*/
printdir(i,parent)
int i;
char *parent;
{
	struct inode inode,sinode;
	struct dir dir[32];
	char newparent[128];
	int b,d;

	if(dflag)
		printf("printdir: inode %d   name = %s\n",i,parent);
	geti(i,&inode);
	b = 0;
	while(fblock(b++,&inode,&dir[0]) != EOF) {
		for(d=0; d< 32; ++d) {
			if(dir[d].inum == 0) {
				if(dir[d].name[0] != '\0' && dir[d].name[0] != ' ')
					printf("%s/%s\t(Deleted entry)\n",parent,dir[d].name);
				continue;
			}
			printf("%s/%s",parent,dir[d].name);
			putchar('\n');
			if(b == 1 && d < 2)
				continue;
			geti(dir[d].inum,&sinode);
			if(sinode.flags & 040000) {
				strcpy(newparent,parent);
				strcat(newparent,"/");
				strcat(newparent,dir[d].name);
				printdir(dir[d].inum,newparent);
			}
		}
	}
}