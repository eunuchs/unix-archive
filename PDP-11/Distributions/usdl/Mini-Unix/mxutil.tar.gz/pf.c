#include <stdio.h>
#include "mxfilsys.h"

char dflag = FALSE;

main(argc,argv)
int argc;
char **argv;
{
	char fname[44],fsname[44];
	long len,cn;
	struct inode inode;
	int i;
	char block[BLOCK];

	strcpy(fsname,"/mx/src");

	while(--argc > 0) {
		if(**++argv == '-') {
			switch(tolower((*argv)[1])) {
			case 'd':
				dflag = 1-dflag;
				break;
			case 'x':
				strcpy(fsname,*++argv);
				--argc;
				break;
			case 'f':
				strcpy(fname,*++argv);
				--argc;
				break;
			default:
				fprintf(stderr,"unkown switch: %s\n",*argv);
				break;
			}
		}
	}
	fsinit(fsname);
	fprintf(stderr,"Search for file %s yields inode %d\n",
		fname,i = srchdir(1,fname));
	geti(i,&inode);
	len = ((long)inode.size0 << 16) + inode.size1;
	for(cn = 0; cn < len; ) {
		fblock((int)(cn >> 9),&inode,block);
		for(i=0; i<BLOCK && cn<len; ++i,++cn)
			putchar(block[i]);
	}
	fsclose();
}
