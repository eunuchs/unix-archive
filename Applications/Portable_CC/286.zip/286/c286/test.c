int d;
foo()
  {
	int a,*b,c;
	c = a;
	b = &a;
	b = &d;
}
