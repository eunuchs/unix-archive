main(){
	int x,y;
	while(x--)
		return(x<y);
}
