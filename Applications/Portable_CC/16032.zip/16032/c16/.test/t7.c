unsigned char x;
int y;
char z;

main()
  {	y = x;
	y = z;
}
