char x[124];

main()
{
	register char *l;
	int  y;

	y = l-x;
	y = (int)l+x;
}
