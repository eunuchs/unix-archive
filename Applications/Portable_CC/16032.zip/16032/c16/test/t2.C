short yydef[];
main(){
register short yyn;
if((yyn = yydef[yyn]) == yyn)return(0);
}
