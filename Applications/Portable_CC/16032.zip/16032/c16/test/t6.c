search_mem(p1, p2, val,count)
register char *p1,p2;
register unsigned int val;
register char count;
{
	register char i;
	register char byte;

	byte = (val >> (i * 4));

}
