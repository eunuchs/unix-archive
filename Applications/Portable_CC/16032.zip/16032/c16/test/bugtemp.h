#define Z(v) for(v= -3; v<= 3; v++)
#define N(v) for(v= -3; v<= 3; ++v?v:(v=1))
#define I(v) for(v=2; v<32768&&v>-32768; v= -v*3/2)
#define A(v) for(v=2; v&&(v<32768&&v>-32768||!(v=0)); v= -v*3/2)
long lt; short it; short unsigned ut; char ct; long v1,v2;
set_it() { it = 1; return 1; }
