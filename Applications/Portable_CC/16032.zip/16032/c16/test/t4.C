struct {
unsigned char x;
unsigned char y;
} foo, *fii;
main()
{
int i;
i = foo.x;
main(foo.x, fii->x);
}


