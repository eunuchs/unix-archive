main(){
char x;
int y;

y = x;
}
