unsigned short x;
long y;

main()
{
	return(y > x);
}
