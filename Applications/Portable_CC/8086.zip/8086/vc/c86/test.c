foo()
  {	char a;
	if (a--) a = 1;
}
