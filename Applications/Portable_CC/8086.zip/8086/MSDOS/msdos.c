| ax = mstub(ax, dx, cx, si, di, bx)

msalloc(size)	{ return mstub(72<<8, 0, 0, 0, 0, size); }

