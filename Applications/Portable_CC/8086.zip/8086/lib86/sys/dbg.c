dbg(a1, a2, a3, a4, a5, a6, a7)
 {
	printf("DBG: ");
	printf(a1, a2, a3, a4, a5, a6, a7);
	printf("\r\n");
 }
