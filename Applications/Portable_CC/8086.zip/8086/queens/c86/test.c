foo()
  {	static int x = 1;

	x += 13;
}
