main(){
	int lda();
	printf("%x\n",lda());}
