cd $1
ar x cont.a
rm -f cont.a
