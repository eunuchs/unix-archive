#include	"pop.h"

pnoecho(popid)
{
register mode;

	mode = pgmode(popid);
	mode =& ~ECHO;
	psmode(popid,mode);
}
