#include	"pop.h"

/* closes popid without clearing */

pclose(popid)
{
register pop *p;

	if ((p = do_get(popid)) == -1) 
		return(-1);
	p->ch = 0;
	return(0);
}
