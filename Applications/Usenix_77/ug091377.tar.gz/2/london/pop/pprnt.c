
extern popout;

pprintf(a)
{
	if (do_get(popout) == -1)
		return(-1);
	do_printf(&a);
}
