#include	"pop.h"

/* Checks if cc is a break
 * character within pop p.
 * If so, then perform the specified action
 * and returns 1.
 * Else returns 0.
 */

do_break(p,cc)
pop *p;
char cc;
{
register struct _brk *b;
register char *s;
register char c;

	c = cc;
	for (b = p->brk, s = &p->brk[NBREAKS]; b < s; b++)
		if (c == b->brkch) {
			(*b->brkact)();
			return(1);
		}
	return(0);
}
