
extern popout;

pread(c)
{
	if (do_get(popout) == -1)
		return(-1);
	return( do_read() );
}
