#include	"pop.h"

pecho(popid)
{
register mode;

	mode = pgmode(popid);
	mode =| ECHO;
	psmode(popid, mode);
}
