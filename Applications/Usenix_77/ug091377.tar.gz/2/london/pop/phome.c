/* Sets pop FT to top-left
 * hand corner of pop.
 * Equivalent to :
 * pmove(popid,0,0)
 */
phome(popid)
{
	return(pmove(popid,0,0));
}
