#include	"pop.h"

ppage(popid)
{
register mode;

	mode = pgmode(popid);
	mode =& ~ROLL;
	mode =| PAGE;
	psmode(popid,mode);
}
