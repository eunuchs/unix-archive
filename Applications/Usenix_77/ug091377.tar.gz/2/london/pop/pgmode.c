#include	"pop.h"


/* returns character mode describing
 * switches for pop
 */
pgmode(popid)
{
register pop *p;

	if ((p = do_get(popid)) == -1)
		return(-1);
	return(p->mode);
}
