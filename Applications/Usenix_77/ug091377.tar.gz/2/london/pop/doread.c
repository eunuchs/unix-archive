#include	"pop.h"

extern popout;
extern pop popdesc[];


/* the basic read character
 * function which reads keyboard
 * input.
 */
do_read()
{
char c;
register pop *p;

	p = &popdesc[popout];
	pflush();

	if (read(0,&c,1) == -1)
		return(-1);

	if (p->mode & ECHO) {
		do_putc(c);
		pflush();
	}

	do_break(p,c);
	return(c);
}
