#include	"pop.h"


/* Sets tab indent to n.
 * If n is 0 then no tab expansion.
 */
pstabs(popid,n)
{
register pop *p;

	if ((p = do_get(popid)) == -1)
		return(-1);
	p->tabset = n;
	return(0);
}
