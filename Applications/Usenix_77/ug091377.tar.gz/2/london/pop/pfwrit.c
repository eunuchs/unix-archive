
extern popout;

pfwrite(popid,buf,n)
char *buf;
{
register popsave;

	popsave = popout;
	if (pselect(popid) == -1)
		return(-1);
	do_write(buf,n);
	pselect(popsave);
	return(0);
}
