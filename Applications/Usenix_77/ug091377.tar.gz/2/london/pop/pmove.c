/* equivalent to :
 * pvseek(popid,0,v); phseek(popid,0,h);
 *
 */

pmove(popid,h,v)
{
	if (pvseek(popid,0,v) == -1)
		return(-1);
	return(phseek(popid,0,h));
}
