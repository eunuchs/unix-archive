do_write(buf,n)
char *buf;
{
	while (n--)
		do_putc(*buf++);
}
