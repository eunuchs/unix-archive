#include	"pop.h"

/* Turns off dynamic output modes
 * (ie ROLL and PAGE)
 */

pnorm(popid)
{
register mode;

	mode = pgmode(popid);
	mode =& ~ROLL;
	mode =& ~PAGE;
	psmode(popid,mode);
}
