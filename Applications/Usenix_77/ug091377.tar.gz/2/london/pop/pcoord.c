#include	"pop.h"

/* returns position on the screen
 * of popid.
 */

pcoord(popid,ad)
int *ad;
{
register pop *p;
register *d;

	if ((p = do_get(popid)) == -1)
		return(-1);

	d = ad;
	*d++ = p->hmin;
	*d++ = p->hmax;
	*d++ = p->vmin;
	*d++ = p->vmax;
	return(0);
}
