
extern popout;

pfprintf(popid,a)
{
register popsave;

	popsave = popout;
	if (pselect(popid) == -1)
		return(-1);
	do_printf(&a);
	pselect(popsave);
}
