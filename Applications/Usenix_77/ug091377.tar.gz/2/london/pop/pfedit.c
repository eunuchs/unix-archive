
extern popout;

pfedit(popid,buf)
{
register popsave, n;

	popsave = popout;
	if (pselect(popid) == -1)
		return(-1);
	n = do_edit(buf);
	pselect(popsave);
	return(n);
}
