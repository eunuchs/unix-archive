#include	"pop.h"

extern popout;


/* Moves FT horizontally
 * within the specified POP.
 */
phseek(popid,sw,offset)
{
register pop *p;
register newh;

	if ((p = do_get(popid)) == -1)
		return(-1);
	switch (sw) {
	case 0:			/* from start */
		newh = p->hmin + offset;
		break;

	case 1:
		newh = p->ch + offset;
		break;

	case 2:
		newh = p->hmax - offset;
	}
	if ((newh < p->hmin) || (newh > p->hmax))
		return(-1);
	p->ch = newh;
	if (popid == popout)
		s_cursor(p->ch,p->cv);
	return(0);
}
