#include	"pop.h"

/* Gives current position of pop
 * cursor within popid.
 */

pwhere(popid,hv)
struct {
	int h,v;
} *hv;
{
register pop *p;

	if ((p = do_get(popid)) == -1)
		return(-1);
	hv->h = p->ch - p->hmin;
	hv->v = p->cv - p->vmin;
	return(0);
}
