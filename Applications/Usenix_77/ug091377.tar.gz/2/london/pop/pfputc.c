
extern popout;

pfputc(popid,c)
char c;
{
register popsave, cp;

	popsave = popout;
	if (pselect(popid) == -1)
		return(-1);
	cp = do_putc(c);
	pselect(popsave);
	return(cp);
}
