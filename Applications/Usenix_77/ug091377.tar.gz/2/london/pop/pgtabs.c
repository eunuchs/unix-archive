#include	"pop.h"

/* Returns current tabset for popid.
 * Zero returned implies no expansion.
 */
pgtabs(popid)
{
register pop *p;

	if ((p = do_get(popid)) == -1)
		return(-1);
	return(p->tabset);
}
