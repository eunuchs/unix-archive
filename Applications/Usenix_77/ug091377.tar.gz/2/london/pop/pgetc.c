#include	"pop.h"

extern char screenmap[NLINES+1][NCHARS+1];

/* Returns the character on the screen
 * at relative position (h,v) within
 * the specified pop.
 */
pgetc(popid,rh,rv)
{
register pop *p;
register h,v;

	if ((p = do_get(popid)) == -1)
		return(-1);

	h = p->hmin + rh;
	v = p->vmin + rv;
	if ((h<p->hmin) || (h>p->hmax) || (v<p->vmin) || (v > p->vmax))
		return(-1);

	return(screenmap[v][h]);
}
