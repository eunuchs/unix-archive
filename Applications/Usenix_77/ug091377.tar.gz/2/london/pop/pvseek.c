#include	"pop.h"

extern popout;

/* Moves FT vertically within
 * the specifed POP.
 */
pvseek(popid,sw,offset)
{
register pop *p;
register newv;

	if ((p = do_get(popid)) == -1)
		return(-1);
	switch (sw) {
	case 0:
		newv = p->vmin + offset;
		break;

	case 1:
		newv = p->cv + offset;
		break;

	case 2:
		newv = p->vmax - offset;
	}
	if ((newv < p->vmin) || (newv > p->vmax))
		return(-1);
	p->cv = newv;
	if (popid == popout)
		s_cursor(p->ch,p->cv);
	return(0);
}
