
extern popout;

pwrite(buf,n)
{
	if (do_get(popout) == -1)
		return(-1);
	return(do_write(buf,n));
}
