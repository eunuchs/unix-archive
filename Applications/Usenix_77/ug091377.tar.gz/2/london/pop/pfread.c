
extern popout;

pfread(popid)
{
register popsave;
register char c;

	popsave = popout;
	if (pselect(popid) == -1)
		return(-1);
	c = do_read();
	pselect(popsave);
	return(c);
}
