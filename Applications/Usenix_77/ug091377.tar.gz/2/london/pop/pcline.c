#include	"pop.h"

extern popout;

/* Clears line lineno in popid
 * (done by writing spaces).
 * Pop cursor is not changed.
 * To change to start of line after
 * this call, all that is required
 * is:  pmove(popid,0,n)
 */

pcline(popid,lineno)
{
register pop *p;
register n;

	if ((p = do_get(popid)) == -1)
		return(-1);
	n = p->vmin + lineno;
	if ((n < p->vmin) || (n > p->vmax))
		return(-1);
	do_cline(popid,n);
	pselect(popout);
	return(0);
}
