#include	"pop.h"

proll(popid)
{
register mode;

	mode = pgmode(popid);
	mode =& ~PAGE;
	mode =| ROLL;
	psmode(popid,mode);
}
