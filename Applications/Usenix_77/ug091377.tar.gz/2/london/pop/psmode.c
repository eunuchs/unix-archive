#include	"pop.h"


psmode(popid,m)
char m;
{
register pop *p;

	if ((p = do_get(popid)) == -1)
		return(-1);
	p->mode = m;
	return(0);
}
