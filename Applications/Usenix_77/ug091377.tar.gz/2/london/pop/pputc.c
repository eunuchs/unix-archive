
extern popout;

pputc(c)
char c;
{
	if (do_get(popout) == -1)
		return(-1);
	return(do_putc(c));
}
