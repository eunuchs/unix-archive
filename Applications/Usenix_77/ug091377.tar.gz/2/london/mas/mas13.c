#

#include	"mas1h.c"

extern struct aform aout;
extern char symbuf[];
extern struct segment segopt;
extern char getnonbl();
extern char getch();
extern pc, pc_def;
extern struct symbol symtab[];
extern struct evalx r;
extern lab;
extern char tch;

pseudop(opc)
{
register n;
register char c;
register l;

	switch (opc) {
	case o_SEG:
		if ( segopt.segcount == 0 )
			segerr();
		segopt.segcount++;
		return;

	case o_EQU:
		if ( ! lab )
			syntax();
		getexpr();
		evalexpr();
		if ( r.r_type != ABS )	/* und, exp or est */
			outaform(a_EQU+lab);
		equsym(lab);
		return;

	case o_ORG:
		if ( lab )
			syntax();
		getexpr();
		evalexpr();
		if ( r.r_type == UND )
			relerr();
		pass1a();
		newif(i_REL);
		evalexpr();
		if ( r.r_type != ABS )
			syserr();
		pc = r.r_val;
		pc_def = ABS;
		return;

	case o_FCB:
		pc =+ getlis();
		return;

	case o_FDB:
		pc =+ getlis() << 1;
		return;

	case o_FCC:
		if ( (c = getnonbl()) != SLASH )
			syntax();
		while ( (c = getch()) != SLASH ) {
			if ( c == BACKSL )
				if ( nonspec(getch()) )
					pc++;
			if ( c == NL )
				syntax();
			if ( c == EOF )
				eoferr();
			pc++;
		}
		return;

	case o_RMB:
	case o_ZMB:
		getexpr();
		evalexpr();
		if ( (n = r.r_type) == UND )
			relerr();
		if ( n != ABS ) {
			pass1a();
			evalexpr();
		}
		if ( r.r_type != ABS )
			syserr();
		if ( (n = r.r_val) < 0 )
			relerr();
		pc =+ n;
		return;

	}
}



nonspec(ch)
char ch;
{
register char c;

	if ( ((c = ch) == SLASH) ||
		(c == BACKSL) ||
		(c == 'n') ||
		(c == 't') ||
		(c == 's') ||
		(c == '0') )
			return(0);

	return(1);
}
