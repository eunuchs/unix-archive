#include "/acct/h/personne.h"
char *overfil "/acct/over.quota";

main(argc,argv)
char *argv[];
{
	register int fh;
	struct user buf;
	char warn;

	fh = -1;
	if (argc > 1) {
		if((getprv() & (PRV_ACCT | PRV_SU)) != (PRV_ACCT | PRV_SU) )
			error("no privileges");
		if(getlnam(argv[1],&buf,128) == 0) error("Who");
		fh = open(overfil,2);
	} else
		if(getrec(&buf,getruid(),128) == 0) error("Who");
	if(fh == -1) fh = open(overfil,0);
	seek(fh,buf.usr_num,0);
	warn = 0;
	if(argc <= 2)
		read(fh,&warn,1);
	else {
		warn = atoi(argv[2]);
		write(fh,&warn,1);
	}
	printf("disk quota: %d, disk used: %d; %d login warnings.\n",
		buf.dsk_lim, buf.dsk_used, warn);
}
