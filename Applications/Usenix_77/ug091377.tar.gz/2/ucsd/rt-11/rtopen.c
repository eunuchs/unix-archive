#
#define	EXECEE		"/usr/bin/rtio"
#define	READFLAG	"r"
#define	WRITEFLAG	"w"
#define	READ		0
#define	WRITE		1
#define	NFILES		16

rtopen(aname,amode)
char *	aname;
int	amode;
	{
	extern int	errno;
	int		fids[2];
	register int	i;
	register char *	execee;
	register char *	flag;

	if	((amode == READ || amode == WRITE) && pipe(fids) == 0)
		switch	(fork())
			{
			default:	/*parent*/
				if	(amode == READ)
					{
					if	(close(fids[1]) == 0)
						return(fids[0]);
					}
				else	if	(close(fids[0]) == 0 &&
						(i = dup(fids[1])) >= 0 &&
						close(fids[1]) == 0)
						return(i);
			case -1:
				close(fids[0]);
				close(fids[1]);
				break;
			case 0:		/*child*/
				i = amode == READ ? 1 : 0;
				if	(fids[i] == i ||
					close(i) == 0 && dup(fids[i]) == i)
					{
					close(i == 0 ? 1 : 0);
					for	(i = 2; i < NFILES; i++)
						close(i);
					errno = 0;
					execee = EXECEE;
					flag = amode == READ ?
						READFLAG : WRITEFLAG;
					execl(execee+9,execee+9,flag,aname,0);
					execl(execee+4,execee+9,flag,aname,0);
					execl(execee,execee+9,flag,aname,0);
					}
				exit(errno ? errno : -1);
			}
	return(-1);
	}

rtfopen(aname,abuf)
char *	aname;
int	abuf[];
	{
	abuf[1] = abuf[2] = 0;
	return((abuf[0] = rtopen(aname,READ)) >= 0 ? 0 : -1);
	}

rtfcreat(aname,abuf)
char *	aname;
int	abuf[];
	{
	abuf[1] = abuf[2] = 0;
	return((abuf[0] = rtopen(aname,WRITE)) >= 0 ? 0 : -1);
	}
