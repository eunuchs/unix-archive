r502a(ar50,acp) 	/*xlate rad50 value to ascii string*/
int	ar50;			/*rad50 value to be xlated*/
char *	acp;			/*pointer to target array*/
	{
	extern int	ldivr;
	register char *	cp;
	register char *	rp;

	cp = acp;
	rp = " ABCDEFGHIJKLMNOPQRSTUVWXYZ$.?0123456789";
	*cp++ = *(rp + ldiv(0,ar50,050*050));
	*cp++ = *(rp + ldivr / 050);
	*cp = *(rp + ldivr % 050);
	}

a2r50(acp,ar50p)		/*xlate ascii string to rad50 string*/
char *	acp;			/*points to null-terminated ascii string*/
int *	ar50p;			/*points to target array*/
	{
	int		i;
	register int	j;
	register char *	ap;
	register char	c;

	ap = "\
\377\377\377\377\377\377\377\377\
\377\377\377\377\377\377\377\377\
\377\377\377\377\377\377\377\377\
\377\377\377\377\377\377\377\377\
\000\377\377\377\033\377\377\377\
\377\377\377\377\377\377\034\377\
\036\037\040\041\042\043\044\045\
\046\047\377\377\377\377\377\377\
\377\001\002\003\004\005\006\007\
\010\011\012\013\014\015\016\017\
\020\021\022\023\024\025\026\027\
\030\031\032\377\377\377\377\377\
\377\001\002\003\004\005\006\007\
\010\011\012\013\014\015\016\017\
\020\021\022\023\024\025\026\027\
\030\031\032\377\377\377\377\377";
	while	(1)
		{
		i = 0;
		for	(j = 050*050 ; j > 0 ; j =/ 050)
			{
			if	((c = *acp++) == '\0')
				return(0);
			if	((c = *(ap + c)) < 0)
				return(-1);
			*ar50p = i =+ j * c;
			}
		ar50p++;
		}
	}

fnm2rt(afnmp,artp)		/*file name to rt11 format*/
char *	afnmp;			/*file name pointer*/
int *	artp;			/*target array pointer*/
	{
	register char * cp;
	register char	c;
	char		rtn[7]; /*holds "name" part*/
	char		rte[4]; /*holds "extension" part*/

	artp[0] = artp[1] = artp[2] = 0;
	cp = rtn;		/*find the name part*/
	while	((c = *afnmp++) != '\0' && c != '.')
		if	(c == ' ' || cp >= &rtn[6])
			return(-1);
		else	*cp++ = c;
	*cp = '\0';		 /*append a terminating null*/
	cp = rte;		 /*find the extension part*/
	if	(c == '.')	/*but only if it is there*/
		while	((c = *afnmp++) != '\0')
			if	(c == '.' || c == ' ' || cp >= &rte[3])
				return(-1);
			else	*cp++ = c;
	*cp = '\0';		 /*append a terminating null*/
	return(a2r50(rtn,artp) | a2r50(rte,artp+2));
/*
	note that there is a SINGLE vertical bar up there, to
	guarantee that both parts always get done.
*/
	}
