/*
 *	name line
 */
char headline[] {"a p l ? 1 1 * version 14 oct 76\n"};
