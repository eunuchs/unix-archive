/*
 *	name line
 */
char headline[] {"a p l \\ 1 1 * version 7 jan 77\n"};
