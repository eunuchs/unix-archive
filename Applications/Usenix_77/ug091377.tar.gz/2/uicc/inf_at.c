at(ax,ay) {
	register x,y;
	if(nargs() == 1) {
		x = ax%100;
		y = ax/100;
	} else {
		x = (ax*80)/512;
		y = (ay*60)/512;
	}
	if(x < 1 || y<1 || x>80 || y>24)
		return(-1);
	putchar('~');
	putchar(021);
	putchar(x>32 ? x+' '-33 : x+'`'-1);
	putchar(y+'`'-1);
	return(0);
}
