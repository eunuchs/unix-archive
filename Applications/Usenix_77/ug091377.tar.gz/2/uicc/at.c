at(ax,ay) {
	register x,y;
	if(nargs() == 1) {
		x = (ax%100 - 1)*8;
		y = (ax/100 - 1)*16;
	} else {
		x = ax;
		y = ay;
	}
	if(x < 0 || y<0 || x>512 || y>512)
		return(-1);
	putchar(022);
	putchar((x>>4)|0100);
	putchar((x&017)|0100);
	putchar((y>>4)|0100);
	putchar(0140|(y&017));
	putchar(033); putchar(4);
	putchar(024);
}
