clkoff()
{
	if(suser())
		*lks=0;
	return;
}

stoppr()
{
	if(suser()) {
		if(u.u_ar0[R0] == 0)
			stopcp();
		else
			u.u_error = EINVAL;
	}
}

//reboot
reboot()
{
	if(suser()) {
		printf("system rebooted\n");
		sysrebt(u.u_ar0[R0]);
	}
}
