main(argc,argv)
char **argv;
{

//shutdown the system orderly

	if(argc==1 || *argv[1]=='0') {
	    if(clkoff()<0) {    //try to turn off the clock
	        printf("not priviledged enough\n");
	        exit();
	    }
	    sync();     //get disk in good state
		stoppr(0);
		printf("stop failed\n");
		exit();
	}
	if(*argv[1]=='1')
		stoppr(1);
    printf("stop failed\n");
    exit();
}
