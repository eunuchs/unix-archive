	0, &stoppr,			/* 27 = stoppr */
	0, &reboot,			/* 29 = reboot */
	0, &clkoff,			/* 33 = clkoff */
