	&vpopen,	&vpclose,	&vpstrategy,	&vptab,	// vp 5
	&vlopen,    &vlclose,    &nodev,    &vlwrite,    &nodev,	// vl 5
	&vpopen,    &vpclose,    &nodev,    &vpwrite,    &vpctl,	// vp 6
