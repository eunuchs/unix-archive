#define MDEF	033
#define ARG	000
#define QUIT	0177
#define QUOTE	034
#define BLKSIZE 3

char ctype[128];  /*  0 => Pass, 1 => Defined Macro, 2 => Macro Def Flag
		   *  4 => Quote
		   */
int tty[3], sv, in, units[20], out;
int pflg 1;
int *unitpt units;
char ttyname[] "/dev/ttyx";	/* JJG: current tty name; will replace x */

main (){

struct block {	struct block *n;
		char ct;
		char dt[];
	     } *def[128], *l;
register char c;
register int i;
register struct block *p;
char buf[128], *d, *dd, *ddd, *alloc(), m, t;

ctype[MDEF] = 2;
ctype[QUOTE] = 4;

ttyname[8]=ttyn(0);		/* JJG: find current tty */
chmod(ttyname,0600);		/* JJG: nobody else writes on it */

/* Set to Raw mode, echo */
gtty(0,tty);
tty[2] = 040 | ((sv=tty[2])&(~072) );
stty(0,tty);

for(;;) switch (ctype[c=get1()])
{
	case 0: /* Ordinary, just send it to the re */
		put1(c);
		break;

	case 1: /* Defined macro, send its char stream to the re */
		for (p=def[c]; p; p = p->n) write(1,p->dt,p->ct);
		break;

	case 2: /* Possible macro defn */
		message("CONTROL FUNCTION");

		/* this if will only be done if there was a previous defn */
		/* removes last defn if there is one */
		if (ctype[m=get1()] == 1) /* "m" -- the defn char */
		{	for (p = def[c]; p;) /* removing last defn */
			{	d = p->n;
				free(p);
				p = d;
			}
			ctype[m] = 0;	/* sets the defn back to ordinary */
		}

		/* does this only if two <MDEF> chars are pressed */
		/* the print macro defn flag is reversed i.e. if off
		   the macro will not be echoed to the re at defn time */
		else if (m==MDEF)
		{	/* change the flag for printing of macro */
			message("MACRO PRINT FLAG CHANGED");
			pflg=1-pflg;
			break;
		}

		/* this elseif is done only if <MDEF> <QUOTE> is pressed */
		/* If so, then a file name is collected from the next input
		   chars.  The file name is terminated by a blank.  If the
		   file name is blank, then output of all the defined macros
		   is done after it asks for a file name.  If the first name
		   was not blank, then all chars come in off the new file
		   until the end-of-file condition. These may be nested. */
		else if (m==QUOTE)
		{	/* a new file for fe */
			message("fe FILE DEFN ");
			gfile(buf); /* fetch the file name */

			if(buf[0])  /* was the file a blank */
			{	/* no, so stack the new input file and use it */
				*unitpt++ = in; /*save old unit */
				/* open the file */
				if( (in=open(buf,0)) == -1 ){
					/* if here, error in opening file */
					message("fe file ERROR");
					/* all input now will come from tty */
					unitpt = units;
					in = 0; }
			}

			/* this code is done if file name was a blank */
			else /* save all the macro defn */
			{	message("fe OUTPUT FOR FILE");
				gfile(buf); /*fetches the output file name */
				/* creates the file */
				if( (out=creat(buf,0777)) == -1 )
					message("fe file ERROR");
				else /* the file was successfully created */
				{	/* write all the macros out */
					for(i=0;i<128;i++) if(ctype[i]==1){
						putw1(MDEF); putw1(i);
						p=def[i];
						while(p){
						   write(out,p->dt,p->ct);
						   p = p->n;}
						putw1(MDEF); putw1('\n');}
					close(out);
					message("fe OUTPUT FILE CLOSED");
			}	}
			break;
		}

		/* this code is done if <MDEF> <not a QUOTE> are pressed */
		/* if another <MDEF> is pressed then nothing will happen
		   but the old macro has already been removed if there
		   was one, if not nothing will happen */
		message ("MACRO DEFINITION");
		for (l = &def[m];;)
		{	d = buf;
			for (i=0; (i<127)&&((c=get1())!=MDEF); i++)
			{	*d++ = c;
				if(pflg) put1 (c);
			}
			if (i)
			{	l->n = p = alloc(BLKSIZE+i);
				l = p;
				p->ct = i;
				p->n = 0;
				ddd = p->dt;
				for (dd=buf; dd<d;) *ddd++ = *dd++;
				ctype[m] = 1;
			}
			else if (l == &def[m]) break;
			if (i<127) break;
		}
		message ("END OF MACRO DEFINITION");
		break;

	/* if the <QUOTE> is pressed it does the same thing as the re */
	/* but if pressed after an <MDEF> then it didn't, rather it
	   defined a file etc. as described above. */
	case 4:  /* QUOTE */
		put1(c);
		put1(get1());
}}



message(s) char *s;{
put1(ARG);
while (*s) write(1,s++,1);
if(!in) sleep(2);
put1(ARG);}


gfile(s) char *s;{
register char c, *t;
t=s;
put1(ARG);
while( (c=get1())!=' '){
	put1(c);
	if(c=='\b'){if(t>s) t--;}
	else{ *t++ = c;}}
*t++ = 0;
sleep(1);
put1(ARG);}


put1(c) char c;{ write(1,&c,1); }
putw1(c) char c;{ write(out,&c,1); }


get1()
{	char c;
     a: if(in){
		if(!read(in,&c,1)){
			close(in);
			message("fe INPUT FILE CLOSED");
			in = *(--unitpt);
			goto a;}}
	else read(0,&c,1);
	if (c==QUIT){
		write(1,&c,1);
		tty[2]=sv;
		stty(0,tty);
		chmod(ttyname,0622);	/* JJG: re-enable writing */
		exit();}
	return(c);
}
