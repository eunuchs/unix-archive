/* routine to send message to all users that the system is going down */
char *dmes "System coming down momentarily - please prepare.";
char *ttyn "/dev/tty?";
main(narg,arg)
int narg;
char *arg[];
{
char buf[3];
char *mes;
int lmes;
int inf,outf;
mes = (narg < 2 ? dmes : arg[1]);
lmes = 0;
while (mes[lmes++]);
inf = open("/etc/ttys",0);
while (read(inf,buf,3) == 3) {
	ttyn[8] = buf[1];
	if (buf[1] == 'k' || buf[1] == 'z') continue;
	if (buf[0] == '1' && (outf = open(ttyn,1)) != 0) {
		write(outf,"\r\n",2);
		write(outf,mes,lmes);
		write(outf,"\r\n",2);
		close(outf);
		}
	while (buf[2] != '\n') if (read(inf,&buf[2],1) != 1) goto syncit;
	}

syncit: sync();
close(inf);
}
