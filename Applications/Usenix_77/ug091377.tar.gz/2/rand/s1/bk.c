#		/* program to kill jobs with the name "background" */
		/* 22 Jan 75: Gillogly */
char cmd[] "ps a\n";
char shell[] "/bin/sh";
char killee[] "background";
strcomp(s,t)
char *s, *t;
{	while (*s++ == *t) if (*++t == '\0') return(1); return(0);}
main()
{	int n,pipei[2],pipeo[2],shl;
	char ps[64];		  /* lines won't be longer */
	char *ptr,ch;
	pipe(pipei);	pipe(pipeo);
	if ((shl=fork())==0)  /* start up the ps program in a child process */
	{	close(1); dup(pipei[1]);  /* ps will go to output pipe */
		close(0); dup(pipeo[0]);  /* will get ps command from here */
		execl(shell,"sh",0);
	}
	write(pipeo[1],cmd,5);	/* writes the 'ps a' command */
	close(0);
	dup(pipei[0]);		/* this is where the ps will get written */
	if ((ch=getchar())!='%' && ch!='#') printf("unexpected input\n");
	for (;;)
	{	for (ptr=ps-1; *ptr != '\n' && *ptr != '%'
					    && *ptr != '#'; *++ptr=getchar())
			if (*ptr==0) --ptr;
		if (*ptr=='%' || *ptr=='#') break;   /* read the last one */
		*ptr=0;
		if (!strcomp(&ps[9],killee)) continue;
		for (ptr = &ps[2]; *ptr==' '; ptr++); /* get to pid */
		for (n=0; *ptr!=' '; n=10*n+(*ptr++)-'0'); /* convert*/
		printf("Killing process %d\n",n);
		if (kill(n,9)<0) printf(" Unable to kill\n");
	}
	kill(shl,9);	/* get rid of the shell */
}
