/* code command -- list chars with the octal equivalent
 * by Keith H. Davis.
 */

char a[] "\n\rl  ddd";
int flg 0;
int rawmode 1;

main(argc, argv)
int argc;
char *argv[];
{	register int i;
	char c;
	int t[3],s;
again:  if(argc>1)
	{       if(argv[1][0]=='-')
		{       argc--; argv++;
			rawmode=0;
			goto again;
		}
		close(0);
		if( open(argv[1],0) == -1 )
		{       write(1,"\nCannot open input file\n",24);
			exit();
		}
	}
	if(rawmode)
	{	flg=1;
		gtty(0,t);
		t[2]=040|((s=t[2])&(~072));
		stty(0,t);
	}
	for(;;)
	{	if(!read(0,&c,1))c=0177;
		i=a[2]=c;
		a[7]=(i&07)+'0'; i=>>3;
		a[6]=(i&07)+'0'; i=>>3;
		a[5]=(i&07)+'0'; i=>>3;
		write(1,a,9);
		if(c==0177)
		{       if(flg){ t[2]=s; stty(0,t); }
			exit();
}	}	}

