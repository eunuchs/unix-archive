#
/* program to print line-numbered version of program */

#define mn 100
char buf[mn];
int n 0;
int nn 0;
#define linespp 58
int pn;
#define pmn 100
char pbuf[pmn];
int fd,fn;
char c;
main(narg,arg)
int narg;
char *arg[];
{
int i,j,p,tm[2];
char lc,qc;
fn=1;

back: fd = (fn < narg ? open(arg[fn],0) : 0);
lc=012;
p = 0;
j=n=nn=i=0;
time(tm);
while ((c = read1()) ) {
    if (qc = (lc == 014) | lc == 012) {
	if (lc == 014) i = 0;
	if (i++ % linespp == 0) {
		if (i != 1) putchar(014);
		printf("%s   %.24s   Page %d\n\n",arg[fn],ctime(tm),++p);
		};
	if (lc == 012) printf("%d",++j);
	putchar('\t');
	}

	putchar(lc=c);
	}
if (fd) close(fd);
putchar(014);
if (++fn < narg) goto back;
putchar(' '); putchar(012);
putchar(014);
putchar(014);
write(1,&pbuf,pn);
}


read1()
{
if (n == nn) {
	if ((nn = read(fd,&buf,mn)) <= 0) return (0);
	n = 0; }

return (buf[n++]);
}




putchar(d)
char d;
{
if (pn == pmn) {
	write(1,&pbuf,pn);
	pn = 0;
	}
pbuf[pn++] = d;
}
