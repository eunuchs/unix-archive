# define personfile "/change/users"

main (argc, argv)               /* Search the file containing user id's */
int argc;                       /* to obtain correspondences between    */
char *argv[];                   /* login names (user id's) and real     */
				/* names. In actuality, the program     */
{       argv++;                 /* returns all lines containing any     */
				/* string supplied as an argument       */

	while (--argc)
	{       if (fork ())
		{   wait();     /* wait for child to process first */
		    argv++;     /* argument and iterate       */
		}
		else
		{   execl ("/usr/bin/grep", "grep", *argv,  personfile, 0);
		    printf ("execl failed\n");
		    exit (0);
		}
	}
}
