/*	tmpread : Read the contents of /usr/adm/wtmp
 *	optional argument for contents of another file of the same format,
 *	e.g. tmpread /etc/utmp
 *		J. Gillogly, 27 Nov 1974
 */

main(nargs,args)
int nargs;
char **args;
{	int fn; /* file descriptor */
	struct
	{	char user[8];	/* user's name */
		char tty;	/* bug in documentation: high order char */
		char dummy;
		int t[2];	/* time of login, logout or reboot */
		int dummy2;
	} buf;
	int i;
	char ch;
	if (nargs<2) fn=open("/usr/adm/wtmp",0);	/* default file */
	else fn=open(args[1],0);			/* or user's file */
	if (fn<0)
	{	printf("Can't open %s\n",
			(nargs<2 ? "/usr/adm/wtmp" : args[1]));
		exit(0);
	}
	printf("user	 tty		time\n");
	for (;;)
	{	if (read(fn,&buf,16) != 16) exit(0);
		for (i=0; i<8; i++)
			printf("%c",((ch=buf.user[i])==0?' ':ch));
		printf("  %c",((ch=buf.tty)==0?' ':ch));
		printf("  %s",ctime(buf.t));
	}
}
