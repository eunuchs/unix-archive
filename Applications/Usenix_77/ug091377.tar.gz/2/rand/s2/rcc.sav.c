/*    OUTPUT FOR STOCK GAINES */
/*    File nrcc.c  */
	/*  Change record  */
	/* 12/5/74 Combined into one program, with UNIX -> 370 transfer */
	/* 1/21/75 Corrected rcc.audit record switch */
	/* 2/25/75 Changed rcc.audit mode to off at start.
		   Fixed bug in nr. files that can be transmitted to rcc.
		   Fixed bug that put "%" at end of transmitted files.	*/
	/* 3/18/75 Fixed exit bug */
	/* 3/18/75 Added feature to copy lines from Wylbur */
char *cleard " Connected to rcc.  <DEL> to exit.\n\r";
   int clrdl 36;
char *page1  "set page	1\r";  /* page1 & page24 must */
char *page24 "set page 24\r";  /*   the same length	    */
   int pagel 12;
char *terse "set terse\r";
   int tersel 10;
char *verbose "set verbose\r";
   int vbosel 12;

char *lockfile "/tmp/rcc.lock";
int lockmode 0677, arg[3],fildes[2], repdes[2];
char fname[50];
char *rcctty "/dev/ttyg";
char *auditfile "./rcc.audit";
char *newaudit  "./rcc.newaudit";
int auditmode 0777, wrotea 0;
 char *dbgfile "dbg";
int dbg 0, dbfd 0;
int fd, sfd 0, lfd, tfdes, pid, nch, stop, quit;
int rflag 0, intflag;
char ccc '\021'; /* break character for Wylbur */
char cr '\r', bl ' ';
char bkchar '\021';
char ch;
main() {
	/* try to get the the line; if can't tell user to wait awhile */
	/* run this code at high priority to prevent races */
	nice(-100);
	if ((lfd=open(lockfile,2)) >= 0) {

		nch = read(lfd,fname,8);
		if (nch  > 0) {
			nice(0);
			printf("\nSORRY, THE RCC LINE IS IN USE BY %s\n",fname);
			exit(0);
		}
	}
	if (creat(lockfile,lockmode) < 0) {
		error("\nCreat failed\n",0);
	}
	seek(lfd,0,0);
	setname();
	write(lfd,fname,8);
	close(lfd);
   /*	nice(0); /* return to lower priority */


	/* open up the line to the 370 and the audit file  */
	if ((fd=open(rcctty,2)) < 0)
		error("\nCannot open rcctty\n",0);

	raw();

	gtty(fd,arg);   /* set up for 1200 baud operation into the 370 */
	arg[0] = (9<<8)|9;
	arg[2] = 010343;
	stty(fd,arg);

	if ((sfd=creat(newaudit,auditmode)) < 0)
		error("\nCannot creat auditfile\n",0);

	pipe(fildes); pipe(repdes);

	if (pid=fork() ) {  rccin();}
	else {	rccout();};
}
raw(){
	gtty(0,arg);	    /* put the controlling keyboard into raw mode */
	arg[2] = 010353;
	stty(0,arg);
     }
unraw(){
	gtty(0,arg);	    /* return keyboard to normal mode */
	arg[2] = 010333;
	stty(0,arg);
       }
waitprompt(){
 char wch;
 wch = 0;
 while(wch != '\003') read(fd,&wch,1); /* Wait for prompt from 370 */
}

error(str,eid) char *str; int eid; {
	nice(0);
	unraw();
	printf(str);
	printf("... This should not have happened--get help!\n");
	if (creat(lockfile,lockmode) < 0) printf("\nCannot unlock lockfile");
	if (eid > 0) kill(eid,9);
	if (eid >= 0) exit(0);
	printf("\nPlease push DEL");
	for (;;) getchar();
}


/*RCCIN   RCCIN  */
char nl '\n';
int  arg[3];
rccin(){
     char gch;

	printf("Welcome to RCC!\t\t\t\t\trcc version 5\r\n");
	printf("Commands are:\r\n");
	printf("\t<DEL> to exit, i.e. return to UNIX.\r\n");
	printf("\t<CTRL-S> to send a UNIX file to Wylbur.\r\n");
	printf("\t\tPut Wylbur in COLLECT mode with a long line length first.\r\n");
	printf("\t<CTRL-R> to start and stop recording on rcc.audit\r\n");
	printf("\t<CTRL-U> to temporarily return to UNIX\r\n");
	printf("\t<CTRL-C> to copy lines into into rcc.audit.\r\n");
	printf("\t<CTRL-D> initiates debugging print on rcc.audit\r\n");
	printf("\nHit <RETURN> to poke the 370: ");

	while (1) {
		switch ((gch=getchar())) {
			case '\022':	gch=0; ch_audit(); break;
			case '\0':	gch = '\021'; break;
			case '\n':	gch = '\r';   break;
			case '\025':	gch = 0; callunix(); break;
			case '\177':	getout(); break;
			case '\004':	gch = 0; dbgr();  break;
			case '\003':	gch = 0; getfl(); break;
			case '\023':	gch = 0; sndfl(); break;
			default:	;
		}

		if (gch) {
					write(fd,&gch,1);
			if (gch == '\r') gch = '\n';
			if (rflag) write(sfd,&gch,1);
		}

	}
}
dbgr(){
 dbg=1-dbg;
 if (dbfd==0) dbfd=creat(dbgfile,auditmode);
 kill(pid,2);
 read(repdes[0],&ccc,1);  /* Wait until <pid> stops */
 ch = 'd';
 write(fildes[1],&ch,1);  /* Send signal to start debug printing*/
 if (dbg) printf("\r\nNow in debugging mode, output on DBG\r\n");
      else  printf("\r\nNo longer in debugging mode\r\n");
}

getout(){
	printf("\nAre you logged off the 370? ");
	if ((ch=getchar()) == 'y' || ch == 'Y') {
		while (ch != '\r') ch = getchar(); /* chew up rest of line */
		printf("\034\013");
		kill(pid,9);
		if (wrotea) {write(sfd,&nl,1);
			       unlink(auditfile);
			       link(newaudit,auditfile);
			      }
		unlink(newaudit);
		creat(lockfile,0777);
		unraw();
		printf("\n\r");
		exit(0);
	};
	while (ch != '\r') ch = getchar();
	printf("Sorry, but you must be logged off!\r\n");
	printf("Back in RCC.\r\n");
	printf("Hit <RETURN> to poke the 370:\r\n");
	return;
}
intcopy(){
 raw();
 quit = 1;
}


 char *endline "\r\n  ";
getfl(){
 int terct, bc, ct, gfc, ncar, i;
 char *pcmd, line[150], *p, *q;

 signal(2,&intcopy);
 quit = 0;
 kill(pid,2);
 wrotea = 1;
 read(repdes[0],&ccc,1);  /* Wait until read370 process stops */
 write(fd,page1,pagel);
 gfc=terct=0;
 while(gfc != '\003')
       {read(fd,&gfc,1);
	terct++;}

 write(fd,terse,tersel);
 waitprompt();

 /* collect parameters */
 printf("\r\nType a legal Wylbur LIST command.	The results will be copied to");
 printf("\r\n	RCC.AUDIT.  Include 'unn' to omit Wylbur line numbers.\r\n");
 while ((gfc = getchar()) != '\r')  write(fd,&gfc,1);
 printf("\n\r\t\t\tHit DEL to interrupt copying\r\n");

 /* start Wylbur sending file */
 unraw();
 write(fd,&cr,1);


 ct = 0;
 printf("\n\r0	  lines copied.  Hit DEL to interrupt copying\r");
 while(1)
       {      /* loop to copy lines */
	pcmd = line;
	ncar=0;
	while(1)
	   {	 /* loop to copy characters */
	    *pcmd = '\004';
	    read(fd,pcmd,1);
	    if (dbg) write(dbfd,pcmd,1);
	    if (*pcmd == '\004') continue;  /*unlikely from Wylbur, I hope*/
	    if (*pcmd == '\003') break;  /* normal exit from loop */
	    if (*pcmd == '\017') {if (dbg) write(dbfd,pcmd,1);
				  read(fd,pcmd,1);
				  if (dbg) write(dbfd,pcmd,1);
				  bc=(*pcmd&017)+(10*(*pcmd>>4));
				  read(fd,pcmd,1); /* throw away line nr */
				  if (dbg) write(dbfd,pcmd,1);
				  bc=bc-ncar+1; /* temp change */
				  if (bc <= 0) continue;
				  ncar=+ bc;
				  while (bc-- > 0) *pcmd++ = ' ';
				  continue;
				 }
	    if (*pcmd < 040 && *pcmd != '\n') continue;
	    pcmd++;
	    if (++ncar > 150)
	       {printf("\nGot line > 150 characters, quit\n\r");
		write(fd,'\021',1);
		quit = 1;
		break;
	       }
	   }
	ncar=ncar-3;
	write(sfd,line,ncar);

	/* test for last line */
	printf("%d\r",++ct);
	if (quit) break;
	p = pcmd-3;
	if (*p++ == '\n') if (*p == ' ')
	      {write(fd,&cr,1);
	       continue;
	      }
	break;
       }

 *pcmd = '\0';
 printf("\n***	Copying complete.  Last line copied was:\n\r%s",line);
 raw();
 signal(2,0);
 if (terct>5) {write(fd,verbose,vbosel);
	       waitprompt();  }

 write(fildes[1],&ccc,1);
 printf("%s\n",page24);
 write(fd,page24,pagel);
 }


ch_audit(){rflag=1-rflag;
 kill(pid,2);
 wrotea = 1;
 read(repdes[0],&ccc,1);  /* Wait until <pid> stops */
 ch = 'x';
 write(fildes[1],&ch,1);  /* Send signal to shift record mode & restart */
 if (rflag) printf("\r\nNow recording on RCC.AUDIT.\r\n");
      else  printf("\r\nNo longer recording on RCC.AUDIT.\r\n");
}
sndfl(){   /* subroutine to send a file to Wylbur */
 if (sendfile()) {
	nice(-100);
	close(tfdes);
	printf("\r\n\t%s transmitted to Wylbur\r\n",fname);
	write(fildes[1],&cr, 1);
	signal(2,0);
	write(fd,&bkchar,1);
	raw();		};
}
stopsnd(){stop=1;
	  signal(2,0);};
sendfile(){
 char *pc;
 int c;
 int namectr, lcount, ccount;
 struct buf {int fldes;
	     int nleft;
	     char *nextp;
	     char buffer[512];}  bbb;
 struct buf *lbuf;
 lbuf = &bbb;
	printf("\tYou are about to send a file to Wylbur.\r\n");
	printf("\tYou should be in COLLECT mode in Wylbur already.\r\n");
RETRY:	printf("\t\tTo quit without transmitting a file, hit <RETURN>.\r\n");
	printf("\tFile name ?\r\n\t");

/* collect file name */
 fname[0]=0; namectr=1;
 for(pc=fname;(*pc++ = getchar()) != '\r';)
				    if (namectr++ >= 50) break;
 if (namectr == 1)   return(0);
 *--pc= '\0';

/* look up file */
 if (fopen(fname, lbuf) < 0)
			   {printf("\r\n\t%s unknown\r\n",fname);
			    goto RETRY;};

/* Transmit file */
 tfdes = bbb.fldes;
 kill(pid,2);	/* put RCCOUT into a wait state */
 signal(2,&stopsnd);
 nice(0);
 stop=0;
 unraw();		/* out of raw mode so DEL will work */
 read(repdes[0],&ccc,1);
 printf("\r\n\t\tHit DEL to interrupt transmission.\r\n");
 lcount=0;
NEXTLINE:
 ccount=0;
 while(1){
   c=getc(lbuf);
   if (c < 0) {return(1);} /* return of 1 to signal something sent */
   else if (c == '\t'){ write(fd,&bl,1);
			while((++ccount % 8) != 0) write(fd,&bl,1);
			continue;}
   else if (c < 040){if (c == '\n') c = '\r'; else continue;};
   write(fd,&c,1); ccount++;
   if (dbg) write(dbfd,&c,1);
   if (c == '\r') break;
	 };
 ch = 0;
 printf(" Sent line %d\r",++lcount);
 waitprompt();
 if (stop) return(1);
 goto NEXTLINE;
}
callunix() {	int shpid;
	if (shpid=fork()) {
		while (shpid != wait(0));
		printf("\nBack in RCC.\n");
		printf("Hit <RETURN> to poke the 370: ");
		raw();
		return;
	}
	else {
		unraw();
		printf("\nLeaving RCC for UNIX.\n");
		printf("Hit <CTRL-D> to return to RCC.\n");
		execl("/bin/sh","-",0);
		printf("\nexecl did not work - get help!\n");
		return;
	}
}



/*RCCOUT   RCCOUT  */
int1(){ signal(2,1);
	write(repdes[1],&cr,1);
	read(fildes[0], &ccc,1);
	intflag=1;
	if (ccc == 'x')  rflag=1-rflag;
	if (ccc == 'd') {dbg=1-dbg;
			 if (dbfd==0) dbfd=open(dbgfile,1);	}
}
rccout() {
	intflag=1;
	while(1) {
		if (intflag) {signal(2,&int1); intflag=0;  };
		ch='\004'; /* Unlikely from Wylbur, I hope */
		read(fd,&ch,1);
		if (ch== '\004') continue;
		if (dbg) write(dbfd,&ch,1);
		if (ch == '\017') {
			putit(ch);

			read(fd,&ch,1);
			if (dbg) write(dbfd,&ch,1);
			putit(ch);
			read(fd,&ch,1);
			if (dbg) write(dbfd,&ch,1);
			putit(ch);
			ch = '\t';
			if (rflag) write(sfd,&ch,1);
		}
		else if (ch < 040 && ch != '\n' && ch != '\t') putit(ch);
		else {
			if (rflag) write(sfd,&ch,1);
			putit(ch);
		}
	}
}

putit(xh) char xh; {
	if (xh) putchar(xh);
	else putchar(0177);
	if (xh == '\034'){
		/*printf(" Connected to rcc.  <DEL> to exit.\n\r"); */
			write(1,cleard,clrdl);
			 }
}
setname()
{       register char *s, *t, c;
	char buf[80];

	t = fname;
	if(getpw(getuid()&255,buf))
	{       s = "unknown";
		while(c = *s++) *t++ = c;
	}
	else
	{       s = buf;
		while((c = *s++) != ':') *t++ = c;  /* pick up name */
	}
	while(t < &fname[8]) *t++ = ' ';
}
