#


#define	STAR	'*'
#define	TAB	'\t'
#define	SP	' '
#define COLON	':'
#define NL	'\n'
#define EOF	'\0'
#define MINUS	'-'
#define PLUS	'+'
#define SLASH	'/'
#define LPAR	'('
#define RPAR	')'
#define QUOTE	'\''
#define COMMA	','
#define PERCEN	'%'
#define BACKSL	'\\'


#define e_CON	0
#define e_SYM	1
#define e_TL	2
#define e_PC	3

#define e_TERM	0
#define e_PLUS	1
#define e_MINUS	2
#define e_SLASH	3
#define	e_STAR	4

#define UND	0
#define EXP	1
#define ABS	2
#define EST	3


#define o_INH	0
#define o_DUAL	1
#define o_STA	2
#define o_AEI	3
#define o_PUSH	4
#define o_IDEI	5
#define o_DEI	6
#define o_JMPS	7
#define o_BNCH	8
#define o_JBRS	10
#define o_JEQS	11

#define o_SEG	100
#define o_END	101
#define o_EQU	102
#define o_FCB	103
#define o_FCC	104
#define o_FDB	105
#define o_MON	106
#define o_NAM	107
#define o_OPT	108
#define o_ORG	109
#define o_PAG	110
#define o_RMB	111
#define o_ZMB	112
#define o_SPC	113



struct segment
    {	char segchar;
	char segtype;
	int segcount;
    };



struct	symbol
    {	char s_name[8];
	int s_pc;
	int s_chain;
	char s_def;
	char s_seg;
    };


struct	fb
    {	int fb_pc;
	char fb_def;
	char fb_lab;
    };


struct iform
    {	int i_pc;
	int i_def;
    };

#define i_LONG	1
#define i_DIR	2
#define i_REL	3


/* offsets from listbuf */

#define l_UND	0
#define l_ADR	2
#define l_C1	9
#define l_C2	12
#define l_LAB	19
#define l_CL	20
#define l_MNE	27
#define l_ACC	31
#define l_OPR	34
#define l_COM	52
#define l_EOL	79
