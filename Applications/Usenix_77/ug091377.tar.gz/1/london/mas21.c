#


#include	"mas2h.c"


char *symtmp, *fbtmp, *itmp, *ltmp;
int sfile, fbfile, ifile;

struct iform *iptr;
int icount;
extern struct iform ibuf[];

extern char listbuf[], line[];
char *lbp, *linep;
int lfile;

int obfile;

extern char inbuf[];
char *nextch;
char tch;
extern struct symbol symtab[];
extern char maddr[];
extern int mcode[];
extern hashtab[];
extern struct fb fbtable[];
extern curfb[];
extern char symbuf[];

int gargc;
char **gargv;


int numsym;
int lab, undef;

struct segment segopt;

int nextfb;

int findes;
int nchar;
char *fins;
int qcompar();


int npc, spc, pc;
int lc;
int operand;


main(argc, argv)
char **argv;
{
register char *s, c;
register n;

	ltmp = "/tmp/motmx.5";
	c = *(ltmp+9) = argv[0][0];	/* temp file char */
	gargc = --argc;
	gargv = ++argv;
	findes = 10;

	symtmp = "/tmp/motmx.0";
	fbtmp = "/tmp/motmx.1";
	itmp = "/tmp/motmx.2";
	*(symtmp+9) = c;
	*(fbtmp+9) = c;
	*(itmp+9) = c;

	if ( (sfile = open(symtmp,0)) == -1 )
		help();
	if ( (fbfile = open(fbtmp,0)) == -1 )
		help();
	read(sfile, hashtab, 256);
	s = symtab;
	do
	    {	n = read(sfile, s, 512);
		s =+ n;
		numsym =+ n;
	    }
	while ( n == 512 );
	numsym =/ 14;

	s = fbtable;
	do
	    {	n = read(fbfile, s, 512);
		s =+ 512;
	    }
	while ( n == 512 );

	close(sfile);
	close(fbfile);
	unlink(symtmp);
	unlink(fbtmp);

	if ( (ifile = open(itmp, 0)) == -1 )
		help();
	icount = read(ifile, ibuf, 512);
	iptr = ibuf;
	icount =>> 2;

	if ( (obfile = creat("m.out",0666)) == -1 )
		help();

	if ( (lfile = creat("m.lst",0666)) == -1 )
		help();

	nextfb = 20;
	for ( n=0; n<20; n++ )
		curfb[n] = n;

	s = "L\n";
	write(obfile, s, 2);
	newrec();
	if ( newfile() == 0 )
		help();
	lbp = listbuf;
	lcopy(&line);

	if ( (c = getch()) == '#' )
	    {	line[l_LAB] = c;
		lc++;
		getsym(getnonbl());
		lmnem();
		linep = line+l_OPR;
		if ( (c = getnonbl()) == MINUS )
		    {	*linep++ = c;
			c = getch();
			segopt.segtype = 2;
		    }
		else
			segopt.segtype = 1;
		segopt.segchar = *linep++ = c;
		segopt.segcount++;
		tch = getch();
		lcomma();
	    }
	else
		nextch--;

	for (;;)		/* main loop */
	    {	spc = pc = npc;
		undef = lab = 0;
		lc++;
		linep = line;
		if ( (c = tch = getch()) == EOF )
		    {	if ( newfile() )
				continue;
			break;
		    }

		switch (c)
		{
		case NL:
			lcomma();
			continue;

		case SP:
		case TAB:
			tch = c;
			break;

		case STAR:
			lcoml();
			continue;

		default:
			getsym(c);
			if ( digit(c) )
				deffb(c-'0');
			else
				lab = lookup();
			llabel();
		}

		if ( (c = tch) != NL )
			c = getnonbl();
		if ( (tch = c) == NL )
		    {	lcomm();
			continue;
		    }

		if ( (n = getmnem(c)) == 0 )	/* get op code */
			continue;		/* zero means done */
		lcode1(n);
		outbyte(n);
		if ( (n = (pc-spc)) == 2 )
		    {	lcode2(operand);
			outbyte(operand);
		    }
		else
		if ( n == 3 )
		    {	lcode3(operand);
			outword(operand);
		    }
		lcomm();
	    }

	if ( iins(i_REL) == 0 )
		syserr();
	outrec();
	endrec();
	if ( n = segopt.segcount )
		llocals(n);
	lglobals();
	unlink(itmp);
	unlink(ltmp);
	exit();
}





deffb(ind)
{
register i;

	i = ind;
	curfb[i] = curfb[i+10];
	curfb[i+10] = nextfb++;
}



newfile()
{
	close(findes);
	if ( gargc-- )
	    {	fins = *gargv++;
		if ( (findes = open(fins,0)) == -1 )
			return(newfile());
		nchar = read(findes, nextch=inbuf, 512);
		lc = 0;
		return(1);
	    }
	return(0);
}




getmnem(ch)
char ch;
{
register char acc;
register opc, n;
int adrm;

	if ( getsym(ch) == 4 )
		acc = (symbuf[3] | 040) - 0140;
	else
		acc = 0;

	lmnem();
	symbuf[3] = 0;
	n = mnemlook();
	adrm = maddr[n];
	opc = mcode[n];
	switch ( adrm )
	{
	case o_INH:
		pc++;
		break;

	case o_DUAL:
		if ( acc == 0 )
			acc = getacc();
		if ( acc == 2 )
			opc =+ 0100;
		opc =+ getimm(2);
		break;

	case o_STA:
		if ( acc == 0 )
			acc = getacc();
		if ( acc == 2 )
			opc =+ 0100;
		opc =+ getdirec(0);
		break;

	case o_AEI:
		if ( acc )
		    {	pc++;
			if ( acc == 2 )
				opc =+ 020;
		    }
		else
			opc =+ getind(0);
		break;

	case o_PUSH:
		if ( acc == 0 )
			acc = getacc();
		if ( acc == 2 )
			opc++; 
		pc++;
		break;

	case o_IDEI:
		opc =+ getimm(3);
		break;

	case o_DEI:
		opc =+ getdirec(0);
		break;

	case o_JMPS:
		opc =+ getind(0);
		break;

	case o_BNCH:
		operand = n = getexpr(0);
		pc =+ 2;
		if ( undef )
			break;
		n =- pc;
		if ( (n < -128) || (n > 127) )
		    {	brerr();
			n = 0;
		    }
		operand = n & 0377;
		break;

	case o_JBRS:
		operand = getexpr(0);
		if ( iins(i_LONG) )
		    {	opc = mcode[n+1];
			pc =+ 3;
			break;
		    }
		pc =+ 2;
		n = operand - pc;
		if ( (n < -128) || (n > 127) )
			syserr();
		operand = n & 0377;
		break;

	case o_JEQS:
		if ( iins(i_LONG) )
		    {	n = getexpr(0);
			operand = 03;	/* inverse jump 2 bytes */
			outbyte(opc);
			outbyte(operand);
			lcode1(opc);
			lcode2(operand);
			lcomm();
			spc =+ 2;
			outbyte(0176);	/* jmp in extended mode */
			outword(n);
			lcode1(0176);
			lcode3(n);
			tch = NL;
			linep = line+l_C2+4;
			lcomma();
			return(0);	/* no opc zero */
		    }
		symbuf[0] = 'b';
		opc = mcode[ mnemlook() ];
		n = getexpr(0);
		pc =+ 2;
		n =- pc;
		if ( (n < -128) || (n > 127) )
			syserr();
		operand = n & 0377;
		break;

	default:
		pseudop(adrm);
		return(0);
	}

	return(opc);
}



help()
{
	printf("help - temp files lost\n");
	unlink(ltmp);
	unlink(symtmp);
	unlink(fbtmp);
	unlink(itmp);
	exit();
}




iins(i)
char i;
{
	if ( (iptr->i_def == i) && (spc == iptr->i_pc) )
	    {	if ( --icount )
		    {	iptr++;
			return(1);
		    }
		icount = read(ifile, ibuf, 512);
		icount =>> 2;
		iptr = ibuf;
		return(1);
	    }
	return(0);
}



syserr()
{
	error("assembler error");
}


error(s)
char *s;
{
	printf("%5.d\t%s\n", lc, s);
}


brerr()
{
	error("branch error");
	line[l_UND] = 'B';
}


fbund()
{
register char *s;
	s = "Ufb";
	printf("%5.d\t%s %s\n", lc, s, symbuf);
}


underr()
{
register char *s;

	s = "U";
	printf("%5.d\t%s %s\n", lc, s, symbuf);
}
