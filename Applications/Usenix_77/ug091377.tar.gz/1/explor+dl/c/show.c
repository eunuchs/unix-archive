#
#include "common.h"

	char outa[4] { ' ',	'-',	'0',	']'};
	char outb[4] { ' ',	' ',	' ',	'['};
	char outc[4] { ' ',	' ',	' ',	'$'};


/*  produce 3-times-overprinted output on printer.  expands line into */
/*  lowest tier of /sngls/  and uses other 3 for output line images */
/*  control characters inew  = form feed, iplus  = overprint, iskip  = */
/*  next line ( *  for dec-10 system, blank for most others) */
/*	rewritten in 'c
 *	jan 20, 1976
 *	lou katz
 *	Columbia University, College of Physicians & Surgeons
 *	630 West 168  Street
 *	New York, N.Y. 10032
 *	212-694-3501
 */

show(inx,iny,inw,inh)
{

	register int i,j,k;
	int iflag,newpg,ileft,irite,linecur,line1,line2,line3;
	int new,num,ill,il,ir,it,ib;
	int ok,iblk,iw,inew,iskip,iplus;

	inew = iskip = iplus = iblk = ' ';
	if (frzzt)
		klear(&frzzt);

	/* setup for print line of max width 132 */
        iw = min0(131,inw);
        rctfy (inx,iny,inw,inh,&il,&ir,&ib,&it,&ok);

	if (!ok)
		return;
	newpg = true;
	linecur = it;
	ill = il-1;

	for (j=ib;j<=it;j++) {
/*      expand line into 3 alphanumeric images for printing */
		xpand(il,linecur,ir,0);
		line1 = ill;
		line2 = ill;
		line3 = ill;

		for (k=il;k<=ir;k++) {
			num = NM[k];
			if (outa[num] != iblk)
				line1 = k;
			NM[k+nperl] = outa[num];
			new = outb[num];
			if (new != iblk)
				line2 = k;
			NM[k+nperl2] = new;
			new = outc[num];
			if (new != iblk)
				line3 = k;
			NM[k+nperl3] = new;
		}
/*      (over)print 1 to 3 lines	*/
/*	this works because nperl > 132. otherwise there might be
 *	overlap and conflict
 */

		NM[ill+nperl] = iskip;
		if(newpg)  NM[ill+nperl] = inew;
		ileft = ill+nperl;
		irite = line1+nperl;

		for (k=ileft;k<=irite;k++)
			printf("%c",NM[k]);



		if(line2 != ill) {
			NM[ill+nperl2] = iplus;
			ileft = ill+nperl2;
			irite = line2+nperl2;

			printf("\r");
			for (k=ileft;k<=irite;k++)
				printf("%c",NM[k]);
	
			if(line3 != ill) {
				NM[ill+nperl3] = iplus;
				ileft = ill+nperl3;
				irite = line3+nperl3;

				printf("\r");
				for (k=ileft;k<=irite;k++)
					printf("%c",NM[k]);
			}
		}
		printf("\n");
		linecur--;
		newpg = false;
	}
}
