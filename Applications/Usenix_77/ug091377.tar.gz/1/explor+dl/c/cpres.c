#
#include "common.h"

/*  inverse of xpand.  always compresses lowest tier of /sngls/ */
cpres (ix1,iy,ix2)
{

	register int i,j,index;
	int minwd,maxwd;

        if(iy < 0 || iy > nperl)return;
        minwd = max0(0,(ix1)/7);
        maxwd = min0(nperw,(ix2)/7);
           if(minwd > maxwd)return;
        index = minwd+nperw* (iy);
        i = (minwd)* 7;

	for (j=minwd;j<maxwd;j++) {
		LINE[index++] = ipak(&NM[i]);
		i =+ 7;
	}
}
