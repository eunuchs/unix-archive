#
#include "common.h"

/* expands ix1,y - ix2,y into /sngls/ (full words). idel = 0,nperl,nperl2,nperl3 */
xpand(ix1,iy,ix2,idel)
{
	register int j,index,idx;
	int minwd,maxwd;

        if (iy<0 || iy>=nperl) {
		return;
	}
        minwd = max0(0,(ix1)/7);
        maxwd = min0(nperw-1,(ix2)/7);
        if(minwd>maxwd) {
		return;
	}
        index = minwd+nperw * iy;
        idx = minwd * 7+idel;
	for (j=minwd;j<=maxwd;j++) {
		splt(LINE[index++],&NM[idx]);
		idx =+ 7;
	}
}
