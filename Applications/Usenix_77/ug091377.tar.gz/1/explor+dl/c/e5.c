main()
{
	/*  growth from nuclei by randomly selected rules.  */
	/*  do 6x4 trials.  */

	register int j,k,l;
	char c;
	int nabrs,many;

	for(j=1;j<=6;j++){
		for(k=1;k<=4;k++){
	/*  place nucleus.  */
			put((20 * j)-10,(20 * k)-10,3);

	/*  select neighborhood and counts.  */
			do {
				nabrs = 100 * ne(0,7);
				nabrs =+ ne(0,7);
				nabrs =+ 40 * ne(0,1);
				nabrs =+ 10 * ne(0,1);
			} while(nabrs==0);

			many = 1000 + 100 * ne(2,8);
			many =+ 10 * ne(2,8);
			many =+ ne(2,8);

	/*  iterate 8 times.  */
			for(l=0;l<8;l++) {
				if (l==0) printf("many=%d, nabrs=%d\n",many,nabrs);
				locop((20 * j)-10,(20 * k)-10,17,17,100,many,nabrs,3,3333);
			}
		}
	}
	for (j=1;j<=6;j++)
		for (k=1;k<=4;k++) {
			printf(":");
			do {
				read(2,&c,1);
			} while (c!='\n');
			printf("");
			show((20 * j)-10,(20 * k)-10,20,20);
		}
}
