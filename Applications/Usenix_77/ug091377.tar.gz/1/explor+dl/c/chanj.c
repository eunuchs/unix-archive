#
#include "common.h"

	int skip 0;
/*  transliterate, according to irule, indicated rectangle.  by columns */

chanj (inx,iny,inw,inh,ipct,irule)
{
	register int j,k;
	int ib,il,ip,ir,it,newn,oldn,iwrd1;
	int ifact,idlsk,iprob,ibyte,iskip;
	int iwrdl,mdrul,ipont,konst,i7;
	char ok;

	if (frzzt)
		klear(&frzzt);
	if(irule < 0 || irule > 3333)
		return;

	rctfy (inx,iny,inw,inh,&il,&ir,&ib,&it,&ok);

	if (!ok)
		return;

        if ((iprob = 2* ipct - ipct/51) <=0)
		return;
        ipont = ne(1,199);
        iskip = ne(0,197);
        idlsk = ne(0,195);

        setxl(irule);
/*      if 0000,1111,2222,3333 and ipct=100 need not read for full words */
/*      complete word is 5461 times 0,1,2, or 3. forget it if ipct not 100 */

        mdrul = irule % 1111;	/* =0 if rule is 0000,1111,etc */
	if (ipct < 100)
		mdrul = 1;
	/* the repeated digit is (irule % 10), so the whole word is konst */
        konst = (irule % 10) * 5461;

	iwrd1 = ib * (nperw) + (il/7);
        iwrdl = iwrd1 + (it-ib)* nperw;

/*      attend to one column at a time */

	for (j=il;j<=ir;j++) {
		ibyte = j % 7;

		if (mdrul == 0) {	/* go here if 5461 rule above applies */
			if (skip > 0) {
				skip--;
				goto lab25;
			}
			if ((ibyte == 0) && ((ir-j) >=6)) {

/*      else do column of full words, then skip 6 columns */

				for (k=iwrd1;k<=iwrdl;k=+nperw)
					LINE[k] = konst;
				skip = 6;
				goto lab25;
			}
		}
lab12:
		ifact = (6-ibyte) *2;
		iskip = (iskip+idlsk) % 198;
	
		for (k=iwrd1;k<=iwrdl;k=+nperw) {
			if (ipct < 100) {
				ip = ipont + iskip;
				ipont = (ip % 199)+1;
				if (IRAN[ipont-1] >= iprob) {
					continue;
				}
			}
	
			i7 = LINE[k];
			oldn = (i7>>ifact) & 03;
			newn = INTO[oldn];
			LINE[k] = (i7 & ~(03<<ifact)) |  (newn<<ifact);
		}
lab25:
		if (ibyte == 6) {
			iwrdl++;
			iwrd1++;
		}
	}
}
