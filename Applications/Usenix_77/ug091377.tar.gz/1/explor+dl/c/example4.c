main()
{
	/* game of life, starting with pi. */
	/* initial configuration. */
	register int ix,iy,j;
	char c;

	put4(107,7,3330);
	put4(107,6,3030);
	put4(107,5,3030);
	for(j=0;j<24;j++){
	/* make a copy before next step. */
		ix = (j%5) * 24 + 12;
		iy = 72 - (j/5) * 16;
		combn(ix,iy,24,16,100,108,8,1,0000,1111,2222,3333);
	/* the rules of life. */
		locop(108,8,24,16,100, 3,757,3,1123);
		locop(108,8,24,16,100,23,757,3, 122);
		chanj(108,8,24,16,100, 330);
/*
		printf(":");
		read(2,&c,1);
		printf("\33\14");
		show(108,8,24,16);
*/
			}
	show(36,48,72,32);
}
