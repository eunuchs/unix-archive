#
#include "common.h"

/*  the number stored at ix,iy.  if off map, num = 4 */
num(ix,iy)
{

	register int ib,index,iword;
	int ibyte;

	if (frzzt)
		klear(&frzzt);

	if (ix < 0 || ix >= nperl ||
	    iy < 0 || iy >= nperl)
		return(4);

        index = nperw * iy + ix/7;
	ibyte = (6 - (ix % 7)) * 2;
	iword = (LINE[index] & (03 << ibyte)) >> ibyte;

	return(iword);
}
