#
/* 'mod' function ala fortran for babies */
/*
 * for mini-explor users
 * lk jan 76
 */

mod(i,j)
{
	return(i%j);
}
