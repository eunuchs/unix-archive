ipak(a)
int a[];
{
	register int *p,n,i;
	p = &a;
	for(i=0;i<7;) {
		n =| *p++<<2;
	}
	return(n);
}
