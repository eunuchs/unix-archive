main()
{
	register int i,j;
	int numxy;

	putfour(19,17);

loop:
	for (i=0;i<2;i++)
		for (j=0;j<2;j++)
			combn(i*32+15,j*32+15,32,32,100,3*32+15,15,ne(1,4),0000,1111,2222,3333);

	chanj(31,31,64,64,100,3+1000 * ne(1,2));

	locop(31,31,64,64,100,1234,757,3,3);
	locop(31,31,64,64,100,5678,757,3,3);

	for (i=0;i<2;i++)
		for (j=0;j<2;j++) {
			color(ne(0,7),ne(1,7),ne(1,7),ne(9,15));
			setopt(3,ne(0,4),ne(0,4),ne(1,4));
			dcombn(i*32+15,j*32+15,32,32,i*32+15,j*32+15);
		}
	dshow('p');
	goto loop;
}


putfour(x,y)
int x,y;
{
	register int i;
	int a;

	a = 2;
	for (i= -4 * a;i<=5 * a;i++)
		put4(96+x,y+i,333);
	for (i= -6 * a;i<=3 * a;i++) {
		put(96+x+i,y-1,3);
		put(96+x+i,y,3);
	}

	for (i= -7 * a;i<a;i++)
		put4(96+x-6 * a,y+i,333);
}
