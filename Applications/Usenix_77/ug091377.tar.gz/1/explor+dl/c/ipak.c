ipak(a)
char a[];
{
	register int j,k;

	for (j=0;j<7;j++) {
		k=<<2;
		k =+ a[j];
	}

	return(k);
}
