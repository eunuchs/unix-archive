#
#include "common.h"
main()
{

	register int i,j;
	char c;

	debug = false;
	for (i=0;i<8;i++) for (j=0;j<8;j++) put (i+2,j+2,2);
	for (j=0;j<6;j++) {
		put (2,j+2,1);
		put (7,j+2,3);
	}
	for (j=0;j<8;j++) {
	combn(20,20,10,10,100,5,5,j+1,0000,1111,2222,3333);
	read(2,&c,1);
	printf("\33\14");
	show(15,15,32,32);
	}
}
