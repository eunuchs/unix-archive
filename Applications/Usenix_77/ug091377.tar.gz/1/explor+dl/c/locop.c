#
#include "common.h"
	int IDEL [8] {
		nplm1,	nperl,	nplp1,	-1,
		1,	-nplm1,	-nperl,	-nplp1
	};
	int MODS[8] {
		400,	200,	100,	40,	10,	4,	2,	1
	};


/*  local operation.  works by expanding appropriate parts of 3 lines */
/*  into top 3 tiers of /sngls/ , computes new line in bottom tier. */
/*  effects do not propagate during one call	*/

locop(ix,iy,iw,ih,ipct,konts,nabrs,nums,irule)
{

	char  okont[10], oknms[10], ok;
	int ndel[8];
	int iprob,ipont,iskip,idlsk;
	register int j,k,l;
	int ip,kcnt,n,kar,ihere,nnn,ilast,numnb,index,ifrst;
	int il,ir,ib,it,ill,irr,ibb,itt;
	int i,m;

	if (!frzzt)
		klear(frzzt);

	if(konts > 8888 || konts < 0 || nabrs > 757)return;
	if(nabrs  < 1 || nums > 8888 || nums < 0)return;
	/* get the area under question and its bordering row/col */
	rctfy (ix,iy,iw+2,ih+2,&il,&ir,&ib,&it,&ok);

	if(( !ok) || irule < 0 || irule > 3333)return;
        ill = il+1;	/* the old left edge */
        irr = ir-1;	/* and right */
        ibb = ib+1;
        itt = it-1;
	if(ibb > itt || ill > irr)return;
        iprob = 2* ipct-ipct/51;
        ipont = ne(1,199);
        iskip = ne(0,197);
        idlsk = ne(0,195);

	setxl(irule);
/*      zero out tables of counts, numbers */
	for (j=0;j<10;j++) {
		oknms[j] = false;
		okont[j] = false;
	}

/*      set counts.  if zero is an ok count, it must be last */

        k = konts/1000;
        if (k) okont[k] = true;
        k = (konts/100) % 10;
        if (k) okont[k] = true;
        k = (konts/10) % 10;
        if (k) okont[k] = true;
        k = konts % 10;
        okont[k] = true;

/*      set numnb = number of neighbors, their delta-addresses into ndel */
/*      e.g. delta-address of neighbor up and right is +nplp1 */
        n = nabrs;
        numnb = 0;

	for (j=0;j<8;j++) {
		if (n>=MODS[j]) {
			ndel[numnb++] = IDEL[j];
		}
		n =% MODS[j];
	}


/*      set ok numbers.  if zero is ok, it must be last */
        k = nums/1000;
        if (k) oknms[k] = true;
        k = (nums/100) % 10;
        if (k) oknms[k] = true;
        k = (nums/10) % 10;
        if (k) oknms[k] = true;
        k = nums % 10;
        oknms[k] = true;

/*      expand first two lines and begin main processing loop */
/*      initially output = original line.  (xpand + cpress do full words) */;
	ifrst = (il/7) * 7;
        ilast = ((ir+6)/7) * 7;	/* get the last location caught by ir */
	xpand(il,ib,ir,nperl2);
	xpand(il,ib+1,ir,nperl3);

	for (k=ibb;k<=itt;k++) {

		for (j=ifrst;j<=ilast;j++) {
			NM[j+nperl] = NM[j+nperl2];
			nnn = NM[j+nperl3];
			NM[j+nperl2] = nnn;
			NM[j] = nnn;
		}

		xpand(il,k+1,ir,nperl3);
		/*      process middle row */
		iskip = (iskip+idlsk) % 198;

		for (l=ill;l<=irr;l++) {
			if (ipct < 100) {
				ip = ipont+iskip;
				ipont = ip % 199;
				if(IRAN[ipont]  >= iprob) goto lab200;
			}
			kcnt = 0;
			ihere = nperl2+l;

			for (m=0;m<numnb;m++) {
				index = ihere+ndel[m];
				kar = NM[index];
				if (oknms [kar])
					kcnt++;
			}

			if (okont[kcnt]) {
				kar = NM[l+nperl2];
				NM[l] = INTO[kar];
			}
		}

lab200:
		cpres(ifrst,k,ilast);
	}
}
