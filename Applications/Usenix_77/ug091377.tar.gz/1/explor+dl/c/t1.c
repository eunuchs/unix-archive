#
#include "common.h"
char ff 014;
main()
{
	register int i;
	register int ix,iy;

	debug = false;
	printf("");
	printf("%c",ff);
	/* contour plot of a mathematical function. */
	/* 2-d iteration pic. cell by cell. */
	for(iy=0;iy<30;iy++)
		for(ix=0;ix<70;ix++)
			put(ix,iy,2);
	for (ix=125-7;ix<125+7;ix++)
		for (iy=125-7;iy<125+7;iy++)
			put(ix,iy,(ix+iy)%2+2);
/*	chanj(35,15,35,15,50,3210); */
	locop(35,15,10,10,100,8765,757,2,3333);
	show(35,15,70,30);
}
