#
#include "common.h"

/* this is unnecessary in c as map is guaranteed to be zero
 * it is being kept for user call to change pictures without
 * reloading explor
 * lk jan 76
 */

/*  clear entire map to zeros at beginning of first map-changing op */

klear(fzflg)
char *fzflg;
{

	register int j;
	static char first;
	*fzflg = false;
	if (!first)
		return;
        first = false;

	for (j=0;j<maxary;j++)
		LINE[j] = 0;

}
