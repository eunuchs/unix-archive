#

/* split word into 7 bytes.  may want machine language replacement */
splt(inword,ar)
char *ar;
{
	register int iword,j;
	register char *arp;

	iword = inword;
	arp = ar;

	for (j=0;j<7;j++) {
		*arp++ = (iword>>(12- j*2)) & 03;
	}
	return;
}
