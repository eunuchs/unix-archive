#
#define nperl  140
#define nperw  nperl/7
#define nplp1  nperl+1
#define nplm1  nperl-1
#define nperl2 nperl*2
#define nperl3 nperl*3
#define nperb  nperl*4
/* maxary is for a square array, with number of lines = nperl
 * and number of words per line = nperl/7
 */
#define maxary nperl*nperw

#define true 1
#define false 0
/*
*	as supplied, nperl = 140.  thus nperw = 20 and nperb = 560
*	the whole array is then 2800.
*	the working array is nperl x nperl values.
*	2-bit values are packed 7 per word, so that
*	maxary = nperl * nperl / 7
*	the working line is 4 * nperl long = nperb
*	nplp1 and nplm1 are nperl+1 and nperl-1 for neighbors
*/
	int	LINE[maxary];
	int	IRAN[199];
	char	NM[nperb];
	int	INTO[4];
	char frzzt;
	char debug;
