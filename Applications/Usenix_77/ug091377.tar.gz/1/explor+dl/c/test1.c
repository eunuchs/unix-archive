main()
{
	char c;
	while((c=getchar())!= '\0')
		putchar(c);
}
