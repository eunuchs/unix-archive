#
#include "common.h"

/* rectify boundaries.  not ok if bottom above top, etc. */
/* input params  x, y, w, h.  output params left, right, bot, top, ok */
/* boundries are inclusive cell indices which are to be modified */

rctfy (inx,iny,inw,inh,il,ir,ib,it,ok)
int *il,*ir,*ib,*it;
char *ok;
{
        *ok = true;
	*il = max0(0,inx-((inw-1)/2));
	*ir = min0(nperl-1,inx+(inw/2));
	*ib = max0(0,iny-((inh-1)/2));
	*it = min0(nperl-1,iny+(inh/2));
	 if ( *il> *ir ||  *ib> *it) {
		*ok = false;
		return(false);
	}

	return(true);
}
