main()
{
	register int i,j,k;
	int ix,iy,idx,idy,size,x,y;

	put4(120,130,2030);
	put4(120,129,2333);
	put4(120,128,2030);
	put4(120,127,2120);
/*
	show(121,129,10,10);
*/

	for (i=0;i<25;i++) {
		ix=ne(10,60);	iy=ne(7,30);
		size = ne(1,3);

		x = ix;
		for(j=0;j<4;j++) {
			y = iy;
			for(k=0;k<4;k++) {
				chanj(x,y,size,size,100,1111* num(120+j,127+k));
				y=+ size;
			}
			x=+ size;
		}
	}
/*
	printf("\33\14");
*/
	show(36,16,71,31);
}
