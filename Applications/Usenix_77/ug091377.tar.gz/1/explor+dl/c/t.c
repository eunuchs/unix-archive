#
#include "common.h"
main()
{

	register int i,j;

	debug = true;
	for (i=0;i<6;i++) for (j=0;j<6;j++) put (i,j,2);
	for (j=0;j<6;j++) {
		put (0,j,1);
		put (5,j,3);
	}
	show(3,3,5,5);
}
