main()
{
	int j;
	j = factorial(16);
	printf ("j= %d\n",j);
}

factorial(n)
int n;
{
	int i;
	i = 1;
	do {
		i =* n;
	} while (--n);
	return (i);
}
