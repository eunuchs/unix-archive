#
#include "common.h"

/*  random choice from n1 thru n2.  pronounced like any. max range=199 */
ne(n1,n2)
{
	static char fflg;
	register int j,k;
	int itemp,irang;
	static int jump,jdel,iswap,index;
	int min,max,maxok,mult,itry;
	/* we use the fact that vars are guaranteed to be zero */
	if (!fflg) {
/*	initialize table with 0-199, then scramble by exchanges */
		fflg = true;
		jump = 1;
		jdel = 2;
		index = 1;
		iswap = 17;

		for (j=0;j<199;j++)
			IRAN[j] = j;
	
		for (j=0;j<199;j++) {
			itemp = IRAN[j];
			IRAN[j] = IRAN[iswap-1];
			IRAN[iswap-1] = itemp;
			k = j+1;
			iswap = ((iswap + k/2* k + k + 53) % 199) +1;
		}
	}
/*      pick a number */
	if (n1 == n2)
		return(n1);
	min = min0(n1,n2);
	max = max0(n1,n2);
	irang = max-min+1;
	if(irang > 199)irang = 199;
	mult = 199/irang;
	maxok = mult* irang-1;

	while(1) {
		itry = IRAN[index-1];
		index = ((index+jump) % 199)+1;
		jump = (jump+jdel) % 197;
		jdel = (jdel+1)%193;
		if (itry <= maxok)
			break;
	}
	return(min+itry/mult);
}
