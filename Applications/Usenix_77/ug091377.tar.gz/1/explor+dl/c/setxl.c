#
#include "common.h"
/*
* decompose n into digits, set entries in xlit table
* used by chanj and locop
*/
	int lastn 9999;
setxl(n)
int n;
{
	if (n==lastn)
		return;
        lastn = n;

        INTO[0] = (((n/1000) % 10) % 4);
        INTO[1] = (((n/ 100) % 10) % 4);
        INTO[2] = (((n/  10) % 10) % 4);
        INTO[3] = (((n     ) % 10) % 4);
}
