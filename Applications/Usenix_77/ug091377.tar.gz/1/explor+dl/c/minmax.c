min0(i1,i2)
{
	if (i1>i2)
		return(i2);
	return(i1);
}

min04(i1,i2,i3,i4)
{
	return(min0(min0(i1,i2),min0(i3,i4)));
}

max0(i1,i2)
{
	if (i1<i2)
		return(i2);
	return(i1);
}

max04(i1,i2,i3,i4)
{
	return(max0(max0(i1,i2),max0(i3,i4)));
}
