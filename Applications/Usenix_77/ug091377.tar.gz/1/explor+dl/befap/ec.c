int	fout;
char	*jsr	{ "\tjsr\tr5,." };
int	lino;
int	eol	{ 1 };
char	chrbuf[1000];
int	chrbp;
int	strbuf[50];
int	strbp;
int	varbuf[50];
int	varbp;
int	numbuf[50];
int	numbp;
int	num;
int	cho;
int	savec;
int	lp;

main()
{
	char *np;

	fout = dup(1);
	printf("%sinit\n", jsr);

loop:
	np = getc();
	if(alpha(np))
		printf("\tjmp\t_%s\n", name(np));
	if(cho) {
		printf("1:\n");
		cho = 0;
	}
	np = getop();
	if(equal("axl",np)) { axl(); goto loop; }
	if(equal("baxl",np)) { baxl(); goto loop; }
	if(equal("bxl",np)) { bxl(); goto loop; }
	if(equal("caxl",np)) { caxl(); goto loop; }
	if(equal("cxl",np)) { cxl(); goto loop; }
	if(equal("camera",np)) { camera(); goto loop; }
	if(equal("chv",np)) { chv(); goto loop; }
	if(equal("do",np)) { doop(); goto loop; }
	if(equal("goto",np)) goto loop;
	if(equal("if",np)) { xif(); goto loop; }
	if(equal("mode",np)) { mode(); goto loop; }
	if(equal("wbt",np)) { wbt(); goto loop; }
	if(equal("xl",np)) { xl(); goto loop; }
	if(equal("xli",np)) { xli(); goto loop; }
	error();
	goto loop;
}

getc()
{
	register c;

	if(savec) {
		c = savec;
		savec = 0;
		return(c);
	}
	if(eol)
		return('\n');
	c = getchar();
	if(c <= 0)
		cleanup();
	eol = c=='\n';
	return(c);
}

equal(a, b)
char *a, *b;
{

	if(!a || !b)
		return(0);
loop:
	while(*a++ == *b)
		if(*b++ == '\0')
			return(1);
	return(0);
}

error()
{
	register f;

	flush();
	f = fout;
	fout = 2;
	printf("\n..%d\n", lino);
	flush();
	fout = f;
}

getop()
{
	register c, op, f;
	int n1, n2;

loop:
	while((c=getc()) != '\n')
		;
	lino++;
	eol = 0;
	c = getc();
	if(c == '/')
		goto loop;
	if(lp = name(c))
		printf("_%s:\n", lp);
	c = space(getc());
	if(c == '\n')
		goto loop;
	op = name(c);
	c = space(getc());
	if(c != '(')
		return(0);
	if((c=getc()) == 'x') {
		f = -1;
		if(getc() != ',')
			return(0);
		c = getc();
	} else
		f = 1;
	c = number(c);
	if(c!=',')
		return(0);
	n1 = num*f;
	if((c=getc()) == 'x') {
		f = -1;
		if(getc() != ',')
			return(0);
		c = getc();
	} else
		f = 1;
	c = number(c);
	if(c!=')')
		return(0);
	n2 = num*f;
	if(n1!=1 || n2!=1) {
		printf("%schoose; 0; %d.; %d.; 1f\n", jsr, n1, n2);
		cho = 1;
	}
	return(op);
}

cleanup()
{
	register i;

	printf("_done:\n\trts\tr5\n");
	i = 0;
	while(i<strbp) {
		printf("s%d:\t<%s\\0>\n", i, strbuf[i]);
		i++;
	}
	printf(".even\n");
	i = 0;
	while(i<numbp) {
		printf("d%d:\t%d.\n", i, numbuf[i]);
		i++;
	}
	printf(".bss\n");
	i = 0;
	while(i<varbp) {
		printf("v%d:\t.=.+2\n", i);
		i++;
	}
	flush();
	exit();
}

name(c)
{
	register i;

	if(!alpha(c)) {
		savec = c;
		return(0);
	}
	i = chrbp;
	while(alpha(c) || digit(c)) {
		chrbuf[i++] = c;
		c = getc();
	}
	chrbuf[i++] = 0;
	savec = c;
	return(lookup());
}

variab(c) {
	register n, i;

	i = 0;
	if(alpha(c)) {
		n = name(c);
		while(i<varbp)
			if(n == varbuf[i++]) {
				i--;
				goto pv;
			}
		varbuf[varbp++] = n;
	pv:
		printf("v%d", i);
		return(getc());
	}
	c = number(c);
	while(i<numbp)
		if(numbuf[i++] == num) {
			i--;
			goto pd;
		}
	numbuf[numbp++] = num;

pd:
	printf("d%d", i);
	return(c);
}

string(c, n) {
	register i;

	i = chrbp;
	while(alpha(c) || digit(c) || c=='.') {
		chrbuf[i++] = c;
		c = getc();
	}
	chrbuf[i++] = 0;
	savec = c;
	c = lookup();
	if(lp)
		goto as1;
	i = 0;
	while(i<strbp) {
		if(c == strbuf[i])
			goto as2;
		i++;
	}
as1:
	strbuf[i=strbp++] = c;
as2:
	if(lp)
		printf("%s_%d:", lp, n);
	printf("s%d", i);
}

lookup()
{
	register i, j;

	i = 0;
	while(i<chrbp) {
		if(equal(chrbuf+chrbp, chrbuf+i))
			return(chrbuf+i);
		while(chrbuf[i++] != 0)
			;
	}
	while(chrbuf[chrbp++] != 0)
		;
	return(chrbuf+i);
}

space(c)
{

	while(c == '\t' || c == ' ')
		c = getc();
	return(c);
}

alpha(c)
{

	if(c <= 'z' && c >= 'a')
		return(1);
	return(0);
}

digit(c)
{

	if(c <= '9' && c >= '0')
		return(1);
	return(0);
}

number(c)
{

	num = 0;
	while(digit(c)) {
		num = num*10+c-'0';
		c = getc();
	}
	return(c);
}

box()
{

	args("ox", 8);
}

circ() {

	args("rc", 7);
}

args(op, nu)
{
	register c, i;

	c = getc();
	if(alpha(c)) {
		c = name(c);
		printf("%sp%s; _%s", jsr, op, c);
		c = getc();
	} else {
		c = number(c);
		printf("%sb%s; %d.", jsr, op, num);
	}
	if(c != '(')
		goto er;
	i = 0;
	while(i++ < nu) {
		printf("; ");
		c = variab(getc());
		if(c != ',')
			if(i!=nu || c!=')')
				goto er;
	}
	nline();
	return;

er:
	error();
}

xlit()
{

	printf("%sxl", jsr);
	litr();
}

nline()
{

	printf("\n");
}

litr()
{
	register c;

	if(number(getc()) != '(')
		goto er;
	printf("; %d.; ", num);
	string(getc(), 4);
	if(getc() != ')')
		goto er;
	nline();
	return;

er:
	error();
}

axlit()
{

	printf("%saxl; ", jsr);
	string(getc(), 1);
	if(getc() != ',')
		goto er;
	printf("; ");
	string(getc(), 2);
	if(getc() != ',')
		goto er;
	printf("; ");
	string(getc(), 3);
	if(getc() != ',')
		goto er;
	nline();
	xlit();
	return;

er:
	error();
}

whole()
{

	printf("%shox\n", jsr);
}

mod(s0, s1, s2)
{

	if(equal(s0, s1)) {
		printf("\tclr\t.mod%s\n", s1);
		return(1);
	}
	if(equal(s0, s2)) {
		printf("\tmov\tpc,.mod%s\n", s1);
		return(1);
	}
	return(0);
}

axl()
{

	whole();
	axlit();
}

baxl()
{

	box();
	axlit();
}

bxl()
{

	box();
	xlit();
}

caxl()
{

	circ();
	axlit();
}

cxl()
{

	circ();
	xlit();
}

camera()
{

	number(getc());
	printf("%scamera; %d.\n", jsr, num);
}

chv()
{
	register c;

	printf("%schv; ", jsr);
	if(variab(getc())!=',')
		goto er;
	c = name(getc());
	if(getc() != ',')
		goto er;
	if(!(equal(c, "add") ||
		equal(c, "sub") ||
		equal(c, "mpy") ||
		equal(c,"div") ||
		equal(c, "set"))) goto er;
	printf("; .%s; ", c);
	if(variab(getc()) == ',') {
		printf("; ");
		variab(getc());
	} else
		printf("; -1");
	nline();
	return;

er:
	error();
}

doop()
{

	printf("\tjsr\tr5,_%s\n", name(getc()));
	getc();
}

xif()
{
	register c;

	printf("%siff; ", jsr);
	if(getc() != '(')
		goto er;
	if(variab(getc()) != ',')
		goto er;
	printf("; ");
	c = name(getc());
	if(!(equal(c, "ge") ||
		equal(c, "gt") ||
		equal(c, "lt") ||
		equal(c, "le") ||
		equal(c, "eq") ||
		equal(c, "ne"))) goto er;
	if(getc() != ',')
		goto er;
	if(variab(getc()) != ')')
		goto er;
	printf("; .%s; 1f\n", c);
	cho = 1;
	return;

er:
	error();
}

mode()
{
	register c;

	if(getc() != '(')
		goto er;

loop:
	c = name(getc());
	if(mod(c, "wrp", "pln")); else
	if(mod(c, "run", "tst")); else
		goto er;
	c = getc();
	if(c == ')')
		return;
	if(c == ',')
		goto loop;

er:
	error();
}

wbt()
{

	printf("%swbt; ", jsr);
	if(getc() != '(')
		goto er;
	string(getc(), 5);
	if(getc() != ',')
		goto er;
	printf("; ");
	string(getc(), 6);
	if(getc() != ',')
		goto er;
	printf("; ");
	string(getc(), 7);
	if(getc() != ')')
			goto er;
	nline();
	return;

er:
	error();
}

xl()
{

	printf("%shox\n", jsr);
	xlit();
}

xli()
{
	register n1, n2, n;

	n1 = name(getc());
	if(getc() != ',')
		goto er;
	n2 = name(getc());
	if(getc() != ',')
		goto er;
	if(equal("nums", n2)) n = 1; else
	if(equal("dirs", n2)) n = 2; else
	if(equal("chst", n2)) n = 3; else
	if(equal("xlit", n2)) n = 4; else
	if(equal("whts", n2)) n = 5; else
	if(equal("blks", n2)) n = 6; else
	if(equal("twks", n2)) n = 7; else
	if(equal("tpls", n2)) n = 8; else
		goto er;
	printf("%sxli; %s_%d", jsr, n1, n);
	litr();
	return;

er:
	error();
}
