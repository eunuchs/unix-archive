#
#define nperw   19
#define nperl  133
#define nplp1  134
#define nplm1  132
#define nperl2 266
#define nperl3 399
#define nperb  532
#define maxary 2527
c
c	as supplied, nperl = 140.  thus nperw = 20 and nperb = 560
c	the whole array is then 2800.
c	the working array is nperl x nperl values.
c	2-bit values are packed 7 per word, so that
c	maxary = nperl * nperl / 7
c	the working line is 4 * nperl long = nperb
c	nplp1 and nplm1 are nperl+1 and nperl-1 for neighbors
c
c	the common block nocr is to  enable the printing of lines
c	without cr and lf
c	this seems to overlap the explor common, so that
c	an 8-byte dummy spacer is put in to prevent problems
c
	   common /nocr/ nocr,dumy99,dummy98
	   integer*2 nocr,dumy99
	   integer dummy98
           common /explor/ dumy8,line(maxary),iran(199),nm(nperb),into(4)
	   real*8 dumy8
