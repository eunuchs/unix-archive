c
      block data
c variables in "qommon":
      common /qommon/ chars,mach2k,k2mach,pictx,picty,picher,buf1,
     c   ranseq,rancnt,
     c   eratio,ldist,rdist,bdist,tdist,maxmsg,wider,higher,prober,
     c   frames,frame1,frame2,frame3,frame4,frscop,frintr,frcard,
     c   prctrl,caller
c
c number of distinct characters = 1 + max. numeric value of any
c character
      integer chars/256/
c system transliteration tables from machine representation (ebcdic,
c ascii, etc.) to knowltonian and from knowltonian to machine
c representation; must be changed for every machine ********************
      logical*1 mach2k(256), k2mach(256)
c picture dimensions
      integer pictx/320/, picty/240/
c picture array
      logical*1 picher(320,240)
c buffer length should = max(pictx,picty,132)
      logical*1 buf1(352)
c random number table
      integer ranseq(192)/
     c 393,262,382,139,031,145,261,248,205,301,384,266,149,132,198,093,
     c 334,188,258,311,210,030,171,080,116,222,118,043,203,048,269,057,
     c 396,255,021,297,156,099,026,357,354,283,363,040,296,163,272,274,
     c 233,364,336,236,047,114,360,320,369,293,270,039,265,330,304,278,
     c 168,029,007,350,287,338,263,028,368,131,282,335,142,153,134,074,
     c 019,349,341,104,281,356,034,011,088,340,259,214,290,013,152,103,
     c 143,388,264,073,377,086,372,329,204,002,023,232,008,033,326,398,
     c 230,037,218,245,260,343,294,392,129,038,096,333,113,347,127,322,
     c 345,181,121,138,077,161,169,082,355,049,010,220,124,020,298,102,
     c 215,213,280,337,070,348,373,239,376,151,106,284,238,119,180,323,
     c 279,325,381,107,183,224,100,196,209,383,374,228,231,036,054,062,
     c 187,189,295,331,252,092,353,085,115,285,001,385,061,174,327,141/
      integer rancnt (209) /
     c 068,275,155,202,253,199,328,303,351,243,083,273,289,310,216,051,
     c 165,128,137,194,078,097,162,321,302,184,346,012,105,069,178,148,
     c 022,208,089,144,250,292,084,056,400,317,087,173,379,154,120,366,
     c 234,044,362,319,185,101,076,140,277,227,370,071,112,315,063,053,
     c 305,006,390,066,058,158,387,226,386,339,176,065,251,035,003,276,
     c 267,095,157,367,375,133,179,395,055,111,025,016,246,166,288,237,
     c 170,150,197,090,316,212,126,177,050,042,024,091,286,098,190,172,
     c 299,015,136,060,117,160,081,399,254,110,041,192,159,175,332,130,
     c 195,052,361,244,193,109,240,358,389,365,009,352,167,211,207,123,
     c 046,324,313,312,314,318,291,268,079,223,067,125,257,094,191,017,
     c 005,206,306,027,394,135,221,229,164,108,241,300,072,378,182,249,
     c 235,371,242,014,256,147,271,146,344,075,342,018,219,059,307,032,
     c 186,200,397,247,217,201,380,064,308,391,309,359,004,045,225,000,
     c 122/
c if an error message previously was produced when the user tried to
c operate on a square at distance d outside the picture, the next error
c message should be sent when he tries to operate at distance eratio*d
c outside the picture.
      integer eratio/4/
c distances outside the picture which last caused error messages
      integer ldist/0/, rdist/0/, bdist/0/, tdist/0/
c maxmsg = max. number of consecutive error messages produced on
c consecutive calls to a subroutine, where all the calls have the same
c error in specifying a parameter.  a different mechanism is used for
c messages caused by the error of trying to operate on a square outside
c the picture.
      integer maxmsg/3/
c counts of consecutive error messages for illegal parameters
      integer wider/1/, higher/1/, prober/1/
c frame counter
      integer frames/0/
c copies of the actual parameters to the most recent call of subroutine
c "frame"
      logical frame1,frame2
      integer frame3,frame4
c switches indicate whether the current frame identification has been
c written to the various display devices; initialized to .true. so users
c will not see a garbage identification displayed if they choose never
c to call subroutine "frame".
      logical frscop/.true./, frintr/.true./, frcard/.true./
c carriage control character for the next write to unit "printr"
      logical*1 prctrl/'1'/
c name of the subroutine calling function "qadj"
      logical*1 caller(6)
c
c
c
c variables in "com1":
      common /com1/ d0,d1,d2,d3,d4,d5,d6,d7,d8,d9
      common /com1/ la,lb,lc,ld,le,lf,lg,lh,li,lj,lk,ll,lm,ln,lo,lp,lq,
     c   lr,ls,lt,lu,lv,lw,lx,ly,lz
      common /com1/ blank,period,lparen,plus,dollar,aster,rparen,minus,
     c   slash,comma,under,equal,quote,less,bar,and,semi,not,prcent,
     c   grater,questn,colon,pound,at,apost
      common /com1/ self,west,east,south,north,swest,nwest,seast,neast,
     c   horiz,vert,aigu,grave,rook,bishop,king
      common /com1/ system,scope,ttyo,ttyi,ptapei,cardi,printr,cardo,
     c   camrao,camrai,fmts
      common /com1/ ttwide,lastin,income,fmtbuf
c
c names of digits, letters, and special characters
      integer d0/0/,d1/1/,d2/2/,d3/3/,d4/4/,d5/5/,d6/6/,d7/7/,d8/8/,
     c   d9/9/
      integer la/10/,lb/11/,lc/12/,ld/13/,le/14/,lf/15/,lg/16/,lh/17/,
     c   li/18/,lj/19/,lk/20/,ll/21/,lm/22/,ln/23/,lo/24/,lp/25/,lq/26/,
     c   lr/27/,ls/28/,lt/29/,lu/30/,lv/31/,lw/32/,lx/33/,ly/34/,lz/35/
      integer blank/36/,period/37/,lparen/38/,plus/39/,dollar/40/,
     c   aster/41/,rparen/42/,minus/43/,slash/44/,comma/45/,under/46/,
     c   equal/47/,quote/48/,less/49/,bar/50/,and/51/,semi/52/,not/53/,
     c   prcent/54/,grater/55/,questn/56/,colon/57/,pound/58/,at/59/,
     c   apost/60/
c names of commonly used neighborhood directions
      integer self/020/, west/040/, east/010/, south/002/,north/200/,
     c   swest/004/, nwest/400/, seast/001/, neast/100/, horiz/070/,
     c   vert/222/, aigu/421/, grave/124/, rook/272/, bishop/525/,
     c   king/777/
c i/o unit assignments
      integer system/0/, scope/1/, ttyo/2/, ttyi/3/, ptapei/4/,
     c   cardi/5/, printr/6/, cardo/7/, camrao/8/, camrai/9/, fmts/10/
c carriage width on teletype
      integer ttwide/72/
c number of the last filled column of the teletype input buffer;
c lastin=0 means an empty line was typed
      integer lastin
c buffer for teletype input
      logical*1 income(72)
c buffer for format specifications read from file "fmts"; 2 card images
      logical*1 fmtbuf(160)
      end
