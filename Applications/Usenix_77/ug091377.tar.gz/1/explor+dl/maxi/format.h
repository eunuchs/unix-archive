(' history h, continue exec c, stop w/o dump s, or stop w/ dump d? ')  1
(' ', 6a1, ': width err')  2
(' ', 6a1, ': rectangle left of picture by ', i11)  3
(' ', 6a1, ': rectangle right of picture by ', i11)  4
(' ', 6a1, ': rectangle below picture by ', i11)  5
(' ', 6a1, ': rectangle above picture by ', i11)  6
(' ', 6a1, ': probability err')  7
(' you called: cheker(', 6(i11, ','), i11, ')')  8
(' frame ', i6, ': ', 2(a4, ' '), i11, ' begins here')  9
(' frame ',i6,' = ',i2,' (mod ',i2,'): ',2(a4,' '),i11,' begins here')  10
(' print', i1, ': width err')  11
(' print', i1, ': height err')  12
(' ', 6a1, ': height err')  13
(' print', i1, ': rectangle left of picture by ', i11)  14
(' print', i1, ': rectangle right of picture by ', i11)  15
(' print', i1, ': rectangle below picture by ', i11)  16
(' print', i1, ': rectangle above picture by ', i11)  17
(' you called: print3(', 4(i11, ','), 't#1,t#2,t#3)')  18
(' you called: print2(', 4(i11, ','), 't#1,t#2)')  19
(' you called: print1(', 4(i11, ','), 't#1)')  20
(' you called: print0(', 3(i11, ','), i11, ')')  21
******************* bad cards deleted here **************
************************** 13 cards deleted *******************
(' watzin(', i11, ',', i11, '); x outside by ', i11)  30
(' watzin(', i11, ',', i11, '); y outside by ', i11)  31
(' cardin: width err; cards may be read but no storage')  32
(' cardin: width > card width; no copy into rightmost cols')  33
(' cardin: rectangle outside picture; cards may be read but no storage')  34
(' cardin: rectangle left of picture; no copy from leftmost card cols')  35
(' cardin: rectangle right of picture; no copy from rightmost card cols')  36
(' cardin: height err; no cards can be read')  37
(' cardin: rectangle below picture; last cards read & ignored')  38
(' cardin: rectangle above picture; first cards read & ignored')  39
(' you called: cardin(', 4(i11, ','), i11, ')')  40
(' cardin: too few data cards')  41
(' stash(', i11, ',', i11, '); x outside by ', i11)  42
(' stash(', i11, ',', i11, '); y outside by ', i11)  43
(' print', i1, ': only leftmost 132 cols within picture can be printed')  44
(' xlitr8: entry ', i3, ' in table is not a char')  45
(' print', i1, ': entry ', i3, ' in table1 is not a char')  46
(' print', i1, ': entry ', i3, ' in table2 is not a char')  47
(' print3: entry ', i3, ' in table3 is not a char')  48
(' you called: qgenr8(', 4(i11, ','), 'your_subrtn)')  49
(' fleck: err in fleck values; min<0, max<0, min>max, or max>', i3)  50
(' addmod: modulus < 2 or > ', i3)  51
(' you called: addmod(', 6(i11, ','), i11, ')')  52
(' you called: fleck(', 6(i11, ','), i11, ')')  53
(' locop: direction err')  54
(' locop: min # of neighbors > max # (in absolute value)')  55
(' locop: min # of neighbors > possible # (in absolute value)')  56
(' locop: max # of neighbors > possible # (in absolute value)')  57
(' locop: max # of neighbors .ge. possible # (in absolute value)')  58
(' locop: lower bound of interval > upper bound (in absolute value)')  59
(' you called: xlitr8(', 5(i11, ','), 'xlit_table)')  60
(' a big "howdy" from ucsc graphic2 system, revised 4/11/72 18:00')  61
(' nowat: 1st param < 1 or > 50')  62
(' you called: nowat(', 4(i11, ','), i11, ')')  63
(' id  consec   total    call      value      value      value      value'/
 '  #   calls   calls  number   number 1   number 2   number 3   number 4')64&65
(' ', 70(1h*))  66
(' ', i2, 3i8, 4i11/ 19(1h ), i8, 4i11)  67
(' you called: census(', 3(i11, ','), i11, ')')  68
(' punch', i1, ': rectangle below picture; fewer than "height" cards punched')69
(' punch', i1, ': width err; no cards punched')  70
(' punch', i1, ': height err; no cards punched')  71
(' punch', i1, ': rectangle left of picture; no punch in leftmost card cols') 72
(' punch',i1,': rectangle right of picture; no punch in rightmost card cols') 73
(' punch', i1, ': rectangle above picture; fewer than "height" cards punched')74
(' punch', i1, ': only leftmost 80 cols of rectangle can be punched')  75
(' you called: punch1(', 4(i11, ','), 't#1)')  76
(' you called: punch0(', 3(i11, ','), i11, ')')  77
(' random: range > 401')  78
(' punch1: entry ', i3, ' in table is not a char')  79
(' locop: lower bound of interval > ', i3, ' (in absolute value)')  80
(' locop: upper bound of interval > ', i3, ' (in absolute value)')  81
(' locop: upper bound of interval .ge. ', i3, ' (in absolute value)')  82
(' you called: locop(', 5(i11, ',')/ 13x, 5(i11, ','), 'xlit_table)')  83
(' locop: entry ', i3, ' in table is not a char')  84
(' copy: orientation err')  85
(' you called: copy(', 5(i11, ',')/ 13x, 5(i11, ','), i11, ')')  86
** last 2 cards; include enough cards to completely fill the block which
** contains the highest numbered format specification **************************
c                 conventions for graphics package
c questions concerning this code should be addressed to:
c dan ross or ken knowlton
c information and computer sciences dept.
c univ. of calif.
c santa cruz, calif.  95060
c revision date and time appear on format card number 61
c
c names:
c all names of system subroutines, variables, etc. which users can
c access, but ordinarily should not access, begin with the letter "q".
c users should avoid creating any name starting with "q", to prevent
c naming conflicts.
c
c error checking and error messages:
c subroutines whose names do not begin with "q" are callable by the
c users.  these subroutines must assume that there can be errors in
c their input parameters.  they must check their parameters, producing
c error messages as appropriate.  they must not pass on erroneous
c parameters in the calls of other subroutines.
c subroutines whose names begin with "q" are not callable by the users.
c these subroutines may assume that all their input parameters are
c correct.
c
c device assignment:
c all references to devices should be made by name rather than by
c number.  device names are assigned in the common area named "com1".
c system (unit 0):  output messages to the computer operator, to the
c    system log, to other conversational users, etc., as specified by an
c    explicit or implicit destination in the text of the message.  no
c    carriage control.
c scope (unit 1):  output display to a storage scope or equivalent
c    device.  pertinent characteristics are:  high speed; point plotting
c    capability on a raster, with one complete horizontal line produced
c    by each "write" statement; no erasure until the entire frame is
c    advanced; possibly no vector generator; possibly no gray scale;
c    possibly no character generator; no carriage control.
c ttyo (unit 2):  output to the user's typewriter-like terminal device.
c    pertinent characteristics are:  cannot operate simultaneously with
c    input from "ttyi"; low speed; hard copy; typeout interruptable by
c    the user; possibly only 72 columns per output line; possibly
c    inoperative tab, backspace, and page eject; asa carriage control
c    characters, modified as follows:
c       blank   print, then carriage return and 1 line upspace
c       0       print, then carriage return and 2 lines upspace
c       1       print, then carriage return and eject to top of next
c                  page
c       +       print, then carriage return only, no upspace
c       .       print only, no carriage return or upspace
c ttyi (unit 3):  input from the user's typewriter-like terminal device.
c    pertinent characteristics are:  cannot operate simultaneously with
c    output to "ttyo", except to send an interrupt which forces early
c    termination of output to "ttyo"; low speed; hard copy; possibly
c    inoperative tab, backspace, and page eject; possibly only full-line
c    interaction capability (instead of single character interaction),
c    so input must be terminated by eom interrupt or carriage return.
c ptapei (unit 4):  input from paper tape reader or equivalent device.
c    pertinent characteristics are:  low speed; continuous text string;
c    alphanumeric or binary; non-reversible; stoppable by program at any
c    character; no carriage control.
c cardi (unit 5):  input from card reader or equivalent device.
c    pertinent characteristics are:  high speed; non-conversational;
c    80 alphanumeric characters produced by each "read" statement;
c    non-reversible; no carriage control.
c printr (unit 6):  output to line printer or equivalent device.
c    pertinent characteristics are:  high speed; non-conversational;
c    one complete horizontal line produced by each "write" statement;
c    alphanumeric characters; no more than 132 columns per line;
c    non-reversible; asa carriage control characters, namely:
c       blank   upspace 1 line, then print
c       0       upspace 2 lines, then print
c       -       upspace 3 lines, then print
c       1       eject to top of next page, then print
c       +       print only, no upspace
c cardo (unit 7):  output to card punch or equivalent device.
c    pertinent characteristics are:  high speed; non-conversational;
c    machine readable; 80 alphanumeric characters produced by each
c    "write" statement; non-reversible; no carriage control.
c camrao (unit 8):  output to camera.  device-dependent characteristics.
c camrai (unit 9):  input from camera.  device-dependent
c    characteristics.
c fmts (unit 10):  format specifications stored in a file of 80-column
c    card images, 1 format per card image.
c (units 11 to 19):  reserved for later system use.
c (units 20 to 99):  available to users.
c
