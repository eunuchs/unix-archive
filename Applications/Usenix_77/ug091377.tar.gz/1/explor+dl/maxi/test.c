 scratch dsname=ics160.fmts,purge,vol=2311=111111;
 scratch dsname=ics160.loadmod,purge,vol=2311=111111;
(' history h, continue exec c, stop w/o dump s, or stop w/ dump d? ')  1
(' ', 6a1, ': width err')  2
(' ', 6a1, ': rectangle left of picture by ', i11)  3
(' ', 6a1, ': rectangle right of picture by ', i11)  4
(' ', 6a1, ': rectangle below picture by ', i11)  5
(' ', 6a1, ': rectangle above picture by ', i11)  6
(' ', 6a1, ': probability err')  7
(' you ed: cheker(', 6(i11, ','), i11, ')')  8;
(' frame ', i6, ': ', 2(a4, ' '), i11, ' begins here')  9
(' frame ',i6,' = ',i2,' (mod ',i2,'): ',2(a4,' '),i11,' begins here')  10;
(' print', i1, ': width err')  11
(' print', i1, ': height err')  12
(' ', 6a1, ': height err')  13
(' print', i1, ': rectangle left of picture by ', i11)  14
(' print', i1, ': rectangle right of picture by ', i11)  15
(' print', i1, ': rectangle below picture by ', i11)  16
(' print', i1, ': rectangle above picture by ', i11)  17
(' you ed: print3(', 4(i11, ','), 't#1,t#2,t#3)')  18;
(' you ed: print2(', 4(i11, ','), 't#1,t#2)')  19;
(' you ed: print1(', 4(i11, ','), 't#1)')  20;
(' you ed: print0(', 3(i11, ','), i11, ')')  21;
* * * * * * * * * * * * * * * * * * *  bad cards deleted here * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * *  13 cards deleted * * * * * * * * * * * * * * * * * * * 
(' watzin(', i11, ',', i11, '); x outside by ', i11)  30
(' watzin(', i11, ',', i11, '); y outside by ', i11)  31
(' cardin: width err; cards may be read but no storage')  32
(' cardin: width > card width; no copy into rightmost cols')  33
(' cardin: rectangle outside picture; cards may be read but no storage')  34
(' cardin: rectangle left of picture; no copy from leftmost card cols')  35
(' cardin: rectangle right of picture; no copy from rightmost card cols')  36
(' cardin: height err; no cards can be read')  37
(' cardin: rectangle below picture; last cards read & ignored')  38
(' cardin: rectangle above picture; first cards read & ignored')  39
(' you ed: cardin(', 4(i11, ','), i11, ')')  40;
(' cardin: too few data cards')  41
(' stash(', i11, ',', i11, '); x outside by ', i11)  42
(' stash(', i11, ',', i11, '); y outside by ', i11)  43
(' print', i1, ': only leftmost 132 cols within picture can be printed')  44
(' xlitr8: entry ', i3, ' in table is not a char')  45
(' print', i1, ': entry ', i3, ' in table1 is not a char')  46
(' print', i1, ': entry ', i3, ' in table2 is not a char')  47
(' print3: entry ', i3, ' in table3 is not a char')  48
(' you ed: qgenr8(', 4(i11, ','), 'your_subrtn)')  49;
(' fleck: err in fleck values; min<0, max<0, min>max, or max>', i3)  50
(' addmod: modulus < 2 or > ', i3)  51
(' you ed: addmod(', 6(i11, ','), i11, ')')  52;
(' you ed: fleck(', 6(i11, ','), i11, ')')  53;
(' locop: direction err')  54
(' locop: min # of neighbors > max # (in absolute value)')  55
(' locop: min # of neighbors > possible # (in absolute value)')  56
(' locop: max # of neighbors > possible # (in absolute value)')  57
(' locop: max # of neighbors  >=  possible # (in absolute value)')  58
(' locop: lower bound of interval > upper bound (in absolute value)')  59
(' you ed: xlitr8(', 5(i11, ','), 'xlit_table)')  60;
(' a big "howdy" from ucsc graphic2 system, revised 4/11/72 18:00')  61
(' nowat: 1st param < 1 or > 50')  62
(' you ed: nowat(', 4(i11, ','), i11, ')')  63;
(' id  consec   total          value      value      value      value'/;
 '  #   s   calls  number   number 1   number 2   number 3   number 4')64&65;
(' ', 70(1h* ))  66
(' ', i2, 3i8, 4i11/ 19(1h ), i8, 4i11)  67
(' you ed: census(', 3(i11, ','), i11, ')')  68;
(' punch', i1, ': rectangle below picture; fewer than "height" cards punched')69
(' punch', i1, ': width err; no cards punched')  70
(' punch', i1, ': height err; no cards punched')  71
(' punch', i1, ': rectangle left of picture; no punch in leftmost card cols') 72
(' punch',i1,': rectangle right of picture; no punch in rightmost card cols') 73
(' punch', i1, ': rectangle above picture; fewer than "height" cards punched')74
(' punch', i1, ': only leftmost 80 cols of rectangle can be punched')  75
(' you ed: punch1(', 4(i11, ','), 't#1)')  76;
(' you ed: punch0(', 3(i11, ','), i11, ')')  77;
(' random: range > 401')  78
(' punch1: entry ', i3, ' in table is not a char')  79
(' locop: lower bound of interval > ', i3, ' (in absolute value)')  80
(' locop: upper bound of interval > ', i3, ' (in absolute value)')  81
(' locop: upper bound of interval  >=  ', i3, ' (in absolute value)')  82
(' you ed: locop(', 5(i11, ',')/ 13x, 5(i11, ','), 'xlit_table)')  83;
(' locop: entry ', i3, ' in table is not a char')  84
(' copy: orientation err')  85
(' you ed: copy(', 5(i11, ',')/ 13x, 5(i11, ','), i11, ')')  86;
* *  last 2 cards; include enough cards to completely fill the block which
* *  contains the highest numbered format specification * * * * * * * * * * * * * * * * * * * * * * * * * * 
/*                  conventions for graphics package */
/*  */
/*  */
/*  */
/*  questions concerning this code should be addressed to: */
/*  dan ross or ken knowlton */
/*  information and computer sciences dept. */
/*  univ. of calif. */
/*  santa cruz, calif.  95060 */
/*  revision date and time appear on format card number 61 */
/*  */
/*  names: */
/*  all names of system subroutines, variables, etc. which users can */
/*  access, but ordinarily should not access, begin with the letter "q". */
/*  users should avoid creating any name starting with "q", to prevent */
/*  naming conflicts. */
/*  */
/*  error checking and error messages: */
/*  subroutines whose names do not begin with "q" are able by the */;
/*  users.  these subroutines must assume that there can be errors in */
/*  their input parameters.  they must check their parameters, producing */
/*  error messages as appropriate.  they must not pass on erroneous */
/*  parameters in the s of other subroutines. */;
/*  subroutines whose names begin with "q" are not able by the users. */;
/*  these subroutines may assume that all their input parameters are */
/*  correct. */
/*  */
/*  device assignment: */
/*  all references to devices should be made by name rather than by */
/*  number.  device names are assigned in the common area named "com1". */
/*  system (unit 0):  output messages to the computer operator, to the */
/*     system log, to other conversational users, etc., as specified by an */
/*     explicit or implicit destination in the text of the message.  no */
/*     carriage control. */
/*  scope (unit 1):  output display to a storage scope or equivalent */
/*     device.  pertinent characteristics are:  high speed; point plotting */
/*     capability on a raster, with one complete horizontal line produced */
/*     by each "write" statement; no erasure until the entire frame is */
/*     advanced; possibly no vector generator; possibly no gray scale; */
/*     possibly no character generator; no carriage control. */
/*  ttyo (unit 2):  output to the user's typewriter-like terminal device. */
/*     pertinent characteristics are:  cannot operate simultaneously with */
/*     input from "ttyi"; low speed; hard copy; typeout interruptable by */
/*     the user; possibly only 72 columns per output line; possibly */
/*     inoperative tab, backspace, and page eject; asa carriage control */
/*     characters, modified as follows: */
/*        blank   print, then carriage return; and 1 line upspace */
/*        0       print, then carriage return; and 2 lines upspace */
/*        1       print, then carriage return; and eject to top of next */
/*                   page */
/*        +       print, then carriage return; only, no upspace */
/*        .       print only, no carriage return; or upspace */
/*  ttyi (unit 3):  input from the user's typewriter-like terminal device. */
/*     pertinent characteristics are:  cannot operate simultaneously with */
/*     output to "ttyo", except to send an interrupt which forces early */
/*     termination of output to "ttyo"; low speed; hard copy; possibly */
/*     inoperative tab, backspace, and page eject; possibly only full-line */
/*     interaction capability (instead of single character interaction), */
/*     so input must be terminated by eom interrupt or carriage return;. */
/*  ptapei (unit 4):  input from paper tape reader or equivalent device. */
/*     pertinent characteristics are:  low speed; continuous text string; */
/*     alphanumeric or binary; non-reversible; stoppable by program at any */
/*     character; no carriage control. */
/*  cardi (unit 5):  input from card reader or equivalent device. */
/*     pertinent characteristics are:  high speed; non-conversational; */
/*     80 alphanumeric characters produced by each "read" statement; */
/*     non-reversible; no carriage control. */
/*  printr (unit 6):  output to line printer or equivalent device. */
/*     pertinent characteristics are:  high speed; non-conversational; */
/*     one complete horizontal line produced by each "write" statement; */
/*     alphanumeric characters; no more than 132 columns per line; */
/*     non-reversible; asa carriage control characters, namely: */
/*        blank   upspace 1 line, then print */
/*        0       upspace 2 lines, then print */
/*        -       upspace 3 lines, then print */
/*        1       eject to top of next page, then print */
/*        +       print only, no upspace */
/*  cardo (unit 7):  output to card punch or equivalent device. */
/*     pertinent characteristics are:  high speed; non-conversational; */
/*     machine readable; 80 alphanumeric characters produced by each */
/*     "write" statement; non-reversible; no carriage control. */
/*  camrao (unit 8):  output to camera.  device-dependent characteristics. */
/*  camrai (unit 9):  input from camera.  device-dependent */
/*     characteristics. */
/*  fmts (unit 10):  format specifications stored in a file of 80-column */
/*     card images, 1 format per card image. */
/*  (units 11 to 19):  reserved for later system use. */
/*  (units 20 to 99):  available to users. */
/*  */
/*  common areas: */
/*  the system recognizes 2 named common areas.  "qommon" is for the */
/*  private use of the system.  "com1" contains system variables which */
/*  users may access.  the system initializes both these areas in a "block */
/*  data" subroutine.  users should not attempt to assign any new */
/*  variables in "com1".  users may create other named or unnamed common */
/*  areas, as desired. */
/*  */
/*  rectangles defined by subroutine parameters: */
/*  many of the system subroutines operate on a rectangle specified by 4 */
/*  input parameters:  x and y coordinates of the center square, the */
/*  width, and the height.  if either width or height or both are even */
/*  numbers, there is no single square located at the center of the */
/*  rectangle.  in this case, the user should supply an x or y coordinate */
/*  of the square just to the left or just below the true center of the */
/*  rectangle. */
/*  */
/*  neighborhood of a square: */
/*  the neighbors of a square consist of the square itself and all squares */
/*  accessible by a chess king's move, including squares outside the */
/*  picture.  no characters ever are stored into squares outside the */
/*  picture.  when accessed, squares outside the picture are assumed to */
/*  have character value = -1.  directions relative to the square under */;
/*  consideration are transmitted as 3 binary-coded decimal (bcd) digits. */
/*  the first digit is for the row above the center square, the second */
/*  digit is for the row containing the center square, and the third digit */
/*  is for the row below the center square.  each bcd digit in turn is */
/*  formed from 3 binary digits, where a "1" means inclusion of the */
/*  direction and a "0" means exclusion of the direction.  for example, to */
/*  encode the pair of directions "northwest" and "southeast", the */
/*  representation is: */
/*      binary 100  =  4 octal */;
/*             000  =  0 */;
/*             001  =  1 */;
/*  and the bcd number representing this set of directions is (decimal) */
/*  401.  names of commonly used neighborhood direction sets have been */
/*  assigned in common area "com1".  users not wishing to remember this */
/*  encoding scheme may perform arithmetic using the named direction sets. */
/*  caution:  do not add in any one direction twice, or subtract a */
/*  direction from a set which does not include the direction.  example: */
/*  direction "king" = direction "rook" + direction "bishop" - direction */;
/*  "self". */
/*  */
/*  array storage: */
/*  it is assumed throughout this code that elements of 2-dimensional */
/*  arrays are stored row-wise.  as an illustrative example, */
/*         dimension array(2,2) */
/*  would cause consecutive storage of array(1,1), array(1,2), array(2,1), */
/*  and array(2,2).  if this assumption is false, major recoding of nearly */
/*  all subroutines becomes necessary. */
/*  */
/*  conversations with users: */
/*  in order to conserve core memory space, the format specifications are */
/*  stored on disk for all output typed to the user.  prior to each */
/*  "write" statement directed to the teletype, the program must  */;
/*  subroutine "getfmt" to read in the proper format specifications from */
/*  the disk.  the program then may write to the user with: */
/*         write (ttyo,fmtbuf) <output list> */
/*  subroutine "getfmt" includes a detailed description of the use of */
/*  format specifications. */
/*  users may type input either as a solicited response to a request from */
/*  the program, or as an unsolicited message.  these two types of input */
/*  must be handled differently. */
/*  a user response is solicited as part of typing out the request */
/*  message, by setting parameter "reply" to true in a  of */;
/*  subroutine "getfmt".  the next executed "write" to the teletype will */
/*  not return; control until the user's response is stored in the teletype */
/*  input buffer "income".  the program should scan the user's response. */
/*  if the response can be understood by the program, even though the */
/*  response might contain errors, the program should process the */
/*  response, typing out error messages and requesting other responses as */
/*  necessary.  only if the response is totally incomprehensible, to the */
/*  extent that it looks like the response was not directed to the program */
/*  at all, should the program  subroutine "huh".  subroutine "huh" */;
/*  never return;s control, but passes the user's response on to other */
/*  programs in the system, to see if they can understand it.  after */
/*  ing "huh", the program should pause and wait for an unsolicited */;
/*  message. */
/*  unsolicited messages first are scanned by the graphics system program. */
/*  if the graphics system program cannot understand the message, it will */
/*   a user's subroutine named "ring".  each user's program must */;
/*  include a subroutine "ring".  if "ring" can understand the message, */
/*  it should process the message and return; control normally.  if "ring" */
/*  cannot understand the message, it should return; control by ing */;
/*  subroutine "notme".  the simplest version of subroutine "ring" would */
/*  be an immediate  of "notme".  warning:  "ring" and any */;
/*  subroutines it s to process a message are executed asynchronously */;
/*  from the remainder of the program.  fortran code is not reentrant. */
/*  extreme caution is required in coding subroutine "ring". */
/*  */
/*  */
/*  */
      block data
/*  variables in "qommon": */
      common /qommon/ chars,mach2k,k2mach,pictx,picty,picher,buf1,
     c   ranseq,rancnt,
     c   eratio,ldist,rdist,bdist,tdist,maxmsg,wider,higher,prober,
     c   frames,frame1,frame2,frame3,frame4,frscop,frintr,frcard,
     c   prctrl,er;
/*  */
/*  number of distinct characters = 1 + max. numeric value of any */;
/*  character */
      integer chars/256/
/*  system transliteration tables from machine representation (ebcdic, */
/*  ascii, etc.) to knowltonian and from knowltonian to machine */
/*  representation; must be changed for every machine * * * * * * * * * * * * * * * * * * * *  */
      logical* 1 mach2k(256), k2mach(256)
/*  picture dimensions */
      integer pictx/320/, picty/240/
/*  picture array */
      logical* 1 picher(320,240)
/*  buffer length should = max(pictx,picty,132) */;
      logical* 1 buf1(352)
/*  random number table */
      integer ranseq(192)/
     c 393,262,382,139,031,145,261,248,205,301,384,266,149,132,198,093,
     c 334,188,258,311,210,030,171,080,116,222,118,043,203,048,269,057,
     c 396,255,021,297,156,099,026,357,354,283,363,040,296,163,272,274,
     c 233,364,336,236,047,114,360,320,369,293,270,039,265,330,304,278,
     c 168,029,007,350,287,338,263,028,368,131,282,335,142,153,134,074,
     c 019,349,341,104,281,356,034,011,088,340,259,214,290,013,152,103,
     c 143,388,264,073,377,086,372,329,204,002,023,232,008,033,326,398,
     c 230,037,218,245,260,343,294,392,129,038,096,333,113,347,127,322,
     c 345,181,121,138,077,161,169,082,355,049,010,220,124,020,298,102,
     c 215,213,280,337,070,348,373,239,376,151,106,284,238,119,180,323,
     c 279,325,381,107,183,224,100,196,209,383,374,228,231,036,054,062,
     c 187,189,295,331,252,092,353,085,115,285,001,385,061,174,327,141/
      integer rancnt (209) /
     c 068,275,155,202,253,199,328,303,351,243,083,273,289,310,216,051,
     c 165,128,137,194,078,097,162,321,302,184,346,012,105,069,178,148,
     c 022,208,089,144,250,292,084,056,400,317,087,173,379,154,120,366,
     c 234,044,362,319,185,101,076,140,277,227,370,071,112,315,063,053,
     c 305,006,390,066,058,158,387,226,386,339,176,065,251,035,003,276,
     c 267,095,157,367,375,133,179,395,055,111,025,016,246,166,288,237,
     c 170,150,197,090,316,212,126,177,050,042,024,091,286,098,190,172,
     c 299,015,136,060,117,160,081,399,254,110,041,192,159,175,332,130,
     c 195,052,361,244,193,109,240,358,389,365,009,352,167,211,207,123,
     c 046,324,313,312,314,318,291,268,079,223,067,125,257,094,191,017,
     c 005,206,306,027,394,135,221,229,164,108,241,300,072,378,182,249,
     c 235,371,242,014,256,147,271,146,344,075,342,018,219,059,307,032,
     c 186,200,397,247,217,201,380,064,308,391,309,359,004,045,225,000,
     c 122/
/*  if an error message previously was produced when the user tried to */
/*  operate on a square at distance d outside the picture, the next error */
/*  message should be sent when he tries to operate at distance eratio* d */
/*  outside the picture. */
      integer eratio/4/
/*  distances outside the picture which last caused error messages */
      integer ldist/0/, rdist/0/, bdist/0/, tdist/0/
/*  maxmsg = max. number of consecutive error messages produced on */;
/*  consecutive s to a subroutine, where all the calls have the same */;
/*  error in specifying a parameter.  a different mechanism is used for */
/*  messages caused by the error of trying to operate on a square outside */
/*  the picture. */
      integer maxmsg/3/
/*  counts of consecutive error messages for illegal parameters */
      integer wider/1/, higher/1/, prober/1/
/*  frame counter */
      integer frames/0/
/*  copies of the actual parameters to the most recent  of subroutine */;
/*  "frame" */
      logical frame1,frame2
      integer frame3,frame4
/*  switches indicate whether the current frame identification has been */
/*  written to the various display devices; initialized to true so users */
/*  will not see a garbage identification displayed if they choose never */
/*  to  subroutine "frame". */;
      logical frscop/true/, frintr/true/, frcard/true/
/*  carriage control character for the next write to unit "printr" */
      logical* 1 prctrl/'1'/
/*  name of the subroutine ing function "qadj" */;
      logical* 1 er(6);
/*  */
/*  */
/*  */
/*  variables in "com1": */
      common /com1/ d0,d1,d2,d3,d4,d5,d6,d7,d8,d9
      common /com1/ la,lb,lc,ld,le,lf,lg,lh,li,lj,lk,ll,lm,ln,lo,lp,lq,
     c   lr,ls,lt,lu,lv,lw,lx,ly,lz
      common /com1/ blank,period,lparen,plus,dollar,aster,rparen,minus,
     c   slash,comma,under,equal,quote,less,bar,and,semi,not,prcent,
     c   grater,questn,colon,pound,at,apost
      common /com1/ self,west,east,south,north,swest,nwest,seast,neast,
     c   horiz,vert,aigu,grave,rook,bishop,king
      common /com1/ system,scope,ttyo,ttyi,ptapei,cardi,printr,cardo,
     c   camrao,camrai,fmts
      common /com1/ ttwide,lastin,income,fmtbuf
/*  */
/*  names of digits, letters, and special characters */
      integer d0/0/,d1/1/,d2/2/,d3/3/,d4/4/,d5/5/,d6/6/,d7/7/,d8/8/,
     c   d9/9/
      integer la/10/,lb/11/,lc/12/,ld/13/,le/14/,lf/15/,lg/16/,lh/17/,
     c   li/18/,lj/19/,lk/20/,ll/21/,lm/22/,ln/23/,lo/24/,lp/25/,lq/26/,
     c   lr/27/,ls/28/,lt/29/,lu/30/,lv/31/,lw/32/,lx/33/,ly/34/,lz/35/
      integer blank/36/,period/37/,lparen/38/,plus/39/,dollar/40/,
     c   aster/41/,rparen/42/,minus/43/,slash/44/,comma/45/,under/46/,
     c   equal/47/,quote/48/,less/49/,bar/50/,and/51/,semi/52/,not/53/,
     c   prcent/54/,grater/55/,questn/56/,colon/57/,pound/58/,at/59/,
     c   apost/60/
/*  names of commonly used neighborhood directions */
      integer self/020/, west/040/, east/010/, south/002/,north/200/,
     c   swest/004/, nwest/400/, seast/001/, neast/100/, horiz/070/,
     c   vert/222/, aigu/421/, grave/124/, rook/272/, bishop/525/,
     c   king/777/
/*  i/o unit assignments */
      integer system/0/, scope/1/, ttyo/2/, ttyi/3/, ptapei/4/,
     c   cardi/5/, printr/6/, cardo/7/, camrao/8/, camrai/9/, fmts/10/
/*  carriage width on teletype */
      integer ttwide/72/
/*  number of the last filled column of the teletype input buffer; */
/*  lastin=0 means an empty line was typed */;
      integer lastin
/*  buffer for teletype input */
      logical* 1 income(72)
/*  buffer for format specifications read from file "fmts"; 2 card images */
      logical* 1 fmtbuf(160)
