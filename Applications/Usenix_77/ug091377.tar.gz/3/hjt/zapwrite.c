#
/*
 * nijmegen, h.j. thomassen, june 1976.
 * UNIX document 16
 */
#define blksiz 512

main (argc,argv)
	char	**argv;

{
int	fildesi,fildes;
char	buffer[blksiz];

	if (argc != 3) {
		printf ("arg count\n");
		exit(0); }

	if (( fildesi = open ("./zapblock\0", 0)) < 0 ) {
		printf ("something wrong with zapblock\n");
		exit(0); }
	if (( read (fildesi, buffer, blksiz)) != blksiz ) {
		printf ("zapblock won't read\n");
		exit(0); }
	if ( ( fildes = open (argv[--argc] , 1)) < 0) {
		printf ("open error on %s\n", argv[argc]);
		exit(0); }
	if ( seek (fildes, blksiz*(atoio(argv[--argc])), 0) < 0) {
		printf ("seek error on block %s\n", argv[argc]);
		exit(0); }
	if ( write (fildes, buffer, blksiz) != blksiz) {
		printf ("write error, %d\n", blksiz);
		exit(0); }
}

atoio(ap)
char *ap;
{
	register n,zero;
	register char *p;
	int f;

	p=ap; n=0; f=0; zero= '0';

loop:	while (*p == ' ' || *p == '	')
		p++;
	if (*p == '-') {
		f++; p++; goto loop; }
	while ( *p >= zero && *p <= '7')
		n= n*8 + *p++ - zero;
	if (( *p == '8' ) || ( *p == '9' ) ) {
		printf (" octal block number required\n");
		exit(0); }
	if (f)  n = -n;
	return(n);
}
