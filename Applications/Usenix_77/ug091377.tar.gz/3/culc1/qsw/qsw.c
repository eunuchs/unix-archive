/* * * * * * * * * * * * * * * * * * * * * * * * * * * * *
		Created by Peter Langston

Permission to copy, either in whole or in part, is  hereby
granted  to  anyone  wishing to do so with the restriction
that this entire notice must accompany any copies.

Copyright (c) 1976 by Peter S. Langston
*		      Commercial Union Leasing Co
*		      645 Madison Ave
*		      New York, NY 10022
* * * * * * * * * * * * * * * * * * * * * * * * * * * * */
main(argc,argv)
char **argv;
{
	register char **q, *comm;
	char *args[256], buf[128];
	int n, fork_flag;

	q = argv;
	n = fork_flag = 0;
	args[n++] = *++q;
	while (*++q != -1) {
		if (**q == '-') {
			if (q[0][1] == '&')
				fork_flag++;
			else
				args[n++] = *q;
			continue;
		}
		printf("%s?",*q);
		read(0,buf,80);
		if (*buf == 'y')
			args[n++] = *q;
	}
	args[n] = 0;
	if (fork_flag) {
		 if (n=fork()) {
			printf("%d\n",n);
			exit(0);
		}
		close(0);	/* to be safe */
	}
	comm = argv[1];
	execv(comm,args);	/* try in local directory */
	copy(comm, copy("/bin/", buf));
	execv(buf, args);	/* try in /bin */
	copy(comm, copy("/usr/bin/", buf));
	execv(buf,args);	/* try in /usr/bin */
	copy(comm, copy("/hshbin/", buf));
	execv(buf,args);	/* try in /hshbin */
	printf("I can't find %s here, in /bin, /usr/bin or /hshbin\n",comm);
}
copy(from,to)
char *from, *to;
{
	register char *f, *t;

	f = from;
	t = to;
	while (*t++ = *f++);
	return(--t);
}
