char olddot[77], newdot[77], junk[20];
main()
{
	register int fh, i;

	fh = open("7x9.dot",2);
	printf("start at ");
	read(0,junk,10);
	if (*junk == '\'') i = junk[1];
	else i = atoi(junk);
	for (; i<128; i++) {
		seek(fh,77*i,0);
		read(fh,olddot,77);
		type(olddot);
		printf("%2d='%c'\n\n",i,i);
	}
}

type(cp)
char cp[][11];
{
	register i, j;

	for (i=10; i>=0; i--) {
		printf("\n");
		for (j=0; j<7; j++) printf("%c",cp[j][i] ? 'x' : ' ');
	}
	printf("\n");
}
