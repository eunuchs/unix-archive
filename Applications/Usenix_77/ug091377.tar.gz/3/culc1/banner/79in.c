char olddot[7][11], newdot[7][11], junk[20], chwide;

main()
{
	register int fh, i;

	fh = open("7x9.dot",2);
	printf("start at ");
	read(0,junk,10);
	if (*junk == '\'') i = junk[1];
	else i = atoi(junk);
	for (; i<128; i++) {
		seek(fh,78*i,0);
		read(fh,&chwide,1);
		read(fh,olddot,77);
		type(olddot);
		printf("%2d='%c'width = %d	",i,i,chwide);
		read(0,junk,10);
		if (*junk == '\n') continue;
		chwide = atoi(junk);
inlop:		get(newdot);
		type(newdot);
		printf("ok? ");
		read(0,junk,10);
		if (*junk != 'y') goto inlop;
		seek(fh,78*i,0);
		write(fh,&chwide,1);
		write(fh,newdot,77);
	}
}

type(cp)
char cp[][11];
{
	register i, j;

	for (i=10; i>=0; i--) {
		printf(":\n");
		for (j=0; j<chwide; j++) printf("%c",cp[j][i] ? 'x' : ' ');
	}
	printf("\n");
}

get(cp)
char cp[][11];
{
	register i, j, ii;

	for (i=10; i>=0; i--) for (j=0; j<7; j++) cp[j][i] = 0;
	printf ("enter dot\n   -------\n");
	for (i=10; i>=0; i--) {
		printf("%2d ",i);
		read(0,junk,8);
		if (*junk == '\n') break;
		if (*junk == 'c') {
			for (j=0; j<7; j++) cp[j][i] = olddot[j][i];
			continue;
		}
		if (*junk>='0' && *junk<='9') {
			ii = atoi(junk);
			for (j=0; j<7; j++) cp[j][i] = cp[j][ii];
			continue;
		}
		for (j=0; j<7; j++) {
			if (junk[j] == '\n') break;
			cp[j][i] = junk[j]=='x' ? 1 : 0;
		}
	}
}
