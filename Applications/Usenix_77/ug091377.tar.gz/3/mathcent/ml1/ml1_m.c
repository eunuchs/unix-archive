struct bufdesc {int fdesc;
		int chrcnt;
		char *buf;
		char *chr;
		int size;
		int colcnt;} buffer[10],*inbuffer,*outbuffer;
char bffr[1024];
int maxout,maxin,error  -1,readin,writin;

opening(file,puntr) int *file;char *puntr; {
	if((*file=open(puntr,0))== -1){
		printf("%s unknown\n",puntr); exit(1);}
	}

main(argc,argv) int argc; char **argv;{
	char *pntr;
	int ibcnt,obcnt,i;
	struct bufdesc *bpntr;
	extern runsys();

	if(argc>11){printf("to many arguments\n");exit();}

/*initialize standard in- and output */
	i=maxin=maxout=1; ibcnt=obcnt=512; inbuffer=buffer;
	inbuffer->buf=bffr; inbuffer->size=512;
	outbuffer=bpntr= &buffer[1];

	if(argc-->1){ pntr=argv[1];
/* try specified in- or output */
	if(*pntr == '-'){ argc--; 
		while (*++pntr) if(*pntr=='i')maxin++; /* nr input +1*/
		pntr = argv++[1]; ibcnt = 512/maxin; bpntr=inbuffer;
		while(*++pntr){
			if(!argc){printf("to less files\n"); exit(1);}
			switch(*pntr){
			case 'i': opening(&(bpntr->fdesc),*++argv);
				bpntr->buf=bffr+ibcnt*i++; 
				bpntr++->size=ibcnt; argc--; break;
			case 'b': opening(&readin,*++argv); argc--;break;
			case 'd': writin= *++argv; argc--; break;
			default: printf("unknown argument switch\n");
				exit(1);
			}
		}
	bpntr->buf=bffr+ibcnt*i;
	bpntr->size=ibcnt;
	outbuffer= ++bpntr;
	/*output*/ maxout=argc; obcnt=512/((maxout==0)+(maxout++)); i=0;
	while(argc--){
		if((bpntr->fdesc=creat(*++argv,0666))<0)
			{printf("can't create %s\n",*argv); exit(1);}
		bpntr->chrcnt=obcnt;
		bpntr->chr=bpntr->buf= &bffr[512+obcnt*i++];
		bpntr->size=obcnt;
		bpntr++;}
	bpntr->fdesc=0;
	} else {
/* ml1 input output */
	bpntr=inbuffer;
	opening(&(bpntr->fdesc),argv[1]);
	bpntr->buf=bffr;
	bpntr->size=256;
	(++bpntr)->buf=bffr+256;
	bpntr++->size=256;
	outbuffer= &buffer[2];
	if(argc>1){
	if((bpntr->fdesc=creat(argv[2],0666))<0)
		{printf("can't create %s\n",argv[2]); exit(1);}
	bpntr->chrcnt=512;
	bpntr->chr=bpntr->buf= &bffr[512];
	bpntr++->size=512;
	}
	bpntr->fdesc=0;
	}}
	/* go for a walk in ml1 */
	runsys();
	exit(++error);

}
