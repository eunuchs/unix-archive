#
/* set nice */

#define	EPERM	1
#define	ESRCH	3
#define	EINVAL	22

main(argc,argv) int argc; char **argv; {
	int procnr,nicety,r;
	extern errno;

	if(argc != 3){printf("arg count?\n"); exit();}
	nicety = atoi(argv[1]);
	procnr = atoi(argv[2]);
	if(nicety < 0 && getuid()&0177400){
		printf("not superuser\n");
		exit(EINVAL);
	}
	r = snice(procnr, nicety);
	if(r == -1)
		switch(errno){
		case EPERM:
			printf("not superuser\n");
			exit(EPERM);
		case ESRCH:
			printf("%s not found\n",argv[2]);
			exit(ESRCH);
		}
	printf("was: %d\n", r);
	exit(0);
}
