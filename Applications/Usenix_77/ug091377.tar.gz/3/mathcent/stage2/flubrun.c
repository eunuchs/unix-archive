# define buffsize 256
# define nchans 16
# define memsize 9000
# define true 1
# define false 0
# define bool int

struct buff{
   int fildes;
   int nunused;
   char nextfree; 
   char buffer[512];
   };

int memory[memsize];

char *rdpt, *wrpt, *chlim, *chused;
char chbuff[buffsize];

struct buff inbuff, outbuff, messbuff, *buffs[nchans];

startup(ptr8, ptr9) 
	int *ptr8, *ptr9;
   { int i;
   inbuff.fildes = 0; outbuff.fildes = 1; messbuff.fildes = 2; 
   for (i = 0; i < nchans; i ++) 
      {buffs[i] = 0;};
   buffs[1] = &inbuff; 
   buffs[3] = &outbuff;
   buffs[4] = &messbuff;
   wrpt = &chbuff[0];
   rdpt = &chbuff[0];
   chlim = &chbuff[buffsize - 1];
   chused = & chbuff[0];
   *ptr8 = & memory[0];
   *ptr9 = & memory[(memsize - 1) / 3 * 3];
   };

rdline(bn)
   int bn;
   {struct buff *bf;
      char c; 
      char *chpt;
      if (bn >= 0 && bn < nchans && (bf = buffs[bn]) != 0)
         {
         chpt = &chbuff[0];
         c = getc(bf);
         while (( c != '\n') && (c >= 0) && (chpt < chlim))
            {*chpt++ = c; c = getc(bf);};
         chused = chpt;
         rdpt = & chbuff[0];
         wrpt = & chbuff[0];
         if (c < 0) {return(1);} else return(0);
         }
      else {return(2);};
   }

wrline(bn)
   int bn;
   {  struct buff *bf;
      char *p;
      char *chpt;
      bf = buffs[bn];
      if ((bn >= 0) && (bn < nchans) && ((bf = buffs[bn]) != 0))
         {
         for (p = &chbuff[0]; p < chused; p ++)
            { putc( * p, bf); };
         putc('\n', bf);
    /* we must find some way of getting an error indication. */
         wrpt = &chbuff[0];
         return(0);
         }
      else return( 2 );
   }

rewind(chan)
   int chan;
   {return(2);};

rdch(f)
   int *f;
   {  
      if (rdpt >= chused) { *f = -1; return(-1);}
      else { *f = *rdpt++; return(0);}
   }

wrch(c)
   int c;
   {  
      if (wrpt >= chlim || c < 0) 
         { chused = wrpt;
           return( 1 );
         }
      else { *wrpt++ = c; 
         if (chused < wrpt) {chused = wrpt;};
         return(0);
         }
   }
 
mess(channel, message)
   int channel;
   char message[];
   {  struct buff *bf;
      if ((channel >= 0) && (channel < nchans) && ((bf = buffs[channel]) != 0))
         {putc(message[0], bf);
          putc(message[1], bf);
          putc(message[2], bf);
          putc(message[3], bf);
          putc('\n', bf);
          return(0);
         }
      else return(-1);
   }

stop(c)
   int c;
	{int p;
	for(p = 3; p <= 4; p ++)
		{fflush(buffs[p]);};
	exit(c);
	}
