# define obr '/'
# define cbr '/'
struct {char low; char high;};
struct {int uic; int char0[3];} file;
int block[256],blck[256],follow,nrfiles, fildes,all 1,out 1,
	allfiles  0, allkinds  0;
int  mnth[] {31,28,31,30,31,30,31,31,30,31,30,31};
char	totable[]	{0,0,0,0,0,0,0,0,
			0,0,0,0,0,0,0,0,
			0,0,0,0,0,0,0,0,
			0,0,0,0,0,0,0,0,
			0,0,0,0,033,0,0,0,
			0,0,0,0,0,0,034,0,
			036,037,040,041,042,043,044,045,
			046,047,0,0,0,0,0,0,
			0,01,02,03,04,05,06,07,
			010,011,012,013,014,015,016,017,
			020,021,022,023,024,025,026,027,
			030,031,032,0,0,0,0,0,
			0,01,02,03,04,05,06,07,
			010,011,012,013,014,015,016,017,
			020,021,022,023,024,025,026,027,
			030,031,032,0,0,0,0,0},
	fromtable[]	{040,'a','b','c','d','e','f','g',
			'h','i','j','k','l','m','n','o','p','q',
			'r','s','t','u','v','w','x','y','z','$',
			'.',0,'0','1','2','3','4','5','6','7','8',
			'9'},
	radix[]		{0,0,0,0},*s,*ss,namefile[11];
struct	filedesc	{int	name[2];int	kind;
			int date;int nrlast;int fblck;int nrblks;
			int lblck;char  prot1;char prot2;} *getfile;

int  getblock(blkpntr,blknr) int blknr ,*blkpntr;{
	seek(fildes,blknr,3); read(fildes,blkpntr,512);return(*blkpntr);}

int convokt() {int okt; okt=0;
	while(*s<'8' && *s>='0') okt=  *s++ - '0' + (okt<<3);
	return(okt);}

int toradix(char1,char2,char3) char char1,char2,char3;{
	return(totable[char1]*050*050+totable[char2]*050+totable[char3]);}

extern char *fromradix() ;


int list(blknr) int blknr; {int follower,wordnr, blcks;
	struct filedesc *descptr;
	follower=getblock(blck,blknr); descptr= &blck[1]; blcks=0;wordnr=0;
	while(wordnr<252){
	if(descptr->name[0]){nrfiles++;
		printf("%.10s\t",string(descptr->name[0],
		descptr->name[1],descptr->kind,1));
		printf("%4d\t",descptr->nrblks); blcks=+ descptr->nrblks;
		if(descptr->date<0){putchar('c');descptr->date=& 077777;}
		datum(descptr->date);
		printf("\t<%o>\n",descptr->prot1&0377); }
	wordnr=+ 9; descptr++;}
	if(follower) blcks=+ list(follower); return(blcks);}

datum(day) int day;{ int year,i; char *month; 
	if(day-3000<0)day=+ 010000;year=day/1000+70;
	if(year%4==0) mnth[1]=29;day=% 1000;
	for(i=0; mnth[i]<day;i++) day=- mnth[i];
	mnth[1]=28;
	month="Jan\0Feb\0Mar\0Apr\0May\0Jun\0Jul\0Aug\0Sep\0Oct\0Nov\0Dec";
	month=+ i<<2;
	printf("\t%2d-%.3s-%2d",day,month,year); 
}

char *string(s1,s2,s3,space) int s1,s2,s3,space;{  char *huppel,*hup;
	hup=namefile;
	huppel=fromradix(s1);while(*huppel)if(*huppel!=' ' | space)*hup++= *huppel++;
						else huppel++;
	huppel=fromradix(s2);while(*huppel)if(*huppel!=' ' |space)*hup++= *huppel++;
						else huppel++;
	huppel=fromradix(s3);
	if(*huppel!=' ' |space){*hup++='.';
		while(*huppel)*hup++= *huppel++;}
	*hup=0;
	return(namefile);}

dumpfile(blcknr,nrbytes) int blcknr,nrbytes;{ int follower;
	follower=getblock(blck,blcknr);
	if(follower){write(out, &blck[1],510);
		return(dumpfile(follower,nrbytes));}
	  else write(out, &blck[1],nrbytes); return(blcknr);
	}

getfdesc(){ char uic1[3],chr[4][3]; int i,j,oke,k;
	k=0;j=0;i=0; oke=1;
	do{ switch(*s * oke){
		case obr: oke++;  break;
		case ','*2:  k++; break;
		case cbr*2: oke++; break;
		case 0: while(j<3){if(i>2){i=0;j++;}chr[j][i++]=040;} break;
		case '1'*2: case '2'*2: case '3'*2: case '4'*2: case '5'*2:
		case '6'*2: case '7'*2: case '8'*2: case '9'*2: case '0'*2:
		uic1[k]=convokt();s--; break;
		case '.'*3:while(j<2){if(i>2){i=0;j++;} if(j<2)chr[j][i++]=040;}
			 k++;break;
		case'+'*3:if(k==1)allfiles=1;else allkinds=1;break;
		default: if(i>2){i=0; j++;} chr[j][i++]= *s;
	}} while(*s++);
	if(oke!=3 ){ printf("dos filename incorrect\n"); exit();}
	file.uic.low= uic1[1]; file.uic.high= uic1[0];
	for(i=0;i<3;i++) file.char0[i]=toradix(chr[i][0],chr[i][1],chr[i][2]);
	}

main(argc,argv) int argc; char **argv; {int i;
	fildes=open("/dev/rk1",0); ss=argv[1]+1;
	if(getblock(block,0)!=012700){printf("no dosdisk!\n");exit();}
	follow=getblock(block,1);
	switch(*ss++){
	case 'l': all=0;s=argv[2]; getfdesc();ss--;
	case 'u':  do {follow=getblock(block,follow);i=1;
		while(i<254){
		if(all?block[i] : block[i]==file.uic){nrfiles=0;
 		    printf("\ndirectory [%o,%o]\n\n",block[i].high&0377,
				block[i].low&0377);
			if(*ss=='l'){printf("\nnr of blocks:\t%d\n",
				list(block[i+1]));
				printf("nr of files:\t%d\n",nrfiles);
				if(!all)exit();}
			}i=+ 4;}
		} while(follow);
	 break;
case 'f':	s=argv[2];getfdesc();
/*direct*/	do{ follow=getblock(block,follow);i=1;
		while(i<254){
			if(block[i]==file.uic){
/*files*/follow=block[i+1];do{follow=getblock(block,follow);getfile= &block[1];
			while(getfile< &block[252]){
/*getfile*/	if((allfiles?1:(getfile->name[0]==file.char0[0] &&
				   getfile->name[1]==file.char0[1])) &&
			(allkinds?1:(getfile->kind==file.char0[2]) )){
		if(*ss=='d')out=creat(string(getfile->name[0],getfile->name[1],
				getfile->kind,0),0666);
		if(getfile->lblck!=dumpfile(getfile->fblck,getfile->nrlast))
			printf("disk read error\n");
		if(*ss=='d')close(out);
			if(!(allfiles ||allkinds))exit();}
			getfile++;}
		}while(follow); exit();
	}i=+ 4; }}while(follow);
}
}
