/* deliver a random value between 0 and k-1 */
int userand	1;

random(k){
register int r;
	if(!userand) return(0);
	r = rand();
	if(r<0) r = -r;
	r =- (r/k)*k;
	return(r);
}
