#
/* determine terminal type (MC use only) */
#define	NOTTY	0
#define	GT40	1
#define	HP	2
#define	HCT	3
#define	DECWR	4

term[10] {
/* 0 */	NOTTY,
/* 1 */	GT40,
/* 2 */	HCT,
/* 3 */	HP,
/* 4 */	HP,
/* 5 */	HP,
/* 6 */	NOTTY,
/* 7 */	NOTTY,
/* 8 */	DECWR,
/* 9 */	NOTTY
};

ttytype(f) int f; {
char c;
	c = ttyn(f);
	if((c < '0') || (c > '9')) /* and in particular if c == 'x' */
		return(NOTTY);
	return(term[c - '0']);
}
