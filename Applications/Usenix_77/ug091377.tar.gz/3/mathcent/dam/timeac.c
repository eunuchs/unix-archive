/* time accounting */
int tvec0[2],tvec[2];

timebeg(){
	time(tvec0);
}

timedif(){
	time(tvec);
	return(tvec[1] - tvec0[1]);
}
