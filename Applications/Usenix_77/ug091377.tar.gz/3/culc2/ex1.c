float	x[55],y[55],z[55],w[165];
extern double sin();
extern double cos();
extern double log();
extern double exp();

double max(a,b)
double a,b;
{
	if(a>b)  return(a); else return(b);
}

main()
{
	int	i,nd;
	float fi;
	float	v,bang,angle;
	int	ipen;
	float yy,xx;
	double rangle;

	for(i=1; i<= 50; i++){
	 x[i-1]=exp((fi=i)*(log(2.0)/5.0));
	}
	nd=50;
	plots(120);
	plot36(.005);
	smode(0,1.5);
	plot(0.0,0.0,-3);
	for(i=1; i<=50; i++){
		y[i-1]=log(x[i-1])/log(10.);
		z[i-1]=log(max(1.0,y[i-1]))/log(10.0);
	}
	scale(x,6.0,nd,1);
	iaxis(1.5,.75,"X",-1,6.,0.0,x[nd],x[nd+1]);
	scale(y,9.0,nd,1);
	scale(z,9.0,nd,1);
	axis(1.5,.75,"Log(X)",6,8.5,90.0,z[nd],z[nd+1]);
	axis(7.5,.75,"Loglog(X)",-9,8.5,90.,z[nd],z[nd+1]);
	symbol(2.5,9.3,.2,"First Sample Plot",0.0,17);
	plot(1.5,.75,-3);
	line(x,y,nd,1,2,0);
	line(x,z,nd,1,-1,1);
	symbol(0.5,7.84,0.08,0,0.0,-1);
	symbol(0.6,7.80,0.14," - Log(X)",0.0,9);
	symbol(0.5,7.34,0.08,1,0.0,-1);
	symbol(0.6,7.30,0.14," - Loglog(X)",0.0,12);
	plot(7.,-.75,-3);
	for(i=1; i<=50; i++){
	 w[3*(i-1)]=exp((fi=i)*(log(2.0)/5.0));
	}
	nd=50;
	symbol(2.5,9.3,.2,"Second Sample Plot",0.0,18);
	for(i=1; i<= 50; i++){
		w[1+(3*(i-1))]=log(w[3*(i-1)])/log(10.);
		w[2+(3*(i-1))]=log(max(1.0,w[1+(3*(i-1))]))/log(10.0);
	}
	w[3*nd]=0.0;
	w[1+(3*nd)]=0.0;
	w[2+(3*nd)]=0.0;
	w[3*(nd+1)]=200.0;
	w[1+(3*(nd+1))]=0.5;
	w[2+(3*(nd+1))]=0.5;
	axis(1.75,0.75,"W(i,1)",-6,6.0,0.0,0.0,200.);
	axis(1.75,0.75,"Log & Loglog(W(i,1))",
        20,8.,90.,0.0,0.5);
	plot(1.75,0.75,-3);
	line(&w[0],&w[1],nd,3,0,0);
	line(&w[0],&w[2],nd,3,0,1);
	plot(7.0,-0.75,-3);
	symbol(2.5,9.3,.2,"Third Sample Plot",0.0,17);
	plot(1.75,0.75,-3);
	offset(1000.,100.,3.,0.05);
	axis(0.0,0.0,"U",-1,6.,0.0,1000.,100.);
	iaxis(0.0,0.0,"Log(U)",6,8.5,90.,3.,.05);
	ipen=13;
	for(i=1000; i<=1600; i=+ 2){
		fi=i;
		v=log(fi)/log(10.0);
		plot(fi,v,ipen);
		ipen=12;
	}
	plot(7.,-.75,-3);
	angle=0.0;
	for(i=1; i<=16; i++){
		bang=angle;
		rangle=angle*.01745;
		xx=4.25+cos(rangle);
		yy=5.5+sin(rangle);
		symbol(xx,yy,.2,"Sample Plot",bang,11);
		angle=22.5+angle;
	}
	plot(8.5,0.0,-3);
	plot(5.5,4.5,3);
	plot(4.5,9.,5);
	plot(7.,2.5,4);
	plot(3.5,1.5,2);
	plot(4.5,9.,4);
	plot(5.5,4.5,3);
	plot(2.,3.5,5);
	plot(3.5,1.5,2);
	plot(7.,2.5,2);
	plot(5.5,4.5,5);
	plot(4.5,9.,3);
	plot(2.,3.5,4);
	plot(8.5,0.0,999);
	poff();
	return(0);
}
