
main()
{
	for(;;)
	{
	write(2,"*",1);
		sleep(30);
	}
}
