extern int col[], row[], sym[], change[], nn, mm[41][42];
melt ()
	{
	tabletomatrix ();
	neighborsoflivecells ();
	update ();
	}

tabletomatrix () {
	register int i, j, k;
	/* first zero mm */
	for (i=1; i<40; i++)
		for (j=1; j<41; j++)
			mm[i][j] = 0;
	/* then put 20 on the perimeter */
	for (i=0; i<42; i++)
		{mm[40][i] = 20; mm[0][i] = 20;}
	for (i=0; i<41; i++)
		{mm[i][41] = 20; mm[i][0] = 20;}
	/* finally put a 1 in mm where there is a live cell */
	for (i=0; i<= nn; i++)

		if (sym[i] != '.')
		{j = ((col[i] + 1)/2) ;
		 k = row[i] + 1;
		 mm[k][j] = 1;
		}
	}

printmatrix () {
	int i, j;
	for (i=0; i<41; i++)
		for (j=0; j<42; j++)
			{printf ("%d", mm[i][j]);
			 if (j == 41) printf ("\n");
			}
	}

neighborsoflivecells () {
	int a, b, i, q;
	register int j,k,p;
	/* checks each element of table of neighbors */
	for (i=0; i<=nn; i++) /* for each live cell */
	   {a = (row[i] + 1);
		
	    b = ((col[i] +1)/2);
		for (j= -1; j<2; j++)
			for (k= -1; k<2; k++)
			{
			 p = a + j;
			 q = b + k;
			 if (mm[p][q] == 0)
				deadneighbor(p,q); /* check for new cell */

			 if (mm[p][q] > 0 && mm[p][q] < 20 && mm[a][b] > 0)
				mm[a][b] = mm[a][b] + 1;
			}
	   }
	}

deadneighbor (l,m)
int l, m; {
	int i, k;
	register int j,n,o;
	for (i= -1; i<2; i++)
		for (j= -1; j<2; j++)
		{
		 n = l + i;
		 o = m + j;

		 if (mm[n][o] > 0 && mm[n][o] < 20)
			mm[l][m] = mm[l][m] - 1;
		}

	/* now see if we have a new live cell */
	if (mm[l][m] == -3)
		{
		 ++nn;
		 row[nn] = l - 1;
		 col[nn] = (m * 2) -1;
		 sym[nn] = '+';
		 change[nn] = 1;

		}
	}

update () {
	register int i, l, m;
	for (i=0; i<=nn; i++)
		{
		 l = ((col[i] + 1)/2);
		 m = row[i] + 1;

		 if ((mm[m][l] != 4) && (mm[m][l] != 5) && (mm[m][l] != (-3)))
		     {
			 sym[i] = '.';
		         change[i] = 1;
		     }
		}
	}
