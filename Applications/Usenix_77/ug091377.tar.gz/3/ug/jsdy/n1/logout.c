main  ()
{
     kill (0,1);
}
