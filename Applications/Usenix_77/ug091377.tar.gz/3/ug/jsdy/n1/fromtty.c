#

#define	ENOEXEC 8

#define unsigned char *
struct stbuf {
	int     dev;
	int     inum;
	int     mode;
	char    nlink;
	char    uid;
	char    gid;
	char    siz0;
	unsigned siz1;
	int     addr[8];
	long    adate;
	long    mdate;
};

struct {
	char    iuid;
	char    igid;
};

char *bin "/usr/bin/xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
char *err "%s: not found\n";
int guid;

main(argc,argv)
char **argv;
{
	register char *comnd, *ptr;
	auto char pwdir[100];
	auto int buf[18];
	extern int errno;

	if(argc < 2) return(0);

	guid = (getgid() << 8) | (getuid() & 0377);
	argv[argc] = 0;
	close(0);
	dup(2);

	comnd = argv[1];
	if(stat(comnd,buf) != -1)
		if(execable(buf)) {
			execv(comnd,&argv[1]);
			if (errno == ENOEXEC) {
				argv[1] = comnd;
				execv("/bin/sh",argv);
				write(2, "No shell!\n", 10);
			}
			return(-1);
		}

	if(*argv[1] == '/') {
		printf(err,argv[1]);
		return(-1);
	}

	/* This next set for Rand personal bins */
	if(getdir(pwdir)) {
		for(comnd = pwdir; *comnd++;);
		ptr = argv[1];
		for(--comnd; *comnd++ = *ptr++;)
			if(comnd >= &pwdir[100]) {
				write(2, "fromtty: command too long", 25);
				return(-1);
			}
		if(stat(pwdir,buf) != -1)
			if(execable(buf)) {
				execv(pwdir,&argv[1]);
				if (errno == ENOEXEC) {
					argv[1] = comnd;
					execv("/bin/sh",argv);
					write(2, "No shell!\n", 10);
				}
				return(-1);
			}
	}

	comnd = &bin[9];
	ptr = argv[1];
	while(*comnd++ = *ptr++)
		if(comnd >= &buf[50]) {
			write(2, "fromtty: command too long", 25);
			return(-1);
		}
	comnd = bin;
	if(stat(&comnd[4],buf) != -1)
		if(execable(buf)) {
			execv(&comnd[4],&argv[1]);
			if (errno == ENOEXEC) {
				argv[1] = &comnd[4];
				execv("/bin/sh",argv);
				write(2, "No shell!\n", 10);
			}
			return(-1);
		}
	if(stat(comnd,buf) != -1)
		if(execable(buf)) {
			execv(comnd, &argv[1]);
			if (errno == ENOEXEC) {
				argv[1] = comnd;
				execv("/bin/sh",argv);
				write(2, "No shell!\n", 10);
			}
			return(-1);
		}
	printf(err,argv[1]);
	return(-1);
}

execable(buf)
struct stbuf *buf;
{
	register fguid;

	fguid = (buf->gid << 8) | (buf->uid);
	return(getprot(guid, fguid, buf->mode) & 1);
}

getprot(mguid, fguid, mode)
{
	if(mguid.iuid == 0) return(mode&0111 ? 7 : 6);
	if(mguid.iuid == fguid.iuid)
		return((mode >> 6) & 07);
	if(mguid.igid == fguid.igid)
		return((mode >> 3) & 07);
	return(mode & 07);
}

getdir(dirbuf)
char *dirbuf;
{
	register char *cp, *cp2;
	register int c;

	if(getpw(guid, dirbuf)) return(0);
	cp = dirbuf;
	c = -5;
	while(*cp) if(*cp++ == ':') if(++c == 0) break;
	if(*cp == '\0') return(0);
	for(cp2 = cp; *cp2; cp2++)
		if(*cp2 == ':') {
			*cp2 = '\0';
			break;
		}
	cp2 = dirbuf;
	while(*cp2++ = *cp++);
	return(dirbuf);
}
