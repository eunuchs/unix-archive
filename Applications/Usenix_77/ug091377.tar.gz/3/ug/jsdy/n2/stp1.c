#include "stp.h"

char	*edir	&dir[0];	/* Allocate no block initially */
char	*nptr	&dir[MDIRENT];	/* just above the nameblock */
int	flags	020;		/* default is flu */

char	mt[]	 "/dev/mt0";
#ifndef NOREW
char	rmt[]	 "/dev/rmt0";
#endif
#ifdef  NOREW
char    nmt[]    "/dev/nmt0";
#endif
char	backup[] "/tmp/mt0dir";

main(argc,argv)
char **argv;
{
	register char c,*ptr;
	extern cmd(), cmr(),cmx(), cmt();

	command = &cmr;
	if ((narg = rnarg = argc) < 2)	narg = 2;
	else {
		ptr = argv[1];	/* get first argument */
		parg = &argv[2]; /* pointer to second argument */
		while (c = *ptr++) switch(c)  {
			case '0':
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
				mt[7] = c;
#ifndef NOREW
				rmt[8] = c;
#endif
#ifdef NOREW
				nmt[8] = c;
#endif
				backup[7] = c;
				continue;
			case 'c':
				flags =| flc;  continue;
			case 'd':
				setcom(&cmd);  continue;
			case 'f':
				flags =| flf;  continue;
			case 'i':
				flags =| fli;  continue;
			case 'm':
				continue;
			case 'r':
				flags =& ~flu;  setcom(&cmr);  continue;
			case 't':
				setcom(&cmt);  continue;
			case 'u':
				flags =| flu;  setcom(&cmr);  continue;
			case 'v':
				flags =| flv;  continue;
			case 'w':
				flags =| flw;  continue;
			case 'x':
				setcom(&cmx);  continue;
			default:
				useerr();
		}
	}
	(*command)();
}

roptap(how)	/* open tape raw mode, go to directory */
{
	register count;

#ifndef NOREW
	if ((fio = open(rmt,how)) < 0) {
		printf("Cannot open %s\n",rmt);
		done(how+how);
	}
	for ever {
		if (read(fio,tapeb,512) <= 0)  break;
		++count;
	}
	endtape = count;
#endif
#ifdef NOREW
	if ((fio = open(nmt,0)) < 0) {
		printf("Cannot open %s\n",nmt);
		done(how+how);
	}
	close(fio);
	optap(how);
#endif
}

optap(how)
{
	register h;

	h = how;
	if ((fio = open(mt,h)) < 0) {
		printf("Cannot open %s\n",mt);
		if (h)		h = 3;
		done(h);
	}
}

setcom(newcom)
{
	extern cmr();

	if (command != &cmr)  		useerr();
	command = newcom;
}

useerr()
{
	printf("Bad usage\n");
	done(0);
}

/*/* COMMANDS */

cmd()
{	extern delete();

	if (flags & (flc|flf))		useerr();
	if (narg <= 2)			useerr();
	rddir();
	gettape(&delete);
	roptap(2);	/* Raw second file read/write */
	wrdir();
	close(fio);
	check();
}

cmr()
{
	if ((flags & flc) == 0) {
		if ((backio = creat(backup,0600)) < 0) {
			printf("Cannot create %s\n", backup);
			done(0);
		}
		rddir();
	}
	getfiles();
	update();
	roptap(2);	/* Raw second file read/write */
	wrdir();
	close(fio);
	check();
}

cmt()
{	extern taboc();

	if (flags & (flc|flf|flw))	useerr();
	rddir();
	if (flags & flv)
		printf("   mode    uid gid tapa    size   date    time name\n");
	gettape(&taboc);
	check();
}

cmx()
{	extern extract();

	if (flags & (flc|flf))		useerr();
	rddir();
	optap(0);
	gettape(&extract);
	close(fio);
	done(0);
}
/**/

check()
{
	flags =& ~flc;
	usage();
	done(0);
}

done(how)  /* 0 no harm, 1 twrite, 2 wseek, 3 optap(~1), 4 roptap(2) */
{
	printf("End\n");
	if ((how==0) && (backio > 0))  /* leave backup file if troublesome exit */
		unlink(backup);
	exit();
}

encode(pname,dptr)	/* pname points to the pathname
			 * nptr points to next location in nameblk
			 * dptr points to the dir entry		   */
{
	register  char *np, *sp;

	sp = pname;
	dptr->d_namep = np = nptr;
	if (np <= edir + 32)  {
			printf("Out of Core\n");
			done(0);
	}
	while (*--np = *sp++);	/* stored backwards */
	nptr = np;
}

decode(pname,dptr)	/* dptr points to the dir entry
			 * name is placed in pname[] */
{

	register char *np, *sp;

	sp = pname;
	np = dptr->d_namep;
	while (*sp++ = *--np);	/* retrieved backwards */
}
