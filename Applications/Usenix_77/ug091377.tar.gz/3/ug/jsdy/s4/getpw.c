#define ever ;;
getpw(guid, buf)
int guid;
char buf[];
{
	auto pbuf[259], uid, gid;
	char store[120];
	static pwf;
	register n, c;
	register char *bp;

	if(pwf == 0)
		pwf = open("/etc/passwd", 0);
	if(pwf < 0)
		return(1);
	seek(pwf, 0, 0);
	pbuf[0] = pwf;
	pbuf[1] = 0;
	pbuf[2] = 0;
	uid = guid & 0377;
	gid = (guid >> 8) & 0377;
	buf[0] = '\0';

	for(ever) {
		bp = store;
		while((c=getc(pbuf)) != '\n') {
			if(c <= 0)
				return(buf[0]?0:1);
			*bp++ = c;
		}
		*bp++ = '\0';
		bp = store;
		n = 3;
		while(--n)
		while((c = *bp++) != ':')
			if(c == '\n')
				return(buf[0]?0:1);
		while((c = *bp++) != ':') {
			if(c<'0' || c>'9')
				continue;
			c =- '0';
			n = n*10 + c;
		}
		if(n != uid) continue;
		n = 0;
		while((c = *bp++) != ':') {
			if(c<'0' || c>'9')
				continue;
			c =- '0';
			n = n*10 + c;
		}
		if(n == gid) {
			bp = store;
			while(*buf++ = *bp++);
			return(0);
		}
		if(buf[0] == '\0') {
			n = buf;
			bp = store;
			while(*buf++ = *bp++);
			buf = n;
		}
	}
}
