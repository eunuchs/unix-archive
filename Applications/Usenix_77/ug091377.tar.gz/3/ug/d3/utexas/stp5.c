#
/* 
 * stp5 - implement p & f flags
 * 	p => create directories to make pathname
 *	f => if needed directories don't exist, use the filename part
 * 		in the current directory
 */

#include "stp.h"

makedirs(namep,mode)
char *namep;
{
	struct statbuf sb;
	register char *endp, *pt, *p;
	int st;
	char locname[48];

	for (endp= locname , pt = namep ;*endp = *pt++; endp++);
	p = locname;
	do {
		while (p<endp && *p != '/')
			p++;
		if (p == endp) {
			printf("endp reached\n");
			return(-1);
		}
		*p = 0;
		st = stat(locname,&sb);
		*p = '/';
	} while (st > 0);
	/* a slash has been found, and the substring up to that slash */
	/* repesents a file that does not exist */
	/* (or cannot be accessed for some other reason) */
	do {
		*p = 0;
		while ((st = fork()) == -1);
		if (st == 0) {
			if (flv)
				printf("Making directory %s\n",locname);
			execl("/bin/mkdir","mkdir",locname,0);
			exit(-1);
		} else if (wait() == -1)
			return(-1);
		if (stat(locname,&sb) == -1)
			return(-1);
		*p = '/';
		while (++p < endp && *p != '/');
	} while (p < endp);
	return(creat(namep,mode));
}
shortname(namep,mode)
char *namep;
{
	register char *p1, *p2;

	p2 = namep;
	for (p1 = namep; *p1 ; p1++)
		if (*p1 == '/')
			p2 = p1 + 1;
	return(creat(p2,mode));
}
