/*
 *	name line
 */
char headline[] {"a p l \\ 1 1 \n11 Apr 1977\n\n"};
