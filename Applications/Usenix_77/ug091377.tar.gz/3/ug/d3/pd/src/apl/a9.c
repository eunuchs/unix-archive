#include "apl.h"

ex_dibm()
{
	error("dibm B");
}

ex_mibm()
{
	register *p;
	int t[6];

	switch(topfix()) {

	default:
		error("ib unk");

	case 20: /* time of day */
		time(t);
		p = t;
		goto tod;

	case 21: /* CPU time */
		times(t);
		t[3] = t[0];
		t[0] = 0;
		t[2] = 0;
		datum = ltod(t) + ltod(t+2);
		break;

	case 24: /* starting time */
		p = stime;

	tod:
		p = localtime(p);
		datum = 60.*(p[0]+60.*(p[1]+60.*p[2]));
		break;

	case 25: /* date */
		time(t);
		p = t;
		goto dt;

	case 26: /* current line # */
		datum = funlc-1;
		if(funlc ==0 ) datum =0;
		break;

	/*
	 * non standard I functions
	 */

	case 28: /* starting date */
		p = stime;

	dt:
		p = localtime(p);
		datum = p[5]+100.*(p[3]+100.*(p[4]+1));
		break;

	case 29: /* iorg */
		datum = thread.iorg;
		break;

	case 30: /* width */
		datum = thread.width;
		break;

	case 31: /* digits */
		datum = thread.digits;
		break;

	case 36: /* 2nd element of ib27 */
		datum = ibeam36 -1;
		if (ibeam36 == 0) datum =0;
		break;
	}
	p = newdat(DA, 0, 1);
	p->datap[0] = datum;
	*sp++ = p;
}
