main(argc,argv)
  int	argc;		/* number of arguments including command name */
  char	**argv;		/* pointer to argument list */
{
  int	creat(),
	doccat(),
	docsect(),
	docwrite(),
	exit(),
	fddoc,
	getpid(),
	i1,
	pid,
	printf(),
	rdcnt,
	read(),
	stat(),
	unlink();
  char	buffer[132],
	*docname,
	*pntr1,
	*tempfile;
  struct  {
	    char	minor;
	    char	major;
	    int		inumber;
	    int		flags;
	    char	nlinks;
	    char	uid;
	    char	gid;
	    char	size0;
	    int		size1;
	    int		addr[8];
	    int		actime[2];
	    int		modtime[2];
	  } fst;
/*
	get document filename from argument list.
*/
  if (argc <= 1)
	{ printf ("E0001 NO DOCUMENT FILENAME SPECIFIED    (DOCUMENT)\n");
	  exit (1);
	}
  docname = argv[1];
  /* check to see if document file already exists */
  if (!stat(docname, &fst))
	{ printf ("E0002 DOCUMENT FILE %s ALREADY EXISTS    (DOCUMENT)\n",
		docname);
	  exit (2);
	}
/*
	open document file.
*/
  if ( (fddoc=creat(docname, 0640)) < 0)
	{ printf ("E0003 UNABLE TO OPEN DOCUMENT FILE %s    (DOCUMENT)\n",
		docname);
	  exit (3);
	}
/*
	get a temporary file to use as a work file.
*/
  tempfile = &("/tmp/d00000");
  pid = getpid();
  for (pntr1=tempfile+10, i1=1; i1<=5; i1++)
	{ (*pntr1--) = pid%10+'0';
	  pid =/ 10;
	}
/*
	create 'program name' section.
*/
  docwrite (fddoc, "PROGRAM NAME:  ", 0);
  printf ("ENTER PROGRAM NAME:  ");
  rdcnt = read(0, buffer, sizeof buffer);
  if (rdcnt <= 0 || buffer[0] == '\n')
	docwrite (fddoc, docname, 1);
  else
	{ buffer[rdcnt-1] = '\0';
	  docwrite (fddoc, buffer, 1);
	}
/*
	create 'author' section.
*/
  docwrite (fddoc, "\nAUTHOR:  ", 0);
  printf ("ENTER AUTHOR'S NAME:  ");
  rdcnt = read(0, buffer, sizeof buffer);
  if (rdcnt <= 0 || buffer[0] == '\n')
	docwrite (fddoc, "unknown", 1);
  else
	{ buffer[rdcnt-1] = '\0';
	  docwrite (fddoc, buffer, 1);
	}
/*
	create 'date written' section.
*/
  docwrite (fddoc, "\nDATE WRITTEN:  ", 0);
  printf ("ENTER DATE PROGRAM WAS WRITTEN:  ");
  rdcnt = read(0, buffer, sizeof buffer);
  if (rdcnt <= 0 || buffer[0] == '\n')
	docwrite (fddoc, "unknown", 1);
  else
	{ buffer[rdcnt-1] = '\0';
	  docwrite (fddoc, buffer, 1);
	}
/*
	create 'source language' section.
*/
  printf ("ENTER THE SOURCE LANGUAGE THAT THE PROGRAM IS WRITTEN IN:  ");
  rdcnt = read(0, buffer, sizeof buffer);
  if (rdcnt > 0 && buffer[0] != '\n')
	{ docwrite (fddoc, "\nSOURCE LANGUAGE:  ", 0);
	  buffer[rdcnt-1] = '\0';
	  docwrite (fddoc, buffer, 1);
	}
/*
	create 'location of source deck' section.
*/
  printf ("ENTER THE LOCATION OF THE SOURCE DECK:  ");
  rdcnt = read(0, buffer, sizeof buffer);
  if (rdcnt > 0 && buffer[0] != '\n')
	{ docwrite (fddoc, "\nLOCATION OF SOURCE:  ", 0);
	  buffer[rdcnt-1] = '\0';
	  docwrite (fddoc, buffer, 1);
	}
/*
	create 'location of binary deck' section.
*/
  printf ("ENTER THE LOCATION OF THE BINARY DECK:  ");
  rdcnt = read(0, buffer, sizeof buffer);
  if (rdcnt > 0 && buffer[0] != '\n')
	{ docwrite (fddoc, "\nLOCATION OF BINARY:  ", 0);
	  buffer[rdcnt-1] = '\0';
	  docwrite (fddoc, buffer, 1);
	}
/*
	create 'syntax' section.
*/
  if (docsect(tempfile, "SYNTAX"))
	{ docwrite (fddoc, "\nSYNTAX:", 1);
	  doccat (tempfile, fddoc);
	}
/*
	create 'description' section.
*/
  if (docsect(tempfile, "DESCRIPTION"))
	{ docwrite (fddoc, "\nDESCRIPTION:", 1);
	  doccat (tempfile, fddoc);
	}
/*
	create 'messages & diagnostics' section.
*/
  if (docsect(tempfile, "MESSAGES & DIAGNOSTICS"))
	{ docwrite (fddoc, "\nMESSAGES & DIAGNOSTICS:", 1);
	  doccat (tempfile, fddoc);
	}
/*
	create 'see also' section.
*/
  if (docsect(tempfile, "SEE ALSO"))
	{ docwrite (fddoc, "\nSEE ALSO:", 1);
	  doccat (tempfile, fddoc);
	}
/*
	create 'files used' section.
*/
  if (docsect(tempfile, "FILES USED"))
	{ docwrite (fddoc, "\nFILES USED:", 1);
	  doccat (tempfile, fddoc);
	}
/*
	create 'known bugs' section.
*/
  if (docsect(tempfile, "KNOWN BUGS"))
	{ docwrite (fddoc, "\nKNOWN BUGS:", 1);
	  doccat (tempfile, fddoc);
	}
/*
	create 'implemtation description' section.
*/
  if (docsect(tempfile, "IMPLEMENTATION DESCRIPTION"))
	{ docwrite (fddoc, "\nIMPLEMENTATION DESCRIPTION:", 1);
	  doccat (tempfile, fddoc);
	}
/*
	insure that temporary work file is erased.
*/
  unlink (tempfile);
}
/*page eject */
doccat (tempfile, fddoc)
  int	fddoc;
  char	*tempfile;
{
  int	close(),
	exit(),
	fdtemp,
	open(),
	printf(),
	rdcnt,
	read(),
	write();
  char	buffer[512];
  if ( (fdtemp=open(tempfile, 0)) < 0)
	{ printf ("E0001 UNABLE TO OPEN WORK FILE    (DOCCAT)\n");
	  exit (1);
	}
  while (rdcnt=read(fdtemp, buffer, sizeof buffer))
	{ if (rdcnt < 0)
			{ printf ("E0002 ERROR READING WORK FILE    (DOCCAT)\n");
		  exit (2);
		}
	  if (write(fddoc, buffer, rdcnt) < 0)
		{ printf ("E0003 ERROR WRITING ON DOCUMENT FILE    (DOCCAT)\n");
		  exit (3);
		}
		}
  close (fdtemp);
}
/*page eject */
docsect (tempfile, message)
  char	*message,
	*tempfile;
{
  int	execl(),
	fork(),
	i1,
	pid,
	printf(),
	stat(),
	wait();
  struct  {
	    char	minor;
	    char	major;
	    int		inumber;
	    int		flags;
	    char	nlinks;
	    char	uid;
	    char	gid;
	    char	size0;
	    int		size1;
	    int		addr[8];
	    int		actime[2];
	    int		modtime[2];
	  } fst;
  printf ("ENTER A ");
  printf ("%s SECTION\n", message);
  pid = fork();
  if (pid < 0)
	return (0);
  if (pid != 0)
	while ( (i1=wait()) != pid && i1 >= 0);
  else
	execl ("/bin/ned", "ned", "-f", "-n", tempfile, 0);
  if (stat(tempfile, &fst) || fst.size1 == 0)
	return (0);
  return(1);
}
/*page eject */
docwrite (fddoc, string, newline)
  int	fddoc,
	newline;
  char	*string;
{
  int	exit(),
	i1,
	printf(),
	write();
  char	*pntr1;
  for (i1=0, pntr1=string; (*pntr1++)!='\0'&&i1<512; i1++);
  if (i1 != 0)
	if (write(fddoc, string, i1) < 0)
		{ printf ("E0001 ERROR WRITING ON DOCUMENT FILE    (DOCWRITE)\n");
		  exit (1);
		}
  if (newline)
	write (fddoc, "\n", 1);
}
