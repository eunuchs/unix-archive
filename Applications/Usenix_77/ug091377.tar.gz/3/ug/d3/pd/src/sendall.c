char *file "/etc/ttys";
int fd, msize, n;
char buf[2000];
struct tty{
	char on;
	char ttyn;
	char mode;
	char nl;
} ttys[36];
main()
{
	struct tty *p;

	if((fd = open(file,0)) < 0){
		printf("can't open %s\n",file);
		exit(1);
	}
	if(read(fd, &ttys, sizeof ttys) <= 0){
		printf("can't read %s\n",file);
		exit(2);
	}
	msize = 0;
	while((n = read(0, &buf[msize], sizeof buf - msize)) > 0)
		msize =+ n;
	if(msize <= 0){
		printf("[nothing to send]\n");
		exit(3);
	}
	for(p = &ttys; p < &ttys[36]; p++)
		send(p);
}

send(p)
struct tty *p;
{
	int i;
	char *s;

	if(p->on != '1')
		return;
	sleep(1);
	i = fork();
	if(i == -1){
		printf("can't fork for ttyn%c\n",p->ttyn);
		return;
	}
	if(i != 0)
		return;
	s = "/dev/tty$";
	s[8] = p->ttyn;
	i = open(s, 1);
	if(i < 0) {
		printf("can't open tty%c\n", p->ttyn);
		exit();
	}
	close(1);
	dup(i);
	write(i, buf, msize);
	exit();
}
