#
#define ERROR	-1
#include "/usr/tgi/src/CS5X7.font"

main(argc, argv)
int argc;
char **argv;
{
	extern fout;
	register int n, w, d;

	if (argc == 1) {
		printf("usage: %s string [string [string...]]\n", *argv);
		exit(ERROR);
	}
	fout = dup(1);
	putchar('\n');

	while (--argc) {
		argv++;
		for (d = 0;d < DEPTH;d++) {
			for (n = 0;argv[0][n];n++) {
				if (argv[0][n] < ' ')
					continue;
				for (w = 0;w < WIDTH;w++) {
					if (bit(argv[0][n], d, w))
						putchar(CHAR);
					else
						putchar(' ');
				}
				putchar(' ');
				putchar(' ');
			}
			putchar('\n');
		}
		putchar('\n');
		putchar('\n');
	}
	flush();
}

bit(c, d, w)
char c;
int d, w;
{
	register int shift, offset;
	int n;

	shift = d * WIDTH + w;
	offset = shift / 16 + (c - ' ') * ((DEPTH * WIDTH + 15) / 16);
	shift =% 16;
	n = tbl[offset] >> (15 - shift) & 01;
	return(n);
}
