: Incremental restore routine
: Written by Walter Lazear, AFDSC, Mar 1977
: 
if $1x = x goto error
chdir $1
echo "tp m7x" >/tmp/tp1
echo Incremental restore starting at: >/dev/tty8
date >/dev/tty8
echo "Restore tape mounted on mt7 ? " 
if { query } goto yes
goto end
: yes
ss /tmp/tp1 $2
: end
echo Incremental restore finished at: >/dev/tty8
date >/dev/tty8
exit
: error
echo USAGE:  irestor directory [list-file]
exit
