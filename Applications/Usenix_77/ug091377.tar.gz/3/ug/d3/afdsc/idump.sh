: Incremental dump routine
: Written by Walter Lazear, AFDSC, Mar 1977
: 
if $2x = x goto error
chdir $2
echo Incremental dump starting at: >/dev/tty8
date >/dev/tty8
echo "Dump tape mounted on mt7 ? " 
if { query } goto yes
goto end
: yes
tp mr /etc/ttys >/dev/null
find . -dtime $1 -a ! -type d -a -print  | xtp
: end
echo Incremental dump finished at: >/dev/tty8
date >/dev/tty8
exit
: error
echo USAGE:  idump dev-name directory
exit
