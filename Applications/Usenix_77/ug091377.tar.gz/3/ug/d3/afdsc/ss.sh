: String command and argument files together
: Written by Charles Muir, AFDSC, Feb 1977
: 
: loop
if $1x = x goto finish
ed - $1 >>sstmp
1,$p
q
shift
goto loop
: finish
/etc/nonl <sstmp >sstmp1
sh sstmp1
rm sstmp
rm sstmp1
exit
