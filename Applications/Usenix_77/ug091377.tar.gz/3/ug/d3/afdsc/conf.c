#include	"/mnt/muir/con-source/con.h"
/*
*	misc declarations
*/
int     i;						/* for statement incrementor		 */
int     l;						/* number of characters read		 */
int     prid;						/* process id of the children		 */
char    buf[BUFLEN];					/* the children's buffer		 */
int     catch ();					/* catch interupts to parent	 */
main (argc, argv)
int     argc;
char   *argv[];
{
    read (PIPER, &p, PSIZE);
    nice (-1);
    loop
    {
	signal (SIGQIT, catch);
	signal (SIGINT, catch);
	while ((l = read (p.fri, buf, BUFLEN)) > 0)
	    {
	    write (p.comm[1], buf, l);
	    sleep (1);
	    }
    }
}
catch ()
{
    signal (SIGINT, catch);
    signal (SIGQIT, catch);
    return;
}
