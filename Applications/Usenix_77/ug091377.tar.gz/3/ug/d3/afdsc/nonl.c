/*
 *	Strip all but last newline
 *	Written by Charles Muir, AFDSC, Feb 1977
 */
main(){
	char c;
	while((c = getchar()) != '\0') {
		if (c == '\n')
			c = 040;
		putchar(c);
	}
	putchar('\n');
}
