{ Copyright (C) 1981 by Bell Laboratories, Inc., and Whitesmiths Ltd. }
.NM linecount count lines in input
.SY
.UL "linecount"
.FU
.UL linecount
counts the lines in its input and writes the total as a line of
text to the output.
.EG
.Q1
linecount
A single line of input.
<ENDFILE>
.S 1
.Q2
