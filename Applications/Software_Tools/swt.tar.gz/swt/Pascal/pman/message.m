{ Copyright (C) 1981 by Bell Laboratories, Inc., and Whitesmiths Ltd. }
.NM message print a message and continue
.SY
.UL "procedure message ('your message here');"
.FU
.UL message
writes the literal string specified to a highly visible place,
such as the user's terminal,
then continues execution.
.RE
Nothing.
