/*
 *	malloc.c
 */

#include "h\types.h"
#include "h\param.h"
#include "h\malloc.h"

struct map coremap[CMAPSIZ];
struct map swapmap[SMAPSIZ];

/*#define BEST_FIT	*/	/* define if want alloc with best fit	*/
#define SWAPTEST		/* test swapper with small memory	*/

#ifdef BEST_FIT
/*
 * allocate core or swap using best fit algorithm
 */

gaddr_t malloc(mp,size)
register struct map *mp;
dword size;
	{
	register struct map *bp;
	register struct map *bfp=0;

	dword rv,a=0xffffffffL;
	for (bp=mp;bp->m_size;bp++)
		{
		if (bp->m_size>=size)
			{
			if (bp->m_size<a)
				{
				a=bp->m_size;
				bfp=bp;
				}
			}
		}
	if ((bp=bfp)==0)
		{
		return(0);
		}
	rv=bp->m_addr;
	bp->m_addr+=size;
	if ((bp->m_size-=size)==0)
		do
		{
		bp++;
		(bp-1)->m_addr=bp->m_addr;
#pragma warn -pia
		} while ((bp-1)->m_size =bp->m_size);
#pragma warn +pia
	return(rv);
	}
#else	/* def BEST_FIT */

/*
 *  use first fit algorithm
 */

gaddr_t malloc (mp,size)
struct map *mp;
dword size;
	{
	gaddr_t a;
	register struct map *bp;

	for (bp=mp;bp->m_size;bp++)
		{
		if (bp->m_size>=size)
			{
			a=bp->m_addr;
			bp->m_addr+=size;
			if ((bp->m_size-=size)==0)
				do
					{
					bp++;
					(bp-1)->m_addr=bp->m_addr;
					}
#pragma warn -pia
				while ((bp-1)->m_size=bp->m_size);
#pragma warn +pia
			return (a);
			}
		}
	return (0);
	}

#endif /* def BEST_FIT */

/*
 * free allocated core or swap
 */

void mfree(mp,size,a)
struct map *mp;
dword size;
gaddr_t a;
	{
	register struct map *bp;
	dword t;
#ifdef SWAPTEST
extern frem;
if (mp==coremap)
if (a<((gaddr_t)frem<<4))
return;
if (size==0)
return;
#endif
	for (bp=mp;bp->m_addr<=a && bp->m_size!=0;bp++) ;
	if (bp>mp &&(bp-1)->m_addr+(bp-1)->m_size==a)
		{
		(bp-1)->m_size+=size;
		if (a+size==bp->m_addr)
			{
			(bp-1)->m_size+=bp->m_size;
			while(bp->m_size)
				{
				bp++;
				(bp-1)->m_addr=bp->m_addr;
				(bp-1)->m_size=bp->m_size;
				}
			}
		}
	else
		{
		if (a+size==bp->m_addr && bp->m_size)
			{
			bp->m_addr-=size;
			bp->m_size+=size;
			}
		else if (size) do
				{
				t=bp->m_addr;
				bp->m_addr=a;
				a=t;
				t=bp->m_size;
				bp->m_size=size;
				bp++;
				}
#pragma warn -pia
				while(size=t);
#pragma warn +pia
		}
	}

