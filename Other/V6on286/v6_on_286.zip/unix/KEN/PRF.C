/*
 *	prf.c
 *	kernel printf & co
 */

#include "h\types.h"
#include "h\param.h"
#include "h\buf.h"
#define printf _STUPID_BORLAND_C_
#include "h\systm.h"
#undef printf

/* panic eseten a panic szovegre mutat a coredump bol megnezheto	*/

char *panicstr;


/* konzol printf nem IT vezerelt, de gyors mivel video membe ir		*/

void coout(char);
#define putchar(c)	coout(c)

void printi(unsigned int,unsigned int);
void printl(unsigned long,unsigned int);

void printf(p,x)
char *p;

	{
	register void *arg;
	register char *cp;
	int c;

	arg=&x;
#pragma warn -pia
	while (c=*(p++))
#pragma warn +pia
		{
		if (c=='\n') putchar('\r');
		if (c=='%')
			{
			switch (c=*(p++))
				{
				case'c':
					 putchar(*((int*)arg)++);
					 break;
				case's':
					 cp=*((char**)arg)++;
#pragma warn -pia
					 while (c=(int)*cp++)
#pragma warn +pia
						putchar(c);
					 break;
				case'u':
					 printi(*((int*)arg)++,10);
					 break;
				case'x':
					 printi(*((int*)arg)++,16);
					 break;
				case'X':
					 printl(*((long*)arg)++,16);
					 break;
				case'l':
					 printl(*((long*)arg)++,10);
					 break;
				default: putchar(c); break;
				}
			}

		 else
			{
			 putchar(c);
			}
		}
	}

static char digits[]="0123456789ABCDEF";

void printi(i,r)
unsigned int i,r;
	{
	register a;
#pragma warn -pia
	if (a=i/r)
#pragma warn +pia
		printi(a,r);
	putchar(digits[i%r]);
	}

void printl(i,r)
unsigned long i;
unsigned int r;
	{
	unsigned long a;
#pragma warn -pia
	if (a=i/r)
#pragma warn +pia
		printl(a,r);
	putchar(digits[(int)(i%r)]);
	}
void panic(s)
char *s;
	{
	panicstr=s;
	update();
	printf("Panic: %s\n",s);
	lock();
printf ("Hit Esc to reboot!\n");
while (inbyte(0x60)!=1);
	closedevices();
	reboot();
	}

void prdev(str,dev)
char *str;
int dev;
	{
	printf ("prdev\n");

//	printf("%s on dev %u/%u\n",str,major(dev),minor(dev));
	}

void deverr(bp,o1,o2)
register struct buf *bp;
	{
	prdev("Error",bp->b_dev);
	printf("Block%u Error%x %x\n",bp->b_blkno,o1,o2);
	} 