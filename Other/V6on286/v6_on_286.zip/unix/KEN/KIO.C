/*      ## KIO.C ##
	(c) Szigeti Szabolcs	1992 mar 2.


	Ideiglenes kernel I/O rutinok a konzol
	driver megvalositasaig

							*/
#define ESC 27		/* Az ESC karakter	*/
#define CLS 1		/* Kepernyo torles	*/
#define CUP 2		/* Kurzor fel		*/
#define CDN 3		/* Kurzor le		*/
#define CRG 4		/* Kurzor jobbra	*/
#define CLF 5		/* Kurzor balra		*/
#define ATT 6		/* Attributum allitas	*/
#define HOM 14		/* Kurzor sarokba	*/
#include "h\param.h"


void vid_put(char,word,byte);	/* karakter kiiras pozicio es attributummal*/
void scroll_up();		/* kepernyo scroll fel	*/
void clear_screen();		/* keprenyo torles	*/
static int lin_beg[]={0,160,320,480,640,800,960,1120,1280,1440,
		1440,1600,1760,1920,2080,2240,2400,2560,2720,
		2880,3040,3200,3360,3520};
char * itoa(int,char*);
char * itox(int,char*);

putco (chr)
char chr;
	{
	static char esc_flag=0,attr_flag=0,attr=7;
	static int pos_y=0,pos_x=0;
	
	if (attr_flag)	{
			attr_flag=0;
			attr=chr;
			return;
			}
	if (esc_flag)
			{
			esc_flag=0;
			switch(chr)
				{
				case ATT :	attr_flag=1;
						return;
				case CUP :	if (--pos_x)
							pos_x=0;
				case CDN :	if (pos_y>23)
							scroll_up(attr);
						else
							pos_y++;
						return;
				case CRG :	if ((++pos_x)>79)
							{
							pos_x=0;
							if (pos_y>23)
								{
								scroll_up(attr);
								pos_y=23;
								}
							else
								pos_y++;
						}
						return;
				case CLF :	if (--pos_x<0)
							{
							pos_x=79;
							if (--pos_y<0)
								{
								pos_y=0;
								}
							}
						return;

				case CLS :	clear_screen(attr);
				case HOM :	pos_x=pos_y=0;
						return;

				default:	break;
				}

			}


	switch (chr)
		{
	   	case ESC  :	esc_flag=1;
				return;

		case '\r' :	pos_x=0;
				return;
		case '\n' :    	pos_x=0;
				if (pos_y>23)
					{
					scroll_up(attr);
					pos_y=23;
					}
				else
					pos_y++;
				return;

		case '\t' : 	if ((pos_x+=10)>79)
					{
					pos_x%=80;
					if (pos_y>23)
						scroll_up(attr);
					else
						pos_y++;
					}
				return;
		default:        vid_put(chr,lin_beg[pos_y]+(pos_x<<1),attr);
				if ((++pos_x)>79)
					{
					pos_x%=80;
					if (pos_y>23)
						{
						scroll_up(attr);
						pos_y=23;
						}
					else
						pos_y++;
					}
				return;

		}

	}

int printf(p,x)
char *p;
int x;

	{
	void *arg;
	char x_c,*x_cp,lin_buf[21];
	int  x_i;
	arg=&x;
	while (x_c=*(p++))
		{
		if (x_c=='%')
			{
			switch (x_c=*(p++))
				{
				case'c': x_c=(char)*(int*)arg;
					 ((int*)arg)++;
					 putco(x_c);
					 break;
				case's': x_cp=*(char**)arg;
					 ((char**)arg)++;
					 while (x_c=*(x_cp++))
						putco (x_c);
					 break;
				case'u': x_i=*(int*)arg;
					 ((int*)arg)++;
					 x_cp=itoa(x_i,lin_buf);
					 while (x_c=*(x_cp++))
						putco (x_c);
					 break;
				case'x': x_i=*(int*)arg;
					 ((int*)arg)++;
					 x_cp=itox(x_i,lin_buf);
					 while (x_c=*(x_cp++))
						putco (x_c);
					 break;
				default: putco(x_c); break;
				}
			}

		 else
			{
			 putco(x_c);
			}
		}
	}