/*      ## GLO.C ##
	(c) Szigeti Szabolcs	1992 jan 28.

		Globalis valtozokat es konstansokat deklaralo file


								      */
 

#include "h\param.h"
#include "h\user.h"
#include "h\proc.h"

#undef	EXTERN   /*	A glo.h-ban talalhato globalis deklaraciok 	*/
#define EXTERN	 /*	fizikailag itt deklaralodnak azaltal, hogy      */
		 /*	az EXTERN uresse valtozik			*/

#include "h\glo.h"
