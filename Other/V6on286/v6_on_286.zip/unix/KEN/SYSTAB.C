/*      ## SYSTAB.C ##

	(c)     Szigeti Szabolcs 1992 mar 28

	rendszerhivasok belepesi ponjainak ugrotablaja                  */


nosys();nullsys();gtime();stime();setgid();getgid();setuid();getuid();
sslep();getpid();nice();read();write();open();creat();close();seek();
link();mknod();unlink();update();chdir();chmod();chown();stat();fstat();
smount();sumount();smdate();update();times();kill();stty();gtty();rexit();
fork();wait();dup();pipe();ssig();exec();sbreak();getswit();lseek();
profil();shdwn();

(*sysent[])()=
		{
		nullsys,/*  0                           */
		rexit,  /*  1 exit                      */
		fork,   /*  2 fork                      */
		read,   /*  3 read                      */
		write,  /*  4 write                     */
		open,   /*  5 open                      */
		close,  /*  6 close                     */
		wait,   /*  7 wait                      */
		creat,  /*  8 creat                     */
		link,   /*  9 link                      */
		unlink, /* 10 unlink                    */
		exec ,  /* 11 exec                      */
		chdir,  /* 12 chdir                     */
		gtime,  /* 13 gettime                   */
		mknod,  /* 14 mknod                     */
		chmod,  /* 15 chmod                     */
		chown,  /* 16 chown                     */
		sbreak, /* 17 break                     */
		stat,   /* 18 stat                      */
		seek,   /* 19 old 16 bit seek           */
		getpid, /* 20 getpid                    */
		smount, /* 21 mount                     */
		sumount,/* 22 umount                    */
		setuid, /* 23 setuid                    */
		getuid, /* 24 getuid                    */
		stime,  /* 25 settime                   */
		nosys,  /* 26 ptrace                    */
		nosys,  /* 27 X		                */
		fstat,  /* 28 fstat                     */
		nosys,  /* 29 X                         */
		smdate, /* 30 smdate                    */
		stty,   /* 31 stty                      */
		gtty,   /* 32 gtty                      */
		nosys,  /* 33 X                         */
		nice,   /* 34 nice                      */
		sslep,  /* 35 sleep                     */
		update, /* 36 sync                      */
		kill,   /* 37 kill                      */
		getswit,/* 38 switch                    */
		nosys,  /* 39 X                         */
		nosys,  /* 40 X                         */
		dup  ,  /* 41 dup                       */
		pipe ,  /* 42 pipe                      */
		times,  /* 43 times                     */
		profil, /* 44 prof                      */
		nosys,  /* 45 X                         */
		setgid, /* 46 setgid                    */
		getgid, /* 47 getgid                    */
		ssig ,  /* 48 sig                       */
		nosys,  /* 49 X                         */
		lseek,  /* 50 lseek                     */
		shdwn,  /* 51 shutdown                  */
		nosys,  /* 52 X                         */
		nosys,  /* 53 X                         */
		nosys,  /* 54 X                         */
		nosys,  /* 55 X                         */
		nosys,  /* 56 X                         */
		nosys,  /* 57 X                         */
		nosys,  /* 58 X                         */
		nosys,  /* 59 X                         */
		nosys,  /* 60 X                         */
		nosys,  /* 61 X                         */
		nosys,  /* 62 X                         */
		nosys,  /* 63 X                         */
		nosys	/* 64 X				*/
		};
