#ifdef STANDSH
#include "h\types.h"
#include "h\param.h"
#include "h\buf.h"
#include "h\inode.h"
int fprintf(f,p,x)
int f;
char *p;
int x;

	{
	void *arg;
	char x_c,*x_cp,lin_buf[21];
	int  x_i;
	arg=&x;
	while (x_c=*(p++))
		{
		if (x_c=='\n') uputc(f,'\r');
		if (x_c=='%')
			{
			switch (x_c=*(p++))
				{
				case'c': x_c=(char)*(int*)arg;
					 ((int*)arg)++;
					 uputc(f,x_c);
					 break;
				case's': x_cp=*(char**)arg;
					 ((char**)arg)++;
					 while (x_c=*(x_cp++))
						uputc (f,x_c);
					 break;
				case'u': x_i=*(int*)arg;
					 ((int*)arg)++;
					 x_cp=uitoa(x_i,lin_buf);
					 while (x_c=*(x_cp++))
						uputc (f,x_c);
					 break;
				case'x': x_i=*(int*)arg;
					 ((int*)arg)++;
					 x_cp=uitox(x_i,lin_buf);
					 while (x_c=*(x_cp++))
						uputc (f,x_c);
					 break;

				default: uputc(f,x_c); break;
				}
			}

		 else
			{
			 uputc(f,x_c);
			}
		}
	}


uitoa(n, s)
char *s;
register int n;
	{
	int sign;
	register char *ptr;
	ptr = s;
	if ((sign = n) < 0) n = -n;
	do
		{
		*ptr++ = n % 10 + '0';
		}
	while ((n = n / 10) > 0);
	if (sign < 0) *ptr++ = '-';
	*ptr = '\0';
	ureverse(s);
	return(s);
  }

uitox(n,s)
char *s;
register unsigned int n;
	{
	register char *ptr;
	ptr=s;
	do
		{
		*ptr=n%16;
		*ptr+=(*ptr<10)?'0':'A'-10;
		ptr++;
		}
	while ((n=n/16)>0);
	*ptr='\0';
	ureverse(s);
	return(s);
	}

ureverse(s)
char *s;
	{
	char *j;
	int c;
	j = s + ustrlen(s) - 1;
	while(s < j)
		{
		c = *s;
		*s++ = *j;
		*j-- = c;
		}
	}
ustrlen(s)
char *s;
	{
	char *p;
	int len;
	p=s;
	len=0;
	while(*p++) len++;
	return (len);
	}
uputc(f,c)
int f;
char c;
	{
	static char pcc;
	pcc=c;
	sys_x(4,f,&pcc,1,0);
	}
uatoi(c,bas)
char *c,bas;
	{
	int rv=0;
	while(*c==' '||*c=='\t')
		(*c)++;
	while(*c<'0'+bas&&*c>='0')
		{
		rv*=bas;
		rv+=*c-'0';
		c++;
		}
	return(rv);
	}

#endif	/* STANDSH */