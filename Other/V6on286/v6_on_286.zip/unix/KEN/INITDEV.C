/*	## inidev.c##
								*/
#include "h\machine.h"

initdevices()
	{
	lock1();
	initclock();
	initcon();
	}
closedevices()
	{
	lock1();
	outbyte (IT1_MASK,~0);
	outbyte (IT2_MASK,~0);
	closeclock();
	closecon();
	reboot();
	}