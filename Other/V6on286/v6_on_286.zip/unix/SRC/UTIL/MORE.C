/*
 * more [file]
 */

#define LINES	22

int l;

main(argc,argv)
char *argv[];

	{
	extern int fin;
	int i=1;

	if (argc==1)
		more ();
	while (--argc)
		{
		l++;
		if ((fin=open(argv[i++]))<0)
			{
			printf ("%s cannot open\n",argv[i-1]);
			}
		else
			{
			printf ("::%s::\n",argv[i-1]);
			more ();
			}
		}
	exit(0);
	}
more ()
	{
	register int c;
	register int p;

	if ((c=getchar())==0)
		return;
	if (
