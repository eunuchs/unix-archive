/* Simple shell:
 *		Command [args [args..]] [&]
 *		& - run in background
 *
 *	Max line no 80 char;
 */

#define NAR	20
char comm[80];	/* command buffer */

int si=-1,so=-1,se=-1;
int n=0;
char *exp,bck;
int args[NAR],ap;
int wst,wpid;
sigi();

main()
	{
	signal(2,sigi);
	close(0); close (1); close(2);
	si=open("/dev/console",0);
	so=open("/dev/console",1);
	se=open("/dev/console",1);
printf("SimpleShell:%u\n",getpid());
	for(;;)		/* process loop */
		{
		bck=1;
		write(so,"$>",2);
		n=read (si,comm,80);
		procbuf();
		if(fork())
			{
			if (bck)
				while((wpid=wait(&wst))!=-1)
				printf("[%u] exit:%u\n",wpid,wst);
			}
		else
			{
			signal (2,0);
			exec (exp,args);
			write (1,"Bad command\n",12);
			exit(-1);
			}
		}
	}
procbuf()
	{
	register char *rp;
	rp=comm;
	for (ap=0;ap<5;args[ap++]=0);
	ap=0;
	comm[n]=0;
	while(*rp==' '||*rp=='\t') rp++;
	args[ap++]=exp=rp;
	while (rp<=&comm[n])
		{
		if (*rp=='&')
			bck=0;
		if (*rp==' '||*rp=='\t'||*rp=='\r'||*rp=='\n')
			{
			*rp++=0;
			while(*rp==' '||*rp=='\t') rp++;
			args[ap++]=rp;
			}
		rp++;
		}
	}
sigi()
	{
	write (1,"Signal\n",7);
	signal (2,sigi);
	}