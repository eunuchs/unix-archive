/*
 * sync
 */

main()
	{
	sync();
	}
