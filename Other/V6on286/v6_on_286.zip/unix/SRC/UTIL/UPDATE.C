/*
 *	update  
 *
 *	syncs at every 30 seconds
 */

#include "..\..\include\signal.h"

#define	UPDTIME	30

main()
	{
	if (fork())
		{
		exit(0);
		}

	close (0);	/* Close std i/o files	*/
	close (1);
	close (2);
			/* Ignore fatal signals	*/
	signal (SIGHUP,SIG_IGN);
	signal (SIGINT,SIG_IGN);
	signal (SIGQIT,SIG_IGN);

	for (;;)
		{
		sync();
		sleep (UPDTIME);
		}
	}