/*	UNIX cat 
 *
 *	cat [file][...]
 *		copy file(s) to stdout;
 *		copy stdin to stdout;
 */

#define SECTSIZ	512
#define STDIN	0
#define STDOUT	1

char buf[SECTSIZ];

main(argc,argv)
char *argv[];
	{
	register f,i;
	int err=0;
	if (argc<2)
		{
		cat (STDIN);
		exit (0);
		}
	for(i=1;i<argc;i++)
		{
		if (*(int*)argv[i]=='-\0')
			f=STDIN;
		else
		if ((f=open(argv[i],0))<0)
			{
			perror (argv[i]);
			err++;
			continue;
			}
		cat(f);
		close(f);

		}
	exit(err);
	}
cat(f)
register f;
	{
	register br;

	while ((br=read(f,buf,SECTSIZ))>0)
		{
		write(STDOUT,buf,br);
		}
	}
