#
/*
 *	mkdir dirnam
 */


char nambuf[18];

main(argc,argv)
int argc;
char *argv[];
	{
	register char *rp=nambuf;
	if (argc<2)
		{
		printf("Usage: %s dirname\n",argv[0]);
		exit(1);
		}
	strcpy (nambuf,argv[1]);
	while (*rp)rp++;
	if (mknod(argv[1],040755,0)==-1)
		{
		perror("Mknod");
		exit(1);
		}
	*rp++='/';
	*rp++='.';
	*rp=0;
	if (link(argv[1],nambuf)==-1)
		{
		perror("Link");
		exit(1);
		}
	*rp++='.';
	*rp=0;

	if (link(".",nambuf)==-1)
		{
		perror("Link");
		exit(1);
		}
	sync();
	}