/*
 *	echo [-n] [text..]
 *
 *	Echos text to stdout 
 *	-n : no new line at end of line
 */

int nlflg=1;

void main(argc,argv)
int argc;
char *argv[];
	{
	register char *c;
	register int i;
	i=1;
	if (argc>1)
		if (*(int*)argv[1]=='-n')
			{
			nlflg=0;
			i++;
			}

	while(i<argc)
		{
		for(c=argv[i];*c;c++);
		write(1,argv[i],c-argv[i]);
		if (i+1<argc)
			write(1," ",1);
		i++;
		}
	if (nlflg)
		write(1,"\n",1);
	exit(0);
	}