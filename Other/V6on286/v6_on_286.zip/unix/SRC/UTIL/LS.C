/*
 * ls
 */
#include "..\..\include\sys\stat.h"
#include "..\..\include\sys\dir.h"
 
#define	minor(x)	((x)&0xff)	/* minor device szam		*/
#define major(x)	((x)>>8)	/* major device szam		*/

main(argc,argv)
char *argv[];
	{
	ls();
	exit(0);
	}
ls()
	{
	int lfp;	/* file pointer . -ra	*/
	int i;
	static struct stat statb;
	static struct dir dirb;
	static char nb[15];

	if ((lfp=open(".",0))==-1)
		{
		perror("open");
		return ;
		}
	while (read(lfp,&dirb,L_DIR)==L_DIR)
		{
		if (dirb.dir_i)
			{
			for(i=0;i<14;i++)
				{
				if (dirb.dir_nam[i]==0)
					{
					nb[i+1]=0;
					break;
					}
				nb[i]=dirb.dir_nam[i];
				}
			stat(nb,&statb);
			switch(statb.s_flags&S_TYPE)
				{
				case S_PLAIN: i='-';
						break;
				case S_DIREC: i='d';
						break;
				case S_CHAR:  i='c';
						break;
				case S_BLOCK: i='b';
						break;
				}
			printf ("%c",i);
			printf ("%c%c%c",(statb.s_flags&0400)?'r':'-',
					    (statb.s_flags&0200)?'w':'-',
			(statb.s_flags&0100)?((statb.s_flags&04000)?'s':'x'):'-');
			printf ("%c%c%c",(statb.s_flags&0040)?'r':'-',
					    (statb.s_flags&0020)?'w':'-',
			(statb.s_flags&0010)?((statb.s_flags&02000)?'s':'x'):'-');
			printf ("%c%c%c ",(statb.s_flags&0004)?'r':'-',
					    (statb.s_flags&0002)?'w':'-',
					    (statb.s_flags&0001)?'x':'-');
		if ((statb.s_flags&S_TYPE)!=S_CHAR&&
		    (statb.s_flags&S_TYPE)!=S_BLOCK)
		    {
			printf ("%3u %3u/%3u ",statb.s_nlinks,statb.s_gid,
				statb.s_uid);
			printf ("%7u ",statb.s_size1);
		    }
		else
			printf ("%3u %3u/%3u         ",statb.s_nlinks,major(statb.
				s_addr[0]),minor(statb.s_addr[0]));
			printf ("%-14s %s",nb,ctime(statb.s_modtime));
			}
		for(i=0;i<14;nb[i]=dirb.dir_nam[i]=0)i++;

		}
	close(lfp);
	}