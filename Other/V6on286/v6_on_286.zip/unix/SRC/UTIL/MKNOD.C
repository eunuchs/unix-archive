main(argc, argv)
int argc;
char **argv;
{
	int m, a, b;

	if(argc != 5)
		{
		printf("arg count\n");
		goto USAGE;
		}

	if(*argv[2] == 'b')
		m = 0160666; 		/* brw-rw-rw	*/
	else

		if(*argv[2] == 'c')
			m = 0120666;	/* crw-rw-rw	*/
		else
			goto USAGE;

	a = atoi(argv[3]);            	/* major dev no	*/
	if(a < 0)
		goto USAGE;

	b = atoi(argv[4]);              /* minor dev no	*/
	if(b < 0)
		goto USAGE;

	if(mknod(argv[1], m, (a<<8)|b) < 0)
		{
		perror("mknod");
		exit(1);
		}
	exit(0);

USAGE:
	printf("usage: mknod name b/c major minor\n");
	exit (1);
}

