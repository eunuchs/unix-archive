/*
 * sleep time
 *
 *	returns with 0 after time has elapsed
 *	returns 1 if bad args
 */

main(argc,argv)
char *argv[];
	{
	unsigned int fortime;
	register char *s;
	register int   c;

	if (argc<2)
		{
		write(2,"arg count\n",10);
		exit(1);
		}
	s=argv[1];
	fortime=0;

	while(c=(int)*s++)
		{
		if(c<'0' || c>'9')
			{
			write(2,"bad character\n",14);
			exit (1);
			}
		fortime=10*fortime+c-'0';
		}
	sleep(fortime);
	exit(0);
	}