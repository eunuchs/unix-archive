/*
 * date
 *
 *	Prints date 
 */

#define CTIMESIZ	25	/* length of string from ctime()	*/

long time();
char *ctime (long*);
write (int,char*,int);

main()
	{
	long ti;
	time(&ti);
	write (1,ctime(&ti),CTIMESIZ);
	return (0);
	}
	
