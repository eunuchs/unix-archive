/*
 *	kill.c [-sig] pid
 *
 *	send signal sig or SIGINT to proc id pid
 */

#include "..\..\include\stdio.h"
#include "..\..\include\signal.h"

main (argc,argv)
int argc;
char *argv[];
	{
	int k_sig=SIGTERM;
	int k_pid;
	extern int fout;

	fout =2;

	if (argc<2)
		{
		printf ("Arg count\n");
		goto USAGE;
		}
	if (argc==2)
		if(*argv[1]!='-')
			k_pid=atoi(argv[1]);
		else
			goto USAGE;

	if (argc>2)
		if(*(argv[1]++)=='-')
			{
			k_pid=atoi(argv[2]);
			k_sig=atoi(argv[1]);
			}
		else
			goto USAGE;

	if (kill(k_pid,k_sig))
		{
		perror ("kill");
		exit (2);
		}
	exit (0);
USAGE:
	printf ("Usage: %s [-sig] pid\n",argv[0]);
	exit (1);
	}