/*
 * strcmp (s,t)
 * char *s,*t;
 *
 * compare s and t
 */

strcmp (s,t)
register char *s,*t;
	{
	while (1)

		{
		if (*s<*t)
			return(-1);
		else
		if (*s>*t)
			return(1);
		else
		if (*s==0 && *t==0)
			return(0);
		s++;
		t++;
		}
	}