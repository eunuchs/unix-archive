/*
 * int abs(int)
 * double fabs(double)
 *
 * return absolute value
 */

abs (x)
	{
	return ( x<0 ? -x : x );
	}
fabs (x)
	{
	abort();
	}
