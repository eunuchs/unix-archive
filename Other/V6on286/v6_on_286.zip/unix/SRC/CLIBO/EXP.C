/*
 * double exp(double x)
 *
 * returns exponetial of x
 */

double exp(x)
double x;
	{
	abort();
	}
