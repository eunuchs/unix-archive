/*
 * dpadd(*long,int)
 *
 * long add
 */

dpadd (x,y)
long *x;
	{
	*x+=y;
	}
