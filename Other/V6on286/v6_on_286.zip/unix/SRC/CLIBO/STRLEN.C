/*
 * strlen (s)
 * char *s;
 *
 * returns length of s
 */

unsigned strlen(s)
register char *s;
	{
	register unsigned n=0;

	while (*s++) n++;

	return(n);
	}