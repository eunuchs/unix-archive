/*
 * char *locv(hi,lo)
 *
 * signed long to ascii
 */

static char buf[13];

char * locv(hi,lo)
	{
	long x=((long)hi<<16)+lo;
	register char *c=&buf[12];
	int sflg=0;

	*c--='\0';
	*c  ='0';
	if (x==0)
		return (c);
	if (x<0)
		{
		x= -x;
		sflg++;
		}

	while (x>0)
		{
		*c-- = (x%10)+'0';
		x /= 10;
		}
	return (c+1);
	}
	
