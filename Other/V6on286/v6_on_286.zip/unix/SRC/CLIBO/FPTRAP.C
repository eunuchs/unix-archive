/*
 * fptrap 
 */

fptrap()
	{
	}
