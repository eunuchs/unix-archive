/*
 * int getc(struct iobuf* )
 * int getw(struct iobuf* )
 * int fopen(char*,struct iobuf*)
 *
 * buffered input
 */

#include "bufio.h"

/*
 * open file for reading
 */

fopen(name,iob)
char *name;
struct ibuf *iob;
	{
	register int fd;

	if (( fd = open(name,0) ) < 0)
		return (-1);

	iob->fildes = fd;
	iob->nleft  = 0;
	iob->nextp  = iob->buff;

	return(0);
	}

/*
 * get one char from iobuf
 */

getc (iob)
struct ibuf *iob;
	{
	register int nb;
	if (iob->nextp==0)
		{
		iob->nextp=iob->buff;
		iob->nleft=0;
		}
	if (iob->nleft<=0)
		{
		nb=read(iob->fildes,iob->buff,512);
		if (nb<=0)
			return(-1);
		iob->nextp=iob->buff;
		iob->nleft=nb;
		}
	iob->nleft--;
	return(*iob->nextp++);
	}
/*
 * get one word from iobuf
 */

getw (iob)
struct ibuf *iob;
	{
	register int w=0,a;

	if ((w=getc(iob))==-1)
		return(-1);

	if ((a=getc(iob))==-1)
		return(-1);

	return ((a<<8)&0xff)+(w&0xff);
	}