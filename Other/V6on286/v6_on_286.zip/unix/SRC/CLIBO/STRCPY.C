/*
 * char * strcpy(s,t)
 * char *s,*t;
 *
 * copy t onto s;
 */

char *strcpy(s,t)
char *s;
register char *t;
	{
	register char *p=s;

	while (*p++=*t++);

	return(s);
	}