/*
 * perror(s)
 * char *s;
 *
 * int sys_nerr;
 * char *sys_errlist[];
 *
 */

char	*sys_errlist[] ={
	"Error 0",
	"Not super-user",
	"No such file or directory",
	"No such process",
	"Interrupted system call",
	"I/O error",
	"No such device or address",
	"Arg list too long",
	"Exec format error",
	"Bad file number",
	"No children",
	"No more processes",
	"Not enough core",
	"Permission denied",
	"Error 14",
	"Block device required",
	"Mount device busy",
	"File exists",
	"Cross-device link",
	"No such device",
	"Not a directory",
	"Is a directory",
	"Invalid argument",
	"File table overflow",
	"Too many open files",
	"Not a typewriter",
	"Text file busy",
	"File too large",
	"No space left on device",
	"Illegal seek",
	"Read-only file system",
	"Too many links",
	"Broken Pipe",
};
int	sys_nerr = sizeof (sys_errlist)/sizeof (sys_errlist[0]) ;
/*
 * Print the error indicated
 * in the cerror cell.
 */

extern int	errno;
perror(s)
char *s;
	{
	register char *c;
	register n;

	c = "Unknown error";
	if(errno < sys_nerr)
		c = sys_errlist[errno];
	n = strlen(s);
	if(n) {
		write(2, s, n);
		write(2, ": ", 2);
	}
	write(2, c, strlen(c));
	write(2, "\n", 1);
        return(0);
	}

