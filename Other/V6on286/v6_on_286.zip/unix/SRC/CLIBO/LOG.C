/*
 * double log (double x)
 *
 * natural log of x;
 */

double log(x)
double x;
	{
	abort();
	}