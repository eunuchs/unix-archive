/*
 * char *ecvt(double value,int ndigit,*decpt,*sign)
 * char *fcvt(double value,int ndigit,*decpt,*sign)
 *
 * convert float to asc prec is in _ndigits
 */

int _ndigits=6;

char *ecvt(value,ndigit,decpt,sign)
double value;
int *decpt,*sign;
	{
	abort();
	}

char *fcvt(value,ndigit,decpt,sign)
double value;
int *decpt,*sign;
	{
	abort();
	}

