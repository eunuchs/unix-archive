/*
 * double pow(x,y);
 * double x,y;
 *
 *          y
 * returns x
 */

double pow(x,y)
double x,y;
	{
	abort();
	}
