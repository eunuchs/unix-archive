/*
 * fcreat (file,iobuf)
 * char *file;
 * struct obuf *iobuf;
 *
 * putc(c,iobuf)
 * int c;
 * struct obuf *iobuf;
 *
 * putw(c,iobuf)
 * int c;
 * struct obuf *iobuf;
 *
 * fflush(iobuf)
 * struct obuf *iobuf;
 */

#include "bufio.h"

fcreat (file,buf)
char *file;
struct obuf *buf;
	{
	register fd;

	if ((fd=creat(file,0666))<0)
		return (-1);
	buf->fildes=fd;
	buf->nunused=512;
	buf->xfree=buf->buff;
	return (0);
	}
putc(c,buf)
struct obuf *buf;
	{
	if (buf->xfree==0)
		{
		buf->xfree=buf->buff;
		buf->nunused=512;
		}
	if (buf->nunused==0)
		fflush (buf);
	*buf->xfree++ =(char)c;
	buf->nunused--;
	return (c);
	}
putw(w,buf)
struct obuf *buf;
	{
	putc ((w>>8)&0xff,buf);
	putc (w&0xff,buf);
	return (w);
	}
fflush (buf)
struct obuf *buf;
	{
	if (buf->xfree==0)
		{
		buf->xfree=buf->buff;
		buf->nunused=512;
		}
	if (buf->nunused!=512)
		{
		write (buf->fildes,buf->buff,512-buf->nunused);
		buf->nunused=0;
		buf->xfree=buf->buff;
		}
	return (0);
	}
