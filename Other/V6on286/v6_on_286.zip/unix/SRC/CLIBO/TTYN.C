#include "../../include/sys/stat.h"
#define SECTOR 512

struct dir {
        int dir_i;
        char dir_nam[14];
};

struct stat sti;

ttyn(fil)
int fil;
{
  unsigned int v;
  char d[ SECTOR ];
  char dfil;
  register char *i, *j;
  struct dir *p;
  fstat(fil, &sti);
  dfil = open("/dev", 0);
  while ((v = read(dfil, d, SECTOR )) > 0) {
    v +=(unsigned int) d;
    for (p = d; p <(struct dir*) v; p ++)
      if (p->dir_i == sti.s_inumber) {
        i = p->dir_nam;
        j = "tty";
        while(*j)
          if (*j++ != *i++)
            return(0);
        return(*i);
      }
  }
  return(0);
}
