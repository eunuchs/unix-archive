/*
 * atoi(char*)
 *
 * convert asc to integer
 */

atoi(c)
register char *c;
	{
	register int n=0;
	int mflg=0;

	while ( *c == ' ' || *c == '\t' ) c++;
	if ( *c == '-' )
		{
		mflg++;
		c++;
		}
	while (0 <= *c && *c <= 9)
		{
		n *= 10;
		n += *c++ - '0';
		}
	return ( mflg ? n : -n );
	}