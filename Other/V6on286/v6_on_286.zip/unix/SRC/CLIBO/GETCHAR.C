/*
 * getchar()
 *
 * get one char from stdin
 */

#include "bufio.h"

struct ibuf fin=
		{
		0,
		0,
		fin.buff,
		{0}
		};


getchar()
	{
	register c;
	c=getc(&fin);
	return (c<0?0:c);
	}
