/*
 * double gamma (double x)
 *
 * gamma function
 */

double gamma (x)
double x;
	{
	abort();
	}
