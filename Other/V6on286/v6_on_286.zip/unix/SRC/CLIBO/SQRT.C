/*
 * double sqrt(x)
 * double x;
 *
 * returns square root of x
 */

double sqrt(x)
double x;
	{
	abort();
	}