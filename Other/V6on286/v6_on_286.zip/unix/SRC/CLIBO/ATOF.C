/*
 * double atof(char*)
 *
 * convert asc to double
 */

double atof(c)
char *c;
	{
	abort();
	}