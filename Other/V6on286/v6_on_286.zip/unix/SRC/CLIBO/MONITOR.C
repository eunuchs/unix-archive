/*
 * monitor(lowpc,highpc,buffer,bufsize)
 * int lowpc(),highpc(), buffer[], bufsize;
 *
 * interface to profile (II) syscall
 */

monitor(lowpc,highpc,buffer,bufsize)
int lowpc(),highpc(), buffer[], bufsize;
	{
	return profile(lowpc,highpc,buffer,bufsize);
	}