/*
 * char *strcat(s,t)
 * char *s,*t;
 *
 * concatenate t to s
 */

char *strcat(s,t)
char *s;
register char *t;
	{
	register char *p=s;

	while (*p) p++;
	while (*p++=*t++);

	return (s);
	}