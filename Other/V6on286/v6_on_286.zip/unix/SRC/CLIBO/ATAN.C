/*
 * double atan(double)
 * double atan2(double,double)
 *
 * returns arc tangent of x or x/y
 */

double atan(x)
double x;
	{
	abort();
	}

double atan2(x,y)
double x,y;
	{
	abort();
	}
