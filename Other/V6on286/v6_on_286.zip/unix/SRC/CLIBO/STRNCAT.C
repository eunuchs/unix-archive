/*
 * char strncat(s,t,n)
 * char *s,*t;
 * unsigned n;
 *
 * concatenate t to s at most n chars
 */

char *strncat(s,t,n)
char *s;
register char *t;
unsigned n;
      {
      register char *p=s;
      
      while (*p) p++;

      while ((--n)&&(*p++=*t++)) ;

      return(s);
      }