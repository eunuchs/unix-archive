/*
 * char * strncpy(s,t,n)
 * char *s,*t;
 * unsigned n;
 *
 * copy t onto s at most n chars;
 */

char *strncpy(s,t,n)
char *s;
register char *t;
unsigned n;
	{
	register char *p=s;

	while ((n--)&&(*p++=*t++));

	return(s);
	}