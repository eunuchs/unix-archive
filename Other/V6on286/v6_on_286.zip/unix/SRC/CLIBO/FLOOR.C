/*
 * double floor(double)
 * double ceil(double)
 *
 * returns ineger part or rounded part
 */

double floor(x)
double x;
	{
	abort();
	}

double ceil(x)
	{
	abort();
	}
