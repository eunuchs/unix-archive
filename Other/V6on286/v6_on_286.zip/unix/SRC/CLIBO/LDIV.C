/*
 * ldiv (int div,divisor)
 * lrem (int div,divisor)
 *
 * long divide and remainder
 */

int ldivr;	/* remainder */

ldiv (hid,div)
long hid;
	{
	ldivr=hid % div;
	return (hid / div);
	}

lrem (hid,div)
long hid;
	{
	return (hid%div);
	}