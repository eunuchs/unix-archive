/*
 * hmul (int x,y)
 *
 * returns the high 16 bits of x*y
 */


hmul (x,y)
	{
	return ( ( ( (long)x * (long)y ) >>16 ) & 0xffff);
	}