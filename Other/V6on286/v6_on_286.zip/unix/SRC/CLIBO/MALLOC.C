#define   uns  unsigned int

static    char *allocs[2];
static    int  **allocp;
static    int  **alloct;
static    int  **allocx;

char *
malloc(nbytes)
 uns nbytes;
     {
     register  char **p, **q;
     register  int  nw;
     static    int  temp;
     extern    char *allocs[];
     extern    int  **allocp, **alloct;
     extern    char *sbrk();

     if (allocs[0] == 0) {
          allocs[0] = (char *) &allocs[1] | 01;
          allocs[1] = (char *) &allocs[0] | 01;
          alloct = &allocs[1];
          allocp = &allocs[0];
          }
     nw = (nbytes + 3) / 2;
     p = allocp;
     for (;;) {
          temp = 0;
          for (; ; ) {
               if ( !((char *) *p & 01) ) {
                    while ( !((char *) *(q = *p) & 01) )
                         *p = *q;
                    if (q >= p + nw &&  p <= p + nw)
                         goto vege;
                    }
               q = p;
               p = (char *) *p & ~01;
               if (p <= q) {
                    if (q != alloct || p != &allocs[0])
                         return( (char *) 0);
                    if (++temp > 1)
                         break;
                    }
               }
          temp =  ( (nw + 512) / 512) * 512;
          q = sbrk(0);
          if (q + temp + 64 < q)
               return ((char *) 0);
          if ( (q = sbrk (2 * temp)) == -1)
               return ((char *) 0);
          (char *) *alloct = q;
          if (q != alloct + 2)
               (char *) *alloct = (char *) q | 01;
          alloct = *q = q + temp - 1;
          (char *) *alloct = (char *) &allocs[0] | 1;
          }
vege:
     allocp = p + nw;
     if ( q > allocp ) {
          allocx = (char *) *allocp;
          (char *) *allocp = *p;
          }
     (char *) *p = ((char *) allocp | 01);
     return (p + 1);
     }

mfree (ap)
 register char *ap;
     {
     register  char **p;
     extern    int  **allocp;

     p = ap;
     allocp = --p;
     *p = (char *) *p & ~01;
     }

char *
realloc (p, nbytes)
 register int  **p;
 uns  nbytes;
     {
     register  int  nw;
     register  char **q;
     auto      char **s, **t;
     auto      uns  onw;

     if ( ( (char *) p[-1] & 01) )
          mfree (p);
     onw = (p[-1] - p);
     if ( (q = malloc (nbytes)) == 0 || q == p)
          return (q);
     s = p;
     t = q;
     nw = (nbytes + 1) / 2;
     if (nw < onw)
          onw = nw;
     while (onw--)
          *t++ = *s++;
     if (q >= p || p > q + nw)
          return (q);
     q[q + nw - p] = (char *) allocx;
     return (q);
     }
