/*
 * char* crypt(char*)
 *
 * encrypt password (not original)
 */


static char code[][32]={
"56dekjIOcn879&*^V65$%@Vbf87$&#}@",
"&*^Bbg78$@bEfAEQ{MNdjyyu45cOPweg",
"&$B!@d&&BCq/sf++=123Esdfv]2341}{",
"IPO!(ZCApqz,cs043m+<>2#R&xcjq43'"
};

static char encr[32];

crypt(p)
register char *p;
	{
	register char *c=encr;
	int i=0;
	while(*p++)
		{
		if (c>&encr[31])
			{
			encr[31]='\0';
			break;
			}
		*c++=code[++i&3][(i+*p)&31];
		}
	return(encr);
	}


