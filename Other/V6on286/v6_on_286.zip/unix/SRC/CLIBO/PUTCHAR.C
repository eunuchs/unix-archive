/*
 * putchar(c)
 *
 * flush()
 */

#include "bufio.h"

struct obuf fout=
		{
		1,
		512,
		fout.buff,
		{0}
		};

putchar (c)
char c;
	{
	if (c==0)
		return;
	if (fout.fildes<3)
		write (fout.fildes,&c,1);
	else
		putc (c,&fout);
	}

flush ()
	{
	fflush (&fout);
	}

