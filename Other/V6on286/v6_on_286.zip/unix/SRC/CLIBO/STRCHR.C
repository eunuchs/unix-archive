/*
 * char *strchr(s,c)
 * char *s,c;
 *
 * returns pointer to firs c in s
 */

char *strchr(s,c)
register char *s;
char c;
	{
	register int ch=(int)c&0xff;

	while (*s)
		{
		if (*s==(char)ch)
			return(s);
		s++;
		}
	return(0);
	}