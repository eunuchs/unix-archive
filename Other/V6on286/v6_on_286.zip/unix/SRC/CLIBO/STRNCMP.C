/*
 * strncmp (s,t,n)
 * char *s,*t;
 * unsigned n;
 *
 * compare s and t at most n chars
 */

strncmp (s,t,n)
register char *s,*t;
unsigned n;
	{
	while (n--)

		{
		if (*s<*t)
			return(-1);
		else
		if (*s>*t)
			return(1);
		else
		if (*s==0 && *t==0)
			return(0);
		s++;
		t++;
		}
	return (0);
	}