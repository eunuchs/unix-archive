/*
 * nlist (filename,nl)
 * char *filename;
 * struct {
 *	  char name[8];
 *	  int type;
 *	  int value;
 *	  } *nl;
 *
 * returns symbol table of filename
 */

struct sym
	{
	char name[8];
	int type;
	int value;
	};

nlist(file,nl)
char *file;
struct sym *nl;
	{
	abort();
	}

