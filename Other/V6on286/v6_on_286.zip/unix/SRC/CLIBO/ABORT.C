/*
 *	abort()
 *
 *	generate core image by executing illegal instruction
 */
#pragma inline

abort()
	{
	write (2,"Aborted\n",8);
	asm int 3;
	}
