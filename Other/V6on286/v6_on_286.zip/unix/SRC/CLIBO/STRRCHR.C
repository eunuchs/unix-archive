/*
 * char *strrchr(s,c)
 * char *s,c;
 *
 * returns pointer to last c in s
 */

char *strrchr(s,c)
register char *s;
char c;
	{
	register int ch=(int)c&0xff;
	unsigned n=strlen(s);
	s+=n;
	
	while (*s&&n--)
		{
		if (*s==(char)ch)
			return(s);
		s--;
		}
	return(0);
	}