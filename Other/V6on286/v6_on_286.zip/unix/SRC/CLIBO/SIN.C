/*
 * double sin(x)
 * double x;
 * double cos(x)
 * double x;
 *
 * returns sine (cosine) of x
 */

double sin(x)
double x;
	{
	abort();
	}
double cos(x)
double x;
	{
	abort();
	}