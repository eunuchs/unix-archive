char *
calloc (num, size)
 unsigned num, size;
     {
     register  char *mp;
     register  int  *q;
     register  int  m;
     extern    char *malloc();

     if (!(mp = malloc(num=num*size)) )
          return (0);
     q = mp;
     for (m = (num+1)>>1;  --m >= 0;  )
          *q++ = 0;
     return (mp);
     }

cfree(p, num, size)
 char *p;
 unsigned num, size;
     {
     return (free(p));
     }
