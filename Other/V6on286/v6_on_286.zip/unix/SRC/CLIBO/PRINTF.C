/*
 * printf (format,arg,...)
 * char *format;
 *
 * formatted output
 * format string : "%-5.7f"
 *    percent sign--^^^^^^
 *    left justify--- ||||
 *    field with------ |||
 *    period----------- ||
 *    precision--------- |
 *    format char--------
 *      d - decimal
 *	o - octal
 *	x - hexadecimal
 *	f - float [-]ddd.ddd format
 *	e - float [-]d.ddde+-dd
 *	c - char 
 *	s - string
 *	l - unsigned decimal
 */

static	int ljflg,fw,pr,prflg;
static  char xbuf[20];
printf (f,a)
char *f;
	{
	char *per;
	register char *fr=f;
	register char *cp;
	int *arg=&a;

	ljflg=fw=pr=prflg=0;

	while (*fr)
		{
		if (*fr!='%')
			{
			putchar (*fr++);
			continue;
			}
		per=++fr;

		if (*fr=='-')
			{
			ljflg++;
			fr++;
			}
		while('0'<=*fr && *fr<='9')
			{
			fw*=10;
			fw+=*fr++ -'0';
			}
		if (*fr=='.')
			{
			fr++;
			prflg++;
			while('0'<=*fr && *fr<='9')
				{
				pr*=10;
				pr+= *fr++ -'0';
				}		
			}
		switch (*fr)
			{
			case 'd':
				 putsr(itoa(*arg));
				 arg++;
				 break;

			case 'o':
				 putsr(utoa(*arg,8));
				 arg++;
				 break;
			case 'x':
				 putsr(utoa(*arg,16));
				 arg++;
				 break;
			case 'f':
				
			case 'e':
				 putsr(" Sorry no float.");
				 arg+=2;
				 break;
			case 'c':
				xbuf[0]=*arg;
				xbuf[1]=0;
				putsr(xbuf);
				arg++;
				break;

			case 's':
				if (prflg && pr==0) prflg=0;
				putsr(*arg);
				arg++;
				break;
					
			case 'l':
				 putsr(utoa(*arg,10));
				 arg++;
				 break;

			default:
				fr++;
				while (per<fr)
					putchar (*per++);
				fr--;
			}
			fr++;
		}
	}

static putsr(cp)
register char *cp;
	{
	int sl=strlen (cp);
	register int i;
	if (pr<sl && prflg) sl=pr;
	i=fw-sl;
	if (sl<fw&&!ljflg)
		{
		while (i--)
			putchar(' ');
		}
	while (*cp)
		{
		putchar (*cp++);
		if (--pr<0 && prflg) break;
		}
	if (sl<fw&&ljflg)
		{
		while (i--)
			putchar(' ');
		}
	}
static itoa(x)
register int x;
	{
	int sf=0;
	register char *cp=&xbuf[20];
	*cp-- =0;
	*cp='0';
	if (x==0)
		return(cp);
	if (x<0)
		{
		sf++;
		x=-x;
		}
	while(x>0)
		{
		*cp-- = x%10 +'0';
		x/=10;
		}
	cp++;
	if (sf)
		*--cp='-';
	return (cp);
	}
static utoa(x,r)
register unsigned x;
	{
	char *hx="0123456789abcdef";

	register char *cp=&xbuf[20];
	*cp--=0;
	*cp='0';
	if (x==0)
		return(cp);
	while (x>0)
		{
		*cp-- = hx[x%r];
		x/=r;
		}
	return (cp+1);
	}

