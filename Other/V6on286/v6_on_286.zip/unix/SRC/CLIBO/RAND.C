/*
 * srand(seed)
 *
 * rand()
 */

static seed;

srand (s)
	{
	seed=s;
	}
rand ()
	{
	register i;

	i=seed*13077;
	i+= 6925;
	seed=i;
	return (i&0x8fff);
	}