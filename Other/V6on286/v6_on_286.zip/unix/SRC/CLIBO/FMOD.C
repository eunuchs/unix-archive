/*
 * double fmod(double x,y)
 *
 * returns x % y 
 */

double fmod (x,y)
double x,y;
	{
	abort();
	}
