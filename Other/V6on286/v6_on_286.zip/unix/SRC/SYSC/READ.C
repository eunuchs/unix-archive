int sys_x();

int read(fp,buf,n)
int fp,*buf,n;
	{
	register rev;

	rev=sys_x(3,fp,buf,n,0);

	if (_BX)
		return -1;
	else
		return rev;
	}

