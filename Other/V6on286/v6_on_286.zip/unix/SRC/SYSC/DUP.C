int sys_x();

int dup(n)
	{
	register rev;

	rev=sys_x(41,n,0,0,0);

	if (_BX)
		return -1;
	else
		return rev;
	}
