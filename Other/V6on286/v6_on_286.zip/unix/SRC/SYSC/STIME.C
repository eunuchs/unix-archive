int sys_x();

int stime(d)
long d;
	{
	sys_x(25,d,0,0);

	if (_BX)
		return -1;
	else
		return 0;
	}
