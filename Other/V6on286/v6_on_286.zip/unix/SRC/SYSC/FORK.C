int par_uid;
int sys_x();

int fork()
	{
	register rev;

	rev=sys_x(2,0,0,0,0);

	if (_BX)
		return(-1);
	else
		{
		par_uid=_DX;
		return(rev);
		}
	} 

