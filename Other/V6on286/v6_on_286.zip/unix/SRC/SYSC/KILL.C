int sys_x();

int kill(p,s)
	{
	sys_x(37,p,s,0,0);

	if (_BX)
		return -1;
	else
		return 0;
	}
