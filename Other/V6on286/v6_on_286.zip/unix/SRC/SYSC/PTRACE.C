
ptrace(req,pid,addr,data)
	{
	sys_x(26,req,pid,addr,data);
	}