profil(buf,siz,off,scal)
	{
	sys_x(44,buf,siz,off,scal);
	}