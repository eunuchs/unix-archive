int sys_x();

int open(fn,m)
	{
	register rev;

	rev=sys_x(5,fn,m,0,0);

	if (_BX)
		return -1;
	else
		return rev;
	}
   