long sys_x();

long lseek(f,o,m)
long o;
	{
	long rev;

	rev=sys_x(50,f,o,m);

	if (_BX)
		return -1;
	else
		return rev;
	}

seek (f,o,m)
	{
	switch (m)
		{
		case 0:
			lseek(f,(unsigned long)o,m);
			break;
		case 1:
		case 2: lseek(f,(long)o,m);
			break;
		case 3:
			lseek(f,(unsigned long)o<<9,m-3);
			break;
		case 4:
		case 5:
			lseek(f,(long)o<<9,m-3);
			break;
		default:
			return(-1);
		}
	return(0);
	}
		
			