int sys_x();

int getcsw()
	{

	return sys_x(38,0,0,0,0);

	}
