int sys_x();

int fstat(f,s)
	{
	sys_x(28,f,s,0,0);

	if (_BX)
		return -1;
	else
		return 0;
	}
