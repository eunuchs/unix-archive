int sys_x();

int wait(s)
int *s;
	{
	register rev;

	rev=sys_x(7,0,0,0,0);

	if (_BX)
		return -1;
	else
		{
		*s=_DX;
		return rev;
		}
	}
