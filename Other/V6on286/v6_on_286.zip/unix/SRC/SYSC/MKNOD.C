int sys_x();

int mknod(n,m,a)
	{
	sys_x(14,n,m,a,0);

	if (_BX)
		return -1;
	else
		return 0;
	}
