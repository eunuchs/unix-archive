int sys_x();
extern unsigned end;
static unsigned  _sbrk_end=&end;

int brk(n)
	{
	register rev;

	rev=sys_x(17,n,0,0,0);

	if (_BX)
		return -1;
	else
		{
		_sbrk_end=n;
		return rev;
		}
	}

int sbrk(n)
register int n;
	{
	_sbrk_end+=n;
	return(brk(_sbrk_end));
	}