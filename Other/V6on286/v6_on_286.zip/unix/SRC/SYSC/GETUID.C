int sys_x();

long getuid()
	{

	return sys_x(24,0,0,0,0);

	}
