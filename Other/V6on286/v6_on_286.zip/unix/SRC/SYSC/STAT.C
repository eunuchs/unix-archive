int sys_x();

int stat(n,s)
	{
	sys_x(18,n,s,0,0);

	if (_BX)
		return -1;
	else
		return 0;
	}
