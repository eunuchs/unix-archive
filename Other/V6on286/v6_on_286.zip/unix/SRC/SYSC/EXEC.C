int sys_x();

int execv(n,p)
	{
	sys_x(11,n,p,0,0);
	return -1;
	}
int execl (n,p)
	{
	sys_x(11,n,&p,0,0);
	return -1;
	}
int exec(n,p)
char *n,*p;
	{
	sys_x(11,n,p,0,0);
	return -1;
	}
