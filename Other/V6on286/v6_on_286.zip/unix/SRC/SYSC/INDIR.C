int indir(pt)
	{

	return(sys_x(0,pt,0,0,0));

	}
