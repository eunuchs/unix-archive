int sys_x();

int signal(n,h)
	{
	register rev;

	rev=sys_x(48,n,h,0,0);

	if (_BX)
		return -1;
	else
		return rev;
	}
