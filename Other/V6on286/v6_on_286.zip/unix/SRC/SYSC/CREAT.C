int sys_x();

int creat(na,m)
	{
	register rev;

	rev=sys_x(8,na,m,0,0);

	if (_BX)
		return -1;
	else
		return rev;
	}
