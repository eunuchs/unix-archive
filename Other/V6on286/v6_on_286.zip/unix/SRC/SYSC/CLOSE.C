int sys_x();

int close(fp)
int fp;
	{
	sys_x(6,fp,0,0,0);

	if (_BX)
		return -1;
	else
		return 0;
	}
