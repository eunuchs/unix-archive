int sys_x();

sync()
	{

	sys_x(36,0,0,0,0);

	}
