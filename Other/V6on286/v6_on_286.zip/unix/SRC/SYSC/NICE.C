int sys_x();

int gtty(n,v)
	{
	sys_x(32,n,v,0,0);

	if (_BX)
		return -1;
	else
		return 0;
	}
