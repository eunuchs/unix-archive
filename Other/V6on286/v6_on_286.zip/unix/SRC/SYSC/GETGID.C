int sys_x();

long getgid()
	{

	return sys_x(47,0,0,0,0);

	}
