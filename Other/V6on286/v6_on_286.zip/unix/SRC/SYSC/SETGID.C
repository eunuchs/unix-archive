int sys_x();

int setgid(g)
	{
	sys_x(46,g,0,0,0);

	if (_BX)
		return -1;
	else
		return 0;
	}
