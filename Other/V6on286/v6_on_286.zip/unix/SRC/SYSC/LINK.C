int sys_x();

int link(n1,n2)
	{
	sys_x(9,n1,n2,0,0);

	if (_BX)
		return -1;
	else
		return 0;
	}
