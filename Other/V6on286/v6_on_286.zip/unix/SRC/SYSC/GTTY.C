int sys_x();

int nice(n)
	{
	sys_x(34,n,0,0,0);

	if (_BX)
		return -1;
	else
		return 0;
	}
