int sys_x();

int smdate(f,d)
long d;
	{
	sys_x(30,f,d,0);

	if (_BX)
		return -1;
	else
		return 0;
	}
