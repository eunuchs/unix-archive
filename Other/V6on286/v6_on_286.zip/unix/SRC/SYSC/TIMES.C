int sys_x();

int times(p,t)
	{
	sys_x(43,p,t,0,0);

	if (_BX)
		return -1;
	else
		return 0;
	}
