int sys_x();

int chdir(n)
	{
	sys_x(12,n,0,0,0);

	if (_BX)
		return -1;
	else
		return 0;
	}
