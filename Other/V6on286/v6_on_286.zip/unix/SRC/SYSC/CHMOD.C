int sys_x();

int chmod(n,m)
	{
	sys_x(15,n,m,0,0);

	if (_BX)
		return -1;
	else
		return 0;
	}
