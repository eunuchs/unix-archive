int sys_x();

int pipe(p)
	{
	sys_x(42,p,0,0,0);

	if (_BX)
		return -1;
	else
		return 0;
	}
