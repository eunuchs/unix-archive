int sys_x();

int umount(d)
	{
	sys_x(22,d,0,0,0);

	if (_BX)
		return -1;
	else
		return 0;
	}
