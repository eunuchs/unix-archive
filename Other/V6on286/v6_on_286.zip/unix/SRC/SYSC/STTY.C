int sys_x();

int stty(t,p)
	{
	sys_x(31,t,p,0,0);

	if (_BX)
		return -1;
	else
		return 0;
	}
