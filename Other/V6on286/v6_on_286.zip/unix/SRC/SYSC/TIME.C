long sys_x();

time(tb)
long *tb;
	{

	return (*tb=sys_x(13,0,0,0,0));

	}
