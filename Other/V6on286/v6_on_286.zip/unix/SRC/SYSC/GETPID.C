int sys_x();

int getpid()
	{

	return sys_x(20,0,0,0,0);

	}
