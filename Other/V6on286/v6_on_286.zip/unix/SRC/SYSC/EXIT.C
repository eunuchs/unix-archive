int sys_x();
	    
int exit(rv)
int rv;
	{                             
	sys_x(1,rv,0,0,0);

	if (_BX)
		return(-1);
	else
		return (0);
	}