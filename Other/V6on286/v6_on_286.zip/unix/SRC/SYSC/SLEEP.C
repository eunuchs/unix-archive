int sys_x();

sleep(n)
	{

	sys_x(35,n,0,0,0);

	}
