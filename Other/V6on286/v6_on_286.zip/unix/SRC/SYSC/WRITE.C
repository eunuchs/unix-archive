int sys_x();

int write(fp,buf,n)                      
int fp,*buf,n;
	{
	register rev;
				   
	rev=sys_x(4,fp,buf,n,0);

	if (_BX)
		return -1;
	else
		return rev;
	}
