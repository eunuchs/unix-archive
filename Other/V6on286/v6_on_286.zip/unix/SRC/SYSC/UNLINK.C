int sys_x();

int unlink(n1)
	{
	sys_x(10,n1,0,0,0);

	if (_BX)
		return -1;
	else
		return 0;
	}
