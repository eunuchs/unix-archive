#include <stdio.h>
#include <string.h>

#define	DONTKILL	0
#define KILL		1

FILE *infil,*outfil;

char inbuf[255],outbuf[255];

struct wasis
	{
	char is[15];
	char tobe[15];
	}
	chng[]=
	{
	{"_TEXT","K_CODE"},
   /*	{"group",NULL},*/
	{"_DATA","K_DATA"},
   /*	{"assume",NULL},*/
	{"_BSS","K_DATA"},
	{"'CODE'","'K_CODE'"},
	{"'BSS'","'K_DATA'"},
	{"'DATA'","'K_DATA'"}
	};


main(argc,argv)
int argc;
char *argv[3];
	{
	init ((argc>1)?argv[1]:NULL,(argc>2)?argv[2]:NULL);
	process();
	exit(0);
	}

init(nev1,nev2)
char *nev1,*nev2;
	{
	 if (nev1==NULL)
		{
		infil=stdin;
		outfil=stdout;
		return;
		}
	 if ((infil=fopen(nev1,"r"))==NULL)
		{
		shut("No infile");
		}
	 if (nev2==NULL)
		{
		outfil=stdout;
		return;
		}
	 if((outfil=fopen(nev2,"w"))==NULL)
		{
		shut("No outfile");
		}
	 }
shut(msg)
char *msg;
	{
	fprintf(stderr,"Fatal error encountered: %s\n",msg);
	exit (-1);
	}
process()
	{
	int i,killflag;
	char *w,*t,*fnd;
	while (fgets(inbuf,255,infil))
		{
		killflag=DONTKILL;
		for (i=0;i<(sizeof(chng)/sizeof(struct wasis));i++)
			{
			w=inbuf;t=outbuf;*t=NULL;
			while ( fnd=strstr(w,chng[i].is))
				{
				if(chng[i].tobe[0]==NULL)
					{
					killflag=KILL;
					}
				strncpy(t,w,(int)(fnd-w));
				t+=(int)(fnd-w);
				w=fnd+strlen(chng[i].is);
				strncpy(t,chng[i].tobe,strlen(chng[i].tobe));
				t+=strlen(chng[i].tobe);
				*t=NULL;
				}
			strcat (t,w);
			strcpy (inbuf,outbuf);
			}
		if(killflag==DONTKILL) fputs(outbuf,outfil);
			else
			{*t=*w=NULL;}
		}
	}


						