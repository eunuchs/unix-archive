/* 	c.c
 *
 *	Karakter es blokkos eszkozok eleresi tablaja
 */

/*
 * nulldev : ures bejegyzes
 * nodev   : ervenytelen bejegyzes = ENXIO hiba
 */

#include "h\types.h"
#include "h\param.h"

#ifdef ROOTDEV
dev_t rootdev=ROOTDEV;
#else
dev_t rootdev=512;//makedev(2,0);
#endif

#ifdef SWAPDEV
dev_t swapdev=SWAPDEV
#else
dev_t swapdev=513;//makedev(2,1);
#endif

nulldev();nodev();

coopen();coclose();cosgtty();coread();cowrite();
syopen();syclose();sysgtty();syread();sywrite();
asopen();asclose();assgtty();asread();aswrite();
		   hdsgtty();hdread();hdwrite();
lpopen();lpclose();lpsgtty();	      lpwrite();
			     mmread();mmwrite();
spopen();spclose();		     ;spwrite();


hdopen();hdclose();hdstrategy(); extern struct devtab hdtab;
fdopen();fdclose();fdstrategy(); extern struct devtab fdtab;

/*                          
 *	Block devices
 */
int (*bdevsw[])()=
	{
/*	xxopen,	xxclose,	xxstrategy,	xxtab		*/

	hdopen,	hdclose,	hdstrategy,	(int)&hdtab, 	/* 0 hd0*/
	nodev , nodev  ,        nodev     ,     0          ,    /* 1 hd1*/
	fdopen,	fdclose,	fdstrategy,	(int)&fdtab, 	/* 2 fd */
	0
	};

/*
 *	Character devices
 */
int (*cdevsw[])()=

/*	xxopen,  xxclose, xxread ,  xxwrite, xxsgtty			*/

	{
	coopen,  coclose, coread ,  cowrite, cosgtty, 		/* 0 co */
	syopen,  syclose, syread ,  sywrite, sysgtty,		/* 1 sy */
	asopen,  asclose, asread ,  aswrite, assgtty,		/* 2 tty*/
	nodev ,  nodev  , nodev  ,  nodev  , nodev  ,		/* 3 tty*/
	lpopen,	 lpclose, nodev  ,  lpwrite, lpsgtty,		/* 4 lp */
	nulldev, nulldev, mmread ,  mmwrite, nodev  ,		/* 5 mem*/
	spopen,  spclose, nodev  ,  spwrite, nodev  ,		/* 6 spk*/
	nodev ,  nodev  , nodev  ,  nodev  , nodev  ,		/* 7    */
	hdopen,  hdclose, hdread ,  hdwrite, hdsgtty,		/* 8 rhd*/
	0
	};

