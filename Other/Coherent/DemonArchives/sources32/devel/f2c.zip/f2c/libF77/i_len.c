#include "f2c.h"

integer i_len(s, n)
char *s;
long int n;
{
return(n);
}
