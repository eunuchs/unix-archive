#include "f2c.h"

double d_imag(z)
doublecomplex *z;
{
return(z->i);
}
