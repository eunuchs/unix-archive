/* imports from msgs.c */
extern void fulldisk();
