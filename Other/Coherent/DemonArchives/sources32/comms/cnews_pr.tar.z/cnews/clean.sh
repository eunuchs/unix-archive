for mydir in `lc -1d`
do
  cd $mydir
  make clean
  cd ..
done
