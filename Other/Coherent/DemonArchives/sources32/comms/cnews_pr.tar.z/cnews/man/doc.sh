them=`ls *.[0-9]`

for myfile in $them
do
        outfile=`expr $myfile : "\(.*\)\.[0-9]"`.doc
	nroff -man -x $myfile > $outfile
done
