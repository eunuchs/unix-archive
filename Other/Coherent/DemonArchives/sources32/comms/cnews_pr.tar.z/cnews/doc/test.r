.de MM
.vs +24
.ce 999
A Heading
\&\\$1
.ce 0
.vs -24
..
.MM "A test string" 

This is more text.
