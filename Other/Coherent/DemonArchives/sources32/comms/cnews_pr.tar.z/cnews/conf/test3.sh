echo 'echo "/FASTSTRCHR.*qqq/s/\\\\\\/\\\\\\*//"'
echo 'echo "/SMALLMEM.*qqq/s/\\\\\\/\\\\\\*//"'
echo 'echo "/FASTSTRCHR.*qqq/s/^/\\\\\\/* /"'
echo 'echo "/SMALLMEM.*qqq/s/^/\\\\\\/* /"'
