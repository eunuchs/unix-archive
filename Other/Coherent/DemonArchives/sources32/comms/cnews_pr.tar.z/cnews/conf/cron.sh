cat >cron <<'!'
0,15,30,45 *    1-31 *  0-6     su news -c '/usr/lib/newsbin/input/newsrun'
30 8    1-31 *  1-5     su news -c '/usr/lib/newsbin/input/newsrunning off'
00 17   1-31 *  1-5     su news -c '/usr/lib/newsbin/input/newsrunning on'
40 *    1-31 *  0-6     su news -c '/usr/lib/newsbin/batch/sendbatches'
59 0    1-31 *  0-6     su news -c '/usr/lib/newsbin/expire/doexpire '
10 8    1-31 *  0-6     su news -c '/usr/lib/newsbin/maint/newsdaily'
00 5,13,21      1-31 *  0-6     su news -c '/usr/lib/newsbin/maint/newswatch | mail shendi'
!
