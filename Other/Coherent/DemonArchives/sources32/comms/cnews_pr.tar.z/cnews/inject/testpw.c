#include <stdio.h>
#include <pwd.h>

int main()
{
  struct passwd pwd;
  struct passwd *ppwd;
  
  ppwd = &pwd;
  while(ppwd = getpwent())
  {
     printf("Username: %s \n", ppwd -> pw_name);
     printf("Password: %s \n", ppwd -> pw_passwd);
     printf("User Id: %d \n", ppwd -> pw_uid);
     printf("Group Id: %d \n", ppwd -> pw_gid);
     printf("Gecos entry: %s \n", ppwd -> pw_gecos);
     printf("Comment filed entry: %s \n", ppwd -> pw_comment);
     printf("Home directory: %s \n", ppwd -> pw_dir);
     printf("Login shell: %s \n\n\n", ppwd -> pw_shell);
  }

exit(0);
}
