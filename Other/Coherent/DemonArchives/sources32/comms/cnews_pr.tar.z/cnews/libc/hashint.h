/*
 * general-purpose in-core hashing, normal interface (internals)
 */
