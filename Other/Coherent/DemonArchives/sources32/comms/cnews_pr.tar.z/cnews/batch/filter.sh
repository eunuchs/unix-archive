echo '#! rnews' "`wc -c $1 | awk '{print $1}'`"
