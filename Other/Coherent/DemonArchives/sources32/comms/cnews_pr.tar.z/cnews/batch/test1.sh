while read name rest
do
  echo $name $rest
done
