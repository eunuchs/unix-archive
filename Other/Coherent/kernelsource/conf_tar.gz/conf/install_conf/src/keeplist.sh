echo '-R *'
echo '-I stext:sdata:*[!_]dev:drvl:*con:boot_gift:asy*:atparm:ASY*:t_*'
echo '-I ndpType:ndpDump'
echo '-I SHMMNI:SEMMNI:NMSQID'

