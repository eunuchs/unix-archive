/*
 * Define these for i386/mmu.c
 */

int	RAM0 = 0;
int	RAMSIZE = 0;

