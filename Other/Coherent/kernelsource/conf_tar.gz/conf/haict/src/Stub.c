#define	_KERNEL		1

#include <stddef.h>
#include <sys/haiscsi.h>

dca_p	ctdca = NULL;

/* End of file */
