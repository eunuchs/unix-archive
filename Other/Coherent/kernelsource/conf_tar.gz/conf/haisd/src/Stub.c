#define _KERNEL		1

#include <stddef.h>
#include <sys/haiscsi.h>

dca_p	sddca = NULL;

/* End of file */
