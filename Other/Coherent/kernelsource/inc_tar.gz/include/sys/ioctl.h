/* (-lgl
 *	Coherent 386 release 4.2
 *	Copyright (c) 1982, 1993 by Mark Williams Company.
 *	All rights reserved. May not be copied without permission.
 *	For copying permission and licensing info, write licensing@mwc.com
 -lgl) */

#ifndef	__SYS_IOCTL_H__
#define	__SYS_IOCTL_H__

/*
 * This header is not defined by iBCS2, the System V ABI, POSIX.1, or POSIX.2,
 * but many applications include it.  This stub permits such programs to
 * compile; the real ioctl information is in the respective driver's header.
 */

#endif	/* ! defined (__SYS_IOCTL_H__) */

