#ifndef	__COH_MD_H__
#define	__COH_MD_H__

#include <common/ccompat.h>

/* Externals from md.c */

int		clrivec	__PROTO ((int level));
int		setivec	__PROTO ((unsigned int level, int (*fun)()));

#endif	/* ! defined (__COH_MD_H__) */
