#ifndef	__COH_PUTCHAR_H__
#define	__COH_PUTCHAR_H__

#include <common/ccompat.h>

/* prototypes from putchar.c */

void		putchar	__PROTO ((char c));

#endif	/* ! defined (__COH_PUTCHAR_H__) */
