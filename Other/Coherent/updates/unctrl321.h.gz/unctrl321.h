#ifndef	unctrl
#define	unctrl(c)	_unctrl[(c) & 0177]

extern char *_unctrl[];
#endif
