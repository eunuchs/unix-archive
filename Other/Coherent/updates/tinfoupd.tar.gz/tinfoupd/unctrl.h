# include	<stdio.h>
# define	unctrl(ch)	(_unctrl[ch])

extern char	*_unctrl[];
