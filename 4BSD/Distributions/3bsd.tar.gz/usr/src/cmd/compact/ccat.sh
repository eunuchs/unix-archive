#
foreach file ($argv)
/usr/ucb/uncompact < $file
end
