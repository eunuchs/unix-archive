main()
{
register int i;
printf("%d\n", i);
}
