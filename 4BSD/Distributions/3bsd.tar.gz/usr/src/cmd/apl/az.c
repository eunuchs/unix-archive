/*
 * This is a dummy plotting function module
 */

sclr() {
	error("Unimplemented function 'sclr'");
}

move() {
	error("Unimplemented function 'move'");
}

line() {
	error("Unimplemented function 'line'");
}
