typedef int jmp_buf[10];
