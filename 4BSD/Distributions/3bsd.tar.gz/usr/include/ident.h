char myname[] = "VAX/UNIX (Ernie Co-vax)";
