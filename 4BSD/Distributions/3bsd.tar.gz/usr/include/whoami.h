#define VAX
#define CSVAX
#define	ERNIE
#define	sysname	"ucbvax"
