#define	VALSIZ	1024
