/*	seg.h	2.1	1/5/80 */

/*
 * Mapper addresses and bits
 */

#define	RO	PG_URKR		/* access abilities */
#define	RW	PG_UW
