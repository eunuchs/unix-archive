#
#	cmap.m	2.1	1/5/80
#
	.set	CMSIZE,8
	.globl	_cmap
	.globl	_ecmap
	.data
_cmap:	.long	0
_ecmap:	.long	0
	.text
