#
#	clock.m	2.1	1/5/80
#
#
# VAX clock registers
#

	.set	ICCS_RUN,0x1
	.set	ICCS_TRANS,0x10
	.set	ICCS_SS,0x20
	.set	ICCS_IE,0x40
	.set	ICCS_INT,0x80
	.set	ICCS_ERR,0x80000000
