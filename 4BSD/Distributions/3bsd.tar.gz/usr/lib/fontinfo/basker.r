.fp \np br
.lg 0
