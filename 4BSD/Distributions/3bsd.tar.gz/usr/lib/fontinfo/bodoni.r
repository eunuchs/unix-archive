.lg 0
.fp \np or
