char version[] = "Version 4.162 Tue Nov 1 10:50:37 PST 1988";
