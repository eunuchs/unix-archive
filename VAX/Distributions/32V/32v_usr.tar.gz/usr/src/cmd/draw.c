/*
see agf for this source
*/
