yywrap()
{
	return(1);
}
