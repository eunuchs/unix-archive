extern int accessnum;		/* number of nodes accessible from START */
extern VERT *after;		/* node numbers associated with after numbers of depth first search */
extern int *ntobef;		/* before numbers associated with nodes */
extern int *ntoaft;		/* after numbers associated with nodes */
