#include <sys/param.h>
char		u[ctob(4)]; /* struct user u */
