/*
 * Mapper addresses and bits
 */

#define	RO	PG_URKR		/* access abilities */
#define	RW	PG_UW
