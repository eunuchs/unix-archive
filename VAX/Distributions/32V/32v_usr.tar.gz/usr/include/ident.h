char myname[] = "research VAX-11/780";
