#define	RTHDRSIZ	060
#define	RTPC	040/2
#define	RTSP	042/2
#define	RTHGH	046/2
