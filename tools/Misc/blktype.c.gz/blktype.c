/* blktype
 *
 * Print the number of non-text characters
 * from a file ona per 512-byte block basis.
 */

#include <sys/types.h>
#include <stdio.h>
#define BLKSIZ 512

int isbin[128];

usage() { printf("blktype [filename]\n"); exit(1); }

main(argc,argv)
 int argc;
 char *argv[];
 {
  char buf[BLKSIZ];
  FILE *zin;
  int blk=0, binbytes, i;

  if (argc!=1 && argc!=2) usage();

  for (i=0;i<9;i++) isbin[i]=1;
  isbin[9]=isbin[10]=0;
  for (i=11;i<32;i++) isbin[i]=1;
  for (i=32;i<128;i++) isbin[i]=0;
  
  if (argc==1) zin= stdin;
  else {
  	zin= fopen(argv[1], "r");
  	if (zin==NULL) { perror("Opening input file"); exit(1); }
  }
  
  for(blk=0;;blk++) {
	if ((fread(buf, BLKSIZ, 1, zin))!=1) break;

	for (binbytes=0,i=0;i<BLKSIZ;i++) 
	    if (buf[i]<0 || isbin[buf[i]]) binbytes++;

	printf("Off %d Blk %d\t\tbin %d\n", blk * BLKSIZ, blk, binbytes);
  }
 }

